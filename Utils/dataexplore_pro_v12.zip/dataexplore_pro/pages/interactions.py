"""
Interactions de Features v12
================================================================================
LECTURE CACHE en priorite — O(1) lookup depuis le precalcul.
Fallback live si la paire n'est pas en cache (paire hors top-K).

Architecture:
  - update() lit dep.cache.get("interactions") -> dict precalcule
  - Si la paire (fa, fb, nb) est dans pairs_2d -> reconstruction O(n_cells)
  - Si feat_c est demande -> lookup pairs_3d ou slice 2D marginalise
  - Fallback live via _live_cell_stats() si absent du cache
  - Badge de statut : "CACHE" ou "CALCUL LIVE"

Affichage:
  - Heatmap A x B avec delta moyen et contours sig.
  - UpSet plot : effectifs par combinaison, membership dots
  - Slices Feature C (si selectionnee)
  - Table de regles classees par |Cohen's d|
  - Regression OLS avec interactions (statsmodels ou fallback numpy)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import product as iproduct
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"
CS_DIV = [[0,"#b2182b"],[0.25,"#f4a582"],[0.5,"#f7f7f7"],[0.75,"#92c5de"],[1,"#2166ac"]]


def layout(dep):
    num = dep.num_features
    if not dep.supervised:
        return html.Div([
            html.Div("Interactions de Features", className="page-title"),
            html.Div("Cette analyse requiert un dataset supervise (avec target).",
                     className="page-subtitle"),
        ], className="page-card")

    tgt = dep.target_name

    return html.Div([
        html.Div("Interactions de Features", className="page-title"),
        html.Div(
            f"Interactions 2-3 features binnees vs target '{tgt}'. "
            "Resultats precalcules au demarrage — acces instantane.",
            className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Feature A:", className="control-label"),
                      dcc.Dropdown(id="int-feat-a",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[0] if len(num)>0 else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Feature B:", className="control-label"),
                      dcc.Dropdown(id="int-feat-b",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[1] if len(num)>1 else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Feature C (optionnelle):", className="control-label"),
                      dcc.Dropdown(id="int-feat-c",
                          options=[{"label":"-- Aucune --","value":""}]
                                  + [{"label":c,"value":c} for c in num],
                          value="", clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Bins:", className="control-label"),
                      dcc.Slider(id="int-bins", min=2, max=6, step=1,
                          value=dep.interaction_n_bins_default,
                          marks={i:str(i) for i in range(2,7)},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"200px"}),

            html.Div([html.Div("Seuil alpha:", className="control-label"),
                      dcc.Dropdown(id="int-alpha",
                          options=[{"label":"0.05","value":"0.05"},
                                   {"label":"0.01","value":"0.01"},
                                   {"label":"0.10","value":"0.10"}],
                          value="0.05", clearable=False, style={"width":"100px"})],
                className="control-group"),
        ], className="controls-row"),

        html.Div(id="int-summary", style={"marginBottom":"16px"}),

        html.Div([
            html.Div([
                html.Div(id="int-heatmap-title", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="int-heatmap",
                    config={"displayModeBar":False}, style={"height":"400px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                html.Div("UpSet Plot -- Effectifs par combinaison",
                         className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="int-upset",
                    config={"displayModeBar":False}, style={"height":"400px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        html.Div(id="int-slice-section", style={"marginBottom":"16px"}),

        html.Div([
            html.Div("Table de Regles -- combinaisons classees par impact",
                     className="chart-card-title"),
            html.Div(id="int-rules-table"),
        ], className="chart-card", style={"marginBottom":"16px"}),

        html.Div([
            html.Div("Regression OLS avec termes d'interaction",
                     className="chart-card-title"),
            html.Div(id="int-regression"),
        ], className="chart-card"),

    ], className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        [Output("int-summary","children"),
         Output("int-heatmap","figure"),
         Output("int-heatmap-title","children"),
         Output("int-upset","figure"),
         Output("int-slice-section","children"),
         Output("int-rules-table","children"),
         Output("int-regression","children")],
        [Input("int-feat-a","value"),
         Input("int-feat-b","value"),
         Input("int-feat-c","value"),
         Input("int-bins","value"),
         Input("int-alpha","value")],
    )
    def update(feat_a, feat_b, feat_c, n_bins, alpha_str):
        alpha  = float(alpha_str or "0.05")
        n_bins = int(n_bins or dep.interaction_n_bins_default)
        feat_c = feat_c or ""
        tgt    = dep.target_name
        empty  = go.Figure()

        if not feat_a or not feat_b or feat_a == feat_b:
            return (_err("Selectionnez 2 features differentes."),
                    empty, "", empty, html.Div(), html.Div(), html.Div())

        if feat_a not in dep.num_features or feat_b not in dep.num_features:
            return (_err("Features invalides."),
                    empty, "", empty, html.Div(), html.Div(), html.Div())

        # ── Try cache first (O(1)) ────────────────────────────────────────
        inter_cache = dep.cache.get("interactions", wait=False)
        cache_ready = inter_cache is not None
        from_cache  = False
        cell_data   = None
        cell_data_3d = None
        meta        = None
        lbls_a = lbls_b = lbls_c = []

        if cache_ready:
            meta    = inter_cache["meta"]
            pairs2d = inter_cache["pairs_2d"]
            pairs3d = inter_cache["pairs_3d"]

            # Canonical key: always (smaller, larger) by feat list order
            feats_order = meta["feats"]
            key_ab = _canonical_key(feat_a, feat_b, feats_order)
            cache_key_2d = (*key_ab, n_bins)

            if cache_key_2d in pairs2d:
                cell_data  = pairs2d[cache_key_2d]
                from_cache = True
                lbls_a = meta["bin_labels"].get((key_ab[0], n_bins), [])
                lbls_b = meta["bin_labels"].get((key_ab[1], n_bins), [])
                # Swap labels if user selected features in reverse order
                if key_ab[0] != feat_a:
                    lbls_a, lbls_b = lbls_b, lbls_a

            if feat_c and feat_c in dep.num_features:
                key_abc = _canonical_key_3(feat_a, feat_b, feat_c, feats_order)
                cache_key_3d = (*key_abc, n_bins)
                if cache_key_3d in pairs3d:
                    cell_data_3d = pairs3d[cache_key_3d]
                    lbls_c = meta["bin_labels"].get((key_abc[2], n_bins), [])
                    if key_abc[2] != feat_c:
                        pass  # C is always 3rd in 3D key

        # ── Fallback: live compute ────────────────────────────────────────
        if cell_data is None:
            cell_data, lbls_a, lbls_b = _live_cell_stats(
                dep, feat_a, feat_b, n_bins, tgt)
            from_cache = False
            if cell_data is None:
                return (_err("Donnees insuffisantes pour cette combinaison."),
                        empty, "", empty, html.Div(), html.Div(), html.Div())
            if meta is None:
                y_enc = _encode_y_live(dep.display_df[tgt].values, dep)
                meta  = {"global_mean": float(np.nanmean(y_enc)),
                         "global_std":  float(np.nanstd(y_enc, ddof=1))}

        global_mean = float(cell_data.get("global_mean", meta.get("global_mean",0)))
        global_std  = float(cell_data.get("global_std",  meta.get("global_std",1)))
        min_n       = dep.interaction_min_samples

        # ── Reconstruct rules from flat cell arrays ────────────────────────
        na = cell_data["na"]; nb_ = cell_data["nb"]
        # If key was swapped, swap na/nb and reshape
        swapped = (cache_ready and from_cache and
                   meta.get("feats") and
                   _canonical_key(feat_a, feat_b, meta["feats"])[0] != feat_a)
        counts   = cell_data["counts"]
        means    = cell_data["means"]
        cohens_d = cell_data["cohens_d"]
        p_vals   = cell_data["p_vals"]
        ci95     = cell_data["ci95"]
        valid    = cell_data["valid"]

        if swapped:
            # Reshape (na*nb) -> (na,nb) -> transpose -> flatten
            counts   = counts.reshape(na, nb_).T.flatten()
            means    = means.reshape(na, nb_).T.flatten()
            cohens_d = cohens_d.reshape(na, nb_).T.flatten()
            p_vals   = p_vals.reshape(na, nb_).T.flatten()
            ci95     = ci95.reshape(na, nb_).T.flatten()
            valid    = valid.reshape(na, nb_).T.flatten()
            na, nb_  = nb_, na

        rules = []
        for ia in range(na):
            for ib in range(nb_):
                cid = ia * nb_ + ib
                if not valid[cid]:
                    continue
                lbl_a = lbls_a[ia] if ia < len(lbls_a) else f"B{ia+1}"
                lbl_b = lbls_b[ib] if ib < len(lbls_b) else f"B{ib+1}"
                rules.append(dict(
                    ia=ia, ib=ib, ic=None, feat_c=None,
                    label=(f"{feat_a[:12]} [{lbl_a}] ET "
                           f"{feat_b[:12]} [{lbl_b}]"),
                    cond_parts=[f"{feat_a[:12]} in [{lbl_a}]",
                                f"{feat_b[:12]} in [{lbl_b}]"],
                    n    = int(counts[cid]),
                    mean = float(means[cid]),
                    delta= float(means[cid]) - global_mean,
                    cohens_d = float(cohens_d[cid]),
                    ci95     = float(ci95[cid]) if not np.isnan(ci95[cid]) else 0.0,
                    p        = float(p_vals[cid]),
                    sig      = bool(p_vals[cid] < alpha),
                ))
        rules.sort(key=lambda r: abs(r["cohens_d"]), reverse=True)

        # ── Cache status badge ─────────────────────────────────────────────
        n_inter   = meta.get("inter_n", "?") if cache_ready else len(dep.display_df)
        min_n_tag = dep.interaction_min_samples
        src_badge = _source_badge(from_cache, n_inter, min_n_tag)

        # ── Summary cards ─────────────────────────────────────────────────
        n_sig  = sum(1 for r in rules if r["sig"])
        n_tot  = len(rules)
        best_d = max(rules, key=lambda r:abs(r["cohens_d"]), default=None)
        best_m = max(rules, key=lambda r:r["mean"], default=None)
        worst  = min(rules, key=lambda r:r["mean"], default=None)
        summary = html.Div([
            src_badge,
            _summary_cards(n_tot, n_sig, alpha, best_d, best_m, worst,
                           global_mean, tgt),
        ])

        # ── Heatmap A x B ─────────────────────────────────────────────────
        mat_mean = np.full((na, nb_), np.nan)
        mat_sig  = np.zeros((na, nb_), dtype=bool)
        mat_n    = np.zeros((na, nb_))
        for r in rules:
            mat_mean[r["ia"], r["ib"]] = r["mean"] - global_mean
            mat_sig[r["ia"], r["ib"]]  = r["sig"]
            mat_n[r["ia"], r["ib"]]    = r["n"]

        txt_heat = []
        for ia in range(na):
            row = []
            for ib in range(nb_):
                v = mat_mean[ia, ib]
                if np.isnan(v):
                    row.append("--")
                else:
                    sign = "u" if v > 0 else "d"
                    star = "*" if mat_sig[ia, ib] else ""
                    row.append(f"D{'+' if v>=0 else ''}{v:.2g}{star}<br>n={int(mat_n[ia,ib])}")
            txt_heat.append(row)

        abs_max = float(np.nanmax(np.abs(mat_mean))) or 1.0
        fig_heat = go.Figure(go.Heatmap(
            z=mat_mean,
            x=[f"B:{l}" for l in (lbls_b[:nb_] if lbls_b else [f"B{i+1}" for i in range(nb_)])],
            y=[f"A:{l}" for l in (lbls_a[:na]  if lbls_a else [f"A{i+1}" for i in range(na)])],
            colorscale=CS_DIV, zmid=0, zmin=-abs_max, zmax=abs_max,
            text=txt_heat, texttemplate="%{text}",
            textfont=dict(size=9, family=FONT),
            showscale=True,
            colorbar=dict(title=dict(text=f"D mu({tgt[:10]})",
                                      font=dict(size=10, family=FONT)),
                          thickness=14, tickfont=dict(size=9)),
            hovertemplate="<b>%{y} x %{x}</b><br>%{text}<extra></extra>",
        ))
        for ia in range(na):
            for ib in range(nb_):
                if mat_sig[ia, ib]:
                    fig_heat.add_shape(type="rect",
                        x0=ib-0.48, x1=ib+0.48, y0=ia-0.48, y1=ia+0.48,
                        line=dict(color="#1e3a5f", width=2.5),
                        fillcolor="rgba(0,0,0,0)", layer="above")
        fig_heat.update_layout(plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=90,r=90,t=20,b=80), font=dict(family=FONT,size=10),
            xaxis=dict(tickangle=-30, tickfont=dict(size=10, color="#1e3a5f")),
            yaxis=dict(tickfont=dict(size=10, color="#1e3a5f")))
        hmap_title = (f"Heatmap mu({tgt[:18]}) -- {feat_a[:16]} x {feat_b[:16]} "
                      f"(contour = sig. alpha={alpha}, min_n={min_n})")

        # ── UpSet plot ────────────────────────────────────────────────────
        feats_list = [feat_a, feat_b]
        if feat_c and feat_c in dep.num_features:
            feats_list.append(feat_c)
        fig_upset = _upset_plot(rules, feats_list, global_mean, tgt, alpha)

        # ── Feature C slices ──────────────────────────────────────────────
        slice_section = html.Div()
        if feat_c and feat_c in dep.num_features:
            if cell_data_3d is not None:
                slice_section = _slice_from_3d(
                    cell_data_3d, feat_a, feat_b, feat_c,
                    lbls_a, lbls_b, lbls_c, tgt, alpha, global_mean)
            else:
                # Marginalise from 2D live compute per slice
                slice_section = _live_slices(
                    dep, feat_a, feat_b, feat_c, n_bins, tgt,
                    alpha, global_mean, min_n, lbls_a, lbls_b)

        # ── Rules table ───────────────────────────────────────────────────
        rules_table = _rules_table(rules, tgt, global_mean, alpha)

        # ── OLS regression ────────────────────────────────────────────────
        feats_for_ols = [feat_a, feat_b]
        if feat_c and feat_c in dep.num_features:
            feats_for_ols.append(feat_c)
        reg_section = _ols_regression(dep, tgt, feats_for_ols, n_bins, rules)

        return (summary, fig_heat, hmap_title, fig_upset,
                slice_section, rules_table, reg_section)


# ===========================================================================
#  LIVE COMPUTE (fallback quand la paire n'est pas en cache)
# ===========================================================================

def _live_cell_stats(dep, feat_a, feat_b, n_bins, tgt):
    """Compute on-the-fly on display_df (50k). Much faster than full dataset."""
    from dataexplore_pro._precompute import (
        _quantile_bins, _filter_rare_bins_fast, _cell_stats_2d, _encode_y)
    df      = dep.display_df
    min_n   = dep.interaction_min_samples
    y_raw   = df[tgt].values
    y_enc   = _encode_y(y_raw, dep)

    for feat in [feat_a, feat_b]:
        if feat not in df.columns:
            return None, [], []

    vals_a = df[feat_a].values.astype(np.float64)
    vals_b = df[feat_b].values.astype(np.float64)

    ba, lbls_a, _ = _quantile_bins(vals_a, ~np.isnan(vals_a), n_bins)
    bb, lbls_b, _ = _quantile_bins(vals_b, ~np.isnan(vals_b), n_bins)
    ba = _filter_rare_bins_fast(ba, min_n)
    bb = _filter_rare_bins_fast(bb, min_n)

    na = int(ba.max()) + 1 if ba.max() >= 0 else 0
    nb = int(bb.max()) + 1 if bb.max() >= 0 else 0
    if na < 2 or nb < 2:
        return None, [], []

    g_mean = float(np.nanmean(y_enc))
    g_std  = float(np.nanstd(y_enc, ddof=1))

    res = _cell_stats_2d(y_enc, ba, bb, na, nb, min_n, g_mean, g_std)
    return res, lbls_a[:na], lbls_b[:nb]


def _encode_y_live(y_raw, dep):
    if dep.is_classification:
        from sklearn.preprocessing import LabelEncoder
        return LabelEncoder().fit_transform(y_raw.astype(str)).astype(np.float64)
    return y_raw.astype(np.float64)


# ===========================================================================
#  KEY HELPERS
# ===========================================================================

def _canonical_key(fa, fb, feats_order):
    """Return (fa,fb) in the order they appear in feats_order."""
    if not feats_order:
        return (fa, fb)
    try:
        ia = feats_order.index(fa)
        ib = feats_order.index(fb)
        return (fa, fb) if ia < ib else (fb, fa)
    except ValueError:
        return (fa, fb)


def _canonical_key_3(fa, fb, fc, feats_order):
    """Return (fa,fb,fc) in feats_order order."""
    if not feats_order:
        return (fa, fb, fc)
    def _idx(f):
        try: return feats_order.index(f)
        except ValueError: return 9999
    ordered = sorted([(fa,_idx(fa)), (fb,_idx(fb)), (fc,_idx(fc))],
                     key=lambda x: x[1])
    return tuple(f for f,_ in ordered)


# ===========================================================================
#  SLICE FROM 3D CACHE
# ===========================================================================

def _slice_from_3d(cell_data_3d, feat_a, feat_b, feat_c,
                    lbls_a, lbls_b, lbls_c, tgt, alpha, global_mean):
    na   = cell_data_3d["na"]
    nb_  = cell_data_3d["nb"]
    nc_  = cell_data_3d["nc"]
    lbls_c_use = lbls_c[:nc_] if lbls_c else [f"C{i+1}" for i in range(nc_)]

    means_3d = cell_data_3d["means"].reshape(na, nb_, nc_)
    sig_3d   = (cell_data_3d["p_vals"] < alpha).reshape(na, nb_, nc_)
    valid_3d = cell_data_3d["valid"].reshape(na, nb_, nc_)

    figs = []
    for ic in range(nc_):
        mat = np.where(valid_3d[:, :, ic],
                       means_3d[:, :, ic] - global_mean, np.nan)
        abs_m = float(np.nanmax(np.abs(mat))) if not np.all(np.isnan(mat)) else 1.0
        txt = [["--" if np.isnan(mat[ia,ib]) else
                f"D{mat[ia,ib]:+.2g}{'*' if sig_3d[ia,ib,ic] else ''}"
                for ib in range(nb_)] for ia in range(na)]
        fig = go.Figure(go.Heatmap(
            z=mat,
            x=[f"B:{l}" for l in (lbls_b[:nb_] if lbls_b else [f"B{i+1}" for i in range(nb_)])],
            y=[f"A:{l}" for l in (lbls_a[:na]  if lbls_a else [f"A{i+1}" for i in range(na)])],
            colorscale=CS_DIV, zmid=0, zmin=-abs_m, zmax=abs_m,
            text=txt, texttemplate="%{text}", textfont=dict(size=9),
            showscale=True, colorbar=dict(thickness=10,tickfont=dict(size=8)),
            hovertemplate="<b>%{y} x %{x}</b><br>Delta=%{z:.3g}<extra></extra>"))
        fig.update_layout(height=240, plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=70,r=70,t=8,b=50), font=dict(family=FONT,size=9),
            xaxis=dict(tickangle=-30), yaxis=dict())
        lbl_c = lbls_c_use[ic] if ic < len(lbls_c_use) else f"C{ic+1}"
        figs.append(html.Div([
            html.Div(f"Slice {feat_c[:16]} in [{lbl_c}] (CACHE 3D)",
                style={"fontWeight":"700","fontSize":"11px","color":"#1e3a5f",
                       "marginBottom":"4px","fontFamily":FONT}),
            dcc.Graph(figure=fig, config={"displayModeBar":False},
                      style={"height":"240px"}),
        ], className="chart-card", style={"flex":"1","minWidth":"240px"}))

    return html.Div([
        html.Div(f"Heatmaps par slice de {feat_c}", className="chart-card-title"),
        html.Div(figs, style={"display":"flex","gap":"12px","flexWrap":"wrap"}),
    ], className="chart-card")


def _live_slices(dep, feat_a, feat_b, feat_c, n_bins, tgt,
                  alpha, global_mean, min_n, lbls_a, lbls_b):
    """Live-compute slices of feat_c from display_df."""
    from dataexplore_pro._precompute import (_quantile_bins,
        _filter_rare_bins_fast, _cell_stats_2d, _encode_y)
    df    = dep.display_df
    y_enc = _encode_y(df[tgt].values, dep)
    if feat_c not in df.columns:
        return html.Div()

    vals_c = df[feat_c].values.astype(np.float64)
    bc, lbls_c, _ = _quantile_bins(vals_c, ~np.isnan(vals_c), n_bins)
    bc = _filter_rare_bins_fast(bc, min_n)
    nc = int(bc.max()) + 1 if bc.max() >= 0 else 0
    if nc < 2:
        return html.Div("Pas assez de bins valides pour Feature C.",
                        style={"color":"#9aa5b4","fontSize":"12px","padding":"8px"})

    vals_a = df[feat_a].values.astype(np.float64)
    vals_b = df[feat_b].values.astype(np.float64)
    ba, la, _ = _quantile_bins(vals_a, ~np.isnan(vals_a), n_bins)
    bb, lb, _ = _quantile_bins(vals_b, ~np.isnan(vals_b), n_bins)
    ba = _filter_rare_bins_fast(ba, min_n)
    bb = _filter_rare_bins_fast(bb, min_n)
    na = int(ba.max()) + 1 if ba.max() >= 0 else 0
    nb_ = int(bb.max()) + 1 if bb.max() >= 0 else 0

    figs = []
    for ic in range(nc):
        mask_c  = bc == ic
        y_sl    = np.where(mask_c, y_enc, np.nan)
        gm_sl   = float(np.nanmean(y_sl))
        gs_sl   = float(np.nanstd(y_sl, ddof=1))
        if na < 2 or nb_ < 2:
            continue
        res = _cell_stats_2d(y_sl, ba, bb, na, nb_, min_n, gm_sl, gs_sl)
        if res is None:
            continue
        mat = np.where(res["valid"].reshape(na, nb_),
                       res["means"].reshape(na, nb_) - global_mean, np.nan)
        sig = (res["p_vals"] < alpha).reshape(na, nb_)
        abs_m = float(np.nanmax(np.abs(mat))) if not np.all(np.isnan(mat)) else 1.0
        txt   = [["--" if np.isnan(mat[ia,ib]) else
                  f"D{mat[ia,ib]:+.2g}{'*' if sig[ia,ib] else ''}"
                  for ib in range(nb_)] for ia in range(na)]
        fig = go.Figure(go.Heatmap(
            z=mat,
            x=[f"B:{l}" for l in (lb[:nb_] if lb else [f"B{i+1}" for i in range(nb_)])],
            y=[f"A:{l}" for l in (la[:na]  if la else [f"A{i+1}" for i in range(na)])],
            colorscale=CS_DIV, zmid=0, zmin=-abs_m, zmax=abs_m,
            text=txt, texttemplate="%{text}", textfont=dict(size=9),
            showscale=True, colorbar=dict(thickness=10,tickfont=dict(size=8)),
            hovertemplate="<b>%{y} x %{x}</b><br>Delta=%{z:.3g}<extra></extra>"))
        fig.update_layout(height=240, plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=70,r=70,t=8,b=50), font=dict(family=FONT,size=9),
            xaxis=dict(tickangle=-30))
        lbl_c = lbls_c[ic] if ic < len(lbls_c) else f"C{ic+1}"
        figs.append(html.Div([
            html.Div(f"Slice {feat_c[:16]} in [{lbl_c}] (calcul live)",
                style={"fontWeight":"700","fontSize":"11px","color":"#e07b39",
                       "marginBottom":"4px","fontFamily":FONT}),
            dcc.Graph(figure=fig, config={"displayModeBar":False},
                      style={"height":"240px"}),
        ], className="chart-card", style={"flex":"1","minWidth":"240px"}))

    if not figs:
        return html.Div()
    return html.Div([
        html.Div(f"Heatmaps par slice de {feat_c}", className="chart-card-title"),
        html.Div(figs, style={"display":"flex","gap":"12px","flexWrap":"wrap"}),
    ], className="chart-card")


# ===========================================================================
#  FIGURE BUILDERS
# ===========================================================================

def _source_badge(from_cache, n_inter, min_n):
    if from_cache:
        return html.Div([
            html.Span("CACHE", style={"background":"#27ae60","color":"white",
                "fontWeight":"800","fontSize":"10px","borderRadius":"4px",
                "padding":"2px 8px","marginRight":"8px","fontFamily":FONT}),
            html.Span(f"Precalcule sur {n_inter:,} pts | min_n={min_n} | instantane",
                style={"fontSize":"11px","color":"#6b7a8d","fontFamily":FONT}),
        ], style={"marginBottom":"10px","display":"flex","alignItems":"center"})
    else:
        return html.Div([
            html.Span("LIVE", style={"background":"#e07b39","color":"white",
                "fontWeight":"800","fontSize":"10px","borderRadius":"4px",
                "padding":"2px 8px","marginRight":"8px","fontFamily":FONT}),
            html.Span(f"Calcul a la volee (paire hors top-K cache) | min_n={min_n}",
                style={"fontSize":"11px","color":"#6b7a8d","fontFamily":FONT}),
        ], style={"marginBottom":"10px","display":"flex","alignItems":"center"})


def _summary_cards(n_tot, n_sig, alpha, best_d, best_m, worst, y_mean, tgt):
    def _c(icon,lbl,val,sub,clr):
        return html.Div([
            html.Div(icon,style={"fontSize":"22px"}),
            html.Div(val,style={"fontSize":"20px","fontWeight":"800","color":clr,
                "fontFamily":FONT}),
            html.Div(lbl,style={"fontSize":"10px","fontWeight":"700","color":"#6b7a8d",
                "textTransform":"uppercase","letterSpacing":".3px"}),
            html.Div(sub,style={"fontSize":"10px","color":"#9aa5b4","marginTop":"2px"}),
        ],style={"background":"white","borderRadius":"10px","padding":"12px 16px",
                 "flex":"1","minWidth":"130px","boxShadow":"0 1px 6px rgba(0,0,0,.07)",
                 "borderLeft":f"4px solid {clr}"})

    best_d_str = f"|d|={abs(best_d['cohens_d']):.2f}" if best_d else "--"
    best_m_str = f"mu={best_m['mean']:.3g}" if best_m else "--"
    worst_str  = f"mu={worst['mean']:.3g}" if worst else "--"
    return html.Div([
        _c("[ ]","Combinaisons",str(n_tot),"cellules valides (n >= min_n)","#4472c4"),
        _c("*","Sig. (alpha="+str(alpha)+")",str(n_sig),
           f"{n_sig/max(n_tot,1)*100:.0f}% des combinaisons","#27ae60"),
        _c("^","Maximum",best_m_str,"mu target la plus haute","#2166ac"),
        _c("v","Minimum",worst_str,"mu target la plus basse","#b2182b"),
        _c("d","Meilleur effet",best_d_str,"Cohen's d le plus fort","#e07b39"),
    ],style={"display":"flex","gap":"10px","flexWrap":"wrap"})


def _upset_plot(rules, feats, global_mean, tgt, alpha):
    top = rules[:min(20, len(rules))]
    if not top:
        return go.Figure()

    n_feats = len(feats)
    ns      = [r["n"] for r in top]
    deltas  = [r["delta"] for r in top]
    sigs    = [r["sig"] for r in top]
    n_rules = len(top)

    bar_colors = []
    for d, sig in zip(deltas, sigs):
        if not sig:   bar_colors.append("rgba(150,150,150,0.4)")
        elif d > 0:   bar_colors.append("rgba(33,102,172,0.85)")
        else:         bar_colors.append("rgba(178,24,43,0.85)")

    fig = make_subplots(rows=2, cols=1, row_heights=[0.65,0.35],
                        vertical_spacing=0.04, shared_xaxes=True)

    fig.add_trace(go.Bar(
        x=list(range(n_rules)), y=ns,
        marker=dict(color=bar_colors,line=dict(width=0.5,color="rgba(255,255,255,.3)")),
        text=[f"n={n}" for n in ns],textposition="outside",textfont=dict(size=8,family=FONT),
        hovertemplate="<b>R%{x}</b><br>n=%{y}<extra></extra>",
        name="Effectif", showlegend=False,
    ), row=1, col=1)

    for i,(r,d) in enumerate(zip(top, deltas)):
        sign = "+" if d > 0 else ""
        star = "*" if r["sig"] else ""
        fig.add_annotation(x=i, y=ns[i]/2, row=1, col=1,
            text=f"D{sign}{d:.2g}{star}",
            showarrow=False, font=dict(size=7,color="white",family=FONT),
            xref="x", yref="y")

    feat_short = [f[:14] for f in feats]
    for fi in range(n_feats):
        fig.add_shape(type="rect", x0=-0.5, x1=n_rules-0.5,
            y0=fi-0.35, y1=fi+0.35, line_width=0,
            fillcolor="#f5f5f5" if fi%2==0 else "white",
            layer="below", row=2, col=1, xref="x2", yref="y2")

    for i, r in enumerate(top):
        parts_lower = [p.split("in")[0].strip().lower() for p in r["cond_parts"]]
        active_fis = []
        for fi, feat in enumerate(feats):
            in_rule = any(feat[:12].lower() in pl for pl in parts_lower)
            clr = bar_colors[i] if in_rule else "rgba(200,200,200,0.3)"
            sz  = 12 if in_rule else 6
            fig.add_trace(go.Scatter(
                x=[i], y=[fi], mode="markers",
                marker=dict(color=clr, size=sz, symbol="circle",
                            line=dict(width=1, color="rgba(255,255,255,.5)")),
                showlegend=False, hoverinfo="skip",
            ), row=2, col=1)
            if in_rule:
                active_fis.append(fi)
        for k in range(len(active_fis)-1):
            fig.add_trace(go.Scatter(
                x=[i,i], y=[active_fis[k], active_fis[k+1]], mode="lines",
                line=dict(color=bar_colors[i],width=2.5),
                showlegend=False, hoverinfo="skip",
            ), row=2, col=1)

    for lbl, clr in [("+ Sig. positif","rgba(33,102,172,0.85)"),
                     ("- Sig. negatif","rgba(178,24,43,0.85)"),
                     ("Non sig.","rgba(150,150,150,0.4)")]:
        fig.add_trace(go.Bar(x=[None],y=[None],marker_color=clr,name=lbl), row=1,col=1)

    fig.update_layout(
        plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=20,r=20,t=20,b=20),
        font=dict(family=FONT,size=10),
        yaxis=dict(title="Effectif n", gridcolor=GRID),
        yaxis2=dict(tickvals=list(range(n_feats)), ticktext=feat_short,
                    gridcolor=GRID, tickfont=dict(size=10,color="#1e3a5f")),
        xaxis2=dict(tickvals=list(range(n_rules)),
                    ticktext=[f"R{i+1}" for i in range(n_rules)],
                    tickfont=dict(size=8), tickangle=-45),
        height=420,
        legend=dict(orientation="h",x=0.5,xanchor="center",y=1.05,
                    font=dict(size=9)),
        barmode="overlay",
    )
    return fig


def _rules_table(rules, tgt, global_mean, alpha):
    if not rules:
        return html.Div("Aucune regle (augmenter n_bins ou reduire min_n).",
                        style={"color":"#9aa5b4","padding":"12px","fontSize":"12px"})
    top = rules[:30]

    def _th(t):
        return html.Th(t,style={"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"9.5px","textTransform":"uppercase",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"})
    def _td(t,clr=None,bold=False):
        s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
        if bold: s["fontWeight"]="700"
        return html.Td(t,style=s)

    rows = []
    for i, r in enumerate(top):
        d = r["cohens_d"]; sig = r["sig"]
        d_lbl = ("grand" if abs(d)>=0.8 else "moyen" if abs(d)>=0.5
                 else "petit" if abs(d)>=0.2 else "neg.")
        bg = ("#f0f8ff" if sig and d>0 else "#fff5f5" if sig and d<0 else "white")
        rule_si    = "SI " + " ET ".join(r["cond_parts"])
        rule_alors = f"ALORS mu({tgt[:12]})={r['mean']:.4g}"
        rows.append(html.Tr([
            _td(f"R{i+1}", bold=True, clr="#4472c4"),
            html.Td(html.Div([
                html.Div(rule_si,  style={"fontSize":"9.5px","color":"#1e3a5f","fontWeight":"700"}),
                html.Div(rule_alors,style={"fontSize":"9px","color":"#374151","marginTop":"1px"}),
            ],style={"lineHeight":"1.3"}),style={"padding":"4px 8px","minWidth":"200px"}),
            _td(f"{r['n']:,}"),
            _td(f"{r['mean']:.4g}", bold=True),
            _td(f"{r['delta']:+.4g}",
                "#2166ac" if r["delta"]>0 else "#b2182b", bold=True),
            _td(f"+-{r['ci95']:.3g}"),
            _td(f"{'u' if d>0 else 'v'} {abs(d):.3f} ({d_lbl})",
                "#2166ac" if d>0.2 else "#b2182b" if d<-0.2 else "#9aa5b4",
                bold=abs(d)>=0.5),
            _td(f"{r['p']:.4f}", "#27ae60" if sig else "#9aa5b4", bold=sig),
            _td("OK" if sig else "--", "#27ae60" if sig else "#9aa5b4", bold=True),
        ], style={"borderBottom":"1px solid #f0f4f8","background":bg}))

    return html.Div([
        html.Div(f"Top {len(top)} regles classees par |Cohen's d|",
            style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"8px",
                   "fontFamily":FONT}),
        html.Div(
            html.Table([
                html.Thead(html.Tr([_th("N"), _th("Regle"), _th("n"),
                                    _th(f"mu({tgt[:10]})"), _th("Delta"),
                                    _th("IC95"), _th("Cohen's d"),
                                    _th("p-value"), _th("Sig.")])),
                html.Tbody(rows),
            ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
            style={"overflowX":"auto","maxHeight":"420px","overflowY":"auto"},
        ),
    ])


def _ols_regression(dep, tgt, feats, n_bins, rules):
    """OLS on binned indicators from display_df (fast enough for callback)."""
    try:
        import statsmodels.api as sm
    except ImportError:
        return html.Div("statsmodels non disponible. pip install statsmodels",
                        style={"color":"#9aa5b4","fontSize":"12px","padding":"12px"})
    try:
        from dataexplore_pro._precompute import (_quantile_bins,
            _filter_rare_bins_fast, _encode_y)
        df    = dep.display_df
        y_enc = _encode_y(df[tgt].values, dep).astype(float)
        min_n = dep.interaction_min_samples

        X_parts    = [np.ones(len(y_enc))]
        col_names  = ["Intercept"]
        bins_dict  = {}

        for feat in feats:
            if feat not in df.columns:
                continue
            vals = df[feat].values.astype(np.float64)
            ok   = ~np.isnan(vals)
            b_arr, lbls, _ = _quantile_bins(vals, ok, n_bins)
            b_arr = _filter_rare_bins_fast(b_arr, min_n)
            nb_act = int(b_arr.max()) + 1 if b_arr.max() >= 0 else 0
            bins_dict[feat] = (b_arr, lbls, nb_act)
            for bi in range(1, nb_act):
                lbl = lbls[bi] if bi < len(lbls) else f"B{bi+1}"
                X_parts.append((b_arr == bi).astype(float))
                col_names.append(f"{feat[:10]}[{lbl}]")

        # 2-way interaction A x B
        fa, fb = feats[0], feats[1]
        if fa in bins_dict and fb in bins_dict:
            ba_, la_, na_ = bins_dict[fa]
            bb_, lb_, nb_ = bins_dict[fb]
            for ia in range(1, na_):
                for ib in range(1, nb_):
                    col = ((ba_==ia) & (bb_==ib)).astype(float)
                    la = la_[ia] if ia < len(la_) else f"B{ia}"
                    lb = lb_[ib] if ib < len(lb_) else f"B{ib}"
                    X_parts.append(col)
                    col_names.append(f"{fa[:8]}[{la}]x{fb[:8]}[{lb}]")

        X_mat = np.column_stack(X_parts).astype(float)
        ok_rows = ~np.isnan(y_enc)
        X_mat = X_mat[ok_rows]; y_fit = y_enc[ok_rows]

        # Drop near-zero variance
        var_mask  = X_mat.var(axis=0) > 1e-8
        X_mat     = X_mat[:, var_mask]
        col_names = [c for c, m in zip(col_names, var_mask) if m]

        model = sm.OLS(y_fit, X_mat)
        res   = model.fit()
        r2, r2a = float(res.rsquared), float(res.rsquared_adj)
        cis     = res.conf_int()

        def _th(t):
            return html.Th(t,style={"padding":"5px 8px","background":"#f0f4f8",
                "color":"#6b7a8d","fontWeight":"700","fontSize":"9.5px",
                "textTransform":"uppercase","borderBottom":"2px solid #e0e4ea",
                "whiteSpace":"nowrap","textAlign":"left"})
        def _td(t,clr=None,bold=False):
            s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151",
               "whiteSpace":"nowrap"}
            if bold: s["fontWeight"]="700"
            return html.Td(t,style=s)

        tbody = []
        for name,b,pv,ci_lo,ci_hi in zip(col_names, res.params,
                                           res.pvalues, cis[:,0], cis[:,1]):
            is_int = "x" in name and "[" in name
            sig    = pv < 0.05
            clr_b  = "#2166ac" if b>0 else "#b2182b"
            tbody.append(html.Tr([
                _td(name, bold=is_int, clr="#4472c4" if is_int else None),
                _td(f"{b:+.4f}", clr_b, True),
                _td(f"[{ci_lo:+.3f},{ci_hi:+.3f}]"),
                _td(f"{pv:.4f}", "#27ae60" if sig else "#9aa5b4", sig),
                _td("OK" if sig else "--", "#27ae60" if sig else "#9aa5b4", True),
            ],style={"borderBottom":"1px solid #f5f5f5",
                     "background":"#f0f8ff" if is_int and sig else "white"}))

        summary_row = html.Div([
            _mini_card("R2",       f"{r2:.4f}",  "#4472c4"),
            _mini_card("R2 adj.",  f"{r2a:.4f}", "#27ae60"),
            _mini_card("N obs.",   f"{len(y_fit):,}", "#9b59b6"),
        ],style={"display":"flex","gap":"8px","flexWrap":"wrap","marginBottom":"12px"})

        table = html.Div(
            html.Table([
                html.Thead(html.Tr([_th("Terme"),_th("Beta"),_th("IC95%"),
                                    _th("p-value"),_th("Sig.")])),
                html.Tbody(tbody),
            ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
            style={"overflowX":"auto","maxHeight":"360px","overflowY":"auto"})

        note = html.Div("Termes avec x = interactions 2-way. "
                        "Fond bleu = interaction significative.",
            style={"fontSize":"10px","color":"#9aa5b4","marginTop":"8px",
                   "fontStyle":"italic","fontFamily":FONT})

        return html.Div([summary_row, table, note])

    except Exception as ex:
        return html.Div(f"Erreur OLS: {ex}",
                        style={"color":"#e74c3c","fontSize":"12px","padding":"12px"})


def _mini_card(label, value, clr):
    return html.Div([
        html.Div(value,style={"fontSize":"17px","fontWeight":"800","color":clr,
            "fontFamily":FONT}),
        html.Div(label,style={"fontSize":"9.5px","color":"#6b7a8d","fontWeight":"600",
            "textTransform":"uppercase","letterSpacing":".3px"}),
    ],style={"background":"white","borderRadius":"8px","padding":"8px 12px",
             "boxShadow":"0 1px 5px rgba(0,0,0,.07)","borderLeft":f"3px solid {clr}"})


def _err(msg):
    return html.Div(msg,style={"color":"#e74c3c","padding":"16px","fontSize":"13px",
                                "fontFamily":FONT})
