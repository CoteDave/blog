"""
_precompute.py — DataExplore Pro v12
================================================================================
Moteur de precalcul — completement parallelise et vectorise.

SAMPLES
  DISPLAY_N  =  50_000   graphiques WebGL
  CORR_N     =  10_000   correlations Pearson/Spearman (cache)
  STATS_N    = 200_000   stats descriptives / PCA
  IMP_N      = 100_000   RF/MI/importance
  INTER_N    = 200_000   interactions

ARCHITECTURE DES THREADS (v12)
  Phase 0  index + encodage target (synchrone immediat)
  Phase 1  6 workers standards : fstats, miss, corr, pca, importance, IV
  Phase 2  lance des que IV est disponible (chevauchement avec Phase 1)
           pool dedie interactions 2D : 1 future par (feat_a, feat_b, n_bins)
  Phase 3  3-way pour top-K paires (apres Phase 2 partielle)

VECTORISATION _filter_rare_bins (v12 NEW)
  bincount -> LUT (Look-Up Table) int16 vectorisee
  O(n + nb) au lieu de O(n x nb_Python_loops)

VECTORISATION _cell_stats_2d / _cell_stats_3d
  aggregation O(n) via np.bincount
  Welch t-test sur tous les n_cells simultanement (array ops)
  p-values batch via scipy.stats.t.sf sur vecteur
  Cohen's d vectorise
  filtre min_n AVANT tout calcul de p

PRIORITE DES PAIRES
  triees par IV_a x IV_b decroissant -> meilleures paires d'abord
"""
from __future__ import annotations
import threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from itertools import combinations
from typing import TYPE_CHECKING
import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from .core import DataExplorePro

DISPLAY_N = 50_000
STATS_N   = 200_000
CORR_N    =  10_000
IMP_N     = 100_000
INTER_N   = 200_000
MAX_3WAY_PAIRS = 20


# ===========================================================================
#  Thread-safe cache
# ===========================================================================

class Cache:
    def __init__(self):
        self._d:      dict = {}
        self._lock    = threading.Lock()
        self._events: dict[str, threading.Event] = {}

    def _ev(self, key: str) -> threading.Event:
        with self._lock:
            if key not in self._events:
                self._events[key] = threading.Event()
            return self._events[key]

    def set(self, key: str, value) -> None:
        with self._lock:
            self._d[key] = value
        self._ev(key).set()

    def get(self, key: str, default=None, *, wait: bool = False, timeout: float = 90):
        if wait:
            self._ev(key).wait(timeout=timeout)
        with self._lock:
            return self._d.get(key, default)

    def ready(self, key: str) -> bool:
        return self._ev(key).is_set()


# ===========================================================================
#  Entry point
# ===========================================================================

def build_cache(dep: "DataExplorePro") -> Cache:
    cache = Cache()

    def _run():
        t0  = time.perf_counter()
        num = dep.num_features
        n   = len(dep.df)
        rng = np.random.default_rng(42)

        df_num = dep.df[num]
        X_full = df_num.fillna(df_num.median()).values.astype(np.float32)
        y_full = dep.y if dep.supervised else None

        def _strat(want: int) -> np.ndarray:
            want = min(want, n)
            if want >= n:
                return np.arange(n)
            if dep.supervised and dep.is_classification and y_full is not None:
                parts = []
                classes, counts = np.unique(y_full, return_counts=True)
                for cls, cnt in zip(classes, counts):
                    ci = np.where(y_full == cls)[0]
                    k  = max(1, int(want * cnt / n))
                    parts.append(rng.choice(ci, size=min(k, cnt), replace=False))
                idx = np.concatenate(parts)
                if len(idx) < want:
                    extra = rng.choice(n, size=want - len(idx), replace=False)
                    idx   = np.unique(np.concatenate([idx, extra]))
                return idx[:want]
            return rng.choice(n, size=want, replace=False)

        idx_corr  = _strat(CORR_N)
        idx_stats = _strat(STATS_N)
        idx_imp   = _strat(IMP_N)
        idx_inter = _strat(INTER_N)

        X_corr  = X_full[idx_corr]
        X_stats = X_full[idx_stats]
        X_imp   = X_full[idx_imp]
        y_imp   = y_full[idx_imp] if y_full is not None else None

        cache.set("idx_stats", idx_stats)
        cache.set("idx_imp",   idx_imp)
        cache.set("corr_n",    len(idx_corr))

        # Holder for the interactions background thread
        inter_threads: list = []

        def _on_iv_ready(iv_result):
            """Triggered as soon as IV is computed — Phase 2 starts immediately."""
            cache.set("iv", iv_result)
            if dep.supervised and y_full is not None:
                t = threading.Thread(
                    target=_interactions_phase,
                    args=(dep, X_full, y_full, idx_inter, num, iv_result, cache),
                    daemon=True, name="dep12_inter"
                )
                t.start()
                inter_threads.append(t)

        # Phase 1 — 6 standard workers
        with ThreadPoolExecutor(max_workers=6, thread_name_prefix="dep12_std") as pool:
            futures: dict = {
                pool.submit(_fstats,   X_full,  num, y_full, dep): "fstats",
                pool.submit(_miss,     X_full,  num, dep):         "miss",
                pool.submit(_corr,     X_corr,  num):              "corr",
                pool.submit(_pca_work, X_stats, num):              "pca",
            }
            if dep.supervised and y_imp is not None:
                futures[pool.submit(_importance, X_imp, y_imp, num,
                                    dep.is_classification)] = "importance"
                futures[pool.submit(_iv, X_full, y_full, num, dep)] = "iv_raw"
            else:
                cache.set("importance", None)
                _on_iv_ready({c: 0.0 for c in num})

            for fut in as_completed(futures):
                key = futures[fut]
                try:
                    res = fut.result()
                    if key == "corr":
                        cache.set("corr_pearson",  res[0])
                        cache.set("corr_spearman", res[1])
                    elif key == "iv_raw":
                        _on_iv_ready(res)
                    else:
                        cache.set(key, res)
                except Exception:
                    import traceback; traceback.print_exc()
                    if key == "corr":
                        cache.set("corr_pearson",  None)
                        cache.set("corr_spearman", None)
                    elif key == "iv_raw":
                        _on_iv_ready({c: 0.0 for c in num})
                    else:
                        cache.set(key, None)

        # Wait for interactions thread (launched in Phase 2)
        for t in inter_threads:
            t.join(timeout=300)

        if not cache.ready("interactions"):
            cache.set("interactions", None)

        cache.set("_ready", True)
        print(f"  [DEP v12] precalcul total {time.perf_counter()-t0:.1f}s  "
              f"({len(num)} features x {n:,} lignes)")

    threading.Thread(target=_run, daemon=True, name="dep12_precompute").start()
    return cache


# ===========================================================================
#  INTERACTIONS PHASE  (Phase 2 + 3)
# ===========================================================================

def _interactions_phase(dep, X_full, y_full, idx, num, iv_cache, cache):
    t0          = time.perf_counter()
    min_n       = dep.interaction_min_samples
    max_feats   = dep.interaction_max_features
    n_bins_list = [2, 3, 4, 5, 6]

    # Feature selection: top-K by IV
    if iv_cache and isinstance(iv_cache, dict):
        ranked    = sorted(iv_cache.items(), key=lambda x: abs(x[1]), reverse=True)
        sel_feats = [f for f, _ in ranked if f in num][:max_feats]
    else:
        sel_feats = list(num[:max_feats])

    if len(sel_feats) < 2:
        cache.set("interactions", None)
        return

    # Sub-sample INTER_N
    X_inter  = X_full[idx].astype(np.float64)
    y_inter  = _encode_y(y_full[idx], dep)
    n_inter  = len(idx)
    feat_col = {f: i for i, f in enumerate(num)}

    global_mean = float(np.nanmean(y_inter))
    global_std  = float(np.nanstd(y_inter, ddof=1))
    if global_std < 1e-9:
        global_std = 1.0

    # Pre-compute bins for every (feature, n_bins)
    bins_arr:   dict[tuple, np.ndarray] = {}
    bin_labels: dict[tuple, list]       = {}
    bin_edges:  dict[tuple, np.ndarray] = {}

    for feat in sel_feats:
        fi   = feat_col[feat]
        vals = X_inter[:, fi].copy()
        ok   = ~np.isnan(vals)
        for nb in n_bins_list:
            b_arr, lbls, edges = _quantile_bins(vals, ok, nb)
            # Filter rare bins BEFORE any interaction — LUT-vectorized
            b_arr = _filter_rare_bins_fast(b_arr, min_n)
            bins_arr[(feat, nb)]   = b_arr
            bin_labels[(feat, nb)] = lbls
            bin_edges[(feat, nb)]  = edges

    # Pair list sorted by IV_a x IV_b (best pairs computed first)
    all_pairs_2d = list(combinations(sel_feats, 2))
    def _pair_score(fa, fb):
        return abs(iv_cache.get(fa, 0.0)) * abs(iv_cache.get(fb, 0.0))
    all_pairs_2d.sort(key=lambda p: _pair_score(*p), reverse=True)

    all_tasks_2d = [(fa, fb, nb)
                    for fa, fb in all_pairs_2d
                    for nb in n_bins_list]
    n_tasks    = len(all_tasks_2d)
    # Aggressive worker count — numpy releases GIL for array ops
    max_workers = min(32, max(8, n_tasks // 3 + 1))

    pairs_2d: dict = {}

    with ThreadPoolExecutor(max_workers=max_workers,
                            thread_name_prefix="dep12_2d") as pool:
        fut_map: dict = {}
        for fa, fb, nb in all_tasks_2d:
            ba   = bins_arr[(fa, nb)]
            bb   = bins_arr[(fb, nb)]
            na_b = int(ba.max()) + 1 if ba.max() >= 0 else 0
            nb_b = int(bb.max()) + 1 if bb.max() >= 0 else 0
            if na_b < 2 or nb_b < 2:
                continue
            fut = pool.submit(
                _cell_stats_2d,
                y_inter, ba, bb, na_b, nb_b, min_n, global_mean, global_std
            )
            fut_map[fut] = (fa, fb, nb)

        for fut in as_completed(fut_map):
            fa, fb, nb = fut_map[fut]
            try:
                res = fut.result()
                if res is not None:
                    pairs_2d[(fa, fb, nb)] = res
            except Exception:
                pass

    t_2d = time.perf_counter() - t0
    print(f"  [DEP v12] 2D: {len(pairs_2d)}/{n_tasks} paires*bins "
          f"en {t_2d:.1f}s (min_n={min_n}, {len(sel_feats)} feats, {max_workers}w)")

    # Phase 3: 3D for top pairs
    pairs_3d: dict = {}
    if len(sel_feats) >= 3:
        nb_def = dep.interaction_n_bins_default
        pair_scores_3d: list = []
        for (fa, fb, nb2), res in pairs_2d.items():
            if nb2 == nb_def:
                d_arr = res["cohens_d"]
                valid = res["valid"]
                max_d = float(np.nanmax(np.abs(d_arr[valid]))) if valid.any() else 0.0
                pair_scores_3d.append((max_d, fa, fb))
        pair_scores_3d.sort(reverse=True)

        top_pairs = [(fa, fb) for _, fa, fb in pair_scores_3d[:MAX_3WAY_PAIRS]]

        tasks_3d = [
            (fa, fb, fc, nb_def)
            for fa, fb in top_pairs
            for fc in sel_feats
            if fc not in (fa, fb)
        ]

        max_w3 = min(24, max(6, len(tasks_3d) // 3 + 1))

        with ThreadPoolExecutor(max_workers=max_w3,
                                thread_name_prefix="dep12_3d") as pool3:
            fut3_map: dict = {}
            for fa, fb, fc, nb in tasks_3d:
                ba = bins_arr[(fa, nb)]
                bb = bins_arr[(fb, nb)]
                bc = bins_arr[(fc, nb)]
                na_b = int(ba.max()) + 1 if ba.max() >= 0 else 0
                nb_b = int(bb.max()) + 1 if bb.max() >= 0 else 0
                nc_b = int(bc.max()) + 1 if bc.max() >= 0 else 0
                if na_b < 2 or nb_b < 2 or nc_b < 2:
                    continue
                f3 = pool3.submit(
                    _cell_stats_3d,
                    y_inter, ba, bb, bc, na_b, nb_b, nc_b,
                    min_n, global_mean, global_std
                )
                fut3_map[f3] = (fa, fb, fc, nb)

            for f3 in as_completed(fut3_map):
                fa, fb, fc, nb = fut3_map[f3]
                try:
                    r3 = f3.result()
                    if r3 is not None:
                        pairs_3d[(fa, fb, fc, nb)] = r3
                except Exception:
                    pass

        t_3d = time.perf_counter() - t0
        print(f"  [DEP v12] 3D: {len(pairs_3d)}/{len(tasks_3d)} triplets "
              f"en {t_3d:.1f}s total")

    meta = dict(
        min_n       = min_n,
        inter_n     = n_inter,
        n_bins_list = n_bins_list,
        feats       = sel_feats,
        bin_labels  = bin_labels,
        bin_edges   = bin_edges,
        global_mean = global_mean,
        global_std  = global_std,
        n_obs       = n_inter,
    )
    cache.set("interactions", {
        "meta":     meta,
        "pairs_2d": pairs_2d,
        "pairs_3d": pairs_3d,
    })


# ===========================================================================
#  VECTORIZED BIN HELPERS
# ===========================================================================

def _encode_y(y_raw: np.ndarray, dep) -> np.ndarray:
    if dep.is_classification:
        from sklearn.preprocessing import LabelEncoder
        return LabelEncoder().fit_transform(y_raw.astype(str)).astype(np.float64)
    return y_raw.astype(np.float64)


def _quantile_bins(vals, ok_mask, nb):
    """Quantile binning via searchsorted. Returns (bin_arr int16, labels, edges)."""
    n = len(vals)
    fallback = (np.full(n, -1, dtype=np.int16),
                [f"Q{i+1}" for i in range(nb)],
                np.array([]))
    x_ok = vals[ok_mask]
    if len(x_ok) < nb * 2:
        return fallback

    pcts  = np.linspace(0, 100, nb + 1)
    edges = np.unique(np.percentile(x_ok, pcts))

    if len(edges) < 3:
        mn, mx = x_ok.min(), x_ok.max()
        if mx <= mn:
            return fallback
        edges = np.linspace(mn, mx, nb + 1)
        if len(np.unique(edges)) < 3:
            return fallback

    n_actual = len(edges) - 1
    labels   = [f"{edges[i]:.3g}-{edges[i+1]:.3g}" for i in range(n_actual)]

    b_arr = np.full(n, -1, dtype=np.int16)
    if ok_mask.any():
        inner    = edges[1:-1]
        assigned = np.searchsorted(inner, vals[ok_mask], side="right")
        assigned = np.clip(assigned, 0, n_actual - 1).astype(np.int16)
        b_arr[ok_mask] = assigned

    return b_arr, labels, edges


def _filter_rare_bins_fast(b_arr: np.ndarray, min_n: int) -> np.ndarray:
    """
    Filter bins with count < min_n and compact-remap survivors.
    Fully vectorized via bincount + LUT (no Python loop over observations).
    O(n + nb).
    """
    if min_n <= 0:
        return b_arr

    valid_mask = b_arr >= 0
    if not valid_mask.any():
        return b_arr

    nb_max = int(b_arr[valid_mask].max()) + 1
    counts = np.bincount(b_arr[valid_mask].astype(np.int64), minlength=nb_max)

    kept = np.where(counts >= min_n)[0]
    if len(kept) == 0:
        return np.full(len(b_arr), -1, dtype=np.int16)
    if len(kept) == nb_max:
        return b_arr  # nothing to filter

    # Build LUT: old_bin -> new_compact_idx  (-1 = dropped)
    lut = np.full(nb_max, -1, dtype=np.int16)
    lut[kept] = np.arange(len(kept), dtype=np.int16)

    # Apply LUT — vectorized
    out    = np.full(len(b_arr), -1, dtype=np.int16)
    ok     = b_arr >= 0
    out[ok] = lut[b_arr[ok]]
    return out


# ===========================================================================
#  CELL STATS 2D  — the hot path
# ===========================================================================

def _cell_stats_2d(y_vals, bin_a, bin_b, na, nb, min_n, global_mean, global_std):
    """
    Per-cell stats for all (ia, ib) in O(n) via bincount.
    Welch t-test + Cohen's d fully vectorized.
    min_n filter applied BEFORE any p-value computation.
    Returns None if 0 cells survive min_n.
    """
    n_cells = na * nb
    ok = (bin_a >= 0) & (bin_b >= 0) & (~np.isnan(y_vals))
    if ok.sum() < min_n:
        return None

    y_v  = y_vals[ok].astype(np.float64)
    ba_v = bin_a[ok].astype(np.int64)
    bb_v = bin_b[ok].astype(np.int64)
    cid  = ba_v * nb + bb_v

    counts  = np.bincount(cid, minlength=n_cells).astype(np.float64)
    sums    = np.bincount(cid, weights=y_v,    minlength=n_cells)
    sums_sq = np.bincount(cid, weights=y_v**2, minlength=n_cells)

    tot_n   = float(counts.sum())
    tot_s   = float(sums.sum())
    tot_sq  = float(sums_sq.sum())

    with np.errstate(invalid="ignore", divide="ignore"):
        means  = np.where(counts > 0,  sums / counts,  np.nan)
        e_sq   = np.where(counts > 0,  sums_sq / counts, np.nan)
        vars_c = np.where(counts > 1,
                          (e_sq - means**2) * counts / np.maximum(counts - 1, 1),
                          np.nan)
        rest_n    = tot_n  - counts
        rest_mean = np.where(rest_n > 0, (tot_s - sums)  / rest_n, np.nan)
        rest_e2   = np.where(rest_n > 0, (tot_sq - sums_sq) / rest_n, np.nan)
        rest_var  = np.where(rest_n > 1,
                             (rest_e2 - rest_mean**2) * rest_n / np.maximum(rest_n - 1, 1),
                             np.nan)

    # Apply min_n BEFORE p-values
    valid = counts >= min_n
    if not valid.any():
        return None

    v_c  = np.where(valid, np.nan_to_num(vars_c),  0.0)
    v_r  = np.where(valid, np.nan_to_num(rest_var), 0.0)
    n_c  = np.maximum(counts, 1.0)
    n_r  = np.maximum(rest_n, 1.0)

    se   = np.sqrt(np.maximum(v_c / n_c + v_r / n_r, 1e-18))
    t_v  = np.where(valid, (means - rest_mean) / se, np.nan)

    va   = v_c / n_c; vb = v_r / n_r
    df_w = (va + vb)**2 / (
        va**2 / np.maximum(n_c - 1, 1) +
        vb**2 / np.maximum(n_r - 1, 1) + 1e-18)
    df_w = np.maximum(df_w, 1.0)

    from scipy.stats import t as t_dist
    p_vals = np.where(valid & ~np.isnan(t_v),
                      2.0 * t_dist.sf(np.abs(t_v), df=df_w), np.nan)

    pooled_std = np.sqrt(
        np.where(valid, (np.nan_to_num(vars_c) + np.nan_to_num(rest_var)) / 2,
                 global_std**2) + 1e-18)
    cohens_d = np.where(valid, (means - global_mean) / pooled_std, np.nan)
    ci95     = np.where(valid & ~np.isnan(df_w),
                        t_dist.ppf(0.975, df=df_w) * se, np.nan)

    return dict(
        na=na, nb=nb,
        counts   = counts.astype(np.float32),
        means    = means.astype(np.float32),
        cohens_d = cohens_d.astype(np.float32),
        p_vals   = p_vals.astype(np.float32),
        ci95     = ci95.astype(np.float32),
        valid    = valid,
        global_mean = global_mean,
        global_std  = global_std,
        total_n  = int(tot_n),
    )


# ===========================================================================
#  CELL STATS 3D
# ===========================================================================

def _cell_stats_3d(y_vals, bin_a, bin_b, bin_c, na, nb, nc,
                    min_n, global_mean, global_std):
    n_cells = na * nb * nc
    ok = (bin_a >= 0) & (bin_b >= 0) & (bin_c >= 0) & (~np.isnan(y_vals))
    if ok.sum() < min_n:
        return None

    y_v  = y_vals[ok].astype(np.float64)
    ba_v = bin_a[ok].astype(np.int64)
    bb_v = bin_b[ok].astype(np.int64)
    bc_v = bin_c[ok].astype(np.int64)
    cid  = ba_v * (nb * nc) + bb_v * nc + bc_v

    counts  = np.bincount(cid, minlength=n_cells).astype(np.float64)
    sums    = np.bincount(cid, weights=y_v,    minlength=n_cells)
    sums_sq = np.bincount(cid, weights=y_v**2, minlength=n_cells)

    tot_n  = float(counts.sum())
    tot_s  = float(sums.sum())
    tot_sq = float(sums_sq.sum())

    with np.errstate(invalid="ignore", divide="ignore"):
        means  = np.where(counts > 0, sums / counts, np.nan)
        e_sq   = np.where(counts > 0, sums_sq / counts, np.nan)
        vars_c = np.where(counts > 1,
                          (e_sq - means**2) * counts / np.maximum(counts - 1, 1), np.nan)
        rest_n    = tot_n   - counts
        rest_mean = np.where(rest_n > 0, (tot_s  - sums)   / rest_n, np.nan)
        rest_e2   = np.where(rest_n > 0, (tot_sq - sums_sq) / rest_n, np.nan)
        rest_var  = np.where(rest_n > 1,
                             (rest_e2 - rest_mean**2) * rest_n / np.maximum(rest_n - 1, 1), np.nan)

    valid = counts >= min_n
    if not valid.any():
        return None

    v_c  = np.where(valid, np.nan_to_num(vars_c),  0.0)
    v_r  = np.where(valid, np.nan_to_num(rest_var), 0.0)
    n_c  = np.maximum(counts, 1.0)
    n_r  = np.maximum(rest_n, 1.0)
    se   = np.sqrt(np.maximum(v_c / n_c + v_r / n_r, 1e-18))
    t_v  = np.where(valid, (means - rest_mean) / se, np.nan)
    va   = v_c / n_c; vb = v_r / n_r
    df_w = (va + vb)**2 / (
        va**2 / np.maximum(n_c - 1, 1) + vb**2 / np.maximum(n_r - 1, 1) + 1e-18)
    df_w = np.maximum(df_w, 1.0)

    from scipy.stats import t as t_dist
    p_vals   = np.where(valid & ~np.isnan(t_v),
                        2.0 * t_dist.sf(np.abs(t_v), df=df_w), np.nan)
    pooled_s = np.sqrt(
        np.where(valid, (np.nan_to_num(vars_c) + np.nan_to_num(rest_var)) / 2,
                 global_std**2) + 1e-18)
    cohens_d = np.where(valid, (means - global_mean) / pooled_s, np.nan)
    ci95     = np.where(valid & ~np.isnan(df_w),
                        t_dist.ppf(0.975, df=df_w) * se, np.nan)

    return dict(
        na=na, nb=nb, nc=nc,
        counts   = counts.astype(np.float32),
        means    = means.astype(np.float32),
        cohens_d = cohens_d.astype(np.float32),
        p_vals   = p_vals.astype(np.float32),
        ci95     = ci95.astype(np.float32),
        valid    = valid,
        global_mean = global_mean,
        global_std  = global_std,
        total_n  = int(tot_n),
    )


# ===========================================================================
#  STANDARD WORKERS (unchanged from v11)
# ===========================================================================

def _fstats(X, cols, y, dep):
    n, p = X.shape
    q    = np.nanpercentile(X, [1,5,10,25,50,75,90,95,99], axis=0)
    mean_v = np.nanmean(X, axis=0).astype(np.float64)
    std_v  = np.nanstd( X, axis=0, ddof=1).astype(np.float64)
    min_v  = np.nanmin( X, axis=0).astype(np.float64)
    max_v  = np.nanmax( X, axis=0).astype(np.float64)
    nan_v  = np.isnan(X).mean(axis=0)
    iqr_v  = q[5] - q[3]
    out_v  = np.mean((X < q[3]-1.5*iqr_v)|(X > q[5]+1.5*iqr_v), axis=0)
    std_s  = np.where(std_v > 0, std_v, 1e-9)
    Xc     = X - mean_v
    skw    = np.nanmean((Xc/std_s)**3, axis=0)
    krt    = np.nanmean((Xc/std_s)**4, axis=0) - 3.0
    return dict(cols=cols, n=n,
                mean=mean_v, std=std_v, min=min_v, max=max_v,
                q01=q[0],q05=q[1],q10=q[2],q25=q[3],
                q50=q[4],q75=q[5],q90=q[6],q95=q[7],q99=q[8],
                iqr=iqr_v, nan_pct=nan_v, outlier_pct=out_v,
                skew=skw, kurt=krt)


def _miss(X, cols, dep):
    n, p   = X.shape
    mp     = np.isnan(X).mean(axis=0)
    mc     = np.isnan(X).sum(axis=0)
    total  = float(mp.mean()*100)
    n_comp = int((~np.isnan(X).any(axis=1)).sum())
    rng    = np.random.default_rng(42)
    idx    = rng.choice(n, size=min(n, 50_000), replace=False)
    M      = np.isnan(X[idx]).astype(np.float32)
    cooc   = (M.T @ M)/len(idx)
    return dict(cols=cols, miss_pct=dict(zip(cols, mp.tolist())),
                miss_cnt=dict(zip(cols, mc.tolist())),
                total_pct=total, n_complete=n_comp, cooc=cooc)


def _corr(X_sample, cols):
    Xd         = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c, m in zip(cols, col_mask) if m]
    cmeans     = np.nanmean(Xd, axis=0)
    nl         = np.isnan(Xd)
    Xd[nl]     = np.take(cmeans, np.where(nl)[1])
    def _pmat(M):
        Mc  = M - M.mean(axis=0)
        nrm = np.linalg.norm(Mc, axis=0)
        nrm = np.where(nrm == 0, 1e-9, nrm)
        mat = (Mc/nrm).T @ (Mc/nrm)
        np.fill_diagonal(mat, 1.0)
        return mat.clip(-1, 1)
    pearson  = _pmat(Xd)
    from scipy.stats import rankdata
    Xr       = np.apply_along_axis(rankdata, 0, Xd).astype(np.float64)
    spearman = _pmat(Xr)
    return (pd.DataFrame(pearson,  index=cols_valid, columns=cols_valid),
            pd.DataFrame(spearman, index=cols_valid, columns=cols_valid))


def _pca_work(X_sample, cols):
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    Xd         = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c, m in zip(cols, col_mask) if m]
    cmeans     = np.nanmean(Xd, axis=0)
    nl         = np.isnan(Xd)
    Xd[nl]     = np.take(cmeans, np.where(nl)[1])
    n_comp     = min(15, Xd.shape[1], Xd.shape[0])
    scaler     = StandardScaler()
    Xs         = scaler.fit_transform(Xd)
    if Xs.shape[0] > 150_000:
        rng = np.random.default_rng(42)
        Xs  = Xs[rng.choice(Xs.shape[0], 150_000, replace=False)]
    pca    = PCA(n_components=n_comp, random_state=42, svd_solver="randomized")
    scores = pca.fit_transform(Xs)
    return dict(cols=cols_valid, scaler=scaler, pca=pca,
                scores=scores.astype(np.float32),
                loadings=pca.components_.T.astype(np.float32),
                explained=pca.explained_variance_ratio_.astype(np.float32),
                n_comp=n_comp)


def _importance(X, y, cols, is_cls):
    from sklearn.feature_selection import (f_classif, f_regression,
        mutual_info_classif, mutual_info_regression)
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.preprocessing import StandardScaler
    from scipy.stats import rankdata
    p  = X.shape[1]
    Xd = X.astype(np.float64)
    yd = y.astype(np.float64)
    cm = np.nanmean(Xd, axis=0)
    nl = np.isnan(Xd)
    Xd[nl] = np.take(cm, np.where(nl)[1])
    def _norm(a):
        mx = a.max(); return (a/mx if mx > 0 else a).clip(0, 1)
    out = {"cols": cols}
    Xc  = Xd - Xd.mean(axis=0); yc = yd - yd.mean()
    sx  = Xd.std(axis=0) + 1e-9; sy = yd.std() + 1e-9
    out["pearson"]  = _norm(np.abs((Xc*yc[:,None]).mean(axis=0)/(sx*sy)))
    Xr  = np.apply_along_axis(rankdata, 0, Xd); yr = rankdata(yd)
    Xrc = Xr - Xr.mean(axis=0); yrc = yr - yr.mean()
    sr  = Xr.std(axis=0)+1e-9; syr = yr.std()+1e-9
    out["spearman"] = _norm(np.abs((Xrc*yrc[:,None]).mean(axis=0)/(sr*syr)))
    try:
        fn  = f_classif if is_cls else f_regression
        yc_ = y.astype(int) if is_cls else yd
        f,_ = fn(Xd, yc_); out["fstat"] = _norm(np.nan_to_num(f,nan=0,posinf=0))
    except: out["fstat"] = np.zeros(p)
    try:
        fn_mi = mutual_info_classif if is_cls else mutual_info_regression
        yc_   = y.astype(int) if is_cls else yd
        mi    = fn_mi(Xd, yc_, random_state=42, n_neighbors=5)
        out["mi"] = _norm(np.nan_to_num(mi, nan=0))
    except: out["mi"] = np.zeros(p)
    try:
        Xs  = StandardScaler().fit_transform(Xd)
        yc_ = y.astype(int) if is_cls else yd
        RF  = RandomForestClassifier if is_cls else RandomForestRegressor
        rf  = RF(n_estimators=60, max_depth=8, max_features="sqrt",
                 min_samples_leaf=20, n_jobs=-1, random_state=42)
        rf.fit(Xs, yc_); out["rf"] = _norm(rf.feature_importances_)
    except: out["rf"] = np.zeros(p)
    stack = np.column_stack([out["pearson"],out["spearman"],out["fstat"],out["mi"],out["rf"]])
    out["global"] = _norm(stack.mean(axis=1))
    return out


def _iv(X_full, y_full, cols, dep):
    if not dep.is_classification or dep.n_classes != 2:
        return _eta2(X_full, y_full, cols)
    cls1      = dep.classes[-1]
    y_bin     = (y_full == cls1).astype(np.int8)
    total_ev  = max(int(y_bin.sum()), 1)
    total_nev = max(len(y_bin) - total_ev, 1)
    result    = {}; N_BINS = 10
    for i, col in enumerate(cols):
        x = X_full[:,i]; ok = ~np.isnan(x); xv, yv = x[ok], y_bin[ok]
        if len(xv) < 20: result[col] = 0.0; continue
        try:
            q  = np.unique(np.percentile(xv, np.linspace(0,100,N_BINS+1)))
            if len(q) < 3: result[col] = 0.0; continue
            b  = np.searchsorted(q[1:-1], xv, side="right"); iv = 0.0
            for bi in np.unique(b):
                m   = b==bi
                ev  = max(int(yv[m].sum()), 1)
                nev = max(int((1-yv[m]).sum()), 1)
                woe = np.log((ev/total_ev)/(nev/total_nev))
                iv += (ev/total_ev - nev/total_nev)*woe
            result[col] = float(np.clip(iv, 0, 5))
        except: result[col] = 0.0
    return result


def _eta2(X, y, cols):
    result = {}
    for i, col in enumerate(cols):
        x = X[:,i]; ok = ~np.isnan(x)
        xv = x[ok].astype(np.float64); yv = y[ok]
        if len(xv) < 10: result[col] = 0.0; continue
        try:
            gm = xv.mean(); sst = ((xv-gm)**2).sum()
            if sst < 1e-12: result[col] = 0.0; continue
            ssb = sum(((xv[yv==c].mean()-gm)**2)*(yv==c).sum()
                      for c in np.unique(yv) if (yv==c).sum()>0)
            result[col] = float(np.clip(ssb/sst, 0, 1))
        except: result[col] = 0.0
    return result
