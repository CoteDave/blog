"""
Aperçu Global — summary statistics and quick charts.
"""

from __future__ import annotations

from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import pandas as pd
import numpy as np

CLASS_PALETTE = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6"]


def layout(dep) -> html.Div:
    df = dep.df
    num = dep.num_features

    # Metric cards
    n_rows = len(df)
    n_num  = len(num)
    n_cat  = len(dep.cat_features)
    n_miss = df.isnull().sum().sum()
    miss_pct = n_miss / (n_rows * len(df.columns)) * 100 if n_rows else 0

    metrics = [
        ("Observations",   f"{n_rows:,}",       "lignes",              ""),
        ("Variables num.", f"{n_num}",           "colonnes numériques", ""),
        ("Variables cat.", f"{n_cat}",           "colonnes catégorielles", ""),
        ("Valeurs NaN",    f"{n_miss:,}",        f"{miss_pct:.1f}% manquantes", "metric-accent"),
    ]

    if dep.supervised:
        cls1 = dep.classes[-1]
        rate = (dep.df[dep.target_name] == cls1).mean() * 100
        metrics.append(("Taux Classe 1", f"{rate:.1f}%", f"{len(dep.classes)} classes", ""))

    cards = [
        html.Div([
            html.Div(label, className="metric-label"),
            html.Div(val,   className=f"metric-value {accent}"),
            html.Div(sub,   className="metric-sub"),
        ], className="metric-card")
        for label, val, sub, accent in metrics
    ]

    return html.Div([
        html.Div("Aperçu Global", className="page-title"),
        html.Div("Vue d'ensemble du jeu de données chargé.", className="page-subtitle"),

        # Metric cards
        html.Div(cards, className="metric-cards"),

        # Charts row
        html.Div([
            # Distribution of first numeric feature
            html.Div([
                html.Div("Distribution — Variables Numériques", className="chart-card-title"),
                dcc.Graph(
                    id="overview-dist",
                    figure=_dist_figure(dep),
                    config={"displayModeBar": False},
                    style={"height": "280px"},
                ),
            ], className="chart-card"),

            # Target distribution (supervised) or 2D scatter (unsupervised)
            html.Div([
                html.Div(
                    "Distribution des Classes" if dep.supervised else "Scatter — 2 premières composantes",
                    className="chart-card-title",
                ),
                dcc.Graph(
                    id="overview-target",
                    figure=_target_figure(dep),
                    config={"displayModeBar": False},
                    style={"height": "280px"},
                ),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom": "18px"}),

        # Describe table
        html.Div([
            html.Div("Statistiques Descriptives", className="chart-card-title"),
            _describe_table(dep),
        ], className="chart-card"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:
    pass  # static page; no callbacks needed


# ─────────────────────────────────────────────────────────────────────────────

def _dist_figure(dep) -> go.Figure:
    num = dep.num_features[:6]  # max 6
    fig = go.Figure()
    palette = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6", "#1abc9c"]

    for i, col in enumerate(num):
        fig.add_trace(go.Box(
            y=dep.df[col],
            name=col,
            marker_color=palette[i % len(palette)],
            boxmean=True,
        ))

    fig.update_layout(
        plot_bgcolor="#f7f8fa",
        paper_bgcolor="#ffffff",
        margin=dict(l=40, r=10, t=10, b=60),
        showlegend=False,
        font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        xaxis=dict(tickangle=-30, gridcolor="#e0e4ea"),
        yaxis=dict(gridcolor="#e0e4ea", zeroline=False),
    )
    return fig


def _target_figure(dep) -> go.Figure:
    if dep.supervised and dep.is_classification:
        counts = [
            (dep.df[dep.target_name] == c).sum()
            for c in dep.classes
        ]
        pcts = [c / len(dep.df) * 100 for c in counts]
        fig = go.Figure(go.Bar(
            x=[f"Classe {c}" for c in dep.classes],
            y=pcts,
            marker_color=CLASS_PALETTE[:len(dep.classes)],
            text=[f"{p:.1f}%" for p in pcts],
            textposition="outside",
        ))
        fig.update_layout(
            plot_bgcolor="#f7f8fa",
            paper_bgcolor="#ffffff",
            margin=dict(l=40, r=10, t=10, b=40),
            showlegend=False,
            yaxis=dict(title="Proportion (%)", gridcolor="#e0e4ea", range=[0, 110]),
            xaxis=dict(gridcolor="#e0e4ea"),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )
        return fig
    else:
        # 2D scatter of first two features
        cols = dep.num_features
        if len(cols) < 2:
            return go.Figure()
        fig = go.Figure(go.Scatter(
            x=dep.df[cols[0]],
            y=dep.df[cols[1]],
            mode="markers",
            marker=dict(color="#4472c4", size=6, opacity=0.7),
        ))
        fig.update_layout(
            plot_bgcolor="#f7f8fa",
            paper_bgcolor="#ffffff",
            margin=dict(l=40, r=10, t=10, b=40),
            xaxis=dict(title=cols[0], gridcolor="#e0e4ea"),
            yaxis=dict(title=cols[1], gridcolor="#e0e4ea"),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )
        return fig


def _describe_table(dep) -> html.Table:
    num = dep.num_features[:8]
    desc = dep.df[num].describe().round(3)
    rows_out = []

    # Header
    header = html.Tr([html.Th("Stat.")] + [html.Th(c) for c in num])

    for stat in desc.index:
        cells = [html.Td(stat, style={"fontWeight": "600", "color": "#6b7a8d"})]
        for col in num:
            cells.append(html.Td(f"{desc.loc[stat, col]:.3g}"))
        rows_out.append(html.Tr(cells))

    return html.Table(
        [html.Thead(header), html.Tbody(rows_out)],
        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontSize": "12.5px",
            "fontFamily": "Plus Jakarta Sans, sans-serif",
        },
        className="desc-table",
    )
