"""
Importance des Variables — random-forest feature importance + correlation with target.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import numpy as np


def layout(dep) -> html.Div:
    return html.Div([
        html.Div("Importance des Variables", className="page-title"),
        html.Div(
            "Importance via Random Forest (supervisé) ou variance (non-supervisé).",
            className="page-subtitle",
        ),
        html.Div([
            html.Div([
                html.Div("Méthode:", className="control-label"),
                dcc.Dropdown(
                    id="imp-method",
                    options=[
                        {"label": "Random Forest", "value": "rf"},
                        {"label": "Corrélation |r|", "value": "corr"},
                        {"label": "Variance normalisée", "value": "var"},
                    ],
                    value="rf" if dep.supervised else "var",
                    clearable=False,
                    style={"width": "220px"},
                ),
            ], className="control-group"),
            html.Div([
                html.Div("Top N variables:", className="control-label"),
                dcc.Slider(id="imp-topn", min=5, max=min(30, len(dep.num_features)),
                           step=5, value=min(15, len(dep.num_features)),
                           marks={5: "5", 15: "15", 30: "30"}),
            ], className="control-group", style={"minWidth": "240px"}),
        ], className="controls-row"),

        dcc.Graph(
            id="imp-chart",
            config={"displayModeBar": False},
            style={"height": "500px"},
        ),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        Output("imp-chart", "figure"),
        [Input("imp-method", "value"), Input("imp-topn", "value")],
    )
    def update_imp(method, top_n):
        num = dep.num_features
        df  = dep.df[num]

        if method == "rf" and dep.supervised:
            try:
                from sklearn.ensemble import RandomForestClassifier
                rf = RandomForestClassifier(n_estimators=120, random_state=42, n_jobs=-1)
                rf.fit(dep.df[num].fillna(dep.df[num].median()), dep.y)
                scores = rf.feature_importances_
            except Exception:
                scores = np.std(df.fillna(0).values, axis=0)
                scores = scores / scores.sum()
        elif method == "corr" and dep.supervised:
            scores = np.array([
                abs(dep.df[c].fillna(dep.df[c].median()).corr(
                    dep.df[dep.target_name].fillna(0)))
                for c in num
            ])
        else:  # variance
            scores = np.std(df.fillna(0).values, axis=0)
            mx = scores.max()
            scores = scores / mx if mx > 0 else scores

        # Sort and clip
        order  = np.argsort(scores)[::-1][:top_n]
        feats  = [num[i] for i in order]
        vals   = [float(scores[i]) for i in order]

        # Gradient bar colors
        norm = np.array(vals) / max(vals) if max(vals) > 0 else np.array(vals)
        colors = [
            f"rgba({int(68 + (224 - 68) * (1 - n))},{int(114 + (123 - 114) * (1 - n))},{int(196 + (57 - 196) * (1 - n))},0.9)"
            for n in norm
        ]

        fig = go.Figure(go.Bar(
            y=feats[::-1], x=vals[::-1],
            orientation="h",
            marker_color=colors[::-1],
            text=[f"{v:.4f}" for v in vals[::-1]],
            textposition="outside",
        ))

        label = {
            "rf":   "Importance Random Forest",
            "corr": "Corrélation absolue avec Target",
            "var":  "Variance normalisée",
        }.get(method, "Score")

        fig.update_layout(
            xaxis=dict(title=label, gridcolor="#e0e4ea", zeroline=False),
            yaxis=dict(gridcolor="#e0e4ea"),
            plot_bgcolor="#f7f8fa",
            paper_bgcolor="#ffffff",
            margin=dict(l=180, r=80, t=20, b=50),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
            showlegend=False,
        )
        return fig
