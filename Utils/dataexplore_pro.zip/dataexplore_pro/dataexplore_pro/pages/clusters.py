"""
Analyse de Clusters — K-Means clustering with PCA projection.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import numpy as np

CLASS_PALETTE = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6", "#1abc9c", "#f39c12"]


def layout(dep) -> html.Div:
    num = dep.num_features

    return html.Div([
        html.Div("Analyse de Clusters", className="page-title"),
        html.Div("Partitionnement K-Means projeté en 2D via ACP.", className="page-subtitle"),

        html.Div([
            html.Div([
                html.Div("Nombre de clusters K:", className="control-label"),
                dcc.Slider(
                    id="clust-k", min=2, max=10, step=1, value=3,
                    marks={i: str(i) for i in range(2, 11)},
                ),
            ], className="control-group", style={"minWidth": "280px"}),
            html.Div([
                html.Div("Variables (PCA input):", className="control-label"),
                dcc.Dropdown(
                    id="clust-vars",
                    options=[{"label": c, "value": c} for c in num],
                    value=num[:10],
                    multi=True,
                    style={"minWidth": "320px"},
                ),
            ], className="control-group"),
        ], className="controls-row"),

        html.Div([
            html.Div([
                dcc.Graph(id="clust-scatter", config={"displayModeBar": False},
                          style={"height": "420px"}),
            ], className="chart-card"),
            html.Div([
                dcc.Graph(id="clust-elbow", config={"displayModeBar": False},
                          style={"height": "420px"}),
            ], className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("clust-scatter", "figure"), Output("clust-elbow", "figure")],
        [Input("clust-k", "value"), Input("clust-vars", "value")],
    )
    def update_clusters(k, vars_sel):
        from sklearn.cluster import KMeans
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler

        if not vars_sel or len(vars_sel) < 2:
            return go.Figure(), go.Figure()

        cols = [c for c in vars_sel if c in dep.num_features]
        X = dep.df[cols].fillna(dep.df[cols].median()).values
        X = StandardScaler().fit_transform(X)

        # ── Elbow curve ──
        ks = range(2, min(11, len(X)))
        inertias = []
        for ki in ks:
            km = KMeans(n_clusters=ki, random_state=42, n_init=10)
            km.fit(X)
            inertias.append(km.inertia_)

        fig_elbow = go.Figure(go.Scatter(
            x=list(ks), y=inertias,
            mode="lines+markers",
            line=dict(color="#4472c4", width=2),
            marker=dict(size=8, color="#e07b39"),
        ))
        fig_elbow.add_vline(x=k, line_dash="dash", line_color="#e74c3c",
                             annotation_text=f"K={k}", annotation_position="top right")
        fig_elbow.update_layout(
            title="Courbe d'inertie (méthode du coude)",
            xaxis=dict(title="K", gridcolor="#e0e4ea"),
            yaxis=dict(title="Inertie", gridcolor="#e0e4ea"),
            plot_bgcolor="#f7f8fa", paper_bgcolor="#ffffff",
            margin=dict(l=60, r=20, t=40, b=50),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )

        # ── K-Means + PCA scatter ──
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(X)

        pca = PCA(n_components=2)
        X2 = pca.fit_transform(X)
        var1, var2 = pca.explained_variance_ratio_[:2] * 100

        fig_sc = go.Figure()
        for ci in range(k):
            mask = labels == ci
            fig_sc.add_trace(go.Scatter(
                x=X2[mask, 0], y=X2[mask, 1],
                mode="markers", name=f"Cluster {ci}",
                marker=dict(
                    color=CLASS_PALETTE[ci % len(CLASS_PALETTE)],
                    size=7, opacity=0.82,
                    line=dict(width=0.5, color="rgba(255,255,255,0.6)"),
                ),
            ))

        fig_sc.update_layout(
            title=f"Clusters K-Means (K={k}) — Projection ACP",
            xaxis=dict(title=f"PC1 ({var1:.1f}%)", gridcolor="#e0e4ea", zeroline=False),
            yaxis=dict(title=f"PC2 ({var2:.1f}%)", gridcolor="#e0e4ea", zeroline=False),
            plot_bgcolor="#f7f8fa", paper_bgcolor="#ffffff",
            margin=dict(l=60, r=20, t=50, b=50),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
            legend=dict(font=dict(size=11)),
        )
        return fig_sc, fig_elbow
