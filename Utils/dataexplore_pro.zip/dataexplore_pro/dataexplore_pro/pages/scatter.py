"""
Analyse Bivariée — Diagrammes de Dispersion
Scatter plot page with lasso selection and real-time stats panel.
"""

from __future__ import annotations

from dash import dcc, html, Input, Output, no_update
import plotly.graph_objects as go
import pandas as pd
import numpy as np

# ─────────────────────────────────────────────────────────────────────────────
#  Color helpers
# ─────────────────────────────────────────────────────────────────────────────

CLASS_PALETTE = [
    "#4472c4",  # blue  (Class 0)
    "#e07b39",  # orange (Class 1)
    "#27ae60",  # green
    "#e74c3c",  # red
    "#9b59b6",  # purple
    "#1abc9c",  # teal
]

PLOT_BG = "#f7f8fa"
GRID_COLOR = "#e0e4ea"


def _class_color(dep, class_val) -> str:
    idx = dep.classes.index(class_val) if class_val in dep.classes else 0
    return CLASS_PALETTE[idx % len(CLASS_PALETTE)]


# ─────────────────────────────────────────────────────────────────────────────
#  Layout
# ─────────────────────────────────────────────────────────────────────────────

def layout(dep) -> html.Div:
    num_cols = dep.num_features
    x_default = num_cols[0] if num_cols else None
    y_default = num_cols[1] if len(num_cols) > 1 else x_default

    # Target filter options
    target_opts = [{"label": "Tout", "value": "__all__"}]
    if dep.supervised:
        for c in dep.classes:
            target_opts.append({"label": f"Classe {c}", "value": str(c)})

    col_opts = [{"label": c, "value": c} for c in num_cols]

    return html.Div([
        html.Div("Analyse Bivariée — Diagrammes de Dispersion", className="page-title"),

        # ── Controls ────────────────────────────────────────────────────
        html.Div([
            html.Div([
                html.Div("Sélectionner Variable X:", className="control-label"),
                dcc.Dropdown(
                    id="scatter-x-col",
                    options=col_opts,
                    value=x_default,
                    clearable=False,
                    style={"fontFamily": "Plus Jakarta Sans, sans-serif"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Sélectionner Variable Y:", className="control-label"),
                dcc.Dropdown(
                    id="scatter-y-col",
                    options=col_opts,
                    value=y_default,
                    clearable=False,
                    style={"fontFamily": "Plus Jakarta Sans, sans-serif"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Filtrer par Target:", className="control-label"),
                dcc.Dropdown(
                    id="scatter-target-filter",
                    options=target_opts,
                    value="__all__",
                    clearable=False,
                    style={"fontFamily": "Plus Jakarta Sans, sans-serif"},
                ),
            ], className="control-group", style={"maxWidth": "260px"}),
        ], className="controls-row"),

        # ── Scatter + Stats ──────────────────────────────────────────────
        html.Div([
            # Main scatter graph
            html.Div([
                dcc.Graph(
                    id="scatter-graph",
                    config={
                        "displayModeBar": True,
                        "modeBarButtonsToAdd": ["lasso2d", "select2d"],
                        "modeBarButtonsToRemove": ["toImage"],
                        "scrollZoom": True,
                    },
                    style={"height": "520px"},
                    animate=False,
                )
            ]),

            # Right stats panel
            html.Div([
                html.Div("Détails de la Sélection (Lasso)", className="stats-panel-title"),
                html.Div(id="scatter-lasso-stats"),
                html.Div(id="scatter-lasso-charts"),
            ], className="stats-panel"),
        ], className="scatter-layout"),
    ], className="page-card")


# ─────────────────────────────────────────────────────────────────────────────
#  Callbacks
# ─────────────────────────────────────────────────────────────────────────────

def register_callbacks(app, dep) -> None:

    @app.callback(
        Output("scatter-graph", "figure"),
        [
            Input("scatter-x-col", "value"),
            Input("scatter-y-col", "value"),
            Input("scatter-target-filter", "value"),
        ],
    )
    def update_scatter(x_col, y_col, target_filter):
        if x_col is None or y_col is None:
            return go.Figure()

        df = dep.df.copy()

        # Apply target filter
        if target_filter != "__all__" and dep.supervised:
            try:
                val = type(dep.classes[0])(target_filter)
                df = df[df[dep.target_name] == val]
            except (ValueError, IndexError):
                pass

        fig = go.Figure()

        if dep.supervised:
            for cls in dep.classes:
                mask = df[dep.target_name] == cls
                sub = df[mask]
                color = _class_color(dep, cls)
                fig.add_trace(go.Scatter(
                    x=sub[x_col],
                    y=sub[y_col],
                    mode="markers",
                    name=f"Classe {cls}",
                    marker=dict(
                        color=color,
                        size=8,
                        opacity=0.82,
                        line=dict(width=0.5, color="rgba(255,255,255,0.6)"),
                    ),
                    text=sub.index,
                    customdata=sub[dep.target_name] if dep.supervised else None,
                    hovertemplate=(
                        f"<b>Target: %{{customdata}}</b><br>"
                        f"{x_col}: %{{x:.2f}}<br>"
                        f"{y_col}: %{{y:,.0f}}<extra></extra>"
                    ),
                ))
        else:
            fig.add_trace(go.Scatter(
                x=df[x_col],
                y=df[y_col],
                mode="markers",
                name="Données",
                marker=dict(
                    color="#4472c4",
                    size=8,
                    opacity=0.8,
                    line=dict(width=0.5, color="rgba(255,255,255,0.6)"),
                ),
                hovertemplate=f"{x_col}: %{{x:.2f}}<br>{y_col}: %{{y:,.0f}}<extra></extra>",
            ))

        fig.update_layout(
            dragmode="lasso",
            plot_bgcolor=PLOT_BG,
            paper_bgcolor="#ffffff",
            margin=dict(l=54, r=16, t=20, b=54),
            xaxis=dict(
                title=dict(text=x_col, font=dict(size=12, color="#6b7a8d")),
                gridcolor=GRID_COLOR,
                linecolor=GRID_COLOR,
                showgrid=True,
                zeroline=False,
                tickfont=dict(size=11),
            ),
            yaxis=dict(
                title=dict(text=y_col, font=dict(size=12, color="#6b7a8d")),
                gridcolor=GRID_COLOR,
                linecolor=GRID_COLOR,
                showgrid=True,
                zeroline=False,
                tickfont=dict(size=11),
            ),
            legend=dict(
                orientation="v",
                x=1.01, y=1,
                font=dict(size=12),
                bgcolor="rgba(255,255,255,.85)",
                borderwidth=1,
                bordercolor=GRID_COLOR,
            ),
            font=dict(family="Plus Jakarta Sans, sans-serif"),
            hoverlabel=dict(
                bgcolor="#1e3a5f",
                font_size=12,
                font_family="Plus Jakarta Sans, sans-serif",
                font_color="white",
                bordercolor="#1e3a5f",
            ),
            uirevision="scatter",  # keep zoom between updates
        )
        return fig

    # ── Lasso stats ────────────────────────────────────────────────────

    @app.callback(
        [
            Output("scatter-lasso-stats",  "children"),
            Output("scatter-lasso-charts", "children"),
        ],
        [
            Input("scatter-graph",       "selectedData"),
            Input("scatter-x-col",       "value"),
            Input("scatter-y-col",       "value"),
        ],
    )
    def update_lasso_stats(selectedData, x_col, y_col):
        df = dep.df

        # --- No selection: show global stats ---
        if not selectedData or not selectedData.get("points"):
            return _default_stats(dep, df, x_col, y_col), _default_charts(dep, df, x_col)

        # --- Extract selected rows ---
        indices = []
        for pt in selectedData["points"]:
            if "pointIndex" in pt:
                indices.append(pt["pointIndex"])
            elif "text" in pt:
                try:
                    indices.append(int(pt["text"]))
                except (ValueError, TypeError):
                    pass

        if not indices:
            return _default_stats(dep, df, x_col, y_col), _default_charts(dep, df, x_col)

        sub = df.iloc[indices]

        # Build stat rows
        rows = [
            ("Nb points sélectionnés", f"{len(sub):,}"),
        ]

        if x_col:
            rows.append((f"{x_col} Moyen", f"{sub[x_col].mean():.2f}"))
        if y_col:
            rows.append((f"{y_col} Moyen", f"{sub[y_col].mean():,.1f}"))

        if dep.supervised and dep.is_classification:
            cls1 = dep.classes[-1]
            rate = (sub[dep.target_name] == cls1).mean()
            rows.append((f"Taux Target (Classe {cls1})", f"{rate:.0%}"))

        stat_els = [
            html.Div([
                html.Span(label, className="stat-label"),
                html.Span(value, className="stat-value"),
            ], className="stat-row")
            for label, value in rows
        ]

        return stat_els, _selection_charts(dep, sub, x_col)


# ─────────────────────────────────────────────────────────────────────────────
#  Helper builders
# ─────────────────────────────────────────────────────────────────────────────

def _default_stats(dep, df, x_col, y_col):
    rows = [("Nb points sélectionnés", f"{len(df):,} (global)")]
    if x_col:
        rows.append((f"{x_col} Moyen", f"{df[x_col].mean():.2f}"))
    if y_col:
        rows.append((f"{y_col} Moyen", f"{df[y_col].mean():,.1f}"))
    if dep.supervised and dep.is_classification:
        cls1 = dep.classes[-1]
        rate = (df[dep.target_name] == cls1).mean()
        rows.append((f"Taux Target (Classe {cls1})", f"{rate:.0%}"))

    return [
        html.Div([
            html.Span(label, className="stat-label"),
            html.Span(value, className="stat-value"),
        ], className="stat-row")
        for label, value in rows
    ] + [html.Div("← Utilisez le lasso pour sélectionner des points",
                  style={"fontSize": "11.5px", "color": "#6b7a8d",
                         "marginTop": "10px", "fontStyle": "italic"})]


def _default_charts(dep, df, x_col):
    return _selection_charts(dep, df, x_col, title_suffix="(global)")


def _selection_charts(dep, sub, x_col, title_suffix="(Lasso)"):
    charts = []

    # ── Target distribution bar chart ──
    if dep.supervised and dep.is_classification:
        cats, counts, colors = [], [], []
        for cls in dep.classes:
            n = (sub[dep.target_name] == cls).sum()
            cats.append(f"Classe {cls}")
            counts.append(n)
            colors.append(_class_color_by_idx(dep.classes.index(cls)))

        total = len(sub)
        pcts = [c / total * 100 if total else 0 for c in counts]

        bar_fig = go.Figure(go.Bar(
            x=cats, y=pcts,
            marker_color=colors,
            text=[f"{p:.0f}%" for p in pcts],
            textposition="outside",
        ))
        bar_fig.update_layout(
            **_mini_layout(f"Répartition Target {title_suffix}"),
            yaxis=dict(range=[0, 110], showgrid=False, visible=False),
            showlegend=False,
        )
        charts.append(html.Div([
            html.Div(f"Répartition Target {title_suffix}",
                     className="chart-card-title"),
            dcc.Graph(figure=bar_fig, config={"displayModeBar": False},
                      style={"height": "160px"}),
        ]))

    # ── X variable histogram ──
    if x_col and x_col in sub.columns:
        hist_fig = go.Figure(go.Histogram(
            x=sub[x_col],
            nbinsx=15,
            marker_color="#4472c4",
            opacity=0.85,
        ))
        hist_fig.update_layout(**_mini_layout(f"Distribution {x_col} {title_suffix}"))
        charts.append(html.Div([
            html.Div(f"Distribution {x_col} {title_suffix}",
                     className="chart-card-title"),
            dcc.Graph(figure=hist_fig, config={"displayModeBar": False},
                      style={"height": "160px"}),
        ]))

    return charts


def _mini_layout(title=""):
    return dict(
        plot_bgcolor="#f7f8fa",
        paper_bgcolor="#ffffff",
        margin=dict(l=6, r=6, t=6, b=30),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        xaxis=dict(
            gridcolor="#e0e4ea",
            showgrid=True,
            zeroline=False,
            tickfont=dict(size=10),
        ),
        yaxis=dict(
            gridcolor="#e0e4ea",
            showgrid=True,
            zeroline=False,
            tickfont=dict(size=10),
        ),
    )


def _class_color_by_idx(idx: int) -> str:
    return CLASS_PALETTE[idx % len(CLASS_PALETTE)]
