"""
app_factory.py — assembles the full Dash application.
"""

from __future__ import annotations
import os
from typing import TYPE_CHECKING

import dash
from dash import dcc, html, Input, Output, ctx
import dash_bootstrap_components as dbc

if TYPE_CHECKING:
    from .core import DataExplorePro

SIDEBAR_ITEMS = [
    ("overview",      "⊞",  "Aperçu Global"),
    ("scatter",       "◎",  "Diagrammes de Dispersion"),
    ("correlation",   "⊟",  "Matrices de Corrélation"),
    ("analysis3d",    "⬡",  "Analyses 3D"),
    ("importance",    "≡",  "Importance des Variables"),
    ("missing",       "▦",  "Valeurs Manquantes (NaN)"),
    ("clusters",      "◑",  "Analyse de Clusters"),
    ("pca",           "⊕",  "Analyse en Composantes Principales (ACP)"),
    ("corr_clusters", "⊞",  "Clusters de Corrélation"),
    ("causal",        "→",  "Découverte Causale"),
    ("posthoc",       "⊶",  "Analyses Post Hoc"),
    ("anova",         "∿",  "ANOVA Fonctionnelle"),
    ("synthesis",     "★",  "Synthèse et Conclusions Scientifiques"),
]

SIDEBAR_DIVIDERS_AFTER = {"scatter", "pca", "missing"}

PAGE_TO_NAV = {
    "overview":    "Exploration de Données",
    "scatter":     "Analyse Bivariée",
    "correlation": "Exploration de Données",
    "analysis3d":  "Analyses 3D",
    "importance":  "Exploration de Données",
    "missing":     "Exploration de Données",
    "clusters":    "Exploration de Données",
    "pca":         "Analyse Univariée",
    "univariate":  "Analyse Univariée",
}

NAV_TABS = [
    ("Analyses 3D",           "analysis3d"),
    ("Exploration de Données","overview"),
    ("Analyse Univariée",     "univariate"),
    ("Analyse Bivariée",      "scatter"),
]

STUB_PAGES = {"corr_clusters", "causal", "posthoc", "anova", "synthesis"}


def create_app(dep):
    assets_dir = os.path.join(os.path.dirname(__file__), "assets")
    app = dash.Dash(
        __name__,
        external_stylesheets=[
            dbc.themes.BOOTSTRAP,
            "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap",
        ],
        suppress_callback_exceptions=True,
        title=dep.title,
        assets_folder=assets_dir,
    )
    app.layout = _build_layout(dep)
    _register_callbacks(app, dep)
    return app


def _build_layout(dep):
    return html.Div([
        dcc.Store(id="active-page", data="scatter"),
        # Header
        html.Header([
            html.Div([
                html.Div(
                    html.Span("◰", style={"fontSize": "20px", "color": "white", "lineHeight": "1"}),
                    className="logo-icon-wrap",
                ),
                html.Span(
                    ["Data", html.Span("Explore", style={"color": "#e07b39"}), " Pro"],
                    className="logo-text",
                ),
            ], className="logo"),
            html.Nav([
                html.Button(
                    label,
                    id={"type": "nav-tab", "index": page_id},
                    n_clicks=0,
                    className="nav-tab-btn" + (" active" if label == "Analyse Bivariée" else ""),
                )
                for label, page_id in NAV_TABS
            ], className="nav-tabs-bar"),
        ], className="app-header"),
        # Body
        html.Div([
            html.Aside(_build_sidebar(), className="sidebar", id="sidebar"),
            html.Main(id="page-content", className="page-content"),
        ], className="app-body"),
    ], className="app-wrapper", style={"fontFamily": "Plus Jakarta Sans, sans-serif"})


def _build_sidebar():
    items = []
    for page_id, symbol, label in SIDEBAR_ITEMS:
        is_active = page_id == "scatter"
        items.append(html.Div(
            [
                html.Span(symbol, style={
                    "fontSize": "16px", "width": "22px", "textAlign": "center",
                    "flexShrink": "0", "display": "inline-block",
                }),
                html.Span(label, style={"fontSize": "13px", "lineHeight": "1.35"}),
            ],
            id={"type": "sidebar-item", "index": page_id},
            className="sidebar-item" + (" active" if is_active else ""),
            n_clicks=0,
            title=label,
            style=_sidebar_item_style(is_active),
        ))
        if page_id in SIDEBAR_DIVIDERS_AFTER:
            items.append(html.Hr(style={"borderColor": "rgba(255,255,255,.1)", "margin": "6px 14px"}))
    return items


def _sidebar_item_style(is_active=False):
    return {
        "display": "flex", "alignItems": "center", "gap": "10px",
        "padding": "9px 14px", "borderRadius": "6px", "cursor": "pointer",
        "transition": "background .16s",
        "color": "white" if is_active else "rgba(255,255,255,.75)",
        "background": "#152d4a" if is_active else "transparent",
        "fontWeight": "600" if is_active else "500",
    }


def _register_callbacks(app, dep):
    from .pages.scatter     import register_callbacks as scatter_cb
    from .pages.overview    import register_callbacks as overview_cb
    from .pages.correlation import register_callbacks as correlation_cb
    from .pages.univariate  import register_callbacks as univariate_cb
    from .pages.analysis_3d import register_callbacks as analysis3d_cb
    from .pages.importance  import register_callbacks as importance_cb
    from .pages.missing     import register_callbacks as missing_cb
    from .pages.clusters    import register_callbacks as clusters_cb
    from .pages.pca         import register_callbacks as pca_cb

    scatter_cb(app, dep)
    overview_cb(app, dep)
    correlation_cb(app, dep)
    univariate_cb(app, dep)
    analysis3d_cb(app, dep)
    importance_cb(app, dep)
    missing_cb(app, dep)
    clusters_cb(app, dep)
    pca_cb(app, dep)

    @app.callback(
        [
            Output("active-page", "data"),
            Output({"type": "sidebar-item", "index": dash.ALL}, "className"),
            Output({"type": "sidebar-item", "index": dash.ALL}, "style"),
        ],
        [
            Input({"type": "sidebar-item", "index": dash.ALL}, "n_clicks"),
            Input({"type": "nav-tab",      "index": dash.ALL}, "n_clicks"),
        ],
        prevent_initial_call=True,
    )
    def navigate(sb_clicks, nav_clicks):
        triggered = ctx.triggered_id
        if not triggered:
            return _nav_outputs("scatter")
        page_id = triggered.get("index", "scatter") if isinstance(triggered, dict) else "scatter"
        return _nav_outputs(page_id)

    @app.callback(
        Output("page-content", "children"),
        Input("active-page", "data"),
    )
    def render_page(page_id):
        return _get_page_layout(dep, page_id or "scatter")

    @app.callback(
        Output({"type": "nav-tab", "index": dash.ALL}, "className"),
        Input("active-page", "data"),
    )
    def highlight_nav(page_id):
        active_section = PAGE_TO_NAV.get(page_id or "scatter", "")
        return [
            "nav-tab-btn active" if label == active_section else "nav-tab-btn"
            for label, _ in NAV_TABS
        ]


def _nav_outputs(page_id):
    classes, styles = [], []
    for pid, _, _ in SIDEBAR_ITEMS:
        active = pid == page_id
        classes.append("sidebar-item active" if active else "sidebar-item")
        styles.append(_sidebar_item_style(active))
    return page_id, classes, styles


def _get_page_layout(dep, page_id):
    from .pages.scatter     import layout as scatter_layout
    from .pages.overview    import layout as overview_layout
    from .pages.correlation import layout as correlation_layout
    from .pages.univariate  import layout as univariate_layout
    from .pages.analysis_3d import layout as analysis3d_layout
    from .pages.importance  import layout as importance_layout
    from .pages.missing     import layout as missing_layout
    from .pages.clusters    import layout as clusters_layout
    from .pages.pca         import layout as pca_layout
    from .pages.stubs       import layout as stub_layout

    page_map = {
        "scatter":     scatter_layout,
        "overview":    overview_layout,
        "correlation": correlation_layout,
        "univariate":  univariate_layout,
        "analysis3d":  analysis3d_layout,
        "importance":  importance_layout,
        "missing":     missing_layout,
        "clusters":    clusters_layout,
        "pca":         pca_layout,
    }

    if page_id in page_map:
        return page_map[page_id](dep)
    if page_id in STUB_PAGES:
        return stub_layout(dep, page_id)
    return scatter_layout(dep)
