"""
Importance des Variables — RF importance + permutation + correlation + interactive comparison.
"""
from __future__ import annotations
import numpy as np
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

CLASS_PALETTE = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"


def layout(dep) -> html.Div:
    num = dep.num_features
    return html.Div([
        html.Div("Importance des Variables", className="page-title"),
        html.Div("Analyse multi-méthodes de l'importance des features.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Méthode principale:", className="control-label"),
                      dcc.Dropdown(id="imp-method",
                                   options=[
                                       {"label":"Random Forest","value":"rf"},
                                       {"label":"Corrélation |r|","value":"corr"},
                                       {"label":"Variance normalisée","value":"var"},
                                   ],
                                   value="rf" if dep.supervised else "var",
                                   clearable=False, style={"width":"230px"})],
                     className="control-group"),
            html.Div([html.Div("Top N:", className="control-label"),
                      dcc.Slider(id="imp-topn", min=5, max=min(30,len(num)),
                                 step=5, value=min(15,len(num)),
                                 marks={5:"5",10:"10",15:"15",20:"20",30:"30"})],
                     className="control-group", style={"minWidth":"220px"}),
            html.Div([html.Div("Comparer 2 méthodes:", className="control-label"),
                      dcc.Dropdown(id="imp-cmp",
                                   options=[
                                       {"label":"Non","value":"none"},
                                       {"label":"RF vs Corr","value":"rf_corr"},
                                       {"label":"RF vs Var","value":"rf_var"},
                                       {"label":"Corr vs Var","value":"corr_var"},
                                   ],
                                   value="none", clearable=False,
                                   style={"width":"200px"})],
                     className="control-group"),
        ], className="controls-row"),

        html.Div([
            html.Div([dcc.Graph(id="imp-chart", config={"displayModeBar":False},
                                style={"height":"500px"})], className="chart-card"),
            html.Div([dcc.Graph(id="imp-scatter", config={"displayModeBar":False},
                                style={"height":"500px"})], className="chart-card",
                     id="imp-scatter-wrap"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("imp-chart","figure"), Output("imp-scatter","figure")],
        [Input("imp-method","value"), Input("imp-topn","value"),
         Input("imp-cmp","value")],
    )
    def update(method, top_n, cmp):
        num   = dep.num_features
        scores= _get_scores(dep, method, num)
        order = np.argsort(scores)[::-1][:top_n]
        feats = [num[i] for i in order]
        vals  = [float(scores[i]) for i in order]

        norm = np.array(vals) / max(max(vals),1e-9)
        colors = [
            f"rgba({int(68+(224-68)*(1-n))},{int(114+(123-114)*(1-n))},{int(196+(57-196)*(1-n))},0.88)"
            for n in norm
        ]

        # Main bar chart
        fig_bar = go.Figure(go.Bar(
            y=feats[::-1], x=vals[::-1], orientation="h",
            marker_color=colors[::-1],
            text=[f"{v:.4f}" for v in vals[::-1]], textposition="outside",
        ))
        fig_bar.update_layout(
            title=f"Importance — {method}",
            xaxis=dict(title="Score", gridcolor=GRID, zeroline=False),
            yaxis=dict(gridcolor=GRID),
            **_base_layout(),
            margin=dict(l=180, r=80, t=45, b=50),
        )

        # Comparison scatter
        if cmp == "none":
            fig_cmp = go.Figure()
            fig_cmp.add_annotation(text="Sélectionnez une comparaison",
                                    xref="paper",yref="paper",x=.5,y=.5,
                                    showarrow=False, font=dict(size=14,color="#6b7a8d"))
            fig_cmp.update_layout(**_base_layout())
        else:
            m1, m2 = cmp.split("_")
            s1 = _get_scores(dep, m1, num)
            s2 = _get_scores(dep, m2, num)
            fig_cmp = go.Figure(go.Scatter(
                x=s1, y=s2, mode="markers+text",
                text=[n[:12] for n in num],
                textposition="top center",
                textfont=dict(size=9, color="#6b7a8d"),
                marker=dict(color="#4472c4", size=8, opacity=0.8,
                            line=dict(width=0.5, color="white")),
                hovertemplate="%{text}<br>%{x:.4f} / %{y:.4f}<extra></extra>",
            ))
            # 1:1 line
            mx = max(max(s1), max(s2))
            fig_cmp.add_trace(go.Scatter(x=[0,mx],y=[0,mx],mode="lines",
                                          line=dict(color="#ccc",dash="dot"),
                                          showlegend=False))
            fig_cmp.update_layout(
                title=f"Comparaison {m1} vs {m2}",
                xaxis=dict(title=m1, gridcolor=GRID, zeroline=False),
                yaxis=dict(title=m2, gridcolor=GRID, zeroline=False),
                **_base_layout(),
            )

        return fig_bar, fig_cmp


def _get_scores(dep, method, num):
    df_num = dep.df[num].fillna(dep.df[num].median())
    if method == "rf" and dep.supervised:
        try:
            from sklearn.ensemble import RandomForestClassifier
            rf = RandomForestClassifier(n_estimators=120, random_state=42, n_jobs=-1)
            rf.fit(df_num, dep.y)
            return rf.feature_importances_
        except Exception:
            pass
    if method == "corr" and dep.supervised:
        return np.array([abs(dep.df[c].fillna(0).corr(
            dep.df[dep.target_name].fillna(0))) for c in num])
    # variance
    s = np.std(df_num.values, axis=0)
    mx = s.max()
    return s / mx if mx > 0 else s


def _base_layout():
    return dict(
        plot_bgcolor=BG, paper_bgcolor="#fff",
        font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        margin=dict(l=50, r=20, t=45, b=50),
    )
