"""
Analyse en Composantes Principales (ACP) — PCA biplot, scree, loadings.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np

CLASS_PALETTE = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6"]


def layout(dep) -> html.Div:
    num = dep.num_features
    max_comp = min(10, len(num))

    return html.Div([
        html.Div("Analyse en Composantes Principales (ACP)", className="page-title"),
        html.Div("Réduction de dimensionnalité et visualisation des structures latentes.", className="page-subtitle"),

        html.Div([
            html.Div([
                html.Div("Nb composantes:", className="control-label"),
                dcc.Slider(id="pca-n", min=2, max=max_comp, step=1, value=min(5, max_comp),
                           marks={i: str(i) for i in range(2, max_comp + 1)}),
            ], className="control-group", style={"minWidth": "260px"}),
            html.Div([
                html.Div("Axes du biplot (X / Y):", className="control-label"),
                html.Div([
                    dcc.Dropdown(id="pca-pc-x", value=1,
                                 options=[{"label": f"PC{i}", "value": i} for i in range(1, max_comp + 1)],
                                 clearable=False, style={"width": "110px"}),
                    dcc.Dropdown(id="pca-pc-y", value=2,
                                 options=[{"label": f"PC{i}", "value": i} for i in range(1, max_comp + 1)],
                                 clearable=False, style={"width": "110px"}),
                ], style={"display": "flex", "gap": "10px"}),
            ], className="control-group"),
        ], className="controls-row"),

        html.Div([
            html.Div([dcc.Graph(id="pca-biplot", config={"displayModeBar": False},
                                style={"height": "440px"})], className="chart-card"),
            html.Div([dcc.Graph(id="pca-scree",  config={"displayModeBar": False},
                                style={"height": "440px"})], className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("pca-biplot", "figure"), Output("pca-scree", "figure")],
        [Input("pca-n", "value"), Input("pca-pc-x", "value"), Input("pca-pc-y", "value")],
    )
    def update_pca(n_comp, pc_x, pc_y):
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler

        num = dep.num_features
        X = dep.df[num].fillna(dep.df[num].median()).values
        X = StandardScaler().fit_transform(X)

        pca = PCA(n_components=n_comp, random_state=42)
        scores = pca.fit_transform(X)
        loadings = pca.components_

        var_ratio = pca.explained_variance_ratio_ * 100

        xi, yi = pc_x - 1, pc_y - 1

        # ── Biplot ──
        fig_bp = go.Figure()

        if dep.supervised:
            for i, cls in enumerate(dep.classes):
                mask = dep.y == cls
                fig_bp.add_trace(go.Scatter(
                    x=scores[mask, xi], y=scores[mask, yi],
                    mode="markers",
                    name=f"Classe {cls}",
                    marker=dict(color=CLASS_PALETTE[i % len(CLASS_PALETTE)],
                                size=7, opacity=0.75,
                                line=dict(width=0.5, color="rgba(255,255,255,0.5)")),
                ))
        else:
            fig_bp.add_trace(go.Scatter(
                x=scores[:, xi], y=scores[:, yi],
                mode="markers",
                marker=dict(color="#4472c4", size=7, opacity=0.75),
            ))

        # Loading arrows (scale to scores range)
        scale = max(abs(scores[:, xi]).max(), abs(scores[:, yi]).max()) * 0.5
        for j, feat in enumerate(num[:10]):  # limit arrows
            fig_bp.add_annotation(
                ax=0, ay=0, axref="x", ayref="y",
                x=float(loadings[xi, j]) * scale,
                y=float(loadings[yi, j]) * scale,
                arrowhead=2, arrowsize=1, arrowwidth=1.5,
                arrowcolor="rgba(231,76,60,0.7)",
                showarrow=True,
            )
            fig_bp.add_annotation(
                x=float(loadings[xi, j]) * scale * 1.15,
                y=float(loadings[yi, j]) * scale * 1.15,
                text=feat[:12], showarrow=False,
                font=dict(size=9, color="#e74c3c"),
            )

        fig_bp.update_layout(
            title=f"Biplot ACP — PC{pc_x} vs PC{pc_y}",
            xaxis=dict(title=f"PC{pc_x} ({var_ratio[xi]:.1f}%)", gridcolor="#e0e4ea", zeroline=True, zerolinecolor="#ccc"),
            yaxis=dict(title=f"PC{pc_y} ({var_ratio[yi]:.1f}%)", gridcolor="#e0e4ea", zeroline=True, zerolinecolor="#ccc"),
            plot_bgcolor="#f7f8fa", paper_bgcolor="#ffffff",
            margin=dict(l=60, r=20, t=50, b=50),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )

        # ── Scree plot ──
        cum_var = np.cumsum(var_ratio)
        fig_sc = go.Figure()
        fig_sc.add_trace(go.Bar(
            x=[f"PC{i+1}" for i in range(n_comp)],
            y=var_ratio,
            name="Variance individuelle",
            marker_color="#4472c4", opacity=0.85,
        ))
        fig_sc.add_trace(go.Scatter(
            x=[f"PC{i+1}" for i in range(n_comp)],
            y=cum_var,
            name="Variance cumulée",
            mode="lines+markers",
            line=dict(color="#e07b39", width=2),
            marker=dict(size=7),
            yaxis="y2",
        ))
        fig_sc.update_layout(
            title="Diagramme d'éboulis (Scree Plot)",
            xaxis=dict(title="Composante", gridcolor="#e0e4ea"),
            yaxis=dict(title="Variance expliquée (%)", gridcolor="#e0e4ea"),
            yaxis2=dict(title="Variance cumulée (%)", overlaying="y", side="right",
                        range=[0, 105], showgrid=False),
            plot_bgcolor="#f7f8fa", paper_bgcolor="#ffffff",
            margin=dict(l=60, r=60, t=50, b=50),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
            legend=dict(font=dict(size=11), x=0.5, y=1.12, orientation="h"),
            barmode="group",
        )
        return fig_bp, fig_sc
