"""
Aperçu Global — Variables grouped by dtype + dataset summary cards.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output, dash_table
import plotly.graph_objects as go

CLASS_PALETTE = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6"]
GRID_CLR = "#e0e4ea"
PLOT_BG  = "#f7f8fa"

# ── dtype grouping ────────────────────────────────────────────────────────────
def _classify_col(series: pd.Series) -> str:
    if pd.api.types.is_bool_dtype(series):
        return "Booléen"
    if pd.api.types.is_integer_dtype(series):
        return "Entier"
    if pd.api.types.is_float_dtype(series):
        return "Flottant"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "Date/Heure"
    if pd.api.types.is_categorical_dtype(series):
        return "Catégoriel"
    if series.nunique() <= 20 and pd.api.types.is_object_dtype(series):
        return "Catégoriel"
    return "Texte"


def layout(dep) -> html.Div:
    df   = dep.df
    cols = [c for c in df.columns if c != dep.target_name]

    # ── Metric cards ──────────────────────────────────────────────────────────
    n_rows   = len(df)
    n_num    = len(dep.num_features)
    n_cat    = len(dep.cat_features)
    n_miss   = int(df.isnull().sum().sum())
    miss_pct = n_miss / max(1, n_rows * len(df.columns)) * 100

    metric_cards = html.Div([
        _mcard("Observations",   f"{n_rows:,}",   "lignes"),
        _mcard("Variables num.", f"{n_num}",       "numériques"),
        _mcard("Variables cat.", f"{n_cat}",       "catégorielles"),
        _mcard("Valeurs NaN",    f"{n_miss:,}",    f"{miss_pct:.1f}%", accent=n_miss > 0),
        _mcard("Classes Target", f"{dep.n_classes}" if dep.supervised else "—",
               dep.target_name if dep.supervised else "non supervisé"),
    ], className="metric-cards")

    # ── Variable groups ───────────────────────────────────────────────────────
    groups: dict[str, list] = {}
    for c in cols:
        dtype_lbl = _classify_col(df[c])
        groups.setdefault(dtype_lbl, []).append(c)

    group_sections = []
    TYPE_ICONS = {
        "Flottant":    "🔢", "Entier": "🔢",
        "Catégoriel":  "🏷️", "Booléen": "🔘",
        "Date/Heure":  "📅", "Texte":  "📝",
    }
    for dtype_lbl in ["Flottant","Entier","Catégoriel","Booléen","Date/Heure","Texte"]:
        if dtype_lbl not in groups:
            continue
        group_cols = groups[dtype_lbl]
        icon = TYPE_ICONS.get(dtype_lbl, "📊")
        rows = _build_var_table(df, group_cols, dtype_lbl)
        group_sections.append(html.Div([
            html.Div([
                html.Span(icon, style={"marginRight":"8px","fontSize":"16px"}),
                html.Span(f"{dtype_lbl}  ·  {len(group_cols)} variable{'s' if len(group_cols)>1 else ''}",
                          style={"fontWeight":"700","fontSize":"14px","color":"#1e3a5f"}),
            ], style={"marginBottom":"10px","display":"flex","alignItems":"center"}),
            rows,
        ], className="chart-card", style={"marginBottom":"16px"}))

    # ── Quick charts ──────────────────────────────────────────────────────────
    quick_charts = html.Div([
        html.Div([
            html.Div("Distribution — 6 premières variables", className="chart-card-title"),
            dcc.Graph(figure=_box_figure(dep), config={"displayModeBar":False},
                      style={"height":"300px"}),
        ], className="chart-card"),
        html.Div([
            html.Div("Target" if dep.supervised else "Scatter 2D", className="chart-card-title"),
            dcc.Graph(figure=_target_figure(dep), config={"displayModeBar":False},
                      style={"height":"300px"}),
        ], className="chart-card"),
    ], className="charts-grid", style={"marginBottom":"18px"})

    return html.Div([
        html.Div("Aperçu Global — Explorer le Jeu de Données", className="page-title"),
        html.Div("Résumé automatique des variables, types, statistiques et distributions.",
                 className="page-subtitle"),
        metric_cards,
        quick_charts,
        html.Div("📋 Variables par Type de Données",
                 style={"fontWeight":"800","fontSize":"17px","color":"#1e3a5f",
                        "marginBottom":"14px","marginTop":"4px"}),
        html.Div(group_sections),
    ], className="page-card")


def register_callbacks(app, dep) -> None:
    pass


# ── Builders ─────────────────────────────────────────────────────────────────

def _mcard(label, value, sub, accent=False):
    return html.Div([
        html.Div(label, className="metric-label"),
        html.Div(value, className="metric-value" + (" metric-accent" if accent else "")),
        html.Div(sub,   className="metric-sub"),
    ], className="metric-card")


def _build_var_table(df: pd.DataFrame, cols: list[str], dtype_lbl: str) -> html.Div:
    """Rich variable table: name | dtype | n_unique | missing | min/max or top values | sparkline."""
    is_numeric = dtype_lbl in ("Flottant", "Entier")

    header_cells = ["Variable", "Dtype", "N uniques", "% NaN"]
    if is_numeric:
        header_cells += ["Min", "Max", "Moyenne", "Std"]
    else:
        header_cells += ["Top valeurs"]

    header = html.Tr([
        html.Th(h, style=_th_style()) for h in header_cells
    ])

    body_rows = []
    for col in cols:
        s = df[col]
        n_unique = s.nunique()
        pct_nan  = s.isnull().mean() * 100
        nan_clr  = "#e74c3c" if pct_nan > 20 else "#e07b39" if pct_nan > 5 else "#6b7a8d"

        base_cells = [
            html.Td(html.Span(col, style={"fontWeight":"600","color":"#1e3a5f","fontSize":"12px"})),
            html.Td(html.Span(str(s.dtype),
                              style={"background":"#eef2ff","color":"#4472c4","borderRadius":"4px",
                                     "padding":"1px 6px","fontSize":"10.5px","fontWeight":"600"})),
            html.Td(f"{n_unique:,}", style=_td_style()),
            html.Td(f"{pct_nan:.1f}%", style={**_td_style(),"color":nan_clr,"fontWeight":"600"}),
        ]

        if is_numeric:
            s_num = s.dropna()
            if len(s_num):
                extra = [
                    html.Td(f"{s_num.min():.3g}", style=_td_style()),
                    html.Td(f"{s_num.max():.3g}", style=_td_style()),
                    html.Td(f"{s_num.mean():.3g}", style=_td_style()),
                    html.Td(f"{s_num.std():.3g}", style=_td_style()),
                ]
            else:
                extra = [html.Td("—", style=_td_style())] * 4
        else:
            top = s.value_counts().head(3)
            top_str = "  ·  ".join([f"{v} ({n})" for v, n in top.items()])
            extra = [html.Td(top_str[:60],
                             style={**_td_style(),"maxWidth":"240px","overflow":"hidden",
                                    "textOverflow":"ellipsis","whiteSpace":"nowrap"})]

        body_rows.append(html.Tr(base_cells + extra,
                                  style={"borderBottom":"1px solid #f0f4f8"}))

    return html.Table(
        [html.Thead(header), html.Tbody(body_rows)],
        style={"width":"100%","borderCollapse":"collapse",
               "fontSize":"12px","fontFamily":"Plus Jakarta Sans, sans-serif"},
    )


def _th_style():
    return {
        "padding":"6px 10px","background":"#f0f4f8","color":"#6b7a8d",
        "fontWeight":"700","fontSize":"11px","textTransform":"uppercase",
        "letterSpacing":".5px","textAlign":"left","borderBottom":"2px solid #e0e4ea",
    }

def _td_style():
    return {"padding":"5px 10px","color":"#374151","fontSize":"12px"}


def _box_figure(dep) -> go.Figure:
    num = dep.num_features[:6]
    PAL = CLASS_PALETTE
    fig = go.Figure()
    for i, col in enumerate(num):
        fig.add_trace(go.Box(y=dep.df[col], name=col[:14],
                             marker_color=PAL[i % len(PAL)], boxmean=True,
                             line_width=1.5))
    fig.update_layout(
        plot_bgcolor=PLOT_BG, paper_bgcolor="#fff",
        margin=dict(l=40, r=10, t=10, b=70),
        showlegend=False,
        font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        xaxis=dict(tickangle=-30, gridcolor=GRID_CLR),
        yaxis=dict(gridcolor=GRID_CLR, zeroline=False),
    )
    return fig


def _target_figure(dep) -> go.Figure:
    if dep.supervised and dep.is_classification:
        counts = [(dep.df[dep.target_name] == c).sum() for c in dep.classes]
        pcts   = [c / len(dep.df) * 100 for c in counts]
        fig = go.Figure(go.Bar(
            x=[f"Classe {c}" for c in dep.classes],
            y=pcts,
            marker_color=CLASS_PALETTE[:len(dep.classes)],
            text=[f"{p:.1f}%" for p in pcts], textposition="outside",
        ))
        fig.update_layout(
            plot_bgcolor=PLOT_BG, paper_bgcolor="#fff",
            margin=dict(l=40, r=10, t=10, b=40), showlegend=False,
            yaxis=dict(title="%", gridcolor=GRID_CLR, range=[0,115]),
            xaxis=dict(gridcolor=GRID_CLR),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )
    else:
        cols = dep.num_features
        if len(cols) < 2:
            return go.Figure()
        fig = go.Figure(go.Scatter(
            x=dep.df[cols[0]], y=dep.df[cols[1]],
            mode="markers", marker=dict(color="#4472c4", size=6, opacity=0.7),
        ))
        fig.update_layout(
            plot_bgcolor=PLOT_BG, paper_bgcolor="#fff",
            margin=dict(l=40, r=10, t=10, b=40),
            xaxis=dict(title=cols[0], gridcolor=GRID_CLR),
            yaxis=dict(title=cols[1], gridcolor=GRID_CLR),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )
    return fig
