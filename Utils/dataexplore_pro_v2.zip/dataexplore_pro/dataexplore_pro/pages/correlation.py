"""
Matrices de Corrélation — correlation heatmap with clustering option.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import plotly.figure_factory as ff
import numpy as np


def layout(dep) -> html.Div:
    num = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]

    return html.Div([
        html.Div("Matrices de Corrélation", className="page-title"),
        html.Div(
            "Corrélation de Pearson entre toutes les variables numériques.",
            className="page-subtitle",
        ),
        html.Div([
            html.Div([
                html.Div("Méthode:", className="control-label"),
                dcc.Dropdown(
                    id="corr-method",
                    options=[
                        {"label": "Pearson",  "value": "pearson"},
                        {"label": "Spearman", "value": "spearman"},
                        {"label": "Kendall",  "value": "kendall"},
                    ],
                    value="pearson",
                    clearable=False,
                    style={"width": "180px"},
                ),
            ], className="control-group"),
            html.Div([
                html.Div("Variables (max 20):", className="control-label"),
                dcc.Dropdown(
                    id="corr-vars",
                    options=col_opts,
                    value=num[:15],
                    multi=True,
                    style={"minWidth": "320px"},
                ),
            ], className="control-group"),
        ], className="controls-row"),

        dcc.Graph(
            id="corr-heatmap",
            config={"displayModeBar": True},
            style={"height": "560px"},
        ),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        Output("corr-heatmap", "figure"),
        [Input("corr-method", "value"), Input("corr-vars", "value")],
    )
    def update_corr(method, vars_sel):
        if not vars_sel or len(vars_sel) < 2:
            return go.Figure()

        cols = [c for c in vars_sel if c in dep.num_features][:20]
        corr = dep.df[cols].corr(method=method).round(3)

        z = corr.values
        labels = list(corr.columns)

        # Custom red-white-blue colorscale
        colorscale = [
            [0.0, "#e74c3c"],
            [0.5, "#ffffff"],
            [1.0, "#4472c4"],
        ]

        fig = go.Figure(go.Heatmap(
            z=z,
            x=labels, y=labels,
            colorscale=colorscale,
            zmid=0, zmin=-1, zmax=1,
            text=[[f"{v:.2f}" for v in row] for row in z],
            texttemplate="%{text}",
            textfont={"size": 10},
            hovertemplate="%{x} vs %{y}: <b>%{z:.3f}</b><extra></extra>",
        ))

        fig.update_layout(
            plot_bgcolor="#ffffff",
            paper_bgcolor="#ffffff",
            margin=dict(l=100, r=20, t=30, b=100),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
            xaxis=dict(tickangle=-45, side="bottom"),
            coloraxis_colorbar=dict(title="r"),
        )
        return fig
