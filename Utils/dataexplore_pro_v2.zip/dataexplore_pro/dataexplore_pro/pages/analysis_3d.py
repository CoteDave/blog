"""
Analyses 3D — interactive 3-D scatter plot.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

CLASS_PALETTE = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6"]


def layout(dep) -> html.Div:
    num = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]

    defaults = num[:3] + [None] * max(0, 3 - len(num))

    return html.Div([
        html.Div("Analyses 3D", className="page-title"),
        html.Div("Explorez les relations entre trois variables simultanément.", className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Axe X:", className="control-label"),
                      dcc.Dropdown(id="a3d-x", options=col_opts, value=defaults[0], clearable=False,
                                   style={"width": "220px"})], className="control-group"),
            html.Div([html.Div("Axe Y:", className="control-label"),
                      dcc.Dropdown(id="a3d-y", options=col_opts, value=defaults[1], clearable=False,
                                   style={"width": "220px"})], className="control-group"),
            html.Div([html.Div("Axe Z:", className="control-label"),
                      dcc.Dropdown(id="a3d-z", options=col_opts, value=defaults[2], clearable=False,
                                   style={"width": "220px"})], className="control-group"),
            html.Div([html.Div("Taille des points:", className="control-label"),
                      dcc.Slider(id="a3d-size", min=3, max=14, step=1, value=7,
                                 marks={3: "3", 7: "7", 14: "14"})],
                     className="control-group", style={"minWidth": "200px"}),
        ], className="controls-row"),

        dcc.Graph(
            id="a3d-graph",
            config={"displayModeBar": True},
            style={"height": "560px"},
        ),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        Output("a3d-graph", "figure"),
        [Input("a3d-x", "value"), Input("a3d-y", "value"),
         Input("a3d-z", "value"), Input("a3d-size", "value")],
    )
    def update_3d(x_col, y_col, z_col, pt_size):
        if not all([x_col, y_col, z_col]):
            return go.Figure()

        df = dep.df
        fig = go.Figure()

        if dep.supervised:
            for i, cls in enumerate(dep.classes):
                mask = df[dep.target_name] == cls
                sub  = df[mask]
                fig.add_trace(go.Scatter3d(
                    x=sub[x_col], y=sub[y_col], z=sub[z_col],
                    mode="markers",
                    name=f"Classe {cls}",
                    marker=dict(
                        color=CLASS_PALETTE[i % len(CLASS_PALETTE)],
                        size=pt_size, opacity=0.82,
                        line=dict(width=0.3, color="rgba(255,255,255,0.5)"),
                    ),
                ))
        else:
            fig.add_trace(go.Scatter3d(
                x=df[x_col], y=df[y_col], z=df[z_col],
                mode="markers",
                marker=dict(color="#4472c4", size=pt_size, opacity=0.8),
            ))

        fig.update_layout(
            scene=dict(
                xaxis=dict(title=x_col, backgroundcolor="#f7f8fa", gridcolor="#e0e4ea"),
                yaxis=dict(title=y_col, backgroundcolor="#f7f8fa", gridcolor="#e0e4ea"),
                zaxis=dict(title=z_col, backgroundcolor="#f7f8fa", gridcolor="#e0e4ea"),
            ),
            paper_bgcolor="#ffffff",
            margin=dict(l=0, r=0, t=20, b=0),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
            legend=dict(font=dict(size=12)),
        )
        return fig
