"""
Valeurs Manquantes (NaN) — heatmap + summary table.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import numpy as np


def layout(dep) -> html.Div:
    return html.Div([
        html.Div("Valeurs Manquantes (NaN)", className="page-title"),
        html.Div("Visualisation et résumé des données manquantes.", className="page-subtitle"),

        html.Div([
            html.Div([
                dcc.Graph(id="miss-heatmap", config={"displayModeBar": False},
                          style={"height": "420px"}),
            ], className="chart-card"),
            html.Div([
                dcc.Graph(id="miss-bar", config={"displayModeBar": False},
                          style={"height": "420px"}),
            ], className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("miss-heatmap", "figure"), Output("miss-bar", "figure")],
        Input("miss-heatmap", "id"),  # dummy trigger on load
    )
    def update_missing(_):
        df   = dep.df[dep.num_features]
        miss = df.isnull()

        # ── Heatmap ──
        sample = miss.sample(min(200, len(miss)), random_state=42) if len(miss) > 200 else miss

        fig_heat = go.Figure(go.Heatmap(
            z=sample.values.astype(int),
            x=sample.columns.tolist(),
            y=[f"Obs {i}" for i in sample.index],
            colorscale=[[0, "#f0f4f8"], [1, "#e74c3c"]],
            showscale=True,
            colorbar=dict(
                tickvals=[0, 1],
                ticktext=["Présent", "Manquant"],
                lenmode="fraction", len=0.5,
            ),
            hovertemplate="%{x}: %{z}<extra></extra>",
        ))
        fig_heat.update_layout(
            title="Carte des valeurs manquantes",
            plot_bgcolor="#ffffff",
            paper_bgcolor="#ffffff",
            margin=dict(l=60, r=20, t=40, b=80),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            xaxis=dict(tickangle=-40),
        )

        # ── Bar ──
        pct_miss = miss.mean() * 100
        pct_miss = pct_miss[pct_miss > 0].sort_values(ascending=False)

        if len(pct_miss) == 0:
            fig_bar = go.Figure()
            fig_bar.add_annotation(
                text="✅ Aucune valeur manquante détectée",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16, color="#27ae60"),
            )
        else:
            colors = [
                "#e74c3c" if v > 20 else "#e07b39" if v > 5 else "#4472c4"
                for v in pct_miss.values
            ]
            fig_bar = go.Figure(go.Bar(
                y=pct_miss.index.tolist(),
                x=pct_miss.values,
                orientation="h",
                marker_color=colors,
                text=[f"{v:.1f}%" for v in pct_miss.values],
                textposition="outside",
            ))
            fig_bar.update_layout(
                title="% Valeurs manquantes par variable",
                xaxis=dict(title="%", range=[0, 110], gridcolor="#e0e4ea"),
                yaxis=dict(autorange="reversed"),
            )

        fig_bar.update_layout(
            plot_bgcolor="#f7f8fa",
            paper_bgcolor="#ffffff",
            margin=dict(l=160, r=60, t=40, b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        )
        return fig_heat, fig_bar
