"""
Analyse Univariée — histograms, box plots, violin plots per variable.
"""

from __future__ import annotations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np

CLASS_PALETTE = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6"]


def layout(dep) -> html.Div:
    num = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]

    return html.Div([
        html.Div("Analyse Univariée", className="page-title"),
        html.Div("Distribution détaillée de chaque variable numérique.", className="page-subtitle"),

        html.Div([
            html.Div([
                html.Div("Variable:", className="control-label"),
                dcc.Dropdown(
                    id="uni-col",
                    options=col_opts,
                    value=num[0] if num else None,
                    clearable=False,
                    style={"width": "280px"},
                ),
            ], className="control-group"),
            html.Div([
                html.Div("Type de graphique:", className="control-label"),
                dcc.Dropdown(
                    id="uni-type",
                    options=[
                        {"label": "Histogramme",  "value": "hist"},
                        {"label": "Box Plot",     "value": "box"},
                        {"label": "Violin Plot",  "value": "violin"},
                        {"label": "ECDF",         "value": "ecdf"},
                    ],
                    value="hist",
                    clearable=False,
                    style={"width": "200px"},
                ),
            ], className="control-group"),
            html.Div([
                html.Div("Grouper par Target:", className="control-label"),
                dcc.Dropdown(
                    id="uni-group",
                    options=[
                        {"label": "Non", "value": "no"},
                        {"label": "Oui", "value": "yes"},
                    ],
                    value="yes" if dep.supervised else "no",
                    clearable=False,
                    style={"width": "120px"},
                    disabled=not dep.supervised,
                ),
            ], className="control-group"),
        ], className="controls-row"),

        html.Div([
            html.Div([
                dcc.Graph(id="uni-main", config={"displayModeBar": False},
                          style={"height": "380px"}),
            ], className="chart-card"),
            html.Div([
                dcc.Graph(id="uni-stats-chart", config={"displayModeBar": False},
                          style={"height": "380px"}),
            ], className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("uni-main", "figure"), Output("uni-stats-chart", "figure")],
        [Input("uni-col", "value"), Input("uni-type", "value"), Input("uni-group", "value")],
    )
    def update_uni(col, chart_type, group):
        if col is None:
            return go.Figure(), go.Figure()

        df = dep.df
        group_by = dep.supervised and group == "yes"

        # ── Main chart ──
        fig_main = go.Figure()
        if group_by:
            for i, cls in enumerate(dep.classes):
                sub = df[df[dep.target_name] == cls][col].dropna()
                clr = CLASS_PALETTE[i % len(CLASS_PALETTE)]
                name = f"Classe {cls}"

                if chart_type == "hist":
                    fig_main.add_trace(go.Histogram(
                        x=sub, name=name, marker_color=clr,
                        opacity=0.72, nbinsx=25,
                    ))
                    fig_main.update_layout(barmode="overlay")
                elif chart_type == "box":
                    fig_main.add_trace(go.Box(
                        y=sub, name=name, marker_color=clr, boxmean=True,
                    ))
                elif chart_type == "violin":
                    fig_main.add_trace(go.Violin(
                        y=sub, name=name, fillcolor=clr,
                        line_color=clr, opacity=0.75,
                        box_visible=True, meanline_visible=True,
                    ))
                elif chart_type == "ecdf":
                    sorted_x = np.sort(sub)
                    ecdf_y = np.arange(1, len(sorted_x) + 1) / len(sorted_x)
                    fig_main.add_trace(go.Scatter(
                        x=sorted_x, y=ecdf_y, name=name,
                        line=dict(color=clr, width=2), mode="lines",
                    ))
        else:
            sub = df[col].dropna()
            clr = "#4472c4"
            if chart_type == "hist":
                fig_main.add_trace(go.Histogram(
                    x=sub, marker_color=clr, opacity=0.85, nbinsx=30,
                ))
            elif chart_type == "box":
                fig_main.add_trace(go.Box(y=sub, marker_color=clr, boxmean=True))
            elif chart_type == "violin":
                fig_main.add_trace(go.Violin(
                    y=sub, fillcolor=clr, line_color=clr,
                    box_visible=True, meanline_visible=True,
                ))
            elif chart_type == "ecdf":
                sorted_x = np.sort(sub)
                ecdf_y = np.arange(1, len(sorted_x) + 1) / len(sorted_x)
                fig_main.add_trace(go.Scatter(
                    x=sorted_x, y=ecdf_y, mode="lines",
                    line=dict(color=clr, width=2),
                ))

        fig_main.update_layout(**_base_layout(col))

        # ── Stats summary chart ──
        stats = df[col].describe()
        fig_stats = go.Figure(go.Bar(
            y=["count", "mean", "std", "min", "25%", "50%", "75%", "max"],
            x=[stats.get(k, 0) for k in ["count", "mean", "std", "min", "25%", "50%", "75%", "max"]],
            orientation="h",
            marker_color="#4472c4",
            text=[f"{stats.get(k, 0):.3g}" for k in ["count", "mean", "std", "min", "25%", "50%", "75%", "max"]],
            textposition="outside",
        ))
        fig_stats.update_layout(
            title=f"Statistiques — {col}",
            **_base_layout(""),
            xaxis=dict(visible=False),
        )

        return fig_main, fig_stats


def _base_layout(title):
    return dict(
        plot_bgcolor="#f7f8fa",
        paper_bgcolor="#ffffff",
        margin=dict(l=50, r=16, t=30, b=50),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        xaxis=dict(gridcolor="#e0e4ea", zeroline=False),
        yaxis=dict(gridcolor="#e0e4ea", zeroline=False),
        legend=dict(font=dict(size=11)),
        title=dict(text=title, font=dict(size=13)),
    )
