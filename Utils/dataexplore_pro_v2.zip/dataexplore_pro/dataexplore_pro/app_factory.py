"""
app_factory.py — assembles the full Dash application.
"""
from __future__ import annotations
import os
import dash
from dash import dcc, html, Input, Output, ctx
import dash_bootstrap_components as dbc

SIDEBAR_ITEMS = [
    ("overview",      "⊞",  "Aperçu Global"),
    ("scatter",       "◎",  "Diagrammes de Dispersion"),
    ("correlation",   "⊟",  "Matrices de Corrélation"),
    ("analysis3d",    "⬡",  "Analyses 3D"),
    ("importance",    "≡",  "Importance des Variables"),
    ("missing",       "▦",  "Valeurs Manquantes (NaN)"),
    ("clusters",      "◑",  "Analyse de Clusters"),
    ("pca",           "⊕",  "Analyse en Composantes Principales (ACP)"),
    ("corr_clusters", "⊞",  "Clusters de Corrélation"),
    ("causal",        "→",  "Découverte Causale"),
    ("posthoc",       "⊶",  "Analyses Post Hoc"),
    ("anova",         "∿",  "ANOVA Fonctionnelle"),
    ("synthesis",     "★",  "Synthèse et Conclusions Scientifiques"),
]

SIDEBAR_DIVIDERS_AFTER = {"scatter", "pca", "missing"}

PAGE_TO_NAV = {
    "overview":     "Exploration de Données",
    "scatter":      "Analyse Bivariée",
    "correlation":  "Exploration de Données",
    "analysis3d":   "Analyses 3D",
    "importance":   "Exploration de Données",
    "missing":      "Exploration de Données",
    "clusters":     "Analyse Clusters",
    "pca":          "Analyse Univariée",
    "univariate":   "Analyse Univariée",
    "corr_clusters":"Exploration de Données",
}

NAV_TABS = [
    ("Analyses 3D",           "analysis3d"),
    ("Exploration de Données","overview"),
    ("Analyse Univariée",     "univariate"),
    ("Analyse Bivariée",      "scatter"),
    ("Analyse Clusters",      "clusters"),
]

STUB_PAGES = {"causal", "posthoc", "anova", "synthesis"}


def create_app(dep):
    assets_dir = os.path.join(os.path.dirname(__file__), "assets")
    app = dash.Dash(
        __name__,
        external_stylesheets=[
            dbc.themes.BOOTSTRAP,
            "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap",
        ],
        suppress_callback_exceptions=True,
        title=dep.title,
        assets_folder=assets_dir,
    )
    app.layout = _build_layout(dep)
    _register_callbacks(app, dep)
    return app


def _build_layout(dep):
    return html.Div([
        dcc.Store(id="active-page", data="scatter"),
        html.Header([
            html.Div([
                html.Div(
                    html.Span("◰", style={"fontSize":"20px","color":"white","lineHeight":"1"}),
                    className="logo-icon-wrap",
                ),
                html.Span(
                    ["Data", html.Span("Explore", style={"color":"#e07b39"}), " Pro"],
                    className="logo-text",
                ),
            ], className="logo"),
            html.Nav([
                html.Button(
                    label,
                    id={"type":"nav-tab","index":page_id},
                    n_clicks=0,
                    className="nav-tab-btn" + (" active" if label == "Analyse Bivariée" else ""),
                )
                for label, page_id in NAV_TABS
            ], className="nav-tabs-bar"),
        ], className="app-header"),
        html.Div([
            html.Aside(_build_sidebar(), className="sidebar", id="sidebar"),
            html.Main(id="page-content", className="page-content"),
        ], className="app-body"),
    ], className="app-wrapper", style={"fontFamily":"Plus Jakarta Sans, sans-serif"})


def _build_sidebar():
    items = []
    for page_id, symbol, label in SIDEBAR_ITEMS:
        is_active = page_id == "scatter"
        items.append(html.Div(
            [
                html.Span(symbol, style={"fontSize":"16px","width":"22px","textAlign":"center",
                                          "flexShrink":"0","display":"inline-block"}),
                html.Span(label, style={"fontSize":"13px","lineHeight":"1.35"}),
            ],
            id={"type":"sidebar-item","index":page_id},
            className="sidebar-item" + (" active" if is_active else ""),
            n_clicks=0, title=label,
            style=_sb_style(is_active),
        ))
        if page_id in SIDEBAR_DIVIDERS_AFTER:
            items.append(html.Hr(style={"borderColor":"rgba(255,255,255,.1)","margin":"6px 14px"}))
    return items


def _sb_style(active=False):
    return {
        "display":"flex","alignItems":"center","gap":"10px",
        "padding":"9px 14px","borderRadius":"6px","cursor":"pointer",
        "transition":"background .16s",
        "color":"white" if active else "rgba(255,255,255,.75)",
        "background":"#152d4a" if active else "transparent",
        "fontWeight":"600" if active else "500",
    }


def _register_callbacks(app, dep):
    from .pages.scatter      import register_callbacks as scatter_cb
    from .pages.overview     import register_callbacks as overview_cb
    from .pages.correlation  import register_callbacks as correlation_cb
    from .pages.univariate   import register_callbacks as univariate_cb
    from .pages.analysis_3d  import register_callbacks as analysis3d_cb
    from .pages.importance   import register_callbacks as importance_cb
    from .pages.missing      import register_callbacks as missing_cb
    from .pages.clusters     import register_callbacks as clusters_cb
    from .pages.pca          import register_callbacks as pca_cb
    from .pages.corr_clusters import register_callbacks as corr_clusters_cb

    scatter_cb(app, dep)
    overview_cb(app, dep)
    correlation_cb(app, dep)
    univariate_cb(app, dep)
    analysis3d_cb(app, dep)
    importance_cb(app, dep)
    missing_cb(app, dep)
    clusters_cb(app, dep)
    pca_cb(app, dep)
    corr_clusters_cb(app, dep)

    @app.callback(
        [Output("active-page","data"),
         Output({"type":"sidebar-item","index":dash.ALL},"className"),
         Output({"type":"sidebar-item","index":dash.ALL},"style")],
        [Input({"type":"sidebar-item","index":dash.ALL},"n_clicks"),
         Input({"type":"nav-tab",     "index":dash.ALL},"n_clicks")],
        prevent_initial_call=True,
    )
    def navigate(sb, nav):
        triggered = ctx.triggered_id
        if not triggered:
            return _nav_out("scatter")
        page_id = triggered.get("index","scatter") if isinstance(triggered,dict) else "scatter"
        return _nav_out(page_id)

    @app.callback(
        Output("page-content","children"),
        Input("active-page","data"),
    )
    def render_page(page_id):
        return _get_page(dep, page_id or "scatter")

    @app.callback(
        Output({"type":"nav-tab","index":dash.ALL},"className"),
        Input("active-page","data"),
    )
    def highlight_nav(page_id):
        active_nav = PAGE_TO_NAV.get(page_id or "scatter","")
        return ["nav-tab-btn active" if lbl == active_nav else "nav-tab-btn"
                for lbl, _ in NAV_TABS]


def _nav_out(page_id):
    classes, styles = [], []
    for pid, _, _ in SIDEBAR_ITEMS:
        a = pid == page_id
        classes.append("sidebar-item active" if a else "sidebar-item")
        styles.append(_sb_style(a))
    return page_id, classes, styles


def _get_page(dep, page_id):
    from .pages.scatter      import layout as sc
    from .pages.overview     import layout as ov
    from .pages.correlation  import layout as co
    from .pages.univariate   import layout as un
    from .pages.analysis_3d  import layout as a3
    from .pages.importance   import layout as im
    from .pages.missing      import layout as mi
    from .pages.clusters     import layout as cl
    from .pages.pca          import layout as pc
    from .pages.corr_clusters import layout as cc
    from .pages.stubs        import layout as st

    pages = {
        "scatter":      sc, "overview":    ov,
        "correlation":  co, "univariate":  un,
        "analysis3d":   a3, "importance":  im,
        "missing":      mi, "clusters":    cl,
        "pca":          pc, "corr_clusters": cc,
    }

    if page_id in pages:
        return pages[page_id](dep)
    if page_id in STUB_PAGES:
        return st(dep, page_id)
    return sc(dep)
