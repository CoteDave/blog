# DataExplore Pro v6

Application d'exploration de données ML — Python Dash.

## Installation rapide
```bash
unzip dataexplore_pro_v6.zip
cd dataexplore_pro
bash install_and_run.sh
```

## Nouvelles fonctionnalités v6
- **Régression OLS + IC 95%** sur le scatter (globale ou par classe)  
- **DBSCAN** en plus de K-Means (Clusters), avec k-distance auto  
- **Radar profile** des clusters (normalisé MinMax)  
- **Graphique secondaire contextuel** dans Analyse Univariée (jamais le même que le principal)  
- **Synthèse améliorée** : tableau features (skew, outliers, NaN) + alertes catégorisées  
- **CSS v6** : design system cohérent (variables CSS, animations, transitions)  
- **app_factory propre** : DEFAULT_PAGE=overview, Loading sur navigation, zéro dépendances cassées  
- **Bugs corrigés** : double-Loading SPLOM, typo boxviolon, cl-profile sans spinner  

## API
```python
from dataexplore_pro import DataExplorePro
dep = DataExplorePro(X, y, feature_names=[...], target_name='Target')
dep.run(host='127.0.0.1', port=8050, open_browser=True)
```
