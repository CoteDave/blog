"""
Interactions de Features v10 — "Means Interactions"
═══════════════════════════════════════════════════════════════════════════════
Analyse des interactions 2-3 features binned vs target :

  • Sélection 2 ou 3 features numériques (binning automatique ajustable)
  • Heatmap interactive : cellule = moyenne du target + test ANOVA
  • UpSet plot (intersection style) : barres des effectifs par combinaison
  • Table de règles : chaque combinaison → n, μ target, écart à la moyenne globale,
    test t (vs reste), Cohen's d, classé par impact
  • Régression OLS avec interactions (statsmodels) : tableau complet + R²
  • Export des règles en texte lisible (SI … ET … ALORS …)

Requiert : numpy, pandas, scipy, sklearn, plotly
Statsmodels optionnel (dégradation gracieuse si absent)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import product
from dash import dcc, html, Input, Output, State
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"

# Colorscales pour heatmap
CS_DIV  = [[0,"#b2182b"],[0.25,"#f4a582"],[0.5,"#f7f7f7"],[0.75,"#92c5de"],[1,"#2166ac"]]
CS_SEQ  = [[0,"#f7fbff"],[0.4,"#6baed6"],[0.7,"#2171b5"],[1,"#08306b"]]


def layout(dep):
    num = dep.num_features
    if not dep.supervised:
        return html.Div([
            html.Div("Interactions de Features", className="page-title"),
            html.Div("⚠️ Cette analyse requiert un dataset supervisé (avec target).",
                     className="page-subtitle"),
        ], className="page-card")

    is_cls = dep.is_classification
    tgt    = dep.target_name

    return html.Div([
        html.Div("Interactions de Features", className="page-title"),
        html.Div(
            f"Interactions 2–3 features binned vs target '{tgt}'. "
            "Heatmap · UpSet plot · Règles · Régression avec interactions.",
            className="page-subtitle"),

        # ── Controls ──────────────────────────────────────────────────
        html.Div([
            html.Div([html.Div("Feature A:", className="control-label"),
                      dcc.Dropdown(id="int-feat-a",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[0] if len(num)>0 else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Feature B:", className="control-label"),
                      dcc.Dropdown(id="int-feat-b",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[1] if len(num)>1 else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Feature C (optionnelle):", className="control-label"),
                      dcc.Dropdown(id="int-feat-c",
                          options=[{"label":"— Aucune —","value":""}]
                                  +[{"label":c,"value":c} for c in num],
                          value="", clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Bins par feature:", className="control-label"),
                      dcc.Slider(id="int-bins", min=2, max=6, step=1, value=3,
                          marks={i:str(i) for i in range(2,7)},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"200px"}),

            html.Div([html.Div("Seuil α:", className="control-label"),
                      dcc.Dropdown(id="int-alpha",
                          options=[{"label":"0.05","value":"0.05"},
                                   {"label":"0.01","value":"0.01"},
                                   {"label":"0.10","value":"0.10"}],
                          value="0.05", clearable=False, style={"width":"100px"})],
                className="control-group"),
        ], className="controls-row"),

        # ── Summary cards ─────────────────────────────────────────────
        html.Div(id="int-summary", style={"marginBottom":"16px"}),

        # ── Heatmap A×B ───────────────────────────────────────────────
        html.Div([
            html.Div([
                html.Div(id="int-heatmap-title", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="int-heatmap",
                    config={"displayModeBar":False}, style={"height":"400px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),

            html.Div([
                html.Div("UpSet Plot — Effectifs par combinaison",
                         className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="int-upset",
                    config={"displayModeBar":False}, style={"height":"400px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # ── Feature C slice (if selected) ──────────────────────────────
        html.Div(id="int-slice-section", style={"marginBottom":"16px"}),

        # ── Rules table ────────────────────────────────────────────────
        html.Div([
            html.Div("📋 Table de Règles — combinaisons classées par impact",
                     className="chart-card-title"),
            html.Div(id="int-rules-table"),
        ], className="chart-card", style={"marginBottom":"16px"}),

        # ── Regression with interactions ────────────────────────────────
        html.Div([
            html.Div("📐 Régression OLS avec termes d'interaction",
                     className="chart-card-title"),
            html.Div(id="int-regression"),
        ], className="chart-card"),

    ], className="page-card")


def register_callbacks(app, dep):

    _memo: dict = {}

    @app.callback(
        [Output("int-summary","children"),
         Output("int-heatmap","figure"),
         Output("int-heatmap-title","children"),
         Output("int-upset","figure"),
         Output("int-slice-section","children"),
         Output("int-rules-table","children"),
         Output("int-regression","children")],
        [Input("int-feat-a","value"),
         Input("int-feat-b","value"),
         Input("int-feat-c","value"),
         Input("int-bins","value"),
         Input("int-alpha","value")],
    )
    def update(feat_a, feat_b, feat_c, n_bins, alpha_str):
        alpha   = float(alpha_str or 0.05)
        n_bins  = int(n_bins or 3)
        feat_c  = feat_c or ""
        tgt     = dep.target_name
        is_cls  = dep.is_classification

        empty = go.Figure()
        if not feat_a or not feat_b or feat_a == feat_b:
            return (_err("Sélectionnez 2 features différentes."),
                    empty,"",empty,html.Div(),[],[])

        feats = [f for f in [feat_a, feat_b, feat_c] if f and f in dep.num_features]
        if len(feats) < 2:
            return (_err("Features invalides."), empty,"",empty,html.Div(),[],[])

        memo_key = (tuple(feats), n_bins, alpha)
        if memo_key in _memo:
            return _memo[memo_key]

        df = dep.display_df[[tgt]+feats].dropna()
        if len(df) < 20:
            return (_err("Données insuffisantes (n<20)."),empty,"",empty,html.Div(),[],[])

        y_raw  = df[tgt].values
        y_num  = _encode_target(y_raw, is_cls)
        y_mean = float(y_num.mean())
        y_std  = float(y_num.std(ddof=1))

        # ── Bin all features ─────────────────────────────────────────
        bin_cols = {}; bin_labels_map = {}
        for f in feats:
            vals = df[f].values
            try:
                q_edges = np.unique(np.percentile(vals, np.linspace(0,100,n_bins+1)))
                if len(q_edges) < 3:
                    q_edges = np.array([vals.min(), vals.median() if hasattr(vals,'median') else np.median(vals), vals.max()])
                cut_vals, cut_bins = pd.cut(vals, bins=q_edges, labels=False,
                                             include_lowest=True, duplicates="drop",
                                             retbins=True)
                n_actual = int(cut_vals.max())+1
                labels = []
                for bi in range(n_actual):
                    lo,hi = cut_bins[bi], cut_bins[bi+1]
                    labels.append(f"{lo:.3g}–{hi:.3g}")
                bin_cols[f]        = cut_vals.astype(float)
                bin_labels_map[f]  = labels
            except Exception:
                rank = pd.qcut(pd.Series(vals), q=n_bins, duplicates="drop", labels=False)
                bin_cols[f]       = rank.values.astype(float)
                bin_labels_map[f] = [f"Q{i+1}" for i in range(n_bins)]

        # ── Build interaction table ──────────────────────────────────
        bin_a = bin_cols[feat_a]; bin_b = bin_cols[feat_b]
        lbls_a = bin_labels_map[feat_a]; lbls_b = bin_labels_map[feat_b]
        na = len(lbls_a); nb = len(lbls_b)

        rules = _build_rules(df, y_num, y_mean, y_std, bin_cols, bin_labels_map,
                             feats, tgt, alpha)

        # ── Summary cards ─────────────────────────────────────────────
        n_sig = sum(1 for r in rules if r.get("sig"))
        n_tot = len(rules)
        best  = max(rules, key=lambda r: abs(r.get("cohens_d",0)), default=None)
        worst = min(rules, key=lambda r: r.get("mean",y_mean), default=None)
        best2 = max(rules, key=lambda r: r.get("mean",y_mean), default=None)

        summary = _summary_cards(n_tot, n_sig, alpha, best, worst, best2,
                                  y_mean, tgt, is_cls)

        # ── Heatmap A×B ───────────────────────────────────────────────
        mat_mean = np.full((na,nb), np.nan)
        mat_n    = np.full((na,nb), 0)
        mat_sig  = np.full((na,nb), False)

        for r in rules:
            if feat_c and len(feats)==3:
                # aggregate over C for main heatmap
                pass  # handled below for 2D only
            if r.get("feat_c") is None:
                ia,ib = r["ia"],r["ib"]
                if 0<=ia<na and 0<=ib<nb:
                    mat_mean[ia,ib] = r["mean"]
                    mat_n[ia,ib]    = r["n"]
                    mat_sig[ia,ib]  = r["sig"]

        if feat_c and len(feats)==3:
            # For 3D: heatmap is A×B marginalized over C
            for ia in range(na):
                for ib in range(nb):
                    grp = y_num[(bin_a==ia)&(bin_b==ib)]
                    if len(grp)>=2:
                        mat_mean[ia,ib] = float(grp.mean())
                        mat_n[ia,ib]    = len(grp)
                        rest = y_num[~((bin_a==ia)&(bin_b==ib))]
                        if len(rest)>=2:
                            _,p=sp_stats.ttest_ind(grp,rest,equal_var=False)
                            mat_sig[ia,ib] = bool(p<alpha)

        mat_rel = mat_mean - y_mean   # relative to global mean

        txt_heat = []
        for ia in range(na):
            row_txt=[]
            for ib in range(nb):
                if np.isnan(mat_mean[ia,ib]):
                    row_txt.append("–")
                else:
                    sign="▲" if mat_rel[ia,ib]>0 else "▼"
                    star="*" if mat_sig[ia,ib] else ""
                    row_txt.append(f"μ={mat_mean[ia,ib]:.3g}<br>"
                                   f"{sign}{abs(mat_rel[ia,ib]):.3g}{star}<br>"
                                   f"n={mat_n[ia,ib]:,}")
            txt_heat.append(row_txt)

        abs_max = float(np.nanmax(np.abs(mat_rel))) or 1.0
        fig_heat = go.Figure(go.Heatmap(
            z=mat_rel,
            x=[f"B:{l}" for l in lbls_b],
            y=[f"A:{l}" for l in lbls_a],
            colorscale=CS_DIV,
            zmid=0, zmin=-abs_max, zmax=abs_max,
            text=txt_heat, texttemplate="%{text}",
            textfont=dict(size=9, family=FONT),
            showscale=True,
            colorbar=dict(
                title=dict(text=f"Δμ({tgt[:12]})",
                           font=dict(size=10,family=FONT)),
                thickness=14, tickfont=dict(size=9),
            ),
            hovertemplate="<b>%{y} × %{x}</b><br>%{text}<extra></extra>",
        ))
        # Mark significant cells with border
        for ia in range(na):
            for ib in range(nb):
                if mat_sig[ia,ib]:
                    fig_heat.add_shape(type="rect",
                        x0=ib-0.5,x1=ib+0.5,y0=ia-0.5,y1=ia+0.5,
                        line=dict(color="#1e3a5f",width=2),
                        fillcolor="rgba(0,0,0,0)",layer="above")

        fig_heat.update_layout(
            plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=80,r=80,t=30,b=80),
            font=dict(family=FONT,size=10),
            xaxis=dict(tickangle=-30,tickfont=dict(size=10,color="#1e3a5f")),
            yaxis=dict(tickfont=dict(size=10,color="#1e3a5f")),
        )
        heatmap_title = (f"Heatmap μ({tgt[:18]}) — {feat_a[:16]} × {feat_b[:16]} "
                         f"(contour = sig. α={alpha})")

        # ── UpSet plot ───────────────────────────────────────────────
        fig_upset = _upset_plot(rules, feats, y_mean, tgt, alpha)

        # ── Feature C slices ─────────────────────────────────────────
        slice_section = html.Div()
        if feat_c and len(feats)==3:
            slice_section = _slice_heatmaps(df, y_num, y_mean, bin_cols, bin_labels_map,
                                             feat_a, feat_b, feat_c, lbls_a, lbls_b,
                                             bin_labels_map[feat_c], tgt, alpha)

        # ── Rules table ───────────────────────────────────────────────
        rules_table = _rules_table(rules, tgt, y_mean, alpha)

        # ── OLS Regression ───────────────────────────────────────────
        reg_section = _ols_regression(df, y_num, bin_cols, feats, bin_labels_map, tgt)

        result = (summary, fig_heat, heatmap_title, fig_upset,
                  slice_section, rules_table, reg_section)
        _memo[memo_key] = result
        return result


# ══════════════════════════════════════════════════════════════════════════════
#  STAT HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _encode_target(y, is_cls):
    if is_cls:
        from sklearn.preprocessing import LabelEncoder
        return LabelEncoder().fit_transform(y.astype(str)).astype(float)
    return y.astype(float)


def _build_rules(df, y_num, y_mean, y_std, bin_cols, bin_labels_map, feats, tgt, alpha):
    """Build one rule per combination of bins."""
    rules=[]
    feat_a, feat_b = feats[0], feats[1]
    feat_c = feats[2] if len(feats)==3 else None

    lbls_a=bin_labels_map[feat_a]; lbls_b=bin_labels_map[feat_b]
    na=len(lbls_a); nb=len(lbls_b)

    iter_c = range(len(bin_labels_map[feat_c])) if feat_c else [None]

    for ia,ib,ic in product(range(na),range(nb),iter_c):
        mask = (bin_cols[feat_a]==ia)&(bin_cols[feat_b]==ib)
        if ic is not None:
            mask = mask&(bin_cols[feat_c]==ic)
        grp  = y_num[mask]
        if len(grp)<3: continue
        rest = y_num[~mask]

        mu   = float(grp.mean())
        sd_g = float(grp.std(ddof=1)) if len(grp)>1 else 0.0
        sd_p = float(np.sqrt((grp.var(ddof=1)+rest.var(ddof=1))/2)) if len(rest)>1 else (sd_g or 1e-9)
        d    = (mu-y_mean)/max(sd_p,1e-9)
        p    = 1.0
        ci95 = 0.0
        if len(rest)>=3:
            try:
                _,p=sp_stats.ttest_ind(grp,rest,equal_var=False)
                se=float(np.sqrt(grp.var(ddof=1)/len(grp)+rest.var(ddof=1)/len(rest)))
                df_t=(se**2)**2/((grp.var(ddof=1)/len(grp))**2/max(len(grp)-1,1)+
                                  (rest.var(ddof=1)/len(rest))**2/max(len(rest)-1,1)+1e-12)
                ci95=float(sp_stats.t.ppf(0.975,df_t)*se)
            except: pass

        # Condition label
        cond=[f"{feat_a[:12]} ∈ [{lbls_a[ia]}]",
              f"{feat_b[:12]} ∈ [{lbls_b[ib]}]"]
        if ic is not None:
            cond.append(f"{feat_c[:12]} ∈ [{bin_labels_map[feat_c][ic]}]")
        rule_text = " ET ".join(cond)

        rules.append(dict(
            ia=ia, ib=ib, ic=ic, feat_c=feat_c,
            mask_idxs=np.where(mask)[0],
            label=rule_text,
            cond_parts=cond,
            n=int(len(grp)),
            mean=mu, delta=mu-y_mean,
            cohens_d=d, ci95=ci95, p=p,
            sig=bool(p<alpha),
        ))
    rules.sort(key=lambda r: abs(r["cohens_d"]), reverse=True)
    return rules


# ══════════════════════════════════════════════════════════════════════════════
#  FIGURE BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _summary_cards(n_tot, n_sig, alpha, best, worst, best2, y_mean, tgt, is_cls):
    def _card(icon,label,value,sub,clr):
        return html.Div([
            html.Div(icon,style={"fontSize":"22px"}),
            html.Div(value,style={"fontSize":"20px","fontWeight":"800","color":clr,"fontFamily":FONT}),
            html.Div(label,style={"fontSize":"10px","fontWeight":"700","color":"#6b7a8d",
                "textTransform":"uppercase","letterSpacing":".3px"}),
            html.Div(sub,style={"fontSize":"10px","color":"#9aa5b4","marginTop":"2px"}),
        ],style={"background":"white","borderRadius":"10px","padding":"12px 16px",
                 "flex":"1","minWidth":"140px","boxShadow":"0 1px 6px rgba(0,0,0,.07)",
                 "borderLeft":f"4px solid {clr}"})

    worst_info = f"μ={worst['mean']:.3g} (Δ={worst['delta']:+.3g})" if worst else "—"
    best2_info = f"μ={best2['mean']:.3g} (Δ={best2['delta']:+.3g})" if best2 else "—"
    best_d = f"|d|={abs(best['cohens_d']):.2f}" if best else "—"

    return html.Div([
        _card("🔢","Combinaisons",str(n_tot),"groupes non vides","#4472c4"),
        _card("⚡","Sig. (α="+str(alpha)+")",str(n_sig),
              f"{n_sig/max(n_tot,1)*100:.0f}% des combinaisons","#27ae60"),
        _card("🔼","Combinaison max",best2_info,"μ target la plus haute","#2166ac"),
        _card("🔽","Combinaison min",worst_info,"μ target la plus basse","#b2182b"),
        _card("📏","Meilleur effet",best_d,"Cohen's d le plus fort","#e07b39"),
    ],style={"display":"flex","gap":"10px","flexWrap":"wrap"})


def _upset_plot(rules, feats, y_mean, tgt, alpha):
    """
    UpSet-style: barres des effectifs + indicateurs de set membership.
    Ordonnées par taille décroissante, coloriées par direction d'effet.
    """
    top = rules[:min(20,len(rules))]
    if not top:
        return go.Figure()

    n_feats = len(feats)
    labels  = [r["label"] for r in top]
    ns      = [r["n"] for r in top]
    deltas  = [r["delta"] for r in top]
    sigs    = [r["sig"] for r in top]
    ds      = [r["cohens_d"] for r in top]

    bar_colors = []
    for d,sig in zip(deltas,sigs):
        if not sig: bar_colors.append("rgba(150,150,150,0.4)")
        elif d>0:   bar_colors.append("rgba(33,102,172,0.85)")
        else:       bar_colors.append("rgba(178,24,43,0.85)")

    # Set membership dots (which features are in each rule)
    n_rules = len(top)
    dot_y_base = -0.5  # below bars

    fig = make_subplots(
        rows=2, cols=1,
        row_heights=[0.65, 0.35],
        vertical_spacing=0.04,
        shared_xaxes=True,
    )

    # ── Row 1 : Bar chart (effectifs) ─────────────────────────────
    fig.add_trace(go.Bar(
        x=list(range(n_rules)), y=ns,
        marker=dict(color=bar_colors,line=dict(width=0.5,color="rgba(255,255,255,.3)")),
        text=[f"n={n}" for n in ns],
        textposition="outside",textfont=dict(size=8,family=FONT),
        hovertemplate="<b>%{customdata}</b><br>n=%{y}<extra></extra>",
        customdata=[r["label"] for r in top],
        name="Effectif",showlegend=False,
    ),row=1,col=1)

    # Δmean annotations on bars
    for i,(r,d) in enumerate(zip(top,deltas)):
        sign="▲" if d>0 else "▼"
        star="*" if r["sig"] else ""
        fig.add_annotation(
            x=i, y=ns[i]/2, row=1, col=1,
            text=f"{sign}{abs(d):.2g}{star}",
            showarrow=False, font=dict(size=7.5,color="white",family=FONT),
            xref="x", yref="y",
        )

    # ── Row 2 : Feature membership matrix ─────────────────────────
    feat_short = [f[:14] for f in feats]

    # Background stripe for each feature row
    for fi in range(n_feats):
        fig.add_shape(type="rect",
            x0=-0.5, x1=n_rules-0.5,
            y0=fi-0.35, y1=fi+0.35,
            line_width=0,
            fillcolor="#f5f5f5" if fi%2==0 else "white",
            layer="below", row=2, col=1,
            xref="x2", yref="y2")

    # Dot matrix
    for i,r in enumerate(top):
        parts_lower = [p.split("∈")[0].strip().lower() for p in r["cond_parts"]]
        for fi,feat in enumerate(feats):
            # Is this feature part of this rule?
            in_rule = any(feat[:12].lower() in pl for pl in parts_lower)
            clr = bar_colors[i] if in_rule else "rgba(200,200,200,0.3)"
            sz  = 12 if in_rule else 6
            fig.add_trace(go.Scatter(
                x=[i], y=[fi], mode="markers",
                marker=dict(color=clr,size=sz,symbol="circle",
                            line=dict(width=1,color="rgba(255,255,255,.5)")),
                showlegend=False, hoverinfo="skip",
            ), row=2, col=1)

        # Connecting line between active features
        active_fis=[fi for fi,feat in enumerate(feats)
                    if any(feat[:12].lower() in pl for pl in parts_lower)]
        if len(active_fis)>=2:
            for k in range(len(active_fis)-1):
                fig.add_trace(go.Scatter(
                    x=[i,i],y=[active_fis[k],active_fis[k+1]],
                    mode="lines",
                    line=dict(color=bar_colors[i],width=2.5),
                    showlegend=False,hoverinfo="skip",
                ),row=2,col=1)

    # Δ legend
    for lbl,clr in [("↑ Sig. positif","rgba(33,102,172,0.85)"),
                     ("↓ Sig. négatif","rgba(178,24,43,0.85)"),
                     ("Non sig.","rgba(150,150,150,0.4)")]:
        fig.add_trace(go.Bar(x=[None],y=[None],marker_color=clr,name=lbl),row=1,col=1)

    fig.update_layout(
        plot_bgcolor="white",paper_bgcolor="white",
        margin=dict(l=20,r=20,t=20,b=20),
        font=dict(family=FONT,size=10),
        yaxis=dict(title=f"Effectif n",gridcolor=GRID),
        yaxis2=dict(tickvals=list(range(n_feats)),ticktext=feat_short,
                    gridcolor=GRID,tickfont=dict(size=10,color="#1e3a5f")),
        xaxis2=dict(tickvals=list(range(n_rules)),
                    ticktext=[f"R{i+1}" for i in range(n_rules)],
                    tickfont=dict(size=8),tickangle=-45),
        height=420,
        legend=dict(orientation="h",x=0.5,xanchor="center",y=1.05,
                    font=dict(size=9)),
        barmode="overlay",
    )
    return fig


def _slice_heatmaps(df, y_num, y_mean, bin_cols, bin_labels_map,
                     feat_a, feat_b, feat_c, lbls_a, lbls_b, lbls_c, tgt, alpha):
    """One heatmap per slice of feature C."""
    na,nb,nc=len(lbls_a),len(lbls_b),len(lbls_c)
    figs=[]
    for ic in range(nc):
        mask_c = bin_cols[feat_c]==ic
        mat=np.full((na,nb),np.nan)
        for ia,ib in product(range(na),range(nb)):
            grp=y_num[mask_c&(bin_cols[feat_a]==ia)&(bin_cols[feat_b]==ib)]
            if len(grp)>=2:
                mat[ia,ib]=float(grp.mean())-y_mean
        abs_m=float(np.nanmax(np.abs(mat))) if not np.all(np.isnan(mat)) else 1.0
        fig=go.Figure(go.Heatmap(
            z=mat,x=[f"B:{l}" for l in lbls_b],y=[f"A:{l}" for l in lbls_a],
            colorscale=CS_DIV,zmid=0,zmin=-abs_m,zmax=abs_m,
            text=[[("–" if np.isnan(mat[ia,ib]) else f"Δ{mat[ia,ib]:+.3g}")
                   for ib in range(nb)] for ia in range(na)],
            texttemplate="%{text}",textfont=dict(size=9),
            showscale=True,colorbar=dict(thickness=10,tickfont=dict(size=8)),
            hovertemplate="<b>%{y} × %{x}</b><br>Δμ=%{z:.3g}<extra></extra>",
        ))
        fig.update_layout(height=260,plot_bgcolor="white",paper_bgcolor="white",
            margin=dict(l=60,r=60,t=10,b=50),font=dict(family=FONT,size=9),
            xaxis=dict(tickangle=-30,tickfont=dict(size=9)),
            yaxis=dict(tickfont=dict(size=9)))
        figs.append(html.Div([
            html.Div(f"Slice {feat_c[:16]} ∈ [{lbls_c[ic]}]",
                style={"fontWeight":"700","fontSize":"11px","color":"#1e3a5f",
                       "marginBottom":"4px","fontFamily":FONT}),
            dcc.Graph(figure=fig,config={"displayModeBar":False},style={"height":"260px"}),
        ],className="chart-card",style={"flex":"1","minWidth":"260px"}))

    return html.Div([
        html.Div(f"Heatmaps par slice de {feat_c}",className="chart-card-title"),
        html.Div(figs,style={"display":"flex","gap":"12px","flexWrap":"wrap"}),
    ],className="chart-card")


def _rules_table(rules, tgt, y_mean, alpha):
    if not rules:
        return html.Div("Aucune règle générée.",style={"color":"#9aa5b4","padding":"12px"})

    top=rules[:min(30,len(rules))]

    def _th(t):
        return html.Th(t,style={"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"9.5px","textTransform":"uppercase",
            "letterSpacing":".3px","borderBottom":"2px solid #e0e4ea",
            "whiteSpace":"nowrap","textAlign":"left"})
    def _td(t,clr=None,bold=False,bg=None):
        s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
        if bold: s["fontWeight"]="700"
        if bg:   s["background"]=bg
        return html.Td(t,style=s)

    rows=[]
    for i,r in enumerate(top):
        d=r["cohens_d"]; sig=r["sig"]
        d_str=("🔼" if d>0 else "🔽")+f" {abs(d):.3f}"
        d_lbl=("grand" if abs(d)>=0.8 else "moyen" if abs(d)>=0.5 else "petit" if abs(d)>=0.2 else "nég.")
        bg=("#f0f8ff" if sig and d>0 else "#fff5f5" if sig and d<0 else "white")

        # Rule text as "SI A ∈ [...] ET B ∈ [...] ALORS μ=..."
        rule_si="SI " + " ET ".join(r["cond_parts"])
        rule_alors=f"ALORS μ({tgt[:12]})={r['mean']:.4g}"

        rows.append(html.Tr([
            _td(f"R{i+1}",bold=True,clr="#4472c4"),
            html.Td(html.Div([
                html.Div(rule_si,style={"fontSize":"9.5px","color":"#1e3a5f","fontWeight":"700"}),
                html.Div(rule_alors,style={"fontSize":"9px","color":"#374151","marginTop":"1px"}),
            ],style={"lineHeight":"1.3"}),
            style={"padding":"4px 8px","minWidth":"200px"}),
            _td(f"{r['n']:,}"),
            _td(f"{r['mean']:.4g}",bold=True),
            _td(f"{r['delta']:+.4g}",
                "#2166ac" if r['delta']>0 else "#b2182b",bold=True),
            _td(f"±{r['ci95']:.3g}"),
            _td(d_str+f" ({d_lbl})",
                "#2166ac" if d>0.2 else "#b2182b" if d<-0.2 else "#9aa5b4",bold=abs(d)>=0.5),
            _td(f"{r['p']:.4f}",
                "#27ae60" if sig else "#9aa5b4",bold=sig),
            _td("✅" if sig else "—","#27ae60" if sig else "#9aa5b4",bold=True),
        ],style={"borderBottom":"1px solid #f0f4f8","background":bg}))

    return html.Div([
        html.Div(f"🏆 Top {len(top)} règles classées par |Cohen's d|",
            style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"8px","fontFamily":FONT}),
        html.Div(
            html.Table([
                html.Thead(html.Tr([_th("N°"),_th("Règle"),_th("n"),_th(f"μ({tgt[:10]})"),
                                    _th("Δmoy"),_th("IC95±"),_th("Cohen's d"),
                                    _th("p-value"),_th("Sig.")])),
                html.Tbody(rows),
            ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
            style={"overflowX":"auto","maxHeight":"420px","overflowY":"auto"},
        ),
    ])


def _ols_regression(df, y_num, bin_cols, feats, bin_labels_map, tgt):
    """OLS with main effects + 2-way interaction terms."""
    try:
        import statsmodels.api as sm
    except ImportError:
        return _ols_fallback(df, y_num, bin_cols, feats, bin_labels_map, tgt)

    try:
        # Build design matrix: one-hot bin indicators + interaction
        X_parts = [np.ones(len(y_num))]
        col_names = ["Intercept"]

        for feat in feats:
            bc = bin_cols[feat].astype(int)
            lbls = bin_labels_map[feat]
            n_b = len(lbls)
            for bi in range(1, n_b):  # drop first for reference
                x_col = (bc==bi).astype(float)
                X_parts.append(x_col)
                col_names.append(f"{feat[:10]}[{lbls[bi]}]")

        # 2-way interactions between feats[0] and feats[1]
        fa,fb = feats[0], feats[1]
        lbls_a,lbls_b = bin_labels_map[fa], bin_labels_map[fb]
        na,nb = len(lbls_a), len(lbls_b)
        for ia in range(1,na):
            for ib in range(1,nb):
                col = ((bin_cols[fa]==ia)&(bin_cols[fb]==ib)).astype(float)
                X_parts.append(col)
                col_names.append(f"{fa[:8]}[{lbls_a[ia]}]×{fb[:8]}[{lbls_b[ib]}]")

        X_mat = np.column_stack(X_parts)
        # Drop near-zero variance columns
        var_mask = X_mat.var(axis=0) > 1e-8
        X_mat    = X_mat[:,var_mask]
        col_names= [c for c,m in zip(col_names,var_mask) if m]

        model = sm.OLS(y_num.astype(float), X_mat)
        res   = model.fit()
        r2, r2a = float(res.rsquared), float(res.rsquared_adj)
        aic     = float(res.aic)

        # Build table
        coefs = res.params; pvals = res.pvalues; ses = res.bse; tvals = res.tvalues
        cis   = res.conf_int()

        def _th(t):
            return html.Th(t,style={"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
                "fontWeight":"700","fontSize":"9.5px","textTransform":"uppercase",
                "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"})
        def _td(t,clr=None,bold=False):
            s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
            if bold: s["fontWeight"]="700"
            return html.Td(t,style=s)

        rows=[]
        for name,b,se_v,tv,pv,ci_lo,ci_hi in zip(col_names,coefs,ses,tvals,pvals,
                                                    cis[:,0],cis[:,1]):
            is_int = "×" in name
            sig  = pv<0.05
            clr_b= "#2166ac" if b>0 else "#b2182b"
            rows.append(html.Tr([
                _td(name,bold=is_int,clr="#4472c4" if is_int else None),
                _td(f"{b:+.4f}",clr_b,bold=True),
                _td(f"{se_v:.4f}"),
                _td(f"{tv:+.3f}"),
                _td(f"[{ci_lo:+.3f},{ci_hi:+.3f}]"),
                _td(f"{pv:.4f}","#27ae60" if sig else "#9aa5b4",bold=sig),
                _td("✅" if sig else "—","#27ae60" if sig else "#9aa5b4",bold=True),
            ],style={"borderBottom":"1px solid #f5f5f5",
                     "background":"#f0f8ff" if is_int and sig else "white"}))

        # Model summary cards
        summary_bar = html.Div([
            _mini_card("R²",f"{r2:.4f}","#4472c4"),
            _mini_card("R² adj.",f"{r2a:.4f}","#27ae60"),
            _mini_card("AIC",f"{aic:.1f}","#e07b39"),
            _mini_card("N obs.",f"{len(y_num):,}","#9b59b6"),
        ],style={"display":"flex","gap":"8px","flexWrap":"wrap","marginBottom":"12px"})

        table=html.Div(
            html.Table([
                html.Thead(html.Tr([_th("Terme"),_th("β"),_th("SE"),_th("t"),
                                    _th("IC95%"),_th("p-value"),_th("Sig.")])),
                html.Tbody(rows),
            ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
            style={"overflowX":"auto","maxHeight":"360px","overflowY":"auto"})

        note=html.Div("Les termes contenant × sont des interactions. "
                      "Fond bleu = interaction significative.",
            style={"fontSize":"10px","color":"#9aa5b4","marginTop":"8px","fontStyle":"italic","fontFamily":FONT})

        return html.Div([summary_bar, table, note])

    except Exception as ex:
        return html.Div(f"Erreur régression: {ex}",
                        style={"color":"#e74c3c","fontSize":"12px","padding":"12px"})


def _ols_fallback(df, y_num, bin_cols, feats, bin_labels_map, tgt):
    """Lightweight fallback without statsmodels: numpy OLS."""
    try:
        X_parts=[np.ones(len(y_num))]
        col_names=["Intercept"]
        for feat in feats:
            bc=bin_cols[feat].astype(float)
            X_parts.append(bc); col_names.append(feat[:18])
        # Interaction term A×B
        if len(feats)>=2:
            X_parts.append(bin_cols[feats[0]]*bin_cols[feats[1]])
            col_names.append(f"{feats[0][:8]}×{feats[1][:8]}")
        X_mat=np.column_stack(X_parts).astype(float)
        b,res,_,_ = np.linalg.lstsq(X_mat,y_num,rcond=None)
        y_hat=X_mat@b; ss_res=((y_num-y_hat)**2).sum(); ss_tot=((y_num-y_num.mean())**2).sum()
        r2=1-ss_res/max(ss_tot,1e-9)
        rows=[]
        for name,bi in zip(col_names,b):
            rows.append(html.Div(f"{name}: β={bi:+.4f}",
                style={"fontSize":"11px","fontFamily":FONT,"padding":"2px 4px"}))
        return html.Div([
            html.Div(f"R² = {r2:.4f} (statsmodels non disponible — OLS numpy simplifié)",
                style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"8px"}),
            html.Div(rows),
        ])
    except Exception as ex:
        return html.Div(f"OLS non disponible: {ex}",style={"color":"#9aa5b4","fontSize":"12px"})


def _mini_card(label,value,clr):
    return html.Div([
        html.Div(value,style={"fontSize":"17px","fontWeight":"800","color":clr,"fontFamily":FONT}),
        html.Div(label,style={"fontSize":"9.5px","color":"#6b7a8d","fontWeight":"600",
            "textTransform":"uppercase","letterSpacing":".3px"}),
    ],style={"background":"white","borderRadius":"8px","padding":"8px 12px",
             "boxShadow":"0 1px 5px rgba(0,0,0,.07)","borderLeft":f"3px solid {clr}"})


def _err(msg):
    return html.Div(msg,style={"color":"#e74c3c","padding":"16px","fontSize":"13px","fontFamily":FONT})
