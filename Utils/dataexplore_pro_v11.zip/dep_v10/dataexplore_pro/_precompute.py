"""
_precompute.py — DataExplore Pro v9
═══════════════════════════════════════════════════════════════════════
Moteur de précalcul parallèle pour datasets jusqu'à 5M×300.

Stratégie :
  DISPLAY_N  = 50 000   → tous les graphiques (WebGL)
  STATS_N    = 200 000  → stats descriptives
  CORR_N     = 10 000   → corrélations Pearson/Spearman (précalculé, instantané)
  IMP_N      = 100 000  → RF, MI, importance
  FULL_PASS  = vecteurs numpy sur toutes les lignes pour IV/eta²/fstats

Parallélisation : ThreadPoolExecutor(4 workers)
  Thread 1 : fstats + miss + IV
  Thread 2 : corr Pearson + Spearman (10k pts)
  Thread 3 : PCA (randomized SVD)
  Thread 4 : importance RF + MI + F-stat
"""
from __future__ import annotations
import threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING
import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from .core import DataExplorePro

DISPLAY_N = 50_000
STATS_N   = 200_000
CORR_N    = 10_000   # v9: dédié corrélation précalculée
IMP_N     = 100_000


class Cache:
    """Dictionnaire thread-safe avec events par clé."""
    def __init__(self):
        self._d: dict = {}
        self._lock    = threading.Lock()
        self._events: dict[str, threading.Event] = {}

    def _ev(self, key):
        with self._lock:
            if key not in self._events:
                self._events[key] = threading.Event()
            return self._events[key]

    def set(self, key, value):
        with self._lock:
            self._d[key] = value
        self._ev(key).set()

    def get(self, key, default=None, wait=False, timeout=90):
        if wait:
            self._ev(key).wait(timeout=timeout)
        with self._lock:
            return self._d.get(key, default)

    def ready(self, key):
        return self._ev(key).is_set()


def build_cache(dep: "DataExplorePro") -> Cache:
    cache = Cache()

    def _run():
        t0  = time.perf_counter()
        num = dep.num_features
        n   = len(dep.df)
        rng = np.random.default_rng(42)

        # ── Shared arrays ─────────────────────────────────────────────
        df_num      = dep.df[num]
        X_full      = df_num.fillna(df_num.median()).values.astype(np.float32)
        y_full      = dep.y if dep.supervised else None

        # ── Stratified sampler ────────────────────────────────────────
        def _strat(want):
            want = min(want, n)
            if want >= n: return np.arange(n)
            if dep.supervised and dep.is_classification and y_full is not None:
                parts = []
                classes, counts = np.unique(y_full, return_counts=True)
                for cls, cnt in zip(classes, counts):
                    ci = np.where(y_full == cls)[0]
                    k  = max(1, int(want * cnt / n))
                    parts.append(rng.choice(ci, size=min(k, cnt), replace=False))
                idx = np.concatenate(parts)
                if len(idx) < want:
                    extra = rng.choice(n, size=want-len(idx), replace=False)
                    idx   = np.unique(np.concatenate([idx, extra]))
                return idx[:want]
            return rng.choice(n, size=want, replace=False)

        idx_corr  = _strat(CORR_N)    # v9: dedicated corr sample
        idx_stats = _strat(STATS_N)
        idx_imp   = _strat(IMP_N)

        X_corr  = X_full[idx_corr]
        X_stats = X_full[idx_stats]
        y_stats = y_full[idx_stats] if y_full is not None else None
        X_imp   = X_full[idx_imp]
        y_imp   = y_full[idx_imp]   if y_full is not None else None

        cache.set("idx_stats", idx_stats)
        cache.set("idx_imp",   idx_imp)
        cache.set("corr_n",    len(idx_corr))   # expose actual N used

        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="dep9") as pool:
            futures = {}
            futures[pool.submit(_fstats,   X_full,  num, y_full, dep)] = "fstats"
            futures[pool.submit(_miss,     X_full,  num, dep)]         = "miss"
            futures[pool.submit(_corr,     X_corr,  num)]              = "corr"
            futures[pool.submit(_pca_work, X_stats, num)]              = "pca"
            if dep.supervised and y_imp is not None:
                futures[pool.submit(_importance, X_imp, y_imp, num,
                                    dep.is_classification)]            = "importance"
                futures[pool.submit(_iv, X_full, y_full, num, dep)]   = "iv"
            else:
                cache.set("importance", None)
                cache.set("iv", {c: 0.0 for c in num})

            for fut in as_completed(futures):
                key = futures[fut]
                try:
                    res = fut.result()
                    if key == "corr":
                        cache.set("corr_pearson",  res[0])
                        cache.set("corr_spearman", res[1])
                    else:
                        cache.set(key, res)
                except Exception as exc:
                    import traceback; traceback.print_exc()
                    if key == "corr":
                        cache.set("corr_pearson",  None)
                        cache.set("corr_spearman", None)
                    else:
                        cache.set(key, None)

        cache.set("_ready", True)
        print(f"  ✅  v9 précalcul {time.perf_counter()-t0:.1f}s  "
              f"({len(num)} features × {n:,} lignes, corr sur {len(idx_corr):,} pts)")

    threading.Thread(target=_run, daemon=True, name="dep9_precompute").start()
    return cache


# ─────────────────────────────────────────────────────────────────────────────
#  WORKERS (inchangés sauf _corr qui utilise CORR_N)
# ─────────────────────────────────────────────────────────────────────────────

def _fstats(X, cols, y, dep):
    n, p = X.shape
    q = np.nanpercentile(X, [1,5,10,25,50,75,90,95,99], axis=0)
    mean_v = np.nanmean(X, axis=0).astype(np.float64)
    std_v  = np.nanstd( X, axis=0, ddof=1).astype(np.float64)
    min_v  = np.nanmin( X, axis=0).astype(np.float64)
    max_v  = np.nanmax( X, axis=0).astype(np.float64)
    nan_v  = np.isnan(X).mean(axis=0)
    iqr_v  = q[5]-q[3]
    out_v  = np.mean((X < q[3]-1.5*iqr_v)|(X > q[5]+1.5*iqr_v), axis=0)
    std_safe = np.where(std_v>0, std_v, 1e-9)
    Xc = X-mean_v
    skw = np.nanmean((Xc/std_safe)**3, axis=0)
    krt = np.nanmean((Xc/std_safe)**4, axis=0)-3.0
    return dict(cols=cols, n=n,
                mean=mean_v, std=std_v, min=min_v, max=max_v,
                q01=q[0],q05=q[1],q10=q[2],q25=q[3],
                q50=q[4],q75=q[5],q90=q[6],q95=q[7],q99=q[8],
                iqr=iqr_v, nan_pct=nan_v, outlier_pct=out_v,
                skew=skw, kurt=krt)


def _miss(X, cols, dep):
    n, p   = X.shape
    mp     = np.isnan(X).mean(axis=0)
    mc     = np.isnan(X).sum(axis=0)
    total  = float(mp.mean()*100)
    n_comp = int((~np.isnan(X).any(axis=1)).sum())
    rng    = np.random.default_rng(42)
    idx    = rng.choice(n, size=min(n,50_000), replace=False)
    M      = np.isnan(X[idx]).astype(np.float32)
    cooc   = (M.T @ M)/len(idx)
    return dict(cols=cols, miss_pct=dict(zip(cols,mp.tolist())),
                miss_cnt=dict(zip(cols,mc.tolist())),
                total_pct=total, n_complete=n_comp, cooc=cooc)


def _corr(X_sample, cols):
    """Pearson + Spearman via numpy pur sur CORR_N points."""
    Xd = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c,m in zip(cols,col_mask) if m]
    cmeans     = np.nanmean(Xd, axis=0)
    nl         = np.isnan(Xd)
    Xd[nl]     = np.take(cmeans, np.where(nl)[1])

    def _pmat(M):
        Mc  = M-M.mean(axis=0)
        nrm = np.linalg.norm(Mc, axis=0)
        nrm = np.where(nrm==0, 1e-9, nrm)
        mat = (Mc/nrm).T @ (Mc/nrm)
        np.fill_diagonal(mat, 1.0)
        return mat.clip(-1,1)

    pearson  = _pmat(Xd)
    from scipy.stats import rankdata
    Xr       = np.apply_along_axis(rankdata, 0, Xd).astype(np.float64)
    spearman = _pmat(Xr)
    return (pd.DataFrame(pearson,  index=cols_valid, columns=cols_valid),
            pd.DataFrame(spearman, index=cols_valid, columns=cols_valid))


def _pca_work(X_sample, cols):
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    Xd = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c,m in zip(cols,col_mask) if m]
    cmeans = np.nanmean(Xd, axis=0)
    nl = np.isnan(Xd)
    Xd[nl] = np.take(cmeans, np.where(nl)[1])
    n_comp = min(15, Xd.shape[1], Xd.shape[0])
    scaler = StandardScaler()
    Xs     = scaler.fit_transform(Xd)
    if Xs.shape[0] > 150_000:
        rng = np.random.default_rng(42)
        Xs  = Xs[rng.choice(Xs.shape[0], 150_000, replace=False)]
    pca    = PCA(n_components=n_comp, random_state=42, svd_solver="randomized")
    scores = pca.fit_transform(Xs)
    return dict(cols=cols_valid, scaler=scaler, pca=pca,
                scores=scores.astype(np.float32),
                loadings=pca.components_.T.astype(np.float32),
                explained=pca.explained_variance_ratio_.astype(np.float32),
                n_comp=n_comp)


def _importance(X, y, cols, is_cls):
    from sklearn.feature_selection import (f_classif, f_regression,
        mutual_info_classif, mutual_info_regression)
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.preprocessing import StandardScaler
    from scipy.stats import rankdata
    p  = X.shape[1]
    Xd = X.astype(np.float64)
    yd = y.astype(np.float64)
    cm = np.nanmean(Xd, axis=0)
    nl = np.isnan(Xd)
    Xd[nl] = np.take(cm, np.where(nl)[1])
    def _norm(a): mx=a.max(); return (a/mx if mx>0 else a).clip(0,1)
    out = {"cols": cols}
    Xc = Xd-Xd.mean(axis=0); yc=yd-yd.mean()
    sx = Xd.std(axis=0)+1e-9; sy=yd.std()+1e-9
    out["pearson"]  = _norm(np.abs((Xc*yc[:,None]).mean(axis=0)/(sx*sy)))
    Xr = np.apply_along_axis(rankdata,0,Xd); yr=rankdata(yd)
    Xrc=Xr-Xr.mean(axis=0); yrc=yr-yr.mean()
    sr=Xr.std(axis=0)+1e-9; syr=yr.std()+1e-9
    out["spearman"] = _norm(np.abs((Xrc*yrc[:,None]).mean(axis=0)/(sr*syr)))
    try:
        fn=f_classif if is_cls else f_regression
        yc_=y.astype(int) if is_cls else yd
        f,_ = fn(Xd,yc_)
        out["fstat"] = _norm(np.nan_to_num(f,nan=0,posinf=0))
    except: out["fstat"] = np.zeros(p)
    try:
        fn_mi=mutual_info_classif if is_cls else mutual_info_regression
        yc_=y.astype(int) if is_cls else yd
        mi = fn_mi(Xd,yc_,random_state=42,n_neighbors=5)
        out["mi"] = _norm(np.nan_to_num(mi,nan=0))
    except: out["mi"] = np.zeros(p)
    try:
        Xs=StandardScaler().fit_transform(Xd)
        yc_=y.astype(int) if is_cls else yd
        RF=RandomForestClassifier if is_cls else RandomForestRegressor
        rf=RF(n_estimators=60,max_depth=8,max_features="sqrt",
              min_samples_leaf=20,n_jobs=-1,random_state=42)
        rf.fit(Xs,yc_)
        out["rf"] = _norm(rf.feature_importances_)
    except: out["rf"] = np.zeros(p)
    stack = np.column_stack([out["pearson"],out["spearman"],out["fstat"],out["mi"],out["rf"]])
    out["global"] = _norm(stack.mean(axis=1))
    return out


def _iv(X_full, y_full, cols, dep):
    if not dep.is_classification or dep.n_classes != 2:
        return _eta2(X_full, y_full, cols)
    cls1 = dep.classes[-1]
    y_bin = (y_full==cls1).astype(np.int8)
    total_ev  = max(int(y_bin.sum()),1)
    total_nev = max(len(y_bin)-total_ev,1)
    result = {}; N_BINS=10
    for i, col in enumerate(cols):
        x=X_full[:,i]; ok=~np.isnan(x); xv,yv=x[ok],y_bin[ok]
        if len(xv)<20: result[col]=0.0; continue
        try:
            q=np.unique(np.percentile(xv,np.linspace(0,100,N_BINS+1)))
            if len(q)<3: result[col]=0.0; continue
            b=np.searchsorted(q[1:-1],xv,side="right"); iv=0.0
            for bi in np.unique(b):
                m=b==bi; ev=max(int(yv[m].sum()),1); nev=max(int((1-yv[m]).sum()),1)
                woe=np.log((ev/total_ev)/(nev/total_nev))
                iv+=(ev/total_ev-nev/total_nev)*woe
            result[col]=float(np.clip(iv,0,5))
        except: result[col]=0.0
    return result


def _eta2(X, y, cols):
    result={}
    for i,col in enumerate(cols):
        x=X[:,i]; ok=~np.isnan(x); xv=x[ok].astype(np.float64); yv=y[ok]
        if len(xv)<10: result[col]=0.0; continue
        try:
            gm=xv.mean(); sst=((xv-gm)**2).sum()
            if sst<1e-12: result[col]=0.0; continue
            ssb=sum(((xv[yv==c].mean()-gm)**2)*(yv==c).sum()
                    for c in np.unique(yv) if (yv==c).sum()>0)
            result[col]=float(np.clip(ssb/sst,0,1))
        except: result[col]=0.0
    return result
