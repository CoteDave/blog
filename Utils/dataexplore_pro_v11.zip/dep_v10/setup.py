from setuptools import setup, find_packages
setup(
    name="dataexplore-pro",
    version="6.0.0",
    packages=find_packages(),
    install_requires=[
        "dash>=2.14",
        "dash-bootstrap-components>=1.5",
        "plotly>=5.18",
        "scikit-learn>=1.2",
        "scipy>=1.7",
        "pandas>=1.5",
        "numpy>=1.22",
    ],
)
