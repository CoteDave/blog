"""
core.py — DataExplore Pro v11
Optimisé 5M×300 : downcast float32, display_df stratifié ≤50k, cache parallèle.
  Nouveauté v11 : interaction_min_samples (filtre bins trop petites avant tout calcul)
"""
from __future__ import annotations
import threading, time, webbrowser
from typing import List, Optional
import numpy as np
import pandas as pd

DISPLAY_N = 50_000

class DataExplorePro:
    def __init__(
        self,
        X,
        y=None,
        feature_names: Optional[List[str]] = None,
        target_name: str  = "Target",
        title: str        = "DataExplore Pro",
        # v11 — interactions
        interaction_min_samples: int = 25,
        interaction_max_features: int = 20,
        interaction_n_bins_default: int = 3,
    ):
        t0 = time.perf_counter()

        if isinstance(X, pd.DataFrame):
            _cols = list(X.columns)
            _raw  = X.values
        else:
            _raw  = np.asarray(X)
            _cols = (list(feature_names) if feature_names
                     else [f"F{i}" for i in range(_raw.shape[1])])

        self.feature_names: List[str] = _cols
        if np.issubdtype(_raw.dtype, np.floating):
            _raw = _raw.astype(np.float32)
        elif np.issubdtype(_raw.dtype, np.integer):
            _raw = _raw.astype(np.int32)

        self.df = pd.DataFrame(_raw, columns=_cols)

        self.supervised: bool  = y is not None
        self.target_name: str  = target_name
        if y is not None:
            self.y = np.asarray(y)
            self.df[target_name]   = self.y
            self.classes: list     = sorted(np.unique(self.y).tolist())
            self.n_classes: int    = len(self.classes)
            self.is_classification = (
                self.n_classes <= 20 and
                (not np.issubdtype(self.y.dtype, np.floating) or self.n_classes == 2)
            )
        else:
            self.y = None; self.classes = []; self.n_classes = 0
            self.is_classification = False

        self.num_features: List[str] = [
            c for c in self.df.columns
            if c != target_name and pd.api.types.is_numeric_dtype(self.df[c])
        ]
        self.cat_features: List[str] = [
            c for c in self.df.columns
            if c != target_name and not pd.api.types.is_numeric_dtype(self.df[c])
        ]

        # v11 interaction params
        self.interaction_min_samples    = max(5, interaction_min_samples)
        self.interaction_max_features   = max(3, interaction_max_features)
        self.interaction_n_bins_default = max(2, min(6, interaction_n_bins_default))

        n   = len(self.df)
        rng = np.random.default_rng(42)
        n_disp = min(DISPLAY_N, n)

        if n_disp >= n:
            self._disp_idx = np.arange(n)
        elif self.supervised and self.is_classification and self.y is not None:
            parts = []
            for cls in self.classes:
                ci = np.where(self.y == cls)[0]
                k  = max(1, int(n_disp * len(ci) / n))
                parts.append(rng.choice(ci, size=min(k, len(ci)), replace=False))
            self._disp_idx = np.concatenate(parts)[:n_disp]
        else:
            self._disp_idx = rng.choice(n, size=n_disp, replace=False)

        self.display_df = self.df.iloc[self._disp_idx].reset_index(drop=True)
        self.title = title
        self._app  = None

        elapsed = time.perf_counter() - t0
        print(f"\n  DataExplore Pro v11")
        print(f"  {n:,} lignes × {len(self.num_features)} features  |  prep {elapsed:.2f}s")
        print(f"  Affichage : {len(self._disp_idx):,} pts (échantillon stratifié)")
        print(f"  Interactions : min_n={self.interaction_min_samples}  "
              f"max_feats={self.interaction_max_features}  "
              f"bins_default={self.interaction_n_bins_default}")
        print(f"  Précalcul parallèle en cours…")

        from ._precompute import build_cache
        self.cache = build_cache(self)

    def run(self, host="127.0.0.1", port=8050, debug=False, open_browser=True):
        from .app_factory import create_app
        self._app = create_app(self)
        if open_browser:
            def _open():
                time.sleep(1.5); webbrowser.open(f"http://{host}:{port}")
            threading.Thread(target=_open, daemon=True).start()
        n = len(self.df)
        print(f"\n  URL  : http://{host}:{port}")
        print(f"  Data : {n:,} lignes · {len(self.num_features)} features")
        print(f"  Ctrl+C pour arrêter\n")
        self._app.run(host=host, port=port, debug=debug)
