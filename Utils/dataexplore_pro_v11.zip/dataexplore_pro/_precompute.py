"""
_precompute.py — DataExplore Pro v11
═══════════════════════════════════════════════════════════════════════════════
Moteur de précalcul parallèle.

Samples:
  DISPLAY_N  = 50 000    → graphiques WebGL
  STATS_N    = 200 000   → stats descriptives
  CORR_N     = 10 000    → corrélations Pearson/Spearman
  IMP_N      = 100 000   → RF/MI/importance
  INTER_N    = 200 000   → interactions (grand sample pour précision)

Threads:
  Thread 1 : fstats + miss + IV
  Thread 2 : corr Pearson+Spearman
  Thread 3 : PCA
  Thread 4 : importance RF+MI
  Threads 5..N : interactions — 1 future par paire (feat_a, feat_b, n_bins)

Vectorisation interactions :
  Pour chaque paire, O(n) via np.bincount sur cell_id = bin_a*nb + bin_b
  → Pas de boucle Python sur les lignes
  → Filtre min_samples AVANT tout t-test
  → Welch t-test et Cohen's d vectorisés sur le vecteur de cellules
"""
from __future__ import annotations
import threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from itertools import combinations
from typing import TYPE_CHECKING
import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from .core import DataExplorePro

DISPLAY_N = 50_000
STATS_N   = 200_000
CORR_N    = 10_000
IMP_N     = 100_000
INTER_N   = 200_000   # v11: sample dédié interactions


# ─────────────────────────────────────────────────────────────────────────────
#  Cache thread-safe
# ─────────────────────────────────────────────────────────────────────────────

class Cache:
    def __init__(self):
        self._d: dict = {}
        self._lock    = threading.Lock()
        self._events: dict[str, threading.Event] = {}

    def _ev(self, key):
        with self._lock:
            if key not in self._events:
                self._events[key] = threading.Event()
            return self._events[key]

    def set(self, key, value):
        with self._lock:
            self._d[key] = value
        self._ev(key).set()

    def get(self, key, default=None, wait=False, timeout=90):
        if wait:
            self._ev(key).wait(timeout=timeout)
        with self._lock:
            return self._d.get(key, default)

    def ready(self, key):
        return self._ev(key).is_set()


# ─────────────────────────────────────────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────────────────────────────────────────

def build_cache(dep: "DataExplorePro") -> Cache:
    cache = Cache()

    def _run():
        t0  = time.perf_counter()
        num = dep.num_features
        n   = len(dep.df)
        rng = np.random.default_rng(42)

        df_num  = dep.df[num]
        X_full  = df_num.fillna(df_num.median()).values.astype(np.float32)
        y_full  = dep.y if dep.supervised else None

        def _strat(want):
            want = min(want, n)
            if want >= n: return np.arange(n)
            if dep.supervised and dep.is_classification and y_full is not None:
                parts = []
                classes, counts = np.unique(y_full, return_counts=True)
                for cls, cnt in zip(classes, counts):
                    ci = np.where(y_full == cls)[0]
                    k  = max(1, int(want * cnt / n))
                    parts.append(rng.choice(ci, size=min(k, cnt), replace=False))
                idx = np.concatenate(parts)
                if len(idx) < want:
                    extra = rng.choice(n, size=want-len(idx), replace=False)
                    idx   = np.unique(np.concatenate([idx, extra]))
                return idx[:want]
            return rng.choice(n, size=want, replace=False)

        idx_corr  = _strat(CORR_N)
        idx_stats = _strat(STATS_N)
        idx_imp   = _strat(IMP_N)
        idx_inter = _strat(INTER_N)

        X_corr  = X_full[idx_corr]
        X_stats = X_full[idx_stats]
        y_stats = y_full[idx_stats] if y_full is not None else None
        X_imp   = X_full[idx_imp]
        y_imp   = y_full[idx_imp]   if y_full is not None else None

        cache.set("idx_stats", idx_stats)
        cache.set("idx_imp",   idx_imp)
        cache.set("corr_n",    len(idx_corr))

        # ── Phase 1 : tâches standard ─────────────────────────────────────
        with ThreadPoolExecutor(max_workers=5, thread_name_prefix="dep11_std") as pool:
            futures = {
                pool.submit(_fstats,   X_full,  num, y_full, dep): "fstats",
                pool.submit(_miss,     X_full,  num, dep):         "miss",
                pool.submit(_corr,     X_corr,  num):              "corr",
                pool.submit(_pca_work, X_stats, num):              "pca",
            }
            if dep.supervised and y_imp is not None:
                futures[pool.submit(_importance, X_imp, y_imp, num,
                                    dep.is_classification)]       = "importance"
                futures[pool.submit(_iv, X_full, y_full, num, dep)] = "iv"
            else:
                cache.set("importance", None)
                cache.set("iv", {c: 0.0 for c in num})

            for fut in as_completed(futures):
                key = futures[fut]
                try:
                    res = fut.result()
                    if key == "corr":
                        cache.set("corr_pearson",  res[0])
                        cache.set("corr_spearman", res[1])
                    else:
                        cache.set(key, res)
                except Exception:
                    import traceback; traceback.print_exc()
                    if key == "corr":
                        cache.set("corr_pearson",  None)
                        cache.set("corr_spearman", None)
                    else:
                        cache.set(key, None)

        # ── Phase 2 : interactions (si supervisé) ──────────────────────────
        if dep.supervised and y_full is not None:
            try:
                inter_result = _interactions_work(
                    dep    = dep,
                    X_full = X_full,
                    y_full = y_full,
                    idx    = idx_inter,
                    num    = num,
                    iv_cache = cache.get("iv"),
                )
                cache.set("interactions", inter_result)
            except Exception:
                import traceback; traceback.print_exc()
                cache.set("interactions", None)
        else:
            cache.set("interactions", None)

        cache.set("_ready", True)
        print(f"  ✅  v11 précalcul {time.perf_counter()-t0:.1f}s  "
              f"({len(num)} features × {n:,} lignes)")

    threading.Thread(target=_run, daemon=True, name="dep11_precompute").start()
    return cache


# ─────────────────────────────────────────────────────────────────────────────
#  INTERACTIONS — cœur vectorisé
# ─────────────────────────────────────────────────────────────────────────────

def _interactions_work(dep, X_full, y_full, idx, num, iv_cache):
    """
    Précalcule les stats de toutes les paires (feat_a, feat_b) pour
    n_bins ∈ {2, 3, 4, 5, 6} et stocke dans un dict imbriqué.

    Structure retournée :
    {
      "meta": {
          "min_n": int,
          "inter_n": int,
          "n_bins_list": [2,3,4,5,6],
          "feats": [...],           # features sélectionnées (top-K par IV)
          "bin_labels": {feat: {n_bins: [label, ...]}},
          "global_mean": float,
          "global_std": float,
      },
      "pairs": {
          (feat_a, feat_b, n_bins): {  # clé hashable
              "na": int, "nb": int,
              "counts":    np.ndarray shape (na*nb,) float32,
              "means":     np.ndarray shape (na*nb,) float32,
              "cohens_d":  np.ndarray shape (na*nb,) float32,
              "p_vals":    np.ndarray shape (na*nb,) float32,
              "valid":     np.ndarray shape (na*nb,) bool,   # count >= min_n
          }
      }
    }
    """
    t0 = time.perf_counter()
    min_n      = dep.interaction_min_samples
    max_feats  = dep.interaction_max_features
    n_bins_list= [2, 3, 4, 5, 6]

    # ── Sélection des features : top-K par IV (ou importance) ─────────────
    if iv_cache and isinstance(iv_cache, dict):
        ranked = sorted(iv_cache.items(), key=lambda x: abs(x[1]), reverse=True)
        sel_feats = [f for f,_ in ranked if f in num][:max_feats]
    else:
        sel_feats = num[:max_feats]

    if len(sel_feats) < 2:
        return None

    # ── Extraction du sous-échantillon (stratifié INTER_N) ────────────────
    X_inter = X_full[idx].astype(np.float64)    # (inter_n, p_full)
    y_inter = _encode_y(y_full[idx], dep)        # (inter_n,) float64

    feat_idx_map = {f: i for i, f in enumerate(num)}
    n_inter = len(idx)

    global_sum   = float(np.nansum(y_inter))
    global_cnt   = float(np.sum(~np.isnan(y_inter)))
    global_mean  = global_sum / max(global_cnt, 1)
    global_std   = float(np.nanstd(y_inter, ddof=1)) if global_cnt > 1 else 1.0

    # ── Pré-calcul des bins pour chaque (feature, n_bins) ─────────────────
    # bins_map[(feat, n_bins)] = np.ndarray(n_inter,) int8  — bin index (-1 = NaN)
    # labels_map[(feat, n_bins)] = list[str]
    bins_map   = {}
    labels_map = {}
    for feat in sel_feats:
        fi   = feat_idx_map[feat]
        vals = X_inter[:, fi]
        ok   = ~np.isnan(vals)
        for nb in n_bins_list:
            b_arr, lbls = _quantile_bins(vals, ok, nb)
            # Filter: remove bins where total count < min_n BEFORE storing
            b_arr = _filter_rare_bins(b_arr, min_n, nb)
            bins_map[(feat, nb)]   = b_arr     # int8, -1 = invalid
            labels_map[(feat, nb)] = lbls

    # ── Calcul parallèle : 1 future par (pair, n_bins) ────────────────────
    all_pairs  = list(combinations(sel_feats, 2))
    all_tasks  = [(fa, fb, nb) for fa, fb in all_pairs for nb in n_bins_list]
    n_tasks    = len(all_tasks)

    pairs_result = {}
    max_workers  = min(16, max(4, n_tasks // 4 + 1))

    with ThreadPoolExecutor(max_workers=max_workers,
                            thread_name_prefix="dep11_inter") as pool:
        future_map = {}
        for fa, fb, nb in all_tasks:
            ba = bins_map[(fa, nb)]
            bb = bins_map[(fb, nb)]
            na_b = int(ba.max()) + 1 if ba.max() >= 0 else 0
            nb_b = int(bb.max()) + 1 if bb.max() >= 0 else 0
            if na_b < 2 or nb_b < 2:
                # Not enough valid bins after filtering
                continue
            fut = pool.submit(
                _cell_stats_vectorized,
                y_inter, ba, bb, na_b, nb_b, min_n, global_mean, global_std
            )
            future_map[fut] = (fa, fb, nb)

        for fut in as_completed(future_map):
            fa, fb, nb = future_map[fut]
            try:
                res = fut.result()
                if res is not None:
                    pairs_result[(fa, fb, nb)] = res
            except Exception:
                pass

    # ── Metadata ──────────────────────────────────────────────────────────
    meta = dict(
        min_n       = min_n,
        inter_n     = n_inter,
        n_bins_list = n_bins_list,
        feats       = sel_feats,
        bin_labels  = {(f, nb): labels_map[(f, nb)]
                       for f in sel_feats for nb in n_bins_list},
        global_mean = global_mean,
        global_std  = global_std,
    )

    elapsed = time.perf_counter() - t0
    n_pairs_done = len(pairs_result)
    print(f"  ✅  interactions: {n_pairs_done}/{n_tasks} paires·bins "
          f"en {elapsed:.1f}s  (min_n={min_n}, {len(sel_feats)} feats)")

    return {"meta": meta, "pairs": pairs_result}


def _encode_y(y_raw, dep):
    """Encode target → float64 pour les stats."""
    if dep.is_classification:
        from sklearn.preprocessing import LabelEncoder
        le = LabelEncoder()
        encoded = le.fit_transform(y_raw.astype(str)).astype(np.float64)
        return encoded
    return y_raw.astype(np.float64)


def _quantile_bins(vals, ok_mask, nb):
    """
    Découpe vals en nb bins quantile. Retourne (bin_array int8, labels list[str]).
    bin_array[i] = -1 si NaN ou hors plage.
    """
    x_ok = vals[ok_mask]
    if len(x_ok) < nb * 2:
        return np.full(len(vals), -1, dtype=np.int8), [f"Q{i+1}" for i in range(nb)]

    # Edges quantile uniques
    percentiles = np.linspace(0, 100, nb + 1)
    edges = np.unique(np.percentile(x_ok, percentiles))
    if len(edges) < 3:
        # Fallback : equal-width
        edges = np.linspace(x_ok.min(), x_ok.max(), nb + 1)

    # Clip to actual nb bins
    n_actual = len(edges) - 1

    # Labels
    labels = [f"{edges[i]:.3g}–{edges[i+1]:.3g}" for i in range(n_actual)]

    # Assign bins : vectorized searchsorted
    b_arr = np.full(len(vals), -1, dtype=np.int8)
    # Only assign where not NaN
    x_vals = vals.copy()
    x_vals[~ok_mask] = np.nan
    assigned = np.searchsorted(edges[1:-1], x_vals, side="right").astype(np.int8)
    # Clip to [0, n_actual-1]
    assigned = np.clip(assigned, 0, n_actual - 1).astype(np.int8)
    b_arr[ok_mask] = assigned[ok_mask]

    return b_arr, labels


def _filter_rare_bins(b_arr, min_n, nb):
    """
    Reindex bins to ignore bins with count < min_n.
    Sets those cells to -1 (invalid). Preserves relative order.
    """
    if min_n <= 0:
        return b_arr
    b_copy = b_arr.copy()
    for bi in range(nb):
        if np.sum(b_arr == bi) < min_n:
            b_copy[b_arr == bi] = -1
    # Compact: remap remaining valid bins to 0..K
    valid_bins = sorted(set(b_copy[b_copy >= 0].tolist()))
    if not valid_bins:
        return np.full(len(b_arr), -1, dtype=np.int8)
    remap = {old: np.int8(new) for new, old in enumerate(valid_bins)}
    out = np.full(len(b_arr), -1, dtype=np.int8)
    for old, new in remap.items():
        out[b_copy == old] = new
    return out


def _cell_stats_vectorized(y_vals, bin_a, bin_b, na, nb, min_n,
                            global_mean, global_std):
    """
    Calcule les stats de toutes les cellules (ia, ib) en O(n) via np.bincount.

    Pas de boucle Python sur les lignes.
    Filtre min_n appliqué AVANT tout t-test.

    Retourne dict avec arrays shape (na*nb,) ou (na, nb).
    """
    n_cells = na * nb

    # Masque : pas NaN dans y, et les deux bins valides
    valid_rows = (bin_a >= 0) & (bin_b >= 0) & (~np.isnan(y_vals))
    if valid_rows.sum() < min_n:
        return None

    y_v   = y_vals[valid_rows].astype(np.float64)
    ba_v  = bin_a[valid_rows].astype(np.int32)
    bb_v  = bin_b[valid_rows].astype(np.int32)

    cell_id = ba_v * nb + bb_v   # shape (n_valid,) — unique int per cell

    # ── Vectorized aggregation via bincount ───────────────────────────────
    counts   = np.bincount(cell_id, minlength=n_cells).astype(np.float64)
    sums     = np.bincount(cell_id, weights=y_v,    minlength=n_cells)
    sums_sq  = np.bincount(cell_id, weights=y_v**2, minlength=n_cells)

    total_n   = float(counts.sum())
    total_sum = float(sums.sum())
    total_sq  = float(sums_sq.sum())

    # ── Per-cell means and variances ─────────────────────────────────────
    with np.errstate(invalid="ignore", divide="ignore"):
        means  = np.where(counts > 0, sums / counts, np.nan)
        m2     = np.where(counts > 0, sums_sq / counts, np.nan)
        # Bessel-corrected variance
        vars_c = np.where(counts > 1,
                          (m2 - means**2) * counts / np.maximum(counts - 1, 1),
                          np.nan)

    # ── Complement (rest) stats — vectorized ─────────────────────────────
    rest_n   = total_n - counts
    rest_sum = total_sum - sums
    rest_sq  = total_sq - sums_sq

    with np.errstate(invalid="ignore", divide="ignore"):
        rest_mean = np.where(rest_n > 0, rest_sum / rest_n, np.nan)
        rest_m2   = np.where(rest_n > 0, rest_sq  / rest_n, np.nan)
        rest_var  = np.where(rest_n > 1,
                             (rest_m2 - rest_mean**2) * rest_n / np.maximum(rest_n - 1, 1),
                             np.nan)

    # ── Apply min_n filter BEFORE computing p-values ──────────────────────
    valid_cell = counts >= min_n   # bool array shape (n_cells,)

    # ── Vectorized Welch t-test (only on valid cells) ─────────────────────
    se_sq = (np.where(valid_cell, vars_c,  0.0) / np.maximum(counts,   1) +
             np.where(valid_cell, rest_var, 0.0) / np.maximum(rest_n,   1))
    se    = np.sqrt(np.maximum(se_sq, 1e-18))
    t_val = np.where(valid_cell, (means - rest_mean) / se, np.nan)

    # Welch-Satterthwaite degrees of freedom
    va = np.where(valid_cell, vars_c,  0.0) / np.maximum(counts,  1)
    vb = np.where(valid_cell, rest_var, 0.0) / np.maximum(rest_n,  1)
    df_w = (va + vb)**2 / (
        va**2 / np.maximum(counts  - 1, 1) +
        vb**2 / np.maximum(rest_n  - 1, 1) + 1e-18
    )
    df_w = np.maximum(df_w, 1.0)

    # Batch p-values via scipy (vectorized over array)
    from scipy.stats import t as t_dist
    p_vals = np.where(
        valid_cell & ~np.isnan(t_val),
        2.0 * t_dist.sf(np.abs(t_val), df=df_w),
        np.nan
    )

    # ── Cohen's d (relative to global mean, pooled std) ──────────────────
    pooled_std = np.sqrt(np.where(valid_cell,
                                   (np.nan_to_num(vars_c) + np.nan_to_num(rest_var)) / 2,
                                   global_std**2) + 1e-18)
    cohens_d   = np.where(valid_cell,
                           (means - global_mean) / pooled_std,
                           np.nan)

    # CI95 on difference (cell mean vs rest mean)
    ci95 = np.where(valid_cell & ~np.isnan(df_w),
                    t_dist.ppf(0.975, df=df_w) * se,
                    np.nan)

    return dict(
        na=na, nb=nb,
        counts   = counts.astype(np.float32),
        means    = means.astype(np.float32),
        cohens_d = cohens_d.astype(np.float32),
        p_vals   = p_vals.astype(np.float32),
        ci95     = ci95.astype(np.float32),
        valid    = valid_cell,                    # bool array
        global_mean = float(global_mean),
        global_std  = float(global_std),
        total_n     = int(total_n),
    )


# ─────────────────────────────────────────────────────────────────────────────
#  AUTRES WORKERS (inchangés v10)
# ─────────────────────────────────────────────────────────────────────────────

def _fstats(X, cols, y, dep):
    n, p = X.shape
    q = np.nanpercentile(X, [1,5,10,25,50,75,90,95,99], axis=0)
    mean_v = np.nanmean(X, axis=0).astype(np.float64)
    std_v  = np.nanstd( X, axis=0, ddof=1).astype(np.float64)
    min_v  = np.nanmin( X, axis=0).astype(np.float64)
    max_v  = np.nanmax( X, axis=0).astype(np.float64)
    nan_v  = np.isnan(X).mean(axis=0)
    iqr_v  = q[5]-q[3]
    out_v  = np.mean((X < q[3]-1.5*iqr_v)|(X > q[5]+1.5*iqr_v), axis=0)
    std_safe = np.where(std_v>0, std_v, 1e-9)
    Xc = X-mean_v
    skw = np.nanmean((Xc/std_safe)**3, axis=0)
    krt = np.nanmean((Xc/std_safe)**4, axis=0)-3.0
    return dict(cols=cols, n=n,
                mean=mean_v, std=std_v, min=min_v, max=max_v,
                q01=q[0],q05=q[1],q10=q[2],q25=q[3],
                q50=q[4],q75=q[5],q90=q[6],q95=q[7],q99=q[8],
                iqr=iqr_v, nan_pct=nan_v, outlier_pct=out_v,
                skew=skw, kurt=krt)


def _miss(X, cols, dep):
    n, p   = X.shape
    mp     = np.isnan(X).mean(axis=0)
    mc     = np.isnan(X).sum(axis=0)
    total  = float(mp.mean()*100)
    n_comp = int((~np.isnan(X).any(axis=1)).sum())
    rng    = np.random.default_rng(42)
    idx    = rng.choice(n, size=min(n,50_000), replace=False)
    M      = np.isnan(X[idx]).astype(np.float32)
    cooc   = (M.T @ M)/len(idx)
    return dict(cols=cols, miss_pct=dict(zip(cols,mp.tolist())),
                miss_cnt=dict(zip(cols,mc.tolist())),
                total_pct=total, n_complete=n_comp, cooc=cooc)


def _corr(X_sample, cols):
    Xd = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c,m in zip(cols,col_mask) if m]
    cmeans     = np.nanmean(Xd, axis=0)
    nl         = np.isnan(Xd)
    Xd[nl]     = np.take(cmeans, np.where(nl)[1])

    def _pmat(M):
        Mc  = M-M.mean(axis=0)
        nrm = np.linalg.norm(Mc, axis=0)
        nrm = np.where(nrm==0, 1e-9, nrm)
        mat = (Mc/nrm).T @ (Mc/nrm)
        np.fill_diagonal(mat, 1.0)
        return mat.clip(-1,1)

    pearson  = _pmat(Xd)
    from scipy.stats import rankdata
    Xr       = np.apply_along_axis(rankdata, 0, Xd).astype(np.float64)
    spearman = _pmat(Xr)
    return (pd.DataFrame(pearson,  index=cols_valid, columns=cols_valid),
            pd.DataFrame(spearman, index=cols_valid, columns=cols_valid))


def _pca_work(X_sample, cols):
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    Xd = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c,m in zip(cols,col_mask) if m]
    cmeans = np.nanmean(Xd, axis=0)
    nl = np.isnan(Xd)
    Xd[nl] = np.take(cmeans, np.where(nl)[1])
    n_comp = min(15, Xd.shape[1], Xd.shape[0])
    scaler = StandardScaler()
    Xs     = scaler.fit_transform(Xd)
    if Xs.shape[0] > 150_000:
        rng = np.random.default_rng(42)
        Xs  = Xs[rng.choice(Xs.shape[0], 150_000, replace=False)]
    pca    = PCA(n_components=n_comp, random_state=42, svd_solver="randomized")
    scores = pca.fit_transform(Xs)
    return dict(cols=cols_valid, scaler=scaler, pca=pca,
                scores=scores.astype(np.float32),
                loadings=pca.components_.T.astype(np.float32),
                explained=pca.explained_variance_ratio_.astype(np.float32),
                n_comp=n_comp)


def _importance(X, y, cols, is_cls):
    from sklearn.feature_selection import (f_classif, f_regression,
        mutual_info_classif, mutual_info_regression)
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.preprocessing import StandardScaler
    from scipy.stats import rankdata
    p  = X.shape[1]
    Xd = X.astype(np.float64)
    yd = y.astype(np.float64)
    cm = np.nanmean(Xd, axis=0)
    nl = np.isnan(Xd)
    Xd[nl] = np.take(cm, np.where(nl)[1])
    def _norm(a): mx=a.max(); return (a/mx if mx>0 else a).clip(0,1)
    out = {"cols": cols}
    Xc = Xd-Xd.mean(axis=0); yc=yd-yd.mean()
    sx = Xd.std(axis=0)+1e-9; sy=yd.std()+1e-9
    out["pearson"]  = _norm(np.abs((Xc*yc[:,None]).mean(axis=0)/(sx*sy)))
    Xr = np.apply_along_axis(rankdata,0,Xd); yr=rankdata(yd)
    Xrc=Xr-Xr.mean(axis=0); yrc=yr-yr.mean()
    sr=Xr.std(axis=0)+1e-9; syr=yr.std()+1e-9
    out["spearman"] = _norm(np.abs((Xrc*yrc[:,None]).mean(axis=0)/(sr*syr)))
    try:
        fn=f_classif if is_cls else f_regression
        yc_=y.astype(int) if is_cls else yd
        f,_ = fn(Xd,yc_)
        out["fstat"] = _norm(np.nan_to_num(f,nan=0,posinf=0))
    except: out["fstat"] = np.zeros(p)
    try:
        fn_mi=mutual_info_classif if is_cls else mutual_info_regression
        yc_=y.astype(int) if is_cls else yd
        mi = fn_mi(Xd,yc_,random_state=42,n_neighbors=5)
        out["mi"] = _norm(np.nan_to_num(mi,nan=0))
    except: out["mi"] = np.zeros(p)
    try:
        Xs=StandardScaler().fit_transform(Xd)
        yc_=y.astype(int) if is_cls else yd
        RF=RandomForestClassifier if is_cls else RandomForestRegressor
        rf=RF(n_estimators=60,max_depth=8,max_features="sqrt",
              min_samples_leaf=20,n_jobs=-1,random_state=42)
        rf.fit(Xs,yc_)
        out["rf"] = _norm(rf.feature_importances_)
    except: out["rf"] = np.zeros(p)
    stack = np.column_stack([out["pearson"],out["spearman"],out["fstat"],out["mi"],out["rf"]])
    out["global"] = _norm(stack.mean(axis=1))
    return out


def _iv(X_full, y_full, cols, dep):
    if not dep.is_classification or dep.n_classes != 2:
        return _eta2(X_full, y_full, cols)
    cls1 = dep.classes[-1]
    y_bin = (y_full==cls1).astype(np.int8)
    total_ev  = max(int(y_bin.sum()),1)
    total_nev = max(len(y_bin)-total_ev,1)
    result = {}; N_BINS=10
    for i, col in enumerate(cols):
        x=X_full[:,i]; ok=~np.isnan(x); xv,yv=x[ok],y_bin[ok]
        if len(xv)<20: result[col]=0.0; continue
        try:
            q=np.unique(np.percentile(xv,np.linspace(0,100,N_BINS+1)))
            if len(q)<3: result[col]=0.0; continue
            b=np.searchsorted(q[1:-1],xv,side="right"); iv=0.0
            for bi in np.unique(b):
                m=b==bi; ev=max(int(yv[m].sum()),1); nev=max(int((1-yv[m]).sum()),1)
                woe=np.log((ev/total_ev)/(nev/total_nev))
                iv+=(ev/total_ev-nev/total_nev)*woe
            result[col]=float(np.clip(iv,0,5))
        except: result[col]=0.0
    return result


def _eta2(X, y, cols):
    result={}
    for i,col in enumerate(cols):
        x=X[:,i]; ok=~np.isnan(x); xv=x[ok].astype(np.float64); yv=y[ok]
        if len(xv)<10: result[col]=0.0; continue
        try:
            gm=xv.mean(); sst=((xv-gm)**2).sum()
            if sst<1e-12: result[col]=0.0; continue
            ssb=sum(((xv[yv==c].mean()-gm)**2)*(yv==c).sum()
                    for c in np.unique(yv) if (yv==c).sum()>0)
            result[col]=float(np.clip(ssb/sst,0,1))
        except: result[col]=0.0
    return result
