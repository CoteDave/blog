"""app_factory.py — DataExplore Pro v6"""
from __future__ import annotations
import os
import dash
from dash import dcc, html, Input, Output, ctx
import dash_bootstrap_components as dbc

DEFAULT_PAGE = "overview"

SIDEBAR_ITEMS = [
    ("overview",      "⊞",  "Aperçu Global"),
    ("univariate",    "≈",  "Analyse Univariée"),
    ("scatter",       "◎",  "Dispersion Bivariée"),
    ("correlation",   "⊟",  "Matrice de Corrélation"),
    ("analysis3d",    "⬡",  "Analyses 3D"),
    ("importance",    "≡",  "Importance des Variables"),
    ("missing",       "▦",  "Valeurs Manquantes"),
    ("clusters",      "◑",  "Analyse de Clusters"),
    ("pca",           "⊕",  "ACP / Réduction de Dimension"),
    ("corr_clusters", "⊶",  "Clusters de Corrélation"),
    ("posthoc",       "⊸",  "Analyses Post-Hoc"),
    ("interactions",  "⊗",  "Interactions de Features"),
    ("causal",        "→",  "Découverte Causale"),
    ("anova",         "∿",  "ANOVA Multi-Facteurs"),
    ("synthesis",     "★",  "Synthèse & Conclusions"),
]

SIDEBAR_DIVIDERS_AFTER = {"scatter", "pca", "missing", "posthoc"}
STUB_PAGES = set()


def create_app(dep):
    assets_dir = os.path.join(os.path.dirname(__file__), "assets")
    app = dash.Dash(
        __name__,
        external_stylesheets=[
            dbc.themes.BOOTSTRAP,
            "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap",
        ],
        suppress_callback_exceptions=True,
        title=dep.title,
        assets_folder=assets_dir,
    )
    app.layout = _build_layout(dep)
    _register_callbacks(app, dep)
    return app


def _build_layout(dep):
    n_obs    = len(dep.df)
    n_feat   = len(dep.num_features)
    mode_txt = f"Supervisé · {dep.n_classes} cls" if dep.supervised else "Non supervisé"

    return html.Div([
        dcc.Store(id="active-page", data=DEFAULT_PAGE),

        html.Header([
            html.Div([
                html.Div(
                    html.Span("◰", style={"fontSize": "20px", "color": "white", "lineHeight": "1"}),
                    className="logo-icon-wrap",
                ),
                html.Span(
                    ["Data", html.Span("Explore", style={"color": "#e07b39"}), " Pro"],
                    className="logo-text",
                ),
            ], className="logo"),

            html.Div([
                html.Span(f"{n_obs:,}", style={"fontWeight": "800", "color": "#1e3a5f"}),
                html.Span(" obs · ", style={"color": "#bbb"}),
                html.Span(f"{n_feat}", style={"fontWeight": "700", "color": "#4472c4"}),
                html.Span(" vars · ", style={"color": "#bbb"}),
                html.Span(mode_txt, style={"color": "#e07b39", "fontWeight": "600"}),
            ], style={
                "marginLeft": "auto", "fontSize": "12px",
                "background": "#f0f4f8", "borderRadius": "99px",
                "padding": "5px 14px", "border": "1px solid #dde2ea",
            }),
        ], className="app-header"),

        html.Div([
            html.Aside(_build_sidebar(), className="sidebar", id="sidebar"),
            html.Main(
                dcc.Loading(
                    html.Div(id="page-content"),
                    type="circle", color="#4472c4",
                    style={"minHeight": "120px"},
                ),
                className="page-content",
            ),
        ], className="app-body"),

    ], className="app-wrapper", style={"fontFamily": "Plus Jakarta Sans, sans-serif"})


def _build_sidebar():
    items = []
    for page_id, symbol, label in SIDEBAR_ITEMS:
        active = (page_id == DEFAULT_PAGE)
        items.append(html.Div(
            [
                html.Span(symbol, style={"fontSize": "14px", "width": "20px",
                                          "textAlign": "center", "flexShrink": "0",
                                          "display": "inline-block"}),
                html.Span(label, style={"fontSize": "12.5px", "lineHeight": "1.3"}),
            ],
            id={"type": "sidebar-item", "index": page_id},
            className="sidebar-item" + (" active" if active else ""),
            n_clicks=0, title=label,
            style=_sb_style(active),
        ))
        if page_id in SIDEBAR_DIVIDERS_AFTER:
            items.append(html.Hr(className="sb-divider"))
    return items


def _sb_style(active=False):
    return {
        "display": "flex", "alignItems": "center", "gap": "9px",
        "padding": "8px 12px", "borderRadius": "6px", "cursor": "pointer",
        "transition": "background .18s, border-left-color .18s",
        "color": "white" if active else "rgba(255,255,255,.68)",
        "background": "rgba(68,114,196,.22)" if active else "transparent",
        "fontWeight": "700" if active else "500",
        "borderLeft": "3px solid #e07b39" if active else "3px solid transparent",
    }


def _register_callbacks(app, dep):
    from .pages.scatter       import register_callbacks as scatter_cb
    from .pages.overview      import register_callbacks as overview_cb
    from .pages.correlation   import register_callbacks as correlation_cb
    from .pages.univariate    import register_callbacks as univariate_cb
    from .pages.analysis_3d   import register_callbacks as analysis3d_cb
    from .pages.importance    import register_callbacks as importance_cb
    from .pages.missing       import register_callbacks as missing_cb
    from .pages.clusters      import register_callbacks as clusters_cb
    from .pages.pca           import register_callbacks as pca_cb
    from .pages.corr_clusters import register_callbacks as corr_clusters_cb
    from .pages.posthoc       import register_callbacks as posthoc_cb
    from .pages.synthesis     import register_callbacks as synthesis_cb
    from .pages.interactions  import register_callbacks as interactions_cb
    from .pages.causal        import register_callbacks as causal_cb
    from .pages.anova         import register_callbacks as anova_cb

    scatter_cb(app, dep);      overview_cb(app, dep)
    correlation_cb(app, dep);  univariate_cb(app, dep)
    analysis3d_cb(app, dep);   importance_cb(app, dep)
    missing_cb(app, dep);      clusters_cb(app, dep)
    pca_cb(app, dep);          corr_clusters_cb(app, dep)
    posthoc_cb(app, dep);      synthesis_cb(app, dep)
    interactions_cb(app, dep)
    causal_cb(app, dep)
    anova_cb(app, dep)

    @app.callback(
        [Output("active-page", "data"),
         Output({"type": "sidebar-item", "index": dash.ALL}, "className"),
         Output({"type": "sidebar-item", "index": dash.ALL}, "style")],
        Input({"type": "sidebar-item", "index": dash.ALL}, "n_clicks"),
        prevent_initial_call=True,
    )
    def navigate(_):
        trig = ctx.triggered_id
        if not trig or not isinstance(trig, dict):
            return _nav_out(DEFAULT_PAGE)
        return _nav_out(trig.get("index", DEFAULT_PAGE))

    @app.callback(
        Output("page-content", "children"),
        Input("active-page", "data"),
    )
    def render_page(page_id):
        return _get_page(dep, page_id or DEFAULT_PAGE)


def _nav_out(page_id):
    classes, styles = [], []
    for pid, _, _ in SIDEBAR_ITEMS:
        a = pid == page_id
        classes.append("sidebar-item active" if a else "sidebar-item")
        styles.append(_sb_style(a))
    return page_id, classes, styles


def _get_page(dep, page_id):
    from .pages.scatter       import layout as sc
    from .pages.overview      import layout as ov
    from .pages.correlation   import layout as co
    from .pages.univariate    import layout as un
    from .pages.analysis_3d   import layout as a3
    from .pages.importance    import layout as im
    from .pages.missing       import layout as mi
    from .pages.clusters      import layout as cl
    from .pages.pca           import layout as pc
    from .pages.corr_clusters import layout as cc
    from .pages.posthoc       import layout as ph
    from .pages.synthesis     import layout as sy
    from .pages.stubs         import layout as st
    from .pages.interactions  import layout as it_
    from .pages.causal        import layout as cau
    from .pages.anova         import layout as ano

    pages = {
        "scatter": sc, "overview": ov, "correlation": co, "univariate": un,
        "analysis3d": a3, "importance": im, "missing": mi, "clusters": cl,
        "pca": pc, "corr_clusters": cc, "posthoc": ph, "synthesis": sy,
        "interactions": it_,
        "causal": cau, "anova": ano,
    }
    if page_id in pages:      return pages[page_id](dep)
    if page_id in STUB_PAGES: return st(dep, page_id)
    return ov(dep)
