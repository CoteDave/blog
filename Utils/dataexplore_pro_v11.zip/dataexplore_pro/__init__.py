"""
DataExplore Pro
===============
Interactive data-exploration dashboard for Python ML workflows.

Quick start
-----------
>>> from dataexplore_pro import DataExplorePro
>>> dep = DataExplorePro(X, y)  # supervised
>>> dep.run()

>>> dep = DataExplorePro(X)     # unsupervised
>>> dep.run()
"""

from .core import DataExplorePro

__version__ = "8.0.0"
__all__ = ["DataExplorePro"]
