"""
Interactions de Features v11
═══════════════════════════════════════════════════════════════════════════════
Toutes les paires (et optionnellement triplets) sont PRÉ-CALCULÉES avant le
déploiement (voir _precompute._interactions_work).

Architecture :
  • Callback reçoit les sélections (feat_a, feat_b, feat_c, n_bins, alpha)
  • Si (feat_a, feat_b, n_bins) est dans le cache → reconstruit INSTANTANÉMENT
  • Sinon → fallback vectorisé O(n) (même algorithme bincount)
  • feat_c (optionnel) → jamais précalculé → toujours vectorisé O(n), rapide

UI :
  • Badge ⚡ Précalculé vs ⏱ Calculé en temps réel + infos N
  • Heatmap A×B : μ target, Δ vs moyenne globale, contour si sig.
  • UpSet plot amélioré
  • Heatmaps par slice de C
  • Table de règles avec "SI … ET … ALORS…"
  • Régression OLS avec termes d'interaction (statsmodels ou fallback)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import product, combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats as sp_stats

PAL   = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID  = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"
CS_DIV = [[0,"#b2182b"],[0.25,"#f4a582"],[0.5,"#f7f7f7"],[0.75,"#92c5de"],[1,"#2166ac"]]


def layout(dep):
    num = dep.num_features
    if not dep.supervised:
        return html.Div([
            html.Div("Interactions de Features", className="page-title"),
            html.Div("⚠️ Requiert un dataset supervisé (avec target).",
                     className="page-subtitle"),
        ], className="page-card")

    tgt    = dep.target_name
    min_n  = dep.interaction_min_samples
    n_bins_def = dep.interaction_n_bins_default

    return html.Div([
        html.Div("Interactions de Features", className="page-title"),
        html.Div(
            f"Interactions 2–3 features binned vs target '{tgt}'. "
            f"Paires pré-calculées (⚡ instantané). min_samples={min_n}.",
            className="page-subtitle"),

        # Controls
        html.Div([
            html.Div([html.Div("Feature A:", className="control-label"),
                      dcc.Dropdown(id="int-feat-a",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[0] if num else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),
            html.Div([html.Div("Feature B:", className="control-label"),
                      dcc.Dropdown(id="int-feat-b",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[1] if len(num)>1 else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),
            html.Div([html.Div("Feature C (optionnelle):", className="control-label"),
                      dcc.Dropdown(id="int-feat-c",
                          options=[{"label":"— Aucune —","value":""}]
                                  +[{"label":c,"value":c} for c in num],
                          value="", clearable=False, style={"width":"200px"})],
                className="control-group"),
            html.Div([html.Div(f"Bins/feature (min_n≥{min_n}):",
                               className="control-label"),
                      dcc.Slider(id="int-bins", min=2, max=6, step=1,
                          value=n_bins_def,
                          marks={i:str(i) for i in range(2,7)},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"200px"}),
            html.Div([html.Div("Seuil α:", className="control-label"),
                      dcc.Dropdown(id="int-alpha",
                          options=[{"label":"0.05","value":"0.05"},
                                   {"label":"0.01","value":"0.01"},
                                   {"label":"0.10","value":"0.10"}],
                          value="0.05", clearable=False, style={"width":"100px"})],
                className="control-group"),
        ], className="controls-row"),

        # Source badge + summary
        html.Div(id="int-source-badge",
                 style={"marginBottom":"8px"}),
        html.Div(id="int-summary",
                 style={"marginBottom":"16px"}),

        # Heatmap A×B + UpSet
        html.Div([
            html.Div([
                html.Div(id="int-heatmap-title", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="int-heatmap",
                    config={"displayModeBar":False}, style={"height":"400px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                html.Div("UpSet Plot — Effectifs & direction par combinaison",
                         className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="int-upset",
                    config={"displayModeBar":False}, style={"height":"400px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # Feature C slices
        html.Div(id="int-slice-section", style={"marginBottom":"16px"}),

        # Rules table
        html.Div([
            html.Div("📋 Table de Règles — SI … ET … ALORS …",
                     className="chart-card-title"),
            html.Div(id="int-rules-table"),
        ], className="chart-card", style={"marginBottom":"16px"}),

        # OLS regression
        html.Div([
            html.Div("📐 Régression OLS avec interactions",
                     className="chart-card-title"),
            html.Div(id="int-regression"),
        ], className="chart-card"),

    ], className="page-card")


def register_callbacks(app, dep):

    _fallback_memo: dict = {}   # memoize fallback computations only

    @app.callback(
        [Output("int-source-badge","children"),
         Output("int-summary","children"),
         Output("int-heatmap","figure"),
         Output("int-heatmap-title","children"),
         Output("int-upset","figure"),
         Output("int-slice-section","children"),
         Output("int-rules-table","children"),
         Output("int-regression","children")],
        [Input("int-feat-a","value"),
         Input("int-feat-b","value"),
         Input("int-feat-c","value"),
         Input("int-bins","value"),
         Input("int-alpha","value")],
    )
    def update(feat_a, feat_b, feat_c, n_bins, alpha_str):
        import time
        t_start = time.perf_counter()

        alpha  = float(alpha_str or 0.05)
        n_bins = int(n_bins or dep.interaction_n_bins_default)
        feat_c = feat_c or ""
        tgt    = dep.target_name
        min_n  = dep.interaction_min_samples

        empty = go.Figure()
        err = lambda m: (_badge("❌ Erreur","#e74c3c"), _err(m),
                         empty,"",empty,html.Div(),[],[])

        if not feat_a or not feat_b or feat_a == feat_b:
            return err("Sélectionnez 2 features différentes.")
        if feat_a not in dep.num_features or feat_b not in dep.num_features:
            return err("Features invalides.")

        # ── Récupère les stats de la paire depuis le cache ────────────────
        inter_cache = dep.cache.get("interactions", wait=False)

        cell_stats_ab, lbls_a, lbls_b, source_info = _get_pair_stats(
            dep, inter_cache, feat_a, feat_b, n_bins, min_n
        )

        if cell_stats_ab is None:
            return err(f"Données insuffisantes pour {feat_a} × {feat_b} "
                       f"(min_n={min_n}, essayez moins de bins).")

        na   = cell_stats_ab["na"]
        nb   = cell_stats_ab["nb"]
        g_mean = float(cell_stats_ab.get("global_mean", 0.0))
        g_std  = float(cell_stats_ab.get("global_std", 1.0))

        # Reconstruct rule list from flat cell_stats arrays
        rules_2d = _reconstruct_rules(
            cell_stats_ab, feat_a, feat_b, lbls_a, lbls_b, alpha,
            feat_c=None, lbl_c=None, ic=None
        )

        # ── Feature C (on-demand vectorisé, non précalculé) ───────────────
        feat_c_stats  = None
        feat_c_slices = {}
        feat_c_lbls   = []
        if feat_c and feat_c in dep.num_features and feat_c != feat_a and feat_c != feat_b:
            feat_c_stats, feat_c_lbls = _compute_feat_c(
                dep, feat_a, feat_b, feat_c, n_bins, min_n, g_mean, g_std
            )
            if feat_c_stats:
                feat_c_slices = feat_c_stats

        # ── Summary cards ─────────────────────────────────────────────────
        n_sig = sum(1 for r in rules_2d if r.get("sig"))
        n_tot = len(rules_2d)
        valid_rules = [r for r in rules_2d if not np.isnan(r.get("mean", np.nan))]
        best_d = max(valid_rules, key=lambda r: abs(r.get("cohens_d",0)), default=None)
        max_r  = max(valid_rules, key=lambda r: r.get("mean", -np.inf), default=None)
        min_r  = min(valid_rules, key=lambda r: r.get("mean",  np.inf), default=None)
        summary = _summary_cards(n_tot, n_sig, alpha, best_d, min_r, max_r, tgt)

        # ── Heatmap ───────────────────────────────────────────────────────
        fig_heat, heat_title = _build_heatmap(
            cell_stats_ab, lbls_a, lbls_b, feat_a, feat_b, tgt, alpha
        )

        # ── UpSet plot ────────────────────────────────────────────────────
        fig_upset = _upset_plot(rules_2d, [feat_a, feat_b], g_mean, tgt, alpha)

        # ── Slices de C ───────────────────────────────────────────────────
        slice_section = html.Div()
        if feat_c_slices:
            slice_section = _slice_section(
                feat_c_slices, feat_c_lbls, feat_a, feat_b, feat_c,
                lbls_a, lbls_b, tgt, alpha
            )

        # ── Table de règles ───────────────────────────────────────────────
        rules_table = _rules_table(rules_2d, tgt, g_mean, alpha)

        # ── Régression OLS ────────────────────────────────────────────────
        reg_section = _ols_section(dep, feat_a, feat_b, feat_c, n_bins, min_n, tgt)

        elapsed_ms = (time.perf_counter() - t_start) * 1000
        badge = _badge(source_info, "#27ae60" if "⚡" in source_info else "#e07b39",
                       extra=f" · {elapsed_ms:.0f}ms")

        return (badge, summary, fig_heat, heat_title, fig_upset,
                slice_section, rules_table, reg_section)


# ══════════════════════════════════════════════════════════════════════════════
#  CACHE LOOKUP + FALLBACK
# ══════════════════════════════════════════════════════════════════════════════

def _get_pair_stats(dep, inter_cache, feat_a, feat_b, n_bins, min_n):
    """
    Cherche (feat_a, feat_b, n_bins) dans le cache.
    Si manquant : calcule à la volée (vectorisé O(n)).
    Retourne (cell_stats_dict, lbls_a, lbls_b, source_info).
    """
    from ._precompute import _quantile_bins, _filter_rare_bins, _cell_stats_vectorized, _encode_y

    # ── Essai cache ───────────────────────────────────────────────────────
    if inter_cache is not None:
        pairs   = inter_cache.get("pairs", {})
        meta    = inter_cache.get("meta", {})
        bin_lbl = meta.get("bin_labels", {})

        # Try both orderings (fa,fb) and (fb,fa)
        for fa2, fb2 in [(feat_a, feat_b), (feat_b, feat_a)]:
            key = (fa2, fb2, n_bins)
            if key in pairs:
                stats = pairs[key]
                lbls_a_raw = bin_lbl.get((fa2, n_bins), [f"B{i}" for i in range(stats["na"])])
                lbls_b_raw = bin_lbl.get((fb2, n_bins), [f"B{i}" for i in range(stats["nb"])])
                # Flip if order was reversed
                if fa2 == feat_b:
                    # Transpose the flat array (na, nb) → (nb, na)
                    stats = _transpose_pair_stats(stats)
                    lbls_a_raw, lbls_b_raw = lbls_b_raw, lbls_a_raw
                n_inter = meta.get("inter_n", "?")
                info = f"⚡ Précalculé · {n_inter:,} pts" if isinstance(n_inter,int) else f"⚡ Précalculé"
                return stats, lbls_a_raw, lbls_b_raw, info

    # ── Fallback : calcul vectorisé O(n) ──────────────────────────────────
    df = dep.display_df
    num = dep.num_features
    feat_idx = {f: i for i, f in enumerate(num)}

    if feat_a not in feat_idx or feat_b not in feat_idx:
        return None, [], [], "Erreur"

    X = df[num].fillna(df[num].median()).values.astype(np.float64)
    y = _encode_y(dep.display_df[dep.target_name].values, dep)

    g_mean = float(np.nanmean(y)); g_std = float(np.nanstd(y, ddof=1))

    vals_a = X[:, feat_idx[feat_a]]
    vals_b = X[:, feat_idx[feat_b]]
    ok_a   = ~np.isnan(vals_a); ok_b = ~np.isnan(vals_b)

    ba, lbls_a = _quantile_bins(vals_a, ok_a, n_bins)
    bb, lbls_b = _quantile_bins(vals_b, ok_b, n_bins)
    ba = _filter_rare_bins(ba, min_n, n_bins)
    bb = _filter_rare_bins(bb, min_n, n_bins)

    na = int(ba.max())+1 if ba.max()>=0 else 0
    nb_v = int(bb.max())+1 if bb.max()>=0 else 0

    if na < 2 or nb_v < 2:
        return None, [], [], "Fallback: pas assez de bins valides"

    stats = _cell_stats_vectorized(y, ba, bb, na, nb_v, min_n, g_mean, g_std)
    if stats is None:
        return None, [], [], "Fallback: données insuffisantes"

    n_used = len(y)
    info = f"⏱ Calculé · {n_used:,} pts (display_df)"
    return stats, lbls_a, lbls_b, info


def _transpose_pair_stats(stats):
    """Transpose (na, nb) → (nb, na) dans un dict de flat arrays."""
    na, nb = stats["na"], stats["nb"]
    mat_shape = (na, nb)

    def _t(arr):
        if arr is None or not hasattr(arr, "reshape"): return arr
        try:
            return arr.reshape(mat_shape).T.ravel()
        except: return arr

    return dict(
        na     = nb, nb = na,
        counts  = _t(stats["counts"]),
        means   = _t(stats["means"]),
        cohens_d= _t(stats["cohens_d"]),
        p_vals  = _t(stats["p_vals"]),
        ci95    = _t(stats.get("ci95")),
        valid   = _t(stats["valid"]),
        global_mean = stats["global_mean"],
        global_std  = stats["global_std"],
        total_n     = stats["total_n"],
    )


def _reconstruct_rules(stats, feat_a, feat_b, lbls_a, lbls_b, alpha,
                        feat_c=None, lbl_c=None, ic=None):
    """
    Reconstruit une liste de règles depuis les flat arrays du cache.
    O(na*nb) — très rapide.
    """
    na, nb = stats["na"], stats["nb"]
    counts  = np.array(stats["counts"],  dtype=np.float32)
    means   = np.array(stats["means"],   dtype=np.float32)
    ds      = np.array(stats["cohens_d"],dtype=np.float32)
    p_vals  = np.array(stats["p_vals"],  dtype=np.float32)
    ci95    = np.array(stats.get("ci95") or np.full(na*nb, np.nan), dtype=np.float32)
    valid   = np.array(stats["valid"],   dtype=bool)
    g_mean  = float(stats.get("global_mean", 0.0))

    rules = []
    for ia in range(na):
        for ib in range(nb):
            idx = ia * nb + ib
            if not valid[idx]: continue
            n   = int(counts[idx])
            mu  = float(means[idx])
            d   = float(ds[idx])
            p   = float(p_vals[idx])
            ci  = float(ci95[idx]) if not np.isnan(ci95[idx]) else 0.0

            lbl_a = lbls_a[ia] if ia < len(lbls_a) else f"B{ia}"
            lbl_b = lbls_b[ib] if ib < len(lbls_b) else f"B{ib}"
            cond  = [f"{feat_a[:14]} ∈ [{lbl_a}]",
                     f"{feat_b[:14]} ∈ [{lbl_b}]"]
            if feat_c and lbl_c:
                cond.append(f"{feat_c[:14]} ∈ [{lbl_c}]")

            rules.append(dict(
                ia=ia, ib=ib, ic=ic,
                label=" ET ".join(cond),
                cond_parts=cond,
                n=n, mean=mu, delta=mu-g_mean,
                cohens_d=d, ci95=ci, p=p,
                sig=bool(p < alpha and not np.isnan(p)),
            ))
    rules.sort(key=lambda r: abs(r["cohens_d"]), reverse=True)
    return rules


def _compute_feat_c(dep, feat_a, feat_b, feat_c, n_bins, min_n, g_mean, g_std):
    """
    Calcule les stats par slice de C — vectorisé O(n) par slice.
    """
    from ._precompute import _quantile_bins, _filter_rare_bins, _cell_stats_vectorized, _encode_y

    df  = dep.display_df
    num = dep.num_features
    feat_idx = {f: i for i, f in enumerate(num)}

    if feat_c not in feat_idx: return {}, []

    X = df[num].fillna(df[num].median()).values.astype(np.float64)
    y = _encode_y(df[dep.target_name].values, dep)

    vals_a = X[:, feat_idx[feat_a]]; ok_a = ~np.isnan(vals_a)
    vals_b = X[:, feat_idx[feat_b]]; ok_b = ~np.isnan(vals_b)
    vals_c = X[:, feat_idx[feat_c]]; ok_c = ~np.isnan(vals_c)

    ba, _   = _quantile_bins(vals_a, ok_a, n_bins)
    bb, _   = _quantile_bins(vals_b, ok_b, n_bins)
    bc, lbls_c = _quantile_bins(vals_c, ok_c, n_bins)

    ba = _filter_rare_bins(ba, min_n, n_bins)
    bb = _filter_rare_bins(bb, min_n, n_bins)
    bc = _filter_rare_bins(bc, min_n, n_bins)

    slices = {}
    for ic in range(int(bc.max())+1 if bc.max()>=0 else 0):
        mask_c = (bc == ic)
        y_sl   = y.copy(); y_sl[~mask_c] = np.nan
        ba_sl  = ba.copy(); ba_sl[~mask_c] = -1
        bb_sl  = bb.copy(); bb_sl[~mask_c] = -1

        na = int(ba.max())+1 if ba.max()>=0 else 0
        nb = int(bb.max())+1 if bb.max()>=0 else 0
        if na < 2 or nb < 2: continue

        stats = _cell_stats_vectorized(y_sl, ba_sl, bb_sl, na, nb, min_n, g_mean, g_std)
        if stats is not None:
            slices[ic] = stats

    return slices, lbls_c


# ══════════════════════════════════════════════════════════════════════════════
#  FIGURE BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _build_heatmap(stats, lbls_a, lbls_b, feat_a, feat_b, tgt, alpha):
    na, nb   = stats["na"], stats["nb"]
    means    = np.array(stats["means"],   dtype=np.float32).reshape(na, nb)
    counts   = np.array(stats["counts"],  dtype=np.float32).reshape(na, nb)
    p_vals   = np.array(stats["p_vals"],  dtype=np.float32).reshape(na, nb)
    valid    = np.array(stats["valid"],   dtype=bool).reshape(na, nb)
    g_mean   = float(stats.get("global_mean", float(np.nanmean(means[valid])) if valid.any() else 0))

    mat_rel = np.where(valid, means - g_mean, np.nan)
    abs_max = float(np.nanmax(np.abs(mat_rel))) if not np.all(np.isnan(mat_rel)) else 1.0

    # Text per cell
    txt = []
    for ia in range(na):
        row = []
        for ib in range(nb):
            if not valid[ia, ib]:
                row.append("—")
            else:
                sign = "▲" if mat_rel[ia,ib] > 0 else "▼"
                star = "*" if (not np.isnan(p_vals[ia,ib]) and p_vals[ia,ib]<alpha) else ""
                row.append(f"μ={means[ia,ib]:.3g}<br>"
                            f"{sign}{abs(mat_rel[ia,ib]):.3g}{star}<br>"
                            f"n={int(counts[ia,ib]):,}")
        txt.append(row)

    x_lbl = [f"B:{l}" for l in lbls_b[:nb]]
    y_lbl = [f"A:{l}" for l in lbls_a[:na]]

    fig = go.Figure(go.Heatmap(
        z=mat_rel, x=x_lbl, y=y_lbl,
        colorscale=CS_DIV, zmid=0, zmin=-abs_max, zmax=abs_max,
        text=txt, texttemplate="%{text}",
        textfont=dict(size=9, family=FONT),
        showscale=True,
        colorbar=dict(title=dict(text=f"Δμ({tgt[:12]})",
                                  font=dict(size=10,family=FONT)),
                      thickness=14, tickfont=dict(size=9)),
        hovertemplate="<b>%{y} × %{x}</b><br>%{text}<extra></extra>",
    ))
    # Contours sur cellules significatives
    for ia in range(na):
        for ib in range(nb):
            if (valid[ia,ib] and not np.isnan(p_vals[ia,ib])
                    and p_vals[ia,ib] < alpha):
                fig.add_shape(type="rect",
                    x0=ib-0.5, x1=ib+0.5, y0=ia-0.5, y1=ia+0.5,
                    line=dict(color="#1e3a5f",width=2),
                    fillcolor="rgba(0,0,0,0)", layer="above")

    fig.update_layout(
        plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=80, r=80, t=30, b=80),
        font=dict(family=FONT, size=10),
        xaxis=dict(tickangle=-30, tickfont=dict(size=10, color="#1e3a5f")),
        yaxis=dict(tickfont=dict(size=10, color="#1e3a5f")),
    )
    title = (f"Heatmap μ({tgt[:18]}) — {feat_a[:16]} × {feat_b[:16]} "
             f"(contour = sig. α={alpha})")
    return fig, title


def _upset_plot(rules, feats, g_mean, tgt, alpha):
    top = [r for r in rules if r.get("n",0) > 0][:20]
    if not top: return go.Figure()

    n_feats = len(feats)
    ns      = [r["n"] for r in top]
    deltas  = [r["delta"] for r in top]
    sigs    = [r["sig"] for r in top]

    def _clr(d, sig):
        if not sig: return "rgba(150,150,150,0.38)"
        return "rgba(33,102,172,0.85)" if d > 0 else "rgba(178,24,43,0.85)"

    bar_colors = [_clr(d, s) for d, s in zip(deltas, sigs)]
    n_rules    = len(top)

    fig = make_subplots(rows=2, cols=1, row_heights=[0.62, 0.38],
                        vertical_spacing=0.03, shared_xaxes=True)

    # Bars (effectifs)
    fig.add_trace(go.Bar(
        x=list(range(n_rules)), y=ns,
        marker=dict(color=bar_colors, line=dict(width=0.5, color="rgba(255,255,255,.3)")),
        text=[f"n={n}" for n in ns],
        textposition="outside", textfont=dict(size=8, family=FONT),
        hovertemplate="<b>%{customdata}</b><br>n=%{y}<br>Δ=%{text}<extra></extra>",
        customdata=[f"Δ={r['delta']:+.3g}" for r in top],
        name="Effectif", showlegend=False,
    ), row=1, col=1)

    # Delta annotations inside bars
    for i, r in enumerate(top):
        sign = "▲" if r["delta"] > 0 else "▼"
        star = "*" if r["sig"] else ""
        fig.add_annotation(
            x=i, y=ns[i]/2,
            text=f"{sign}{abs(r['delta']):.2g}{star}",
            showarrow=False,
            font=dict(size=7.5, color="white", family=FONT),
            xref="x", yref="y",
        )

    # Feature membership matrix
    feat_short = [f[:14] for f in feats]
    for fi in range(n_feats):
        fig.add_shape(type="rect",
            x0=-0.5, x1=n_rules-0.5,
            y0=fi-0.38, y1=fi+0.38,
            line_width=0,
            fillcolor="#f5f5f5" if fi % 2 == 0 else "white",
            layer="below", row=2, col=1, xref="x2", yref="y2")

    for i, r in enumerate(top):
        parts_l = [p.split("∈")[0].strip().lower() for p in r["cond_parts"]]
        active  = []
        for fi, feat in enumerate(feats):
            in_rule = any(feat[:14].lower() in pl for pl in parts_l)
            clr = bar_colors[i] if in_rule else "rgba(200,200,200,0.28)"
            sz  = 11 if in_rule else 5
            fig.add_trace(go.Scatter(
                x=[i], y=[fi], mode="markers",
                marker=dict(color=clr, size=sz, symbol="circle",
                            line=dict(width=0.8, color="rgba(255,255,255,.5)")),
                showlegend=False, hoverinfo="skip",
            ), row=2, col=1)
            if in_rule: active.append(fi)

        if len(active) >= 2:
            for k in range(len(active)-1):
                fig.add_trace(go.Scatter(
                    x=[i, i], y=[active[k], active[k+1]],
                    mode="lines",
                    line=dict(color=bar_colors[i], width=2.5),
                    showlegend=False, hoverinfo="skip",
                ), row=2, col=1)

    # Legend traces
    for lbl, clr in [("↑ Sig. positif","rgba(33,102,172,0.85)"),
                     ("↓ Sig. négatif","rgba(178,24,43,0.85)"),
                     ("Non sig.","rgba(150,150,150,0.4)")]:
        fig.add_trace(go.Bar(x=[None], y=[None], marker_color=clr, name=lbl), row=1, col=1)

    fig.update_layout(
        plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=20, r=20, t=20, b=20),
        font=dict(family=FONT, size=10), height=400,
        yaxis=dict(title="n", gridcolor=GRID),
        yaxis2=dict(tickvals=list(range(n_feats)), ticktext=feat_short,
                    gridcolor=GRID, tickfont=dict(size=10, color="#1e3a5f")),
        xaxis2=dict(tickvals=list(range(n_rules)),
                    ticktext=[f"R{i+1}" for i in range(n_rules)],
                    tickfont=dict(size=8), tickangle=-45),
        legend=dict(orientation="h", x=0.5, xanchor="center", y=1.07,
                    font=dict(size=9)),
        barmode="overlay",
    )
    return fig


def _slice_section(slices, lbls_c, feat_a, feat_b, feat_c,
                   lbls_a, lbls_b, tgt, alpha):
    """One heatmap per slice of feature C."""
    cards = []
    for ic, stats in slices.items():
        if ic >= len(lbls_c): continue
        na, nb   = stats["na"], stats["nb"]
        means    = np.array(stats["means"],  dtype=np.float32).reshape(na, nb)
        p_vals   = np.array(stats["p_vals"], dtype=np.float32).reshape(na, nb)
        valid    = np.array(stats["valid"],  dtype=bool).reshape(na, nb)
        g_mean   = float(stats.get("global_mean", 0.0))
        mat_rel  = np.where(valid, means - g_mean, np.nan)
        abs_m    = float(np.nanmax(np.abs(mat_rel))) if not np.all(np.isnan(mat_rel)) else 1.0

        txt = [[("—" if not valid[ia,ib]
                 else f"Δ{mat_rel[ia,ib]:+.3g}"
                      +("*" if not np.isnan(p_vals[ia,ib]) and p_vals[ia,ib]<alpha else ""))
                for ib in range(nb)] for ia in range(na)]

        fig = go.Figure(go.Heatmap(
            z=mat_rel, x=[f"B:{l}" for l in lbls_b[:nb]],
            y=[f"A:{l}" for l in lbls_a[:na]],
            colorscale=CS_DIV, zmid=0, zmin=-abs_m, zmax=abs_m,
            text=txt, texttemplate="%{text}", textfont=dict(size=9),
            showscale=True,
            colorbar=dict(thickness=10, tickfont=dict(size=8)),
            hovertemplate="<b>%{y} × %{x}</b><br>Δμ=%{z:.3g}<extra></extra>",
        ))
        fig.update_layout(height=240, plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=60, r=60, t=10, b=50), font=dict(family=FONT, size=9),
            xaxis=dict(tickangle=-30, tickfont=dict(size=9)),
            yaxis=dict(tickfont=dict(size=9)))

        cards.append(html.Div([
            html.Div(f"Slice {feat_c[:16]} ∈ [{lbls_c[ic]}]",
                style={"fontWeight":"700","fontSize":"11px","color":"#1e3a5f",
                       "marginBottom":"4px","fontFamily":FONT}),
            dcc.Graph(figure=fig, config={"displayModeBar":False},
                      style={"height":"240px"}),
        ], className="chart-card", style={"flex":"1","minWidth":"240px"}))

    if not cards: return html.Div()
    return html.Div([
        html.Div(f"Heatmaps par slice de {feat_c}", className="chart-card-title"),
        html.Div(cards, style={"display":"flex","gap":"12px","flexWrap":"wrap"}),
    ], className="chart-card")


def _rules_table(rules, tgt, g_mean, alpha):
    if not rules:
        return html.Div("Aucune règle (toutes les combinaisons sous min_n).",
                        style={"color":"#9aa5b4","padding":"12px","fontFamily":FONT})
    top = rules[:30]

    def _th(t):
        return html.Th(t, style={"padding":"5px 8px","background":"#f0f4f8",
            "color":"#6b7a8d","fontWeight":"700","fontSize":"9.5px",
            "textTransform":"uppercase","letterSpacing":".3px",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"})
    def _td(t, clr=None, bold=False):
        s = {"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
        if bold: s["fontWeight"] = "700"
        return html.Td(t, style=s)

    rows = []
    for i, r in enumerate(top):
        d   = r["cohens_d"]; sig = r["sig"]
        d_lbl = ("grand" if abs(d)>=0.8 else "moyen" if abs(d)>=0.5
                 else "petit" if abs(d)>=0.2 else "nég.")
        bg  = "#f0f8ff" if sig and d>0 else "#fff5f5" if sig and d<0 else "white"
        si  = "SI " + " ET ".join(r["cond_parts"])
        alors = f"ALORS μ({tgt[:10]})={r['mean']:.4g}"

        rows.append(html.Tr([
            _td(f"R{i+1}", bold=True, clr="#4472c4"),
            html.Td(html.Div([
                html.Div(si,    style={"fontSize":"9.5px","color":"#1e3a5f","fontWeight":"700"}),
                html.Div(alors, style={"fontSize":"9px","color":"#374151","marginTop":"1px"}),
            ], style={"lineHeight":"1.3"}),
            style={"padding":"4px 8px","minWidth":"200px"}),
            _td(f"{r['n']:,}"),
            _td(f"{r['mean']:.4g}", bold=True),
            _td(f"{r['delta']:+.4g}",
                "#2166ac" if r["delta"]>0 else "#b2182b", bold=True),
            _td(f"±{r['ci95']:.3g}"),
            _td(f"{'↑' if d>0 else '↓'}{abs(d):.3f} ({d_lbl})",
                "#2166ac" if d>0.2 else "#b2182b" if d<-0.2 else "#9aa5b4",
                bold=abs(d)>=0.5),
            _td(f"{r['p']:.4f}",
                "#27ae60" if sig else "#9aa5b4", bold=sig),
            _td("✅" if sig else "—", "#27ae60" if sig else "#9aa5b4", bold=True),
        ], style={"borderBottom":"1px solid #f0f4f8","background":bg}))

    return html.Div([
        html.Div(f"Top {len(top)} règles classées par |Cohen's d|",
                 style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"8px","fontFamily":FONT}),
        html.Div(
            html.Table([
                html.Thead(html.Tr([_th("N°"),_th("Règle"),_th("n"),
                                    _th(f"μ({tgt[:10]})"),_th("Δmoy"),_th("IC95±"),
                                    _th("Cohen's d"),_th("p-value"),_th("Sig.")])),
                html.Tbody(rows),
            ], style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
            style={"overflowX":"auto","maxHeight":"420px","overflowY":"auto"}),
    ])


def _ols_section(dep, feat_a, feat_b, feat_c, n_bins, min_n, tgt):
    """OLS avec termes d'interaction — utilise les bins précalculés si dispo."""
    from ._precompute import _quantile_bins, _filter_rare_bins, _encode_y

    df  = dep.display_df
    num = dep.num_features
    fi  = {f: i for i, f in enumerate(num)}

    feats = [f for f in [feat_a, feat_b, feat_c] if f and f in fi]
    if len(feats) < 2:
        return html.Div()

    X = df[num].fillna(df[num].median()).values.astype(np.float64)
    y = _encode_y(df[tgt].values, dep)

    # Build bin arrays
    bins = {}
    lbls = {}
    for feat in feats:
        vals = X[:, fi[feat]]; ok = ~np.isnan(vals)
        ba, lbl = _quantile_bins(vals, ok, n_bins)
        ba = _filter_rare_bins(ba, min_n, n_bins)
        bins[feat] = ba; lbls[feat] = lbl

    # Design matrix : one-hot bins + 2-way interaction
    cols_dm = ["Intercept"]
    X_parts = [np.ones(len(y))]

    for feat in feats:
        ba = bins[feat]; n_b = int(ba.max())+1 if ba.max()>=0 else 0
        for bi in range(1, n_b):   # reference = bin 0
            col = (ba==bi).astype(np.float64)
            X_parts.append(col)
            lbl_bi = lbls[feat][bi] if bi < len(lbls[feat]) else f"B{bi}"
            cols_dm.append(f"{feat[:10]}[{lbl_bi}]")

    # 2-way: feat_a × feat_b
    fa, fb = feats[0], feats[1]
    na_b = int(bins[fa].max())+1 if bins[fa].max()>=0 else 0
    nb_b = int(bins[fb].max())+1 if bins[fb].max()>=0 else 0
    for ia in range(1, na_b):
        for ib in range(1, nb_b):
            col = ((bins[fa]==ia)&(bins[fb]==ib)).astype(np.float64)
            X_parts.append(col)
            la = lbls[fa][ia] if ia < len(lbls[fa]) else f"B{ia}"
            lb = lbls[fb][ib] if ib < len(lbls[fb]) else f"B{ib}"
            cols_dm.append(f"{fa[:8]}[{la}]×{fb[:8]}[{lb}]")

    X_mat = np.column_stack(X_parts).astype(np.float64)
    var_mask = X_mat.var(axis=0) > 1e-8
    X_mat    = X_mat[:, var_mask]
    cols_dm  = [c for c, m in zip(cols_dm, var_mask) if m]

    try:
        import statsmodels.api as sm
        model = sm.OLS(y.astype(np.float64), X_mat)
        res   = model.fit()
        r2 = float(res.rsquared); r2a = float(res.rsquared_adj); aic = float(res.aic)
        coefs = res.params; pvals = res.pvalues; ses = res.bse; tvals = res.tvalues
        cis   = res.conf_int()

        def _th(t):
            return html.Th(t, style={"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
                "fontWeight":"700","fontSize":"9.5px","textTransform":"uppercase",
                "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"})
        def _td(t, clr=None, bold=False):
            s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
            if bold: s["fontWeight"]="700"
            return html.Td(t, style=s)

        rows = []
        for name,b,se_v,tv,pv,ci_lo,ci_hi in zip(
                cols_dm, coefs, ses, tvals, pvals, cis[:,0], cis[:,1]):
            is_int = "×" in name; sig = pv<0.05
            rows.append(html.Tr([
                _td(name, bold=is_int, clr="#4472c4" if is_int else None),
                _td(f"{b:+.4f}","#2166ac" if b>0 else "#b2182b",True),
                _td(f"{se_v:.4f}"),
                _td(f"{tv:+.3f}"),
                _td(f"[{ci_lo:+.3f},{ci_hi:+.3f}]"),
                _td(f"{pv:.4f}","#27ae60" if sig else "#9aa5b4",bold=sig),
                _td("✅" if sig else "—","#27ae60" if sig else "#9aa5b4",True),
            ], style={"borderBottom":"1px solid #f5f5f5",
                      "background":"#f0f8ff" if is_int and sig else "white"}))

        summary_bar = html.Div([
            _mini_card("R²",   f"{r2:.4f}", "#4472c4"),
            _mini_card("R² adj.",f"{r2a:.4f}","#27ae60"),
            _mini_card("AIC",  f"{aic:.1f}", "#e07b39"),
            _mini_card("N obs.",f"{len(y):,}","#9b59b6"),
        ], style={"display":"flex","gap":"8px","flexWrap":"wrap","marginBottom":"12px"})

        table = html.Div(
            html.Table([
                html.Thead(html.Tr([_th("Terme"),_th("β"),_th("SE"),_th("t"),
                                    _th("IC95%"),_th("p-value"),_th("Sig.")])),
                html.Tbody(rows),
            ], style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
            style={"overflowX":"auto","maxHeight":"340px","overflowY":"auto"})

        note = html.Div("Les termes × sont des interactions. Fond bleu = interaction sig.",
            style={"fontSize":"10px","color":"#9aa5b4","marginTop":"8px",
                   "fontStyle":"italic","fontFamily":FONT})
        return html.Div([summary_bar, table, note])

    except ImportError:
        # Fallback numpy
        try:
            b, _, _, _ = np.linalg.lstsq(X_mat, y, rcond=None)
            y_hat = X_mat @ b
            ss_res = ((y - y_hat)**2).sum(); ss_tot = ((y - y.mean())**2).sum()
            r2 = float(1 - ss_res/max(ss_tot,1e-9))
            rows = [html.Div(f"{c}: β={bv:+.4f}",
                             style={"fontSize":"11px","fontFamily":FONT,"padding":"2px 4px"})
                    for c, bv in zip(cols_dm, b)]
            return html.Div([
                html.Div(f"R² = {r2:.4f} (statsmodels absent — OLS numpy)",
                         style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"8px","fontFamily":FONT}),
                html.Div(rows),
            ])
        except Exception as ex:
            return html.Div(f"OLS non disponible: {ex}",
                            style={"color":"#9aa5b4","fontSize":"12px","fontFamily":FONT})
    except Exception as ex:
        return html.Div(f"Erreur régression: {ex}",
                        style={"color":"#e74c3c","fontSize":"12px","fontFamily":FONT})


# ══════════════════════════════════════════════════════════════════════════════
#  MICRO HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _summary_cards(n_tot, n_sig, alpha, best_d, min_r, max_r, tgt):
    def _card(icon, label, value, sub, clr):
        return html.Div([
            html.Div(icon, style={"fontSize":"20px"}),
            html.Div(value, style={"fontSize":"19px","fontWeight":"800","color":clr,"fontFamily":FONT}),
            html.Div(label, style={"fontSize":"10px","fontWeight":"700","color":"#6b7a8d",
                "textTransform":"uppercase","letterSpacing":".3px"}),
            html.Div(sub, style={"fontSize":"9.5px","color":"#9aa5b4","marginTop":"2px"}),
        ], style={"background":"white","borderRadius":"10px","padding":"10px 14px",
                  "flex":"1","minWidth":"130px","boxShadow":"0 1px 6px rgba(0,0,0,.06)",
                  "borderLeft":f"4px solid {clr}"})

    def _fmt(r, label):
        if not r: return "—"
        return f"μ={r['mean']:.3g} (Δ={r['delta']:+.3g})"

    return html.Div([
        _card("🔢","Combinaisons",str(n_tot),"groupes ≥ min_n","#4472c4"),
        _card("⚡","Sig. (α="+str(alpha)+")",str(n_sig),
              f"{n_sig/max(n_tot,1)*100:.0f}% des comb.","#27ae60"),
        _card("🔼","Max μ target",_fmt(max_r,""),"combinaison la plus haute","#2166ac"),
        _card("🔽","Min μ target",_fmt(min_r,""),"combinaison la plus basse","#b2182b"),
        _card("📏","Effet max",
              f"|d|={abs(best_d['cohens_d']):.2f}" if best_d else "—",
              "Cohen's d le plus fort","#e07b39"),
    ], style={"display":"flex","gap":"10px","flexWrap":"wrap"})


def _badge(text, clr="#27ae60", extra=""):
    return html.Div(
        text + extra,
        style={"display":"inline-block","padding":"3px 10px","borderRadius":"4px",
               "background":clr,"color":"white","fontSize":"11px","fontWeight":"700",
               "fontFamily":FONT,"boxShadow":"0 1px 4px rgba(0,0,0,.12)"})


def _mini_card(label, value, clr):
    return html.Div([
        html.Div(value, style={"fontSize":"16px","fontWeight":"800","color":clr,"fontFamily":FONT}),
        html.Div(label, style={"fontSize":"9.5px","color":"#6b7a8d","fontWeight":"600",
            "textTransform":"uppercase","letterSpacing":".3px"}),
    ], style={"background":"white","borderRadius":"8px","padding":"8px 12px",
              "boxShadow":"0 1px 5px rgba(0,0,0,.07)","borderLeft":f"3px solid {clr}"})


def _err(msg):
    return html.Div(msg, style={"color":"#e74c3c","padding":"16px",
                                 "fontSize":"13px","fontFamily":FONT})
