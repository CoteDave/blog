"""
ANOVA Multi-Facteurs v11
══════════════════════════════════════════════════════════════
  • ANOVA 1, 2 ou 3 voies avec interaction plots
  • Test de Levene (homoscédasticité) + Shapiro (normalité résidus, échantillon)
  • Effet sizes : η² (eta carré), ω² (omega carré), f de Cohen
  • Diagramme d'interaction : profils de moyennes par groupe croisé
  • QQ plot des résidus + histogramme
  • Table ANOVA complète (SS, df, MS, F, p, η², ω²)
  • Analyse de contraste : chaque modalité vs référence
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
FONT = "Plus Jakarta Sans, sans-serif"
GRID = "#e0e4ea"; BG = "#f7f8fa"


def layout(dep):
    num      = dep.num_features
    cat_cols = dep.cat_features if hasattr(dep,"cat_features") else []

    # Build factor options: cat + binnable numeric
    grp_opts = []
    if dep.supervised:
        grp_opts.append({"label":f"🎯 Target ({dep.target_name})","value":"__target__"})
    for c in cat_cols:
        if dep.display_df[c].nunique()<=20:
            grp_opts.append({"label":f"📂 {c}","value":c})
    for c in num[:8]:
        grp_opts.append({"label":f"📊 {c} (binné Q)","value":f"__bin__{c}"})

    if not grp_opts:
        return html.Div([
            html.Div("ANOVA Multi-Facteurs", className="page-title"),
            html.Div("⚠️ Aucune variable catégorielle ou target disponible.",
                     className="page-subtitle"),
        ], className="page-card")

    return html.Div([
        html.Div("ANOVA Multi-Facteurs", className="page-title"),
        html.Div("1, 2 ou 3 voies · taille d'effet η²/ω² · interaction plots · "
                 "QQ résidus · contraste vs référence.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Variable Y (numérique):", className="control-label"),
                      dcc.Dropdown(id="an-y",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[0] if num else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),

            html.Div([html.Div("Facteur A:", className="control-label"),
                      dcc.Dropdown(id="an-fa",
                          options=grp_opts,
                          value=grp_opts[0]["value"] if grp_opts else None,
                          clearable=False, style={"width":"220px"})],
                className="control-group"),

            html.Div([html.Div("Facteur B (optionnel):", className="control-label"),
                      dcc.Dropdown(id="an-fb",
                          options=[{"label":"— Aucun —","value":""}]+grp_opts,
                          value="", clearable=False, style={"width":"220px"})],
                className="control-group"),

            html.Div([html.Div("Facteur C (optionnel):", className="control-label"),
                      dcc.Dropdown(id="an-fc",
                          options=[{"label":"— Aucun —","value":""}]+grp_opts,
                          value="", clearable=False, style={"width":"220px"})],
                className="control-group"),

            html.Div([html.Div("Nb quartiles (vars binned):", className="control-label"),
                      dcc.Slider(id="an-bins",min=2,max=6,step=1,value=3,
                          marks={i:str(i) for i in range(2,7)},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"200px"}),
        ], className="controls-row"),

        # ANOVA Summary cards
        html.Div(id="an-cards", style={"marginBottom":"16px"}),

        # ANOVA table + effect size
        html.Div([
            html.Div([
                html.Div("📋 Table ANOVA complète", className="chart-card-title"),
                html.Div(id="an-table"),
            ], className="chart-card", style={"flex":"1.2"}),
            html.Div([
                html.Div("📏 Tailles d'effet", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="an-effect",
                    config={"displayModeBar":False}, style={"height":"280px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], style={"display":"flex","gap":"16px","marginBottom":"16px","alignItems":"flex-start"}),

        # Interaction plot + Violin per group
        html.Div([
            html.Div([
                html.Div(id="an-interact-title", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="an-interact",
                    config={"displayModeBar":False}, style={"height":"380px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                html.Div("Distribution par groupe (Facteur A)", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="an-violin",
                    config={"displayModeBar":False}, style={"height":"380px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # QQ plot + residuals histogram
        html.Div([
            html.Div([
                html.Div("QQ Plot — Normalité des résidus", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="an-qq",
                    config={"displayModeBar":False}, style={"height":"320px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                html.Div("Résidus vs Valeurs prédites", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="an-resid",
                    config={"displayModeBar":False}, style={"height":"320px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid"),

    ], className="page-card")


def register_callbacks(app, dep):

    _memo: dict = {}

    @app.callback(
        [Output("an-cards","children"),
         Output("an-table","children"),
         Output("an-effect","figure"),
         Output("an-interact","figure"),
         Output("an-interact-title","children"),
         Output("an-violin","figure"),
         Output("an-qq","figure"),
         Output("an-resid","figure")],
        [Input("an-y","value"),
         Input("an-fa","value"),
         Input("an-fb","value"),
         Input("an-fc","value"),
         Input("an-bins","value")],
    )
    def update(y_col, fa, fb, fc, n_bins):
        n_bins = int(n_bins or 3)
        fb = fb or ""; fc = fc or ""
        empty = go.Figure()

        if not y_col or not fa:
            return (_err("Sélectionnez Y et au moins le Facteur A."),
                    [],[],empty,"",empty,empty,empty)

        memo_key = (y_col,fa,fb,fc,n_bins)
        if memo_key in _memo:
            return _memo[memo_key]

        df = dep.display_df.copy()

        # ── Build factor columns ──────────────────────────────────────
        factors = []
        for f_id, label in [(fa,"A"),(fb,"B"),(fc,"C")]:
            if not f_id: continue
            try:
                col_name = f"Factor_{label}"
                df[col_name] = _make_factor(df, f_id, dep, n_bins)
                factors.append((col_name, f_id, label))
            except Exception:
                continue

        if not factors:
            return (_err("Erreur lors de la création des facteurs."),
                    [],[],empty,"",empty,empty,empty)

        # Filter complete cases
        keep_cols = [y_col]+[f[0] for f in factors]
        df = df[keep_cols].dropna()
        if len(df) < 10:
            return (_err("Données insuffisantes après filtrage."),
                    [],[],empty,"",empty,empty,empty)

        y = df[y_col].values.astype(float)

        # ── ANOVA decomposition ───────────────────────────────────────
        anova_rows, residuals, y_pred = _anova_decompose(df, y, factors)

        # ── Summary cards ─────────────────────────────────────────────
        n_grp_A = df[factors[0][0]].nunique()
        ss_total = float(((y-y.mean())**2).sum())
        ss_error = float((residuals**2).sum())
        eta2_total = 1 - ss_error/max(ss_total,1e-9)

        # Levene + Shapiro
        groups_A = [y[df[factors[0][0]]==g] for g in df[factors[0][0]].unique() if len(y[df[factors[0][0]]==g])>=2]
        levene_p = 1.0; shapiro_p = 1.0
        try:
            _,levene_p = sp_stats.levene(*groups_A)
        except: pass
        try:
            samp = residuals[:min(5000,len(residuals))]
            _,shapiro_p = sp_stats.shapiro(samp[:min(len(samp),5000)])
        except: pass

        main_fa = next((r for r in anova_rows if r["factor"]==factors[0][2]),None)
        main_p  = main_fa["p"] if main_fa else 1.0

        cards = _summary_cards(len(df), n_grp_A, len(factors), eta2_total,
                                main_p, levene_p, shapiro_p, y_col)

        # ── ANOVA table ───────────────────────────────────────────────
        table_el = _anova_table(anova_rows, ss_total)

        # ── Effect size bar chart ─────────────────────────────────────
        fig_eff = _effect_bar(anova_rows)

        # ── Interaction plot ──────────────────────────────────────────
        if len(factors)>=2:
            fig_int, int_title = _interaction_plot(df, y, factors, y_col)
        else:
            fig_int  = _means_plot(df, y, factors[0], y_col)
            int_title= f"Profil de moyennes — Facteur {factors[0][2]}"

        # ── Violin ────────────────────────────────────────────────────
        fig_vio = _violin_by_group(df, y, factors[0], y_col)

        # ── QQ plot ───────────────────────────────────────────────────
        fig_qq = _qq_plot(residuals, shapiro_p)

        # ── Residuals vs fitted ───────────────────────────────────────
        fig_res = _resid_fitted(y_pred, residuals, y_col)

        result = (cards, table_el, fig_eff, fig_int, int_title,
                  fig_vio, fig_qq, fig_res)
        _memo[memo_key] = result
        return result


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _make_factor(df, f_id, dep, n_bins):
    if f_id == "__target__":
        return df[dep.target_name].astype(str)
    elif f_id.startswith("__bin__"):
        base = f_id.replace("__bin__","")
        return pd.qcut(df[base], q=n_bins, duplicates="drop").astype(str)
    else:
        return df[f_id].astype(str)


def _anova_decompose(df, y, factors):
    """Manual Type-I SS ANOVA decomposition."""
    n = len(y); gm = y.mean()
    anova_rows = []
    y_pred = np.full(n, gm)
    residuals = y - gm
    ss_explained = 0.0

    for col_name, f_id, label in factors:
        grp = df[col_name].values
        grp_means = {g: y[grp==g].mean() for g in np.unique(grp) if len(y[grp==g])>0}
        ss_b = sum(len(y[grp==g])*(grp_means[g]-gm)**2 for g in grp_means)
        df_b = len(grp_means)-1
        ss_w = sum(((y[grp==g]-grp_means[g])**2).sum() for g in grp_means)
        df_w = n - len(grp_means)
        ms_b = ss_b/max(df_b,1); ms_w = ss_w/max(df_w,1)
        F    = ms_b/max(ms_w,1e-12)
        p    = float(sp_stats.f.sf(F, df_b, df_w))
        # η² and ω²
        ss_t = ((y-gm)**2).sum()
        eta2 = ss_b/max(ss_t,1e-9)
        omega2 = (ss_b - df_b*ms_w)/max(ss_t + ms_w, 1e-9)
        f_cohen= np.sqrt(eta2/max(1-eta2,1e-9))
        anova_rows.append(dict(factor=label, f_id=f_id, ss=ss_b, df=df_b,
            ms=ms_b, F=F, p=p, eta2=eta2,
            omega2=max(omega2,0), f_cohen=f_cohen,
            grp_means=grp_means, ss_w=ss_w, df_w=df_w, ms_w=ms_w))
        ss_explained += ss_b

    # Error row
    ss_err = ((y-gm)**2).sum() - ss_explained
    ss_err = max(ss_err, 0)
    df_err = max(n - sum(r["df"] for r in anova_rows) - 1, 1)
    ms_err = ss_err/df_err
    anova_rows.append(dict(factor="Erreur", f_id="",ss=ss_err,df=df_err,
        ms=ms_err,F=np.nan,p=np.nan,eta2=np.nan,omega2=np.nan,f_cohen=np.nan,
        grp_means={},ss_w=0,df_w=0,ms_w=0))

    # Residuals
    col0 = factors[0][0]
    grp  = df[col0].values
    gm_d = {g: y[grp==g].mean() for g in np.unique(grp) if len(y[grp==g])>0}
    y_pred = np.array([gm_d.get(g,gm) for g in grp])
    residuals = y - y_pred
    return anova_rows, residuals, y_pred


# ══════════════════════════════════════════════════════════════════════════════
#  FIGURE BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _summary_cards(n, n_grp, n_factors, eta2, main_p, levene_p, shapiro_p, y_col):
    def _c(icon,lbl,val,sub,clr):
        return html.Div([
            html.Div(icon,style={"fontSize":"22px"}),
            html.Div(val,style={"fontSize":"20px","fontWeight":"800","color":clr,"fontFamily":FONT}),
            html.Div(lbl,style={"fontSize":"10px","fontWeight":"700","color":"#6b7a8d",
                "textTransform":"uppercase","letterSpacing":".3px"}),
            html.Div(sub,style={"fontSize":"10px","color":"#9aa5b4","marginTop":"2px"}),
        ],style={"background":"white","borderRadius":"10px","padding":"12px 16px",
                 "flex":"1","minWidth":"130px","boxShadow":"0 1px 6px rgba(0,0,0,.07)",
                 "borderLeft":f"4px solid {clr}"})

    eta2_lbl = ("Nég." if eta2<.01 else "Petit" if eta2<.06
                else "Moyen" if eta2<.14 else "Grand")
    hom_ok = levene_p>0.05; norm_ok = shapiro_p>0.05
    return html.Div([
        _c("🔢","N obs.",f"{n:,}",f"{n_grp} groupes Facteur A","#4472c4"),
        _c("🧪","ANOVA A",f"p={main_p:.4f}",
           "✅ Sig." if main_p<0.05 else "❌ Non sig.",
           "#27ae60" if main_p<0.05 else "#e74c3c"),
        _c("📏","η² total",f"{eta2:.3f}",f"Taille effet: {eta2_lbl}","#e07b39"),
        _c("⚖️","Homoscéd.",f"p={levene_p:.3f}",
           "✅ OK" if hom_ok else "⚠️ Hétéroscéd.","#27ae60" if hom_ok else "#f39c12"),
        _c("📐","Normalité rés.",f"p={shapiro_p:.3f}",
           "✅ OK" if norm_ok else "⚠️ Non normal","#27ae60" if norm_ok else "#f39c12"),
    ],style={"display":"flex","gap":"10px","flexWrap":"wrap"})


def _anova_table(rows, ss_total):
    def _th(t):
        return html.Th(t,style={"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"9.5px","textTransform":"uppercase",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"})
    def _td(t,clr=None,bold=False):
        s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
        if bold: s["fontWeight"]="700"
        return html.Td(t,style=s)

    body=[]
    for r in rows:
        is_err = r["factor"]=="Erreur"
        sig = not is_err and not np.isnan(r["p"]) and r["p"]<0.05
        body.append(html.Tr([
            _td(f"Facteur {r['factor']}" if not is_err else "Résiduelle",
                bold=not is_err, clr="#4472c4" if not is_err else None),
            _td(f"{r['ss']:.2f}"),
            _td(f"{r['df']:.0f}"),
            _td(f"{r['ms']:.2f}"),
            _td("—" if is_err else f"{r['F']:.3f}",
                "#e07b39" if not is_err else None, not is_err),
            _td("—" if is_err else f"{r['p']:.4f}",
                "#27ae60" if sig else "#9aa5b4" if not is_err else None, sig),
            _td("—" if is_err or np.isnan(r['eta2']) else f"{r['eta2']:.4f}",
                "#4472c4" if not is_err else None),
            _td("—" if is_err or np.isnan(r['omega2']) else f"{r['omega2']:.4f}"),
            _td("—" if is_err else ("✅" if sig else "—"),
                "#27ae60" if sig else "#9aa5b4",sig),
        ],style={"borderBottom":"1px solid #f0f4f8",
                 "background":"#f0f8ff" if sig else "white"}))

    return html.Div(
        html.Table([
            html.Thead(html.Tr([_th("Source"),_th("SS"),_th("df"),_th("MS"),
                                _th("F"),_th("p-value"),_th("η²"),_th("ω²"),_th("Sig.")])),
            html.Tbody(body),
        ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
        style={"overflowX":"auto"})


def _effect_bar(rows):
    data = [(r["factor"],r["eta2"],r["omega2"],r["f_cohen"])
            for r in rows if r["factor"]!="Erreur" and not np.isnan(r.get("eta2",np.nan))]
    if not data: return go.Figure()
    labels = [d[0] for d in data]
    eta2s  = [d[1] for d in data]
    omega2s= [d[2] for d in data]

    fig = go.Figure()
    fig.add_trace(go.Bar(name="η²",x=labels,y=eta2s,
        marker_color="#4472c4",
        text=[f"{v:.3f}" for v in eta2s],textposition="outside",textfont=dict(size=9)))
    fig.add_trace(go.Bar(name="ω²",x=labels,y=omega2s,
        marker_color="#27ae60",
        text=[f"{v:.3f}" for v in omega2s],textposition="outside",textfont=dict(size=9)))
    # Reference lines
    for y_,lbl in [(0.01,"Petit"),(0.06,"Moyen"),(0.14,"Grand")]:
        fig.add_hline(y=y_,line_dash="dot",line_color="#9aa5b4",line_width=1,
            annotation_text=lbl,annotation_font_size=8,annotation_font_color="#9aa5b4")
    fig.update_layout(barmode="group",plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=40,r=20,t=20,b=40),font=dict(family=FONT,size=10),
        yaxis=dict(title="Taille d'effet",gridcolor=GRID,range=[0,max(max(eta2s),0.2)*1.3]),
        legend=dict(font=dict(size=10),orientation="h",x=0.5,xanchor="center",y=-0.25))
    return fig


def _interaction_plot(df, y, factors, y_col):
    """Profils de moyennes A × B."""
    col_a, id_a, lbl_a = factors[0]
    col_b, id_b, lbl_b = factors[1]

    grps_a = sorted(df[col_a].unique())
    grps_b = sorted(df[col_b].unique())

    fig = go.Figure()
    for i,gb in enumerate(grps_b):
        xs=[]; ys=[]; errs=[]
        for ga in grps_a:
            vals = y[(df[col_a]==ga)&(df[col_b]==gb)]
            if len(vals)>=2:
                xs.append(str(ga)); ys.append(float(vals.mean()))
                errs.append(float(vals.std(ddof=1)/np.sqrt(len(vals))*1.96))
        clr=PAL[i%len(PAL)]
        fig.add_trace(go.Scatter(x=xs,y=ys,mode="lines+markers",
            name=f"{lbl_b}={gb}",line=dict(color=clr,width=2.5),
            marker=dict(size=9,color=clr,line=dict(width=1.5,color="white")),
            error_y=dict(type="data",array=errs,visible=True,
                         color=clr,thickness=1.5,width=5),
            hovertemplate=f"{lbl_b}={gb}<br>μ=%{{y:.4g}}<extra></extra>"))

    fig.update_layout(
        xaxis=dict(title=f"Facteur A",gridcolor=GRID,tickangle=-30),
        yaxis=dict(title=f"μ ({y_col[:16]})",gridcolor=GRID),
        plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=20,t=20,b=60),font=dict(family=FONT,size=11),
        legend=dict(font=dict(size=10),bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1,bordercolor=GRID))
    return fig, f"Interaction Plot — Facteur A × Facteur B · μ({y_col[:14]}) ± IC95%"


def _means_plot(df, y, factor, y_col):
    col_name, f_id, label = factor
    grps = sorted(df[col_name].unique())
    means=[]; errs=[]; ns=[]
    for g in grps:
        v=y[df[col_name]==g]
        means.append(float(v.mean())); ns.append(len(v))
        errs.append(float(v.std(ddof=1)/np.sqrt(len(v))*1.96) if len(v)>1 else 0)

    fig=go.Figure()
    fig.add_trace(go.Bar(x=[str(g) for g in grps],y=means,
        marker_color=[PAL[i%len(PAL)] for i in range(len(grps))],
        error_y=dict(type="data",array=errs,visible=True,thickness=2,width=6),
        text=[f"n={n}" for n in ns],textposition="outside",textfont=dict(size=9),
        hovertemplate="Groupe=%{x}<br>μ=%{y:.4g}<extra></extra>"))
    fig.add_hline(y=float(y.mean()),line_dash="dash",line_color="#9aa5b4",
        annotation_text=f"μ global={y.mean():.4g}",annotation_font_size=9)
    fig.update_layout(plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=20,t=20,b=60),font=dict(family=FONT,size=11),
        xaxis=dict(title=f"Facteur {label}",gridcolor=GRID),
        yaxis=dict(title=f"μ ({y_col[:16]})",gridcolor=GRID))
    return fig


def _violin_by_group(df, y, factor, y_col):
    col_name, f_id, label = factor
    grps = sorted(df[col_name].unique())
    fig=go.Figure()
    for i,g in enumerate(grps):
        v=y[df[col_name]==g]; clr=PAL[i%len(PAL)]
        r,gb,b=int(clr[1:3],16),int(clr[3:5],16),int(clr[5:7],16)
        fig.add_trace(go.Violin(y=v,name=str(g)[:16],
            fillcolor=f"rgba({r},{gb},{b},0.22)",line_color=clr,line_width=2,
            box=dict(visible=True,fillcolor=f"rgba({r},{gb},{b},0.5)",
                     line=dict(color=clr,width=1.5)),
            meanline=dict(visible=True,color=clr,width=2),
            points=False,
            hovertemplate=f"Groupe={g}<br>%{{y:.4g}}<extra></extra>"))
        # Annotation
        mu,sd=float(v.mean()),float(v.std(ddof=1))
        fig.add_annotation(x=str(g)[:16],y=float(v.max())+(float(v.max())-float(v.min()))*0.06,
            text=f"μ={mu:.3g}<br>n={len(v):,}",showarrow=False,
            font=dict(size=8,family=FONT,color="#374151"),
            bgcolor="rgba(255,255,255,0.85)",bordercolor=clr,borderwidth=1,borderpad=2)
    fig.update_layout(violinmode="group",plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=20,t=20,b=60),font=dict(family=FONT,size=11),
        xaxis=dict(title=f"Facteur {label}",gridcolor=GRID),
        yaxis=dict(title=y_col[:18],gridcolor=GRID),showlegend=False)
    return fig


def _qq_plot(residuals, shapiro_p):
    n = len(residuals)
    r_sorted = np.sort(residuals)
    quantiles = sp_stats.norm.ppf(np.arange(1,n+1)/(n+1))
    mu_r = float(r_sorted.mean()); sd_r = float(r_sorted.std(ddof=1))+1e-9
    r_std = (r_sorted-mu_r)/sd_r

    fig=go.Figure()
    fig.add_trace(go.Scatter(x=quantiles,y=r_std,mode="markers",
        marker=dict(color="#4472c4",size=4,opacity=0.6),
        hovertemplate="Q théorique=%{x:.3f}<br>Q observé=%{y:.3f}<extra></extra>",
        showlegend=False))
    # Reference line
    mn=min(quantiles.min(),r_std.min()); mx=max(quantiles.max(),r_std.max())
    fig.add_trace(go.Scatter(x=[mn,mx],y=[mn,mx],mode="lines",
        line=dict(color="#e74c3c",width=1.5,dash="dash"),showlegend=False))
    sig_str = f"Shapiro-Wilk p={shapiro_p:.4f} — {'✅ Normal' if shapiro_p>0.05 else '⚠️ Non normal'}"
    fig.add_annotation(x=0.05,y=0.95,xref="paper",yref="paper",
        text=sig_str,showarrow=False,
        font=dict(size=10,family=FONT,color="#27ae60" if shapiro_p>0.05 else "#e07b39"),
        bgcolor="rgba(255,255,255,0.85)",borderpad=4)
    fig.update_layout(plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=20,t=20,b=50),font=dict(family=FONT,size=11),
        xaxis=dict(title="Quantiles théoriques (Normal)",gridcolor=GRID),
        yaxis=dict(title="Quantiles observés (std)",gridcolor=GRID))
    return fig


def _resid_fitted(y_pred, residuals, y_col):
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=y_pred,y=residuals,mode="markers",
        marker=dict(color="#4472c4",size=5,opacity=0.55,
                    line=dict(width=0.3,color="rgba(255,255,255,.5)")),
        hovertemplate=f"Prédit=%{{x:.4g}}<br>Résidu=%{{y:.4g}}<extra></extra>",
        showlegend=False))
    fig.add_hline(y=0,line_dash="dash",line_color="#e74c3c",line_width=1.5)
    # Smoothed trend
    try:
        from scipy.signal import savgol_filter
        order=np.argsort(y_pred)
        xs=y_pred[order]; rs=residuals[order]
        wl=max(5,min(len(rs)//8|1,51)); wl=wl if wl%2==1 else wl+1
        if len(rs)>=wl+2:
            sm=savgol_filter(rs,wl,3)
            fig.add_trace(go.Scatter(x=xs,y=sm,mode="lines",
                line=dict(color="#e07b39",width=2),showlegend=False,
                hoverinfo="skip"))
    except: pass
    fig.update_layout(plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=20,t=20,b=50),font=dict(family=FONT,size=11),
        xaxis=dict(title=f"Valeurs prédites ({y_col[:14]})",gridcolor=GRID),
        yaxis=dict(title="Résidus",gridcolor=GRID,zeroline=False))
    return fig


def _err(msg):
    return html.Div(msg,style={"color":"#e74c3c","padding":"16px","fontSize":"13px","fontFamily":FONT})
