"""
Clusters de Corrélation — hierarchical clustering of features by correlation.
Dendrogram + reordered heatmap + cluster-mean radar.
"""
from __future__ import annotations
import numpy as np
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots

CLASS_PALETTE = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"


def layout(dep) -> html.Div:
    num = dep.num_features
    col_opts = [{"label":c,"value":c} for c in num]

    return html.Div([
        html.Div("Clusters de Corrélation", className="page-title"),
        html.Div("Groupement hiérarchique des variables par similarité de corrélation.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Méthode corrélation:", className="control-label"),
                      dcc.Dropdown(id="cc-method",
                                   options=[{"label":"Pearson","value":"pearson"},
                                            {"label":"Spearman","value":"spearman"}],
                                   value="pearson", clearable=False,
                                   style={"width":"180px"})],
                     className="control-group"),
            html.Div([html.Div("Linkage:", className="control-label"),
                      dcc.Dropdown(id="cc-linkage",
                                   options=[{"label":"Ward","value":"ward"},
                                            {"label":"Complete","value":"complete"},
                                            {"label":"Average","value":"average"}],
                                   value="ward", clearable=False,
                                   style={"width":"160px"})],
                     className="control-group"),
            html.Div([html.Div("Nb clusters:", className="control-label"),
                      dcc.Slider(id="cc-k", min=2, max=8, step=1, value=3,
                                 marks={i:str(i) for i in range(2,9)})],
                     className="control-group", style={"minWidth":"240px"}),
            html.Div([html.Div("Variables:", className="control-label"),
                      dcc.Dropdown(id="cc-vars", options=col_opts,
                                   value=num[:min(20,len(num))], multi=True,
                                   style={"minWidth":"300px"})],
                     className="control-group"),
        ], className="controls-row"),

        # Reordered heatmap
        html.Div([dcc.Loading(dcc.Graph(id="cc-heatmap", config={"displayModeBar":True},
                            style={"height":"560px"}), type="circle", color="#4472c4")], className="chart-card",
                 style={"marginBottom":"16px"}),

        # Cluster info + feature groups
        html.Div(id="cc-groups",
                 style={"display":"grid","gridTemplateColumns":"repeat(auto-fill,minmax(280px,1fr))",
                        "gap":"14px","marginBottom":"16px"}),

        # Correlation within/between clusters
        html.Div([dcc.Loading(dcc.Graph(id="cc-within", config={"displayModeBar":False},
                            style={"height":"320px"}), type="circle", color="#4472c4")], className="chart-card"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    # v8: memoize corr-clusters per inputs
    _cc_memo: dict = {}

    @app.callback(
        [Output("cc-heatmap","figure"),
         Output("cc-groups","children"),
         Output("cc-within","figure")],
        [Input("cc-method","value"), Input("cc-linkage","value"),
         Input("cc-k","value"),     Input("cc-vars","value")],
    )
    def update(method, linkage, k, vars_sel):
        memo_key = (method, linkage, k, tuple(sorted(vars_sel or [])))
        if memo_key in _cc_memo:
            return _cc_memo[memo_key]
        from scipy.cluster.hierarchy import linkage as sp_linkage, fcluster, dendrogram
        from scipy.spatial.distance import squareform

        if not vars_sel or len(vars_sel) < 3:
            empty = go.Figure()
            return empty, [], empty

        cols = [c for c in vars_sel if c in dep.num_features][:25]
        # v7: use cache for pearson/spearman
        cache_key = "corr_pearson" if method == "pearson" else "corr_spearman"
        full_c = dep.cache.get(cache_key, wait=False)  # non-blocking
        if full_c is not None:
            valid = [c for c in cols if c in full_c.index]
            corr  = full_c.loc[valid, valid]
            cols  = valid
        else:
            corr = dep.display_df[cols].corr(method=method)

        # ── Hierarchical clustering ──────────────────────────────────────
        dist_mat = 1 - corr.abs().values
        np.fill_diagonal(dist_mat, 0)
        dist_mat = np.clip(dist_mat, 0, None)
        condensed = squareform(dist_mat, checks=False)
        condensed = np.clip(condensed, 0, None)

        Z = sp_linkage(condensed, method=linkage)
        order = _leaf_order(Z, len(cols))
        cluster_labels = fcluster(Z, k, criterion="maxclust")

        # ── Reordered heatmap ────────────────────────────────────────────
        cols_ord  = [cols[i] for i in order]
        corr_ord  = corr.iloc[order, :].iloc[:, order]
        cl_ord    = cluster_labels[order]

        z     = corr_ord.values
        labels = cols_ord

        fig_heat = go.Figure(go.Heatmap(
            z=z, x=labels, y=labels,
            colorscale=[[0,"#e74c3c"],[0.5,"#ffffff"],[1,"#4472c4"]],
            zmid=0, zmin=-1, zmax=1,
            text=[[f"{v:.2f}" for v in row] for row in z],
            texttemplate="%{text}", textfont={"size":9},
            hovertemplate="%{x} ↔ %{y}: <b>%{z:.3f}</b><extra></extra>",
        ))

        # Add cluster separator lines
        boundaries = _cluster_boundaries(cl_ord)
        for b in boundaries:
            fig_heat.add_shape(type="line", x0=b-0.5, y0=-0.5, x1=b-0.5, y1=len(cols)-0.5,
                                line=dict(color="black", width=2))
            fig_heat.add_shape(type="line", x0=-0.5, y0=b-0.5, x1=len(cols)-0.5, y1=b-0.5,
                                line=dict(color="black", width=2))

        # Color bars on axes showing cluster assignment
        for ci in range(1, k+1):
            idxs = [j for j, c in enumerate(cl_ord) if c == ci]
            if not idxs:
                continue
            clr = CLASS_PALETTE[(ci-1) % len(CLASS_PALETTE)]
            mid = np.mean(idxs)
            fig_heat.add_annotation(
                x=len(cols)-0.5, y=mid,
                text=f"G{ci}", showarrow=False,
                font=dict(color=clr, size=11, family="Plus Jakarta Sans"),
                xanchor="left", xref="x", yref="y",
            )

        fig_heat.update_layout(
            plot_bgcolor="#fff", paper_bgcolor="#fff",
            margin=dict(l=100, r=80, t=30, b=110),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            xaxis=dict(tickangle=-45, side="bottom"),
            title=dict(text=f"Heatmap corrélation ordonnée par cluster (K={k})",
                       font=dict(size=13)),
        )

        # ── Cluster group cards ──────────────────────────────────────────
        group_cards = []
        for ci in range(1, k+1):
            members = [cols[i] for i in range(len(cols)) if cluster_labels[i] == ci]
            clr = CLASS_PALETTE[(ci-1) % len(CLASS_PALETTE)]
            # avg within-cluster correlation
            if len(members) > 1:
                sub_corr = dep.display_df[members].corr(method=method)  # v7
                n = len(members)
                avg_corr = (sub_corr.values.sum() - n) / max(1, n*(n-1))
            else:
                avg_corr = 1.0

            group_cards.append(html.Div([
                html.Div([
                    html.Span(f"Groupe {ci}", style={"fontWeight":"800","color":clr,
                                                       "fontSize":"14px"}),
                    html.Span(f" · {len(members)} var.",
                              style={"color":"#6b7a8d","fontSize":"12px"}),
                ], style={"marginBottom":"8px","display":"flex","alignItems":"baseline","gap":"4px"}),
                html.Div(f"r̄ intra-cluster : {avg_corr:.3f}",
                         style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"8px"}),
                html.Div([
                    html.Span(m, style={
                        "display":"inline-block","background":_hex_alpha(clr,0.12),
                        "color":clr,"borderRadius":"99px","padding":"2px 8px",
                        "fontSize":"11px","fontWeight":"600","margin":"2px",
                        "border":f"1px solid {_hex_alpha(clr,0.3)}",
                    }) for m in members
                ]),
            ], className="chart-card"))

        # ── Within vs Between cluster correlation ─────────────────────────
        within_means, between_means, group_names = [], [], []
        for ci in range(1, k+1):
            mi = [cols[i] for i in range(len(cols)) if cluster_labels[i] == ci]
            oi = [c for c in cols if c not in mi]
            if len(mi) > 1:
                sc = dep.display_df[mi].corr(method=method).values  # v7
                np.fill_diagonal(sc, np.nan)
                within_means.append(float(np.nanmean(np.abs(sc))))
            else:
                within_means.append(1.0)
            if oi and mi:
                bc = dep.display_df[mi+oi].corr(method=method)  # v7
                bc_vals = bc.loc[mi, oi].values
                between_means.append(float(np.mean(np.abs(bc_vals))))
            else:
                between_means.append(0.0)
            group_names.append(f"G{ci}")

        fig_within = go.Figure()
        fig_within.add_trace(go.Bar(x=group_names, y=within_means, name="|r| intra",
                                     marker_color="#4472c4", opacity=0.85))
        fig_within.add_trace(go.Bar(x=group_names, y=between_means, name="|r| inter",
                                     marker_color="#e07b39", opacity=0.85))
        fig_within.update_layout(
            title="Corrélation moyenne |r| Intra vs Inter-Groupes",
            barmode="group",
            plot_bgcolor=BG, paper_bgcolor="#fff",
            margin=dict(l=50,r=20,t=45,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif",size=11),
            yaxis=dict(title="|r| moyen", gridcolor=GRID, range=[0,1.1]),
            xaxis=dict(gridcolor=GRID),
            legend=dict(font=dict(size=11)),
        )

        result = fig_heat, group_cards, fig_within
        _cc_memo[memo_key] = result
        return result


# ── helpers ───────────────────────────────────────────────────────────────────

def _leaf_order(Z, n):
    from scipy.cluster.hierarchy import dendrogram
    dg = dendrogram(Z, no_plot=True)
    return dg["leaves"]


def _cluster_boundaries(labels):
    boundaries = []
    for i in range(1, len(labels)):
        if labels[i] != labels[i-1]:
            boundaries.append(i)
    return boundaries


def _hex_alpha(hex_color, alpha):
    h = hex_color.lstrip("#")
    r,g,b = int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
    return f"rgba({r},{g},{b},{alpha})"
