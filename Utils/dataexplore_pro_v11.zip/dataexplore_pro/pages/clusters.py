"""
Analyse de Clusters v10
 • K-Means / DBSCAN / Agglomeratif — ScatterGL WebGL
 • Hull convexe, silhouette, elbow
 • Cluster insights cards (même sans lasso)
 • Lasso → panel Sélection vs Reste renforcé :
   - Insight cards (n, target, divergence)
   - Violin comparatif par feature (top 6)
   - Forest plot Cohen's d avec zones d'effet
   - Tableau Mann-Whitney complet
   - Mini barres de proportion target
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy.spatial import ConvexHull
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"


def _ha(h, a):
    h=h.lstrip("#"); r,g,b=int(h[:2],16),int(h[2:4],16),int(h[4:6],16)
    return f"rgba({r},{g},{b},{a})"

def _rgb(h):
    h=h.lstrip("#"); return int(h[:2],16),int(h[2:4],16),int(h[4:6],16)

def _hull(x, y, color):
    pts=np.column_stack([x,y]); pts=pts[~np.isnan(pts).any(axis=1)]
    if len(pts)<3: return None
    try:
        hv=ConvexHull(pts).vertices
        hx=np.append(pts[hv,0],pts[hv[0],0]); hy=np.append(pts[hv,1],pts[hv[0],1])
        return go.Scatter(x=hx,y=hy,fill="toself",fillcolor=_ha(color,0.10),
            line=dict(color=color,width=1.8,dash="dot"),mode="lines",
            showlegend=False,hoverinfo="skip")
    except: return None

def _base(title=""):
    return dict(title=dict(text=title,font=dict(size=12,color="#1e3a5f")),
        plot_bgcolor=BG,paper_bgcolor="#fff",margin=dict(l=50,r=16,t=44,b=50),
        font=dict(family=FONT,size=11),xaxis=dict(gridcolor=GRID,zeroline=False),
        yaxis=dict(gridcolor=GRID,zeroline=False),
        legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1,bordercolor=GRID))


def layout(dep):
    num = dep.num_features
    return html.Div([
        html.Div("Analyse de Clusters", className="page-title"),
        html.Div("K-Means · DBSCAN · Agglomératif — lasso pour comparer sélection vs reste",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Algorithme:", className="control-label"),
                      dcc.Dropdown(id="cl-algo",
                          options=[{"label":"K-Means","value":"kmeans"},
                                   {"label":"DBSCAN","value":"dbscan"},
                                   {"label":"Agglomératif","value":"agglo"}],
                          value="kmeans",clearable=False,style={"width":"170px"})],
                className="control-group"),
            html.Div([html.Div("K (K-Means/Agglo):", className="control-label"),
                      dcc.Slider(id="cl-k",min=2,max=10,step=1,value=3,
                          marks={i:str(i) for i in range(2,11)})],
                className="control-group",style={"minWidth":"260px"}),
            html.Div([html.Div("Variables:", className="control-label"),
                      dcc.Dropdown(id="cl-vars",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[:min(10,len(num))],multi=True,
                          style={"minWidth":"280px"})],
                className="control-group"),
            html.Div([html.Div("Hull:", className="control-label"),
                      dcc.Dropdown(id="cl-hull",
                          options=[{"label":"Convexe","value":"convex"},
                                   {"label":"Aucun","value":"none"}],
                          value="convex",clearable=False,style={"width":"130px"})],
                className="control-group"),
        ], className="controls-row"),

        # Cluster insight cards
        html.Div(id="cl-insight-cards",style={"marginBottom":"14px"}),

        # Scatter + lasso panel
        html.Div([
            html.Div([
                dcc.Loading(dcc.Graph(id="cl-scatter",
                    config={"displayModeBar":True,
                            "modeBarButtonsToAdd":["lasso2d","select2d"],
                            "scrollZoom":True},
                    style={"height":"440px"}),type="circle",color="#4472c4"),
                html.Div("⬅ Outil lasso/box → insights sur la sélection",
                    style={"fontSize":"10.5px","color":"#9aa5b4","marginTop":"4px",
                           "textAlign":"center","fontStyle":"italic"}),
            ],className="chart-card",style={"flex":"1.5","minWidth":"0"}),

            html.Div(id="cl-lasso-panel",className="chart-card",
                style={"flex":"1","minWidth":"300px","maxWidth":"500px",
                       "overflowY":"auto","maxHeight":"540px"}),
        ],style={"display":"flex","gap":"16px","marginBottom":"16px","alignItems":"flex-start"}),

        # Elbow + Silhouette
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-elbow",
                config={"displayModeBar":False},style={"height":"300px"}),
                type="circle",color="#4472c4")],className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-sil",
                config={"displayModeBar":False},style={"height":"300px"}),
                type="circle",color="#4472c4")],className="chart-card"),
        ],className="charts-grid",style={"marginBottom":"16px"}),

        # Radar profile
        html.Div([dcc.Loading(dcc.Graph(id="cl-profile",
            config={"displayModeBar":False},style={"height":"340px"}),
            type="circle",color="#4472c4")],className="chart-card"),

        dcc.Store(id="cl-labels-store"),
    ],className="page-card")


def register_callbacks(app, dep):

    # ── Main clustering ──────────────────────────────────────────────────────
    @app.callback(
        [Output("cl-scatter","figure"),Output("cl-elbow","figure"),
         Output("cl-sil","figure"),Output("cl-profile","figure"),
         Output("cl-insight-cards","children"),
         Output("cl-labels-store","data")],
        [Input("cl-k","value"),Input("cl-vars","value"),
         Input("cl-hull","value"),Input("cl-algo","value")],
    )
    def update(k, vars_sel, hull_mode, algo):
        from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler, MinMaxScaler
        from sklearn.metrics import silhouette_samples
        from sklearn.neighbors import NearestNeighbors

        algo=algo or "kmeans"; empty=go.Figure()
        if not vars_sel or len(vars_sel)<2:
            return empty,empty,empty,empty,html.Div(),None

        cols=[c for c in vars_sel if c in dep.num_features]
        df=dep.display_df
        X_raw=df[cols].fillna(df[cols].median()).values
        X=StandardScaler().fit_transform(X_raw)

        # ── Clustering ───────────────────────────────────────────────
        if algo=="dbscan":
            nbrs=NearestNeighbors(n_neighbors=min(5,len(X)-1)).fit(X)
            dk,_=nbrs.kneighbors(X)
            eps_auto=float(np.percentile(np.sort(dk[:,-1]),85))
            db=DBSCAN(eps=eps_auto,min_samples=max(3,len(X)//60)).fit(X)
            labels=db.labels_; n_cls=len(set(labels))-(1 if -1 in labels else 0)
            yd=np.sort(dk[:,-1])
            fig_elbow=go.Figure([go.Scatter(x=list(range(len(yd))),y=yd,mode="lines",
                line=dict(color="#4472c4",width=2))])
            fig_elbow.add_hline(y=eps_auto,line_dash="dash",line_color="#e74c3c",
                annotation_text=f"ε={eps_auto:.3f}")
            fig_elbow.update_layout(**_base(f"k-distance DBSCAN · ε={eps_auto:.3f} · {n_cls} clusters"),
                xaxis_title="Points triés",yaxis_title="Distance k-NN")
        elif algo=="agglo":
            max_k=min(11,len(X)); ks=list(range(2,max_k)); scores=[]
            for ki in ks:
                a=AgglomerativeClustering(n_clusters=ki).fit(X)
                tmp=a.labels_
                if len(set(tmp))>=2:
                    try:
                        sc=float(silhouette_samples(X[:min(5000,len(X))],
                                                    tmp[:min(5000,len(X))]).mean())
                    except: sc=0.0
                else: sc=0.0
                scores.append(sc)
            ag=AgglomerativeClustering(n_clusters=k).fit(X); labels=ag.labels_
            fig_elbow=go.Figure([go.Scatter(x=ks,y=scores,mode="lines+markers",
                line=dict(color="#4472c4",width=2),marker=dict(size=8,color="#e07b39"))])
            fig_elbow.add_vline(x=k,line_dash="dash",line_color="#e74c3c",
                annotation_text=f"K={k}")
            fig_elbow.update_layout(**_base("Silhouette vs K — Agglomératif"),
                xaxis_title="K",yaxis_title="Silhouette moyen")
            n_cls=k
        else:  # kmeans
            max_k=min(11,len(X)); ks=list(range(2,max_k)); inertias=[]
            for ki in ks:
                km_i=KMeans(n_clusters=ki,random_state=42,n_init=5,max_iter=100)
                km_i.fit(X); inertias.append(km_i.inertia_)
            fig_elbow=go.Figure([go.Scatter(x=ks,y=inertias,mode="lines+markers",
                line=dict(color="#4472c4",width=2),marker=dict(size=8,color="#e07b39"),
                hovertemplate="K=%{x}<br>Inertie: %{y:,.0f}<extra></extra>")])
            fig_elbow.add_vline(x=k,line_dash="dash",line_color="#e74c3c",
                annotation_text=f"K={k}")
            fig_elbow.update_layout(**_base("Courbe d'Inertie — Méthode du Coude"),
                xaxis_title="K",yaxis_title="Inertie")
            km=KMeans(n_clusters=k,random_state=42,n_init=10,max_iter=200)
            labels=km.fit_predict(X); n_cls=k

        # ── PCA 2D ──────────────────────────────────────────────────
        pca=PCA(n_components=2,random_state=42)
        X2=pca.fit_transform(X); v1,v2=pca.explained_variance_ratio_[:2]*100

        fig_sc=go.Figure()
        unique_labels=[l for l in sorted(set(labels)) if l!=-1]
        if -1 in labels:
            noise=X2[labels==-1]
            fig_sc.add_trace(go.Scattergl(x=noise[:,0],y=noise[:,1],mode="markers",
                name="Bruit (-1)",marker=dict(color="#aaa",size=4,opacity=0.4),
                hovertemplate="Bruit<br>PC1:%{x:.2f} PC2:%{y:.2f}<extra></extra>"))
        for ci in unique_labels:
            mask=labels==ci; clr=PAL[ci%len(PAL)]; n_c=int(mask.sum())
            pt_idxs=np.where(mask)[0]
            fig_sc.add_trace(go.Scattergl(x=X2[mask,0],y=X2[mask,1],mode="markers",
                name=f"Cluster {ci}  (n={n_c:,})",
                marker=dict(color=clr,size=7,opacity=0.80,
                            line=dict(width=0.4,color="rgba(255,255,255,.5)")),
                customdata=pt_idxs,
                hovertemplate=f"Cluster {ci}<br>PC1:%{{x:.2f}}<br>PC2:%{{y:.2f}}<extra></extra>"))
            if hull_mode=="convex" and n_c>=3:
                h=_hull(X2[mask,0],X2[mask,1],clr)
                if h: fig_sc.add_trace(h)
        # Centroids
        for ci in unique_labels:
            cx,cy=X2[labels==ci].mean(axis=0)
            fig_sc.add_trace(go.Scatter(x=[cx],y=[cy],mode="markers+text",
                marker=dict(symbol="x",size=14,color=PAL[ci%len(PAL)],
                            line=dict(width=2.5,color="white")),
                text=[str(ci)],textposition="top center",
                textfont=dict(size=11,color="white",family=FONT),
                showlegend=False,hoverinfo="skip"))
        fig_sc.update_layout(**_base(f"Clusters PCA 2D · PC1={v1:.1f}% PC2={v2:.1f}%"),
            xaxis_title=f"PC1 ({v1:.1f}%)",yaxis_title=f"PC2 ({v2:.1f}%)",dragmode="lasso")

        # ── Silhouette ──────────────────────────────────────────────
        try:
            valid=(labels!=-1)
            if len(set(labels[valid]))>=2 and valid.sum()>=4:
                n_sil=min(5000,valid.sum())
                rng2=np.random.default_rng(42)
                sil_idx=rng2.choice(valid.sum(),n_sil,replace=False) if valid.sum()>n_sil else np.arange(valid.sum())
                sil_vals=silhouette_samples(X[valid][sil_idx],labels[valid][sil_idx])
                sil_avg=float(sil_vals.mean())
                fig_sil=go.Figure(); y_lo=0
                for ci in unique_labels:
                    lv=labels[valid][sil_idx]; sil_ci=np.sort(sil_vals[lv==ci])
                    clr=PAL[ci%len(PAL)]; y_hi=y_lo+len(sil_ci)
                    fig_sil.add_trace(go.Bar(x=sil_ci,y=list(range(y_lo,y_hi)),
                        orientation="h",name=f"Cluster {ci}",
                        marker_color=clr,opacity=0.82,
                        hovertemplate=f"Cluster {ci}<br>Sil=%{{x:.3f}}<extra></extra>"))
                    y_lo=y_hi+4
                fig_sil.add_vline(x=sil_avg,line_dash="dash",line_color="#e74c3c",
                    annotation_text=f"moy={sil_avg:.3f}",annotation_font_size=10)
                fig_sil.update_layout(**_base(f"Silhouette · score moyen={sil_avg:.3f}"),
                    xaxis_title="Coefficient silhouette",
                    yaxis=dict(visible=False),showlegend=True)
            else: fig_sil=go.Figure()
        except: fig_sil=go.Figure()

        # ── Radar profile ────────────────────────────────────────────
        try:
            top_cols=cols[:min(8,len(cols))]
            X_norm=MinMaxScaler().fit_transform(
                df[top_cols].fillna(df[top_cols].median()).values)
            fig_prof=go.Figure()
            for ci in unique_labels:
                mask=labels==ci; means=X_norm[mask].mean(axis=0)
                theta=top_cols+[top_cols[0]]; r=list(means)+[means[0]]
                clr=PAL[ci%len(PAL)]
                fig_prof.add_trace(go.Scatterpolar(r=r,theta=theta,fill="toself",
                    name=f"Cluster {ci}  (n={mask.sum():,})",line_color=clr,
                    fillcolor=_ha(clr,0.15),line_width=2.5,opacity=0.9,
                    hovertemplate=f"Cluster {ci}<br>%{{theta}}: %{{r:.2f}}<extra></extra>"))
            fig_prof.update_layout(polar=dict(radialaxis=dict(visible=True,range=[0,1],
                gridcolor=GRID,tickfont=dict(size=9))),showlegend=True,
                title=dict(text="Profile Radar (normalisé 0–1)",font=dict(size=12,color="#1e3a5f")),
                paper_bgcolor="#fff",font=dict(family=FONT,size=11),
                margin=dict(l=50,r=50,t=50,b=30),
                legend=dict(font=dict(size=11)))
        except: fig_prof=go.Figure()

        # ── Insight cards ────────────────────────────────────────────
        cards=_cluster_insight_cards(dep,df,cols,labels,unique_labels)

        return fig_sc,fig_elbow,fig_sil,fig_prof,cards,{"labels":labels.tolist(),"cols":cols}


    # ── Lasso panel ──────────────────────────────────────────────────────────
    @app.callback(
        Output("cl-lasso-panel","children"),
        [Input("cl-scatter","selectedData"),Input("cl-labels-store","data")],
    )
    def lasso_panel(selected, store):
        if not selected or not selected.get("points") or not store:
            return _placeholder()

        idxs=[]
        for pt in selected["points"]:
            cd=pt.get("customdata")
            if cd is not None:
                try: idxs.append(int(cd))
                except: pass
        if not idxs:
            return _placeholder()

        df=dep.display_df.reset_index(drop=True)
        n_total=len(df); sel_set=set(idxs)
        rst_idx=[i for i in range(n_total) if i not in sel_set]
        if not rst_idx or len(idxs)<3:
            return _placeholder("Sélection trop petite (n<3).")

        sel_df=df.iloc[sorted(sel_set)]; rst_df=df.iloc[rst_idx]
        n_sel=len(sel_df); n_rst=len(rst_df)

        out=[]

        # Header cards
        out.append(html.Div([
            html.Div([
                html.Div(f"{n_sel:,}",style={"fontSize":"22px","fontWeight":"800",
                    "color":"#4472c4","fontFamily":FONT}),
                html.Div("Points sélectionnés",style={"fontSize":"10px","color":"#6b7a8d",
                    "fontWeight":"600","textTransform":"uppercase"}),
            ],style={"flex":"1","textAlign":"center","background":"#eff5ff",
                     "borderRadius":"8px","padding":"10px"}),
            html.Div([
                html.Div(f"{n_rst:,}",style={"fontSize":"22px","fontWeight":"800",
                    "color":"#e07b39","fontFamily":FONT}),
                html.Div("Reste du dataset",style={"fontSize":"10px","color":"#6b7a8d",
                    "fontWeight":"600","textTransform":"uppercase"}),
            ],style={"flex":"1","textAlign":"center","background":"#fff8f0",
                     "borderRadius":"8px","padding":"10px"}),
        ],style={"display":"flex","gap":"8px","marginBottom":"14px","padding":"0 4px"}))

        # ── Target comparison ─────────────────────────────────────────
        if dep.supervised:
            tgt=dep.target_name
            out.append(html.Div("🎯 Comparaison Target",
                style={"fontWeight":"700","fontSize":"12px","color":"#1e3a5f",
                       "marginBottom":"6px","fontFamily":FONT}))
            if dep.is_classification:
                try:
                    from scipy.stats import chi2_contingency
                    g=pd.Series(["Sél."]*n_sel+["Reste"]*n_rst)
                    t=pd.concat([sel_df[tgt].astype(str),rst_df[tgt].astype(str)],ignore_index=True)
                    ct=pd.crosstab(g,t)
                    chi2,p,dof,_=chi2_contingency(ct)
                    k_sq=min(ct.shape)-1
                    v=float(np.sqrt(chi2/max((n_sel+n_rst)*k_sq,1e-9)))
                    sig="✅ Sig." if p<0.05 else "❌ Non sig."
                    clr_p="#27ae60" if p<0.05 else "#e74c3c"
                    # Stacked bars
                    fig=go.Figure()
                    for i,cls in enumerate(dep.classes):
                        c=PAL[i%len(PAL)]
                        p_sel=float(sel_df[tgt].eq(cls).mean()*100)
                        p_rst=float(rst_df[tgt].eq(cls).mean()*100)
                        fig.add_trace(go.Bar(name=str(cls),x=["Sélection","Reste"],
                            y=[p_sel,p_rst],marker_color=c,
                            hovertemplate=f"Cls {cls}: %{{y:.1f}}%<extra></extra>"))
                    fig.update_layout(barmode="stack",height=160,
                        plot_bgcolor=BG,paper_bgcolor="#fff",
                        margin=dict(l=30,r=8,t=8,b=30),
                        font=dict(family=FONT,size=9),
                        yaxis=dict(title="%",gridcolor=GRID),
                        legend=dict(font=dict(size=8),orientation="h",y=-0.35))
                    out+=[dcc.Graph(figure=fig,config={"displayModeBar":False},
                                    style={"height":"160px"}),
                          _stat_row("Cramér V",f"{v:.3f}"),
                          _stat_row("Chi² p",f"{p:.4f}",clr_p),
                          _stat_row("",sig,clr_p)]
                except: pass
            else:
                try:
                    a=sel_df[tgt].dropna().values; b=rst_df[tgt].dropna().values
                    if len(a)>=3 and len(b)>=3:
                        _,p=sp_stats.ttest_ind(a,b,equal_var=False)
                        sd=np.sqrt((a.std(ddof=1)**2+b.std(ddof=1)**2)/2+1e-12)
                        d=(a.mean()-b.mean())/sd; clr_p="#27ae60" if p<0.05 else "#e74c3c"
                        fig=go.Figure()
                        fig.add_trace(go.Box(y=a,name="Sélection",
                            marker_color="#4472c4",boxmean=True,
                            hovertemplate="Sélection: %{y:.4g}<extra></extra>"))
                        fig.add_trace(go.Box(y=b,name="Reste",
                            marker_color="#e07b39",boxmean=True,
                            hovertemplate="Reste: %{y:.4g}<extra></extra>"))
                        fig.update_layout(height=170,plot_bgcolor=BG,paper_bgcolor="#fff",
                            margin=dict(l=30,r=8,t=8,b=30),font=dict(family=FONT,size=9),
                            yaxis=dict(title=tgt[:14],gridcolor=GRID),
                            legend=dict(font=dict(size=9)))
                        out+=[dcc.Graph(figure=fig,config={"displayModeBar":False},
                                        style={"height":"170px"}),
                              _stat_row(f"Moy. Sél.",f"{a.mean():.4g}","#4472c4"),
                              _stat_row(f"Moy. Reste",f"{b.mean():.4g}","#e07b39"),
                              _stat_row("Cohen's d",f"{d:+.3f}"),
                              _stat_row("Welch p",f"{p:.4f}",clr_p)]
                except: pass

        # ── Feature analysis ─────────────────────────────────────────
        feat_rows=[]
        for col in [c for c in dep.num_features if c in df.columns and c!=dep.target_name][:30]:
            a=sel_df[col].dropna().values; b=rst_df[col].dropna().values
            if len(a)<3 or len(b)<3: continue
            try:
                _,p_mw=sp_stats.mannwhitneyu(a,b,alternative="two-sided")
                sd=np.sqrt((a.std(ddof=1)**2+b.std(ddof=1)**2)/2+1e-12)
                d=(a.mean()-b.mean())/max(sd,1e-12)
                feat_rows.append((col,a.mean(),b.mean(),d,p_mw))
            except: pass

        feat_rows.sort(key=lambda r:abs(r[3]),reverse=True)
        top15=feat_rows[:15]; top6=feat_rows[:6]

        if not top15:
            out.append(html.Div("Pas assez de données.",
                style={"color":"#9aa5b4","fontSize":"12px","padding":"12px"}))
            return html.Div(out,style={"padding":"6px"})

        # Violin comparison for top-6 most different features
        out.append(html.Div("📊 Top features — Sélection vs Reste",
            style={"fontWeight":"700","fontSize":"12px","color":"#1e3a5f",
                   "margin":"12px 0 6px","fontFamily":FONT}))

        n_sub=min(2,len(top6)//3+1)
        n_col=min(3,len(top6))
        if top6:
            h_v=max(140,160//n_sub)
            fig_vio=make_subplots(rows=max(1,(len(top6)+n_col-1)//n_col),
                                   cols=n_col,vertical_spacing=0.18,
                                   horizontal_spacing=0.08)
            for idx,(col,m_s,m_r,d,p) in enumerate(top6):
                r,c=(idx//n_col)+1,(idx%n_col)+1
                a_v=sel_df[col].dropna().values; b_v=rst_df[col].dropna().values
                clr_d="#4472c4" if d>0 else "#e07b39"
                fig_vio.add_trace(go.Violin(y=a_v,name="Sél",box_visible=True,
                    meanline_visible=True,line_color="#4472c4",fillcolor=_ha("#4472c4",0.2),
                    showlegend=False,points=False,
                    hovertemplate=f"{col}<br>Sél.: %{{y:.3g}}<extra></extra>"),row=r,col=c)
                fig_vio.add_trace(go.Violin(y=b_v,name="Reste",box_visible=True,
                    meanline_visible=True,line_color="#e07b39",fillcolor=_ha("#e07b39",0.2),
                    showlegend=False,points=False,
                    hovertemplate=f"{col}<br>Reste: %{{y:.3g}}<extra></extra>"),row=r,col=c)
                lbl=col[:12]+"…" if len(col)>12 else col
                stars=("***" if p<0.001 else "**" if p<0.01 else "*" if p<0.05 else "ns")
                fig_vio.update_xaxes(title_text=f"<b>{lbl}</b><br>d={d:+.2f} {stars}",
                    title_font=dict(size=8,color=clr_d),row=r,col=c)
            fig_vio.update_layout(height=int(h_v*((len(top6)+n_col-1)//n_col)),
                plot_bgcolor=BG,paper_bgcolor="#fff",
                margin=dict(l=24,r=8,t=8,b=8),
                font=dict(family=FONT,size=8),violinmode="overlay")
            out.append(dcc.Graph(figure=fig_vio,config={"displayModeBar":False},
                style={"height":f"{int(h_v*((len(top6)+n_col-1)//n_col))}px",
                       "marginBottom":"8px"}))

        # Forest plot
        lbls=[r[0][:18] for r in top15]
        dvals=[r[3] for r in top15]
        sig_flags=[abs(r[3])>=0.2 and r[4]<0.05 for r in top15]
        colors=["#e07b39" if d>0 else "#4472c4" for d in dvals]
        opac=[1.0 if s else 0.35 for s in sig_flags]
        h_fp=max(200,len(top15)*22+50)
        fig_f=go.Figure()
        for xv,dash,anno in [(0,"solid",""),(0.2,"dot","petit"),(0.5,"dot","moyen"),
                              (-0.2,"dot",""),(-.5,"dot","")]:
            fig_f.add_vline(x=xv,line_dash=dash,
                line_color="#9aa5b4" if xv==0 else "rgba(150,150,150,.3)",
                line_width=1.5 if xv==0 else 1,
                annotation_text=anno,annotation_font_size=7,
                annotation_font_color="#9aa5b4")
        fig_f.add_trace(go.Bar(x=dvals,y=lbls,orientation="h",
            marker=dict(color=colors,opacity=opac,
                        line=dict(width=0.5,color="rgba(255,255,255,.4)")),
            hovertemplate="<b>%{y}</b><br>Cohen's d=%{x:+.3f}<extra></extra>",
            showlegend=False))
        fig_f.update_layout(plot_bgcolor=BG,paper_bgcolor="#fff",height=h_fp,
            margin=dict(l=140,r=40,t=10,b=30),
            xaxis=dict(title="Cohen's d (sél − reste)",gridcolor=GRID,zeroline=False),
            yaxis=dict(tickfont=dict(size=9),autorange="reversed"),
            font=dict(family=FONT,size=9))
        out.append(html.Div("🌲 Forest plot — Cohen's d",
            style={"fontWeight":"700","fontSize":"11px","color":"#1e3a5f",
                   "margin":"10px 0 4px","fontFamily":FONT}))
        out.append(dcc.Graph(figure=fig_f,config={"displayModeBar":False},
            style={"height":f"{h_fp}px"}))

        # Table
        out.append(html.Div("📋 Tableau complet",
            style={"fontWeight":"700","fontSize":"11px","color":"#1e3a5f",
                   "margin":"10px 0 4px","fontFamily":FONT}))
        hdr=html.Tr([html.Th(h,style=_th()) for h in ["Variable","μ Sél","μ Reste","d","p (MW)","Sig."]])
        bdy=[]
        for col,ms,mr,d,p in top15:
            is_sig=abs(d)>=0.2 and p<0.05
            bg=("#fff8f0" if is_sig and d>0 else "#f0f5ff" if is_sig and d<0 else "#fff")
            bdy.append(html.Tr([
                html.Td(col[:18],style={**_td(),"fontWeight":"700","color":"#1e3a5f"}),
                html.Td(f"{ms:.3g}",style=_td("#4472c4")),
                html.Td(f"{mr:.3g}",style=_td("#e07b39")),
                html.Td(f"{d:+.3f}",style=_td("#e07b39" if d>0.2 else "#4472c4" if d<-0.2 else None)),
                html.Td(f"{p:.4f}",style=_td("#27ae60" if p<0.05 else None)),
                html.Td("✅" if is_sig else "—",style=_td("#27ae60" if is_sig else "#9aa5b4")),
            ],style={"borderBottom":"1px solid #f5f5f5","background":bg}))
        out.append(html.Div(html.Table([html.Thead(hdr),html.Tbody(bdy)],
            style={"width":"100%","borderCollapse":"collapse","fontSize":"10.5px","fontFamily":FONT}),
            style={"overflowX":"auto"}))

        return html.Div(out,style={"padding":"6px"})


# ══════════════════════════════════════════════════════════════════════════════

def _cluster_insight_cards(dep, df, cols, labels, unique_labels):
    """Cards d'insights pour chaque cluster — visible sans sélection lasso."""
    if not unique_labels:
        return html.Div()
    # Top discriminating features via ANOVA
    best_feats=[]
    for col in cols[:20]:
        groups=[df[col].dropna().values[labels==ci] for ci in unique_labels]
        groups=[g for g in groups if len(g)>=3]
        if len(groups)<2: continue
        try:
            f,p=sp_stats.f_oneway(*groups)
            if not np.isnan(f): best_feats.append((col,f,p))
        except: pass
    best_feats.sort(key=lambda x:x[1],reverse=True)
    top3=[b[0] for b in best_feats[:3]]

    cards=[]
    for ci in unique_labels:
        mask=labels==ci; clr=PAL[ci%len(PAL)]
        n_c=int(mask.sum())
        lines=[html.Div([
            html.Div(f"Cluster {ci}",style={"fontWeight":"800","fontSize":"13px",
                "color":clr,"fontFamily":FONT}),
            html.Div(f"n = {n_c:,}  ({n_c/len(labels)*100:.1f}%)",
                style={"fontSize":"10px","color":"#6b7a8d"}),
        ])]
        for col in top3:
            g=df[col].values[mask]
            g=g[~np.isnan(g)]
            if len(g)>0:
                lines.append(html.Div(
                    f"{col[:14]}: μ={g.mean():.3g} σ={g.std(ddof=1):.3g}",
                    style={"fontSize":"9.5px","color":"#374151","marginTop":"2px"}))
        if dep.supervised and dep.is_classification:
            tgt_v=df[dep.target_name].values[mask]
            from collections import Counter
            most=Counter(tgt_v).most_common(1)
            if most:
                dom_cls,dom_n=most[0]
                lines.append(html.Div(
                    f"🎯 {dep.target_name[:12]}: {dom_cls} ({dom_n/n_c:.0%})",
                    style={"fontSize":"9.5px","color":clr,"marginTop":"3px","fontWeight":"700"}))
        cards.append(html.Div(lines,style={
            "background":"white","borderRadius":"10px","padding":"10px 14px",
            "flex":"1","minWidth":"120px","boxShadow":"0 1px 6px rgba(0,0,0,.06)",
            "borderLeft":f"4px solid {clr}"}))
    return html.Div(cards,style={"display":"flex","gap":"10px","flexWrap":"wrap"})


def _placeholder(msg=None):
    return html.Div([
        html.Div("🔍 Insights Lasso",style={"fontWeight":"800","color":"#1e3a5f",
            "fontSize":"13px","marginBottom":"12px"}),
        html.Div([
            html.Div("←",style={"fontSize":"28px","textAlign":"center","marginBottom":"8px"}),
            html.Div(msg or "Sélectionnez des points avec lasso ou box.",
                style={"fontSize":"12px","color":"#9aa5b4","textAlign":"center"}),
            html.Ul([html.Li("Comparaison Target"),html.Li("Violin top features"),
                     html.Li("Forest plot Cohen's d"),html.Li("Tableau Mann-Whitney")],
                style={"fontSize":"11px","color":"#bbb","paddingLeft":"16px",
                       "lineHeight":"1.8","marginTop":"10px"}),
        ],style={"background":"#f7f8fa","borderRadius":"10px","padding":"18px",
                  "border":"1.5px dashed #dde2ea"}),
    ],style={"padding":"6px"})

def _stat_row(label,value,color=None):
    return html.Div([
        html.Span(label,style={"fontSize":"11px","color":"#6b7a8d","fontWeight":"600","flex":"1"}),
        html.Span(value,style={"fontSize":"11px","fontWeight":"700","color":color or "#1e3a5f"}),
    ],style={"display":"flex","justifyContent":"space-between","padding":"3px 6px",
              "borderBottom":"1px solid #f5f5f5"})

def _th():
    return {"padding":"4px 6px","background":"#f0f4f8","color":"#6b7a8d","fontWeight":"700",
            "fontSize":"9.5px","textTransform":"uppercase","letterSpacing":".3px",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"}

def _td(color=None):
    s={"padding":"3px 6px","fontSize":"10.5px","color":"#374151","whiteSpace":"nowrap"}
    if color: s.update({"color":color,"fontWeight":"700"})
    return s
