"""
Analyses Post-Hoc v9 — Comparaisons multiples lisibles et professionnelles

Layout :
  • 4 cards de résumé (N groupes, test omnibus, paires sig., taille d'effet)
  • Violin + strip plot annoté (n, moyenne, IC)
  • Forest plot avec Cohen's d, zones d'effet colorées
  • Heatmap gradient p-values (pas binaire)
  • Letter display (a/b/ab — groupes homogènes)
  • Tableau simplifié avec interprétation
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep):
    num      = dep.num_features
    cat_cols = dep.cat_features if hasattr(dep,"cat_features") else []

    y_opts = [{"label":c,"value":c} for c in num]
    grp_opts = []
    if dep.supervised:
        grp_opts.append({"label":f"🎯 Target ({dep.target_name})","value":"__target__"})
    for c in cat_cols:
        if dep.display_df[c].nunique() <= 20:
            grp_opts.append({"label":f"📂 {c}","value":c})
    for c in num[:6]:
        grp_opts.append({"label":f"📊 {c} (4 quartiles)","value":f"__bin__{c}"})

    return html.Div([
        html.Div("Comparaisons Post-Hoc", className="page-title"),
        html.Div(
            "Comparez les groupes : ANOVA, Kruskal-Wallis, Tukey, Cohen's d. "
            "Tout est calculé et interprété automatiquement.",
            className="page-subtitle"),

        # Controls
        html.Div([
            html.Div([html.Div("Variable à comparer (Y):", className="control-label"),
                      dcc.Dropdown(id="ph-y", options=y_opts,
                          value=num[0] if num else None,
                          clearable=False, style={"width":"200px"})],
                className="control-group"),
            html.Div([html.Div("Groupes:", className="control-label"),
                      dcc.Dropdown(id="ph-grp", options=grp_opts,
                          value=grp_opts[0]["value"] if grp_opts else None,
                          clearable=False, style={"width":"240px"})],
                className="control-group"),
            html.Div([html.Div("Correction:", className="control-label"),
                      dcc.Dropdown(id="ph-method",
                          options=[
                              {"label":"Tukey HSD",        "value":"tukey"},
                              {"label":"Bonferroni",        "value":"bonf"},
                              {"label":"Holm-Bonferroni",   "value":"holm"},
                              {"label":"Games-Howell",      "value":"games"},
                              {"label":"Dunn (non-param.)", "value":"dunn"},
                          ],
                          value="tukey", clearable=False, style={"width":"200px"})],
                className="control-group"),
            html.Div([html.Div("Seuil α:", className="control-label"),
                      dcc.Dropdown(id="ph-alpha",
                          options=[{"label":"0.05","value":"0.05"},
                                   {"label":"0.01","value":"0.01"},
                                   {"label":"0.10","value":"0.10"}],
                          value="0.05", clearable=False, style={"width":"100px"})],
                className="control-group"),
        ], className="controls-row"),

        # Summary cards
        html.Div(id="ph-summary", style={"marginBottom":"16px"}),

        # Violin + Forest
        html.Div([
            html.Div([
                html.Div("Distribution par groupe", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="ph-violin",
                    config={"displayModeBar":False}, style={"height":"420px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                html.Div("Forest plot — Différences & Taille d'effet (Cohen's d)",
                         className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="ph-forest",
                    config={"displayModeBar":False}, style={"height":"420px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # Heatmap + Letter display
        html.Div([
            html.Div([
                html.Div("Heatmap p-values (pairwise)", className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="ph-heatmap",
                    config={"displayModeBar":False}, style={"height":"380px"}),
                    type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                html.Div("Groupes homogènes (letter display) & Tableau",
                         className="chart-card-title"),
                html.Div(id="ph-table",
                         style={"maxHeight":"380px","overflowY":"auto","padding":"4px"}),
            ], className="chart-card"),
        ], className="charts-grid"),

    ], className="page-card")


def register_callbacks(app, dep):

    _memo: dict = {}

    @app.callback(
        [Output("ph-summary","children"),
         Output("ph-violin","figure"),
         Output("ph-forest","figure"),
         Output("ph-heatmap","figure"),
         Output("ph-table","children")],
        [Input("ph-y","value"), Input("ph-grp","value"),
         Input("ph-method","value"), Input("ph-alpha","value")],
    )
    def update(y_col, grp_col, method, alpha_str):
        alpha = float(alpha_str or 0.05)
        empty = go.Figure()

        if not y_col or not grp_col:
            return _err("Sélectionnez une variable Y et un groupement."), \
                   empty, empty, empty, []

        memo_key = (y_col, grp_col, method, alpha)
        if memo_key in _memo:
            return _memo[memo_key]

        df = dep.display_df.copy()

        # Build groups
        if grp_col == "__target__":
            gv = df[dep.target_name].astype(str)
        elif grp_col.startswith("__bin__"):
            base = grp_col.replace("__bin__","")
            gv   = pd.qcut(df[base], q=4, duplicates="drop").astype(str)
        else:
            gv = df[grp_col].astype(str)

        df["__grp__"] = gv
        raw = df.groupby("__grp__")[y_col].apply(lambda x: x.dropna().values)
        valid_grps = {k:v for k,v in raw.items() if len(v)>=3}

        if len(valid_grps) < 2:
            msg = _err("Moins de 2 groupes avec suffisamment de données (n≥3).")
            return msg, empty, empty, empty, []

        grp_names = sorted(valid_grps.keys())
        grp_data  = [valid_grps[g] for g in grp_names]
        n_grps    = len(grp_names)

        # ── Omnibus ───────────────────────────────────────────────────
        ov = _omnibus(grp_data, alpha)

        # ── Pairwise ─────────────────────────────────────────────────
        pairs_df  = _pairwise(valid_grps, grp_names, method, alpha)

        n_sig     = int((pairs_df["p_adj"] < alpha).sum())
        n_pairs   = len(pairs_df)

        # Overall effect size: eta²
        all_vals  = np.concatenate(grp_data)
        gm        = all_vals.mean()
        sst       = ((all_vals-gm)**2).sum()
        ssb       = sum(len(g)*(g.mean()-gm)**2 for g in grp_data)
        eta2      = float(np.clip(ssb/max(sst,1e-9), 0, 1))

        # ── Summary cards ────────────────────────────────────────────
        summary = _summary_cards(grp_names, valid_grps, ov, n_sig, n_pairs,
                                  eta2, alpha, y_col)

        # ── Violin ───────────────────────────────────────────────────
        fig_vio = _violin_plot(valid_grps, grp_names, y_col, pairs_df, alpha)

        # ── Forest plot ───────────────────────────────────────────────
        fig_forest = _forest_plot(pairs_df, method, alpha)

        # ── Heatmap p-values ─────────────────────────────────────────
        fig_heat = _pvalue_heatmap(pairs_df, grp_names, alpha)

        # ── Letters + Table ───────────────────────────────────────────
        table_el = _letters_and_table(pairs_df, valid_grps, grp_names, alpha, method)

        result = summary, fig_vio, fig_forest, fig_heat, table_el
        _memo[memo_key] = result
        return result


# ══════════════════════════════════════════════════════════════════════
#  STATS HELPERS
# ══════════════════════════════════════════════════════════════════════

def _omnibus(grp_data, alpha):
    out = {}
    try:
        f,p = sp_stats.f_oneway(*grp_data)
        out["anova"] = {"stat":f,"p":p,"label":"ANOVA F","sig":p<alpha}
    except: out["anova"] = None
    try:
        h,p = sp_stats.kruskal(*grp_data)
        out["kw"]    = {"stat":h,"p":p,"label":"Kruskal-Wallis H","sig":p<alpha}
    except: out["kw"] = None
    try:
        s,p = sp_stats.levene(*grp_data)
        out["levene"] = {"stat":s,"p":p,"label":"Levene W","sig":p>alpha}
    except: out["levene"] = None
    return out


def _cohens_d(a, b):
    na,nb = len(a),len(b)
    pooled = np.sqrt(((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1)) / max(na+nb-2,1))
    return float((a.mean()-b.mean()) / max(pooled,1e-12))


def _pairwise(valid_grps, grp_names, method, alpha):
    pairs = list(combinations(grp_names,2))
    rows  = []
    for g1,g2 in pairs:
        a,b   = valid_grps[g1], valid_grps[g2]
        diff  = float(a.mean()-b.mean())
        d     = _cohens_d(a,b)
        se    = np.sqrt(a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))
        dft   = (se**2)**2 / ((a.var(ddof=1)/len(a))**2/max(len(a)-1,1) +
                               (b.var(ddof=1)/len(b))**2/max(len(b)-1,1) + 1e-12)
        t     = diff / max(se,1e-12)
        p_raw = float(2*sp_stats.t.sf(abs(t),df=dft))
        ci    = float(sp_stats.t.ppf(0.975,dft)*se)
        rows.append({"G1":g1,"G2":g2,"diff":diff,"se":se,"ci95":ci,
                     "t":t,"d":d,"p_raw":p_raw})
    df = pd.DataFrame(rows)
    m  = len(df)
    if m == 0: return df
    # Correction
    df = df.sort_values("p_raw").reset_index(drop=True)
    if method in ("bonf","holm"):
        adj = []; max_p=0.0
        for i,row in df.iterrows():
            p = min(1.0, row["p_raw"]*(m-i if method=="holm" else m))
            p = max(p,max_p); max_p=p
            adj.append(p)
        df["p_adj"] = adj
    else:
        df["p_adj"] = (df["p_raw"]*m).clip(0,1)
    df["sig"] = df["p_adj"] < alpha
    return df


# ══════════════════════════════════════════════════════════════════════
#  UI BUILDERS
# ══════════════════════════════════════════════════════════════════════

def _err(msg):
    return html.Div(msg,style={"color":"#e74c3c","padding":"16px","fontSize":"13px"})


def _summary_cards(grp_names, valid_grps, ov, n_sig, n_pairs, eta2, alpha, y_col):
    # Card data
    sizes = {g:len(v) for g,v in valid_grps.items()}
    min_n, max_n = min(sizes.values()), max(sizes.values())

    # Omnibus best p
    best_p = 1.0
    best_label = ""
    for k,v in ov.items():
        if v and "p" in v and v["p"] < best_p:
            best_p = v["p"]; best_label = v["label"]

    # Effect size label
    eta2_label = ("Négligeable (<.01)" if eta2<.01 else
                  "Petite (.01–.06)" if eta2<.06 else
                  "Moyenne (.06–.14)" if eta2<.14 else
                  "Grande (≥.14)")
    eta2_clr   = ("#9aa5b4" if eta2<.01 else "#f39c12" if eta2<.06
                  else "#e07b39" if eta2<.14 else "#27ae60")

    # Sig pct
    sig_pct = n_sig/max(n_pairs,1)*100

    cards = [
        {"icon":"👥","label":"Groupes","value":str(len(grp_names)),
         "sub":f"n={min_n:,}–{max_n:,} obs/groupe","clr":"#4472c4"},
        {"icon":"🧪","label":"Test omnibus","value":f"p={best_p:.4f}",
         "sub":f"{best_label} — {'✅ Différence sig.' if best_p<alpha else '❌ Pas de différence sig.'}",
         "clr":"#27ae60" if best_p<alpha else "#e74c3c"},
        {"icon":"⚡","label":"Paires significatives","value":f"{n_sig}/{n_pairs}",
         "sub":f"{sig_pct:.0f}% des paires à α={alpha}",
         "clr":"#e07b39"},
        {"icon":"📏","label":"Taille d'effet η²","value":f"{eta2:.3f}",
         "sub":eta2_label,"clr":eta2_clr},
    ]

    # Omnibus detail badges
    omnibus_badges = []
    for k,v in ov.items():
        if not v: continue
        icon = "✅" if v["sig"] else "❌"
        omnibus_badges.append(html.Span(
            f"{icon} {v['label']} = {v['stat']:.3f}, p={v['p']:.4f}",
            style={"background":"#f0f4f8","borderRadius":"4px","padding":"4px 8px",
                   "fontSize":"11px","color":"#374151","fontFamily":FONT}))

    return html.Div([
        html.Div([
            html.Div([
                html.Div(c["icon"],
                         style={"fontSize":"24px","lineHeight":"1"}),
                html.Div(c["value"],
                         style={"fontSize":"22px","fontWeight":"800",
                                "color":c["clr"],"fontFamily":FONT}),
                html.Div(c["label"],
                         style={"fontSize":"11px","fontWeight":"700",
                                "color":"#6b7a8d","textTransform":"uppercase",
                                "letterSpacing":".4px"}),
                html.Div(c["sub"],
                         style={"fontSize":"11px","color":"#9aa5b4","marginTop":"2px"}),
            ], style={"background":"white","borderRadius":"10px",
                      "padding":"14px 18px","flex":"1","minWidth":"160px",
                      "boxShadow":"0 1px 6px rgba(0,0,0,.07)",
                      "borderLeft":f"4px solid {c['clr']}"})
            for c in cards
        ], style={"display":"flex","gap":"12px","flexWrap":"wrap","marginBottom":"10px"}),

        html.Div(omnibus_badges,
                 style={"display":"flex","gap":"8px","flexWrap":"wrap","padding":"4px 0"}),
    ])


def _violin_plot(valid_grps, grp_names, y_col, pairs_df, alpha):
    fig = go.Figure()
    for i,g in enumerate(grp_names):
        vals = valid_grps[g]
        clr  = PAL[i%len(PAL)]
        r,g_,b = _hex_rgb(clr)

        # Violin
        fig.add_trace(go.Violin(
            y=vals, name=g, x=[g]*len(vals),
            fillcolor=f"rgba({r},{g_},{b},0.25)",
            line_color=clr, line_width=2,
            box=dict(visible=True,fillcolor=f"rgba({r},{g_},{b},0.5)",
                     line=dict(color=clr,width=1.5)),
            meanline=dict(visible=True,color=clr,width=2),
            points=False,
            hoverinfo="skip",
        ))
        # Strip (jittered dots)
        if len(vals) <= 300:
            jitter = np.random.default_rng(42+i).uniform(-0.08,0.08,len(vals))
            fig.add_trace(go.Scatter(
                x=[g]*len(vals)+jitter, y=vals, mode="markers",
                name=g, showlegend=False,
                marker=dict(color=clr,size=4,opacity=0.45,
                            line=dict(width=0.3,color="white")),
                hovertemplate=f"<b>{g}</b><br>%{{y:.4g}}<extra></extra>",
            ))
        # Annotations: mean ± se
        mean,std = vals.mean(), vals.std(ddof=1)
        se = std/np.sqrt(len(vals))
        fig.add_annotation(
            x=g, y=vals.max()+(vals.max()-vals.min())*0.06,
            text=f"μ={mean:.3g}<br>σ={std:.3g}<br>n={len(vals):,}",
            showarrow=False,
            font=dict(size=9,family=FONT,color="#374151"),
            bgcolor="rgba(255,255,255,0.85)",
            bordercolor=clr, borderwidth=1, borderpad=3,
        )

    # Significance bars (Tukey-style)
    if len(pairs_df) > 0:
        sig_pairs = pairs_df[pairs_df["sig"]].head(5)
        if len(sig_pairs) > 0:
            all_max = max(v.max() for v in valid_grps.values())
            all_rng = max(v.max()-v.min() for v in valid_grps.values())
            for k,(idx,row) in enumerate(sig_pairs.iterrows()):
                y_bar = all_max + all_rng*(0.18 + k*0.12)
                g1_x, g2_x = grp_names.index(row["G1"]), grp_names.index(row["G2"])
                stars = "***" if row["p_adj"]<0.001 else "**" if row["p_adj"]<0.01 else "*"
                for xi in [g1_x,g2_x]:
                    fig.add_shape(type="line",
                        x0=grp_names[xi],x1=grp_names[xi],
                        y0=y_bar-all_rng*0.015,y1=y_bar,
                        line=dict(color="#374151",width=1))
                fig.add_shape(type="line",
                    x0=row["G1"],x1=row["G2"],y0=y_bar,y1=y_bar,
                    line=dict(color="#374151",width=1))
                fig.add_annotation(
                    x=(g1_x+g2_x)/2 if g1_x<g2_x else row["G1"],
                    y=y_bar+all_rng*0.015,
                    xref="x" if g1_x>=0 else "x",
                    text=f"<b>{stars}</b>",
                    showarrow=False,font=dict(size=12,color="#e74c3c"))

    fig.update_layout(
        violinmode="group",
        xaxis=dict(title="Groupe",tickfont=dict(size=10),gridcolor=GRID),
        yaxis=dict(title=y_col,gridcolor=GRID,zeroline=False),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=60,r=20,t=30,b=60),
        font=dict(family=FONT,size=11),
        showlegend=False,
    )
    return fig


def _forest_plot(pairs_df, method, alpha):
    if len(pairs_df)==0:
        return go.Figure()

    df = pairs_df.sort_values("d", ascending=True).reset_index(drop=True)
    labels  = [f"{r.G1[:12]} vs {r.G2[:12]}" for _,r in df.iterrows()]
    colors  = ["#e74c3c" if r.sig else "rgba(68,114,196,0.45)" for _,r in df.iterrows()]
    sizes   = [10 if r.sig else 7 for _,r in df.iterrows()]

    fig = go.Figure()

    # Effect size bands (Cohen's d scale)
    for x0,x1,lbl,clr in [
        (-0.2, 0.2, "Négligeable",  "rgba(200,200,200,0.12)"),
        (-0.5,-0.2, "Petit",        "rgba(68,114,196,0.07)"),
        ( 0.2, 0.5, "Petit",        "rgba(68,114,196,0.07)"),
        (-0.8,-0.5, "Moyen",        "rgba(68,114,196,0.12)"),
        ( 0.5, 0.8, "Moyen",        "rgba(68,114,196,0.12)"),
    ]:
        fig.add_vrect(x0=x0,x1=x1,fillcolor=clr,line_width=0,layer="below")

    # Reference lines
    for xv,dash,lbl in [(0,"dash","Pas de différence"),
                         (-0.5,"dot","|d|=0.5"),(0.5,"dot",""),
                         (-0.8,"dot","|d|=0.8"),(0.8,"dot","")]:
        fig.add_vline(x=xv,line_dash=dash,line_color="#9aa5b4",
                      line_width=1.2,
                      annotation_text=lbl if lbl else "",
                      annotation_font_size=8,
                      annotation_font_color="#9aa5b4")

    # Points with CI-like bars using error_x on Cohen's d
    # CI on d ≈ d ± 1.96*SE_d
    d_se = []
    for _,r in df.iterrows():
        n1 = len(pairs_df[pairs_df.G1==r.G1]) + 1
        n2 = len(pairs_df[pairs_df.G2==r.G2]) + 1
        se_d = np.sqrt((n1+n2)/(n1*n2) + r.d**2/(2*(n1+n2-2)))
        d_se.append(min(float(se_d)*1.96, 3.0))

    fig.add_trace(go.Scatter(
        x=df["d"].tolist(), y=labels,
        mode="markers",
        marker=dict(color=colors, size=sizes, symbol="diamond",
                    line=dict(width=1.5,color="white")),
        error_x=dict(type="data",array=d_se,visible=True,
                     color="rgba(100,120,180,0.45)",thickness=2,width=6),
        hovertemplate=(
            "<b>%{y}</b><br>"
            "Cohen's d = <b>%{x:.3f}</b><br>"
            "Δmoyenne = %{customdata[0]:+.4g}<br>"
            "p adj. = %{customdata[1]:.4f}<br>"
            "Sig. = %{customdata[2]}<extra></extra>"),
        customdata=list(zip(df["diff"],df["p_adj"],
                            ["✅ Oui" if s else "❌ Non" for s in df["sig"]])),
        showlegend=False,
    ))

    # Legend for colors
    for lbl,clr in [("Significatif","#e74c3c"),("Non sig.","rgba(68,114,196,0.45)")]:
        fig.add_trace(go.Scatter(x=[None],y=[None],mode="markers",
            marker=dict(color=clr,size=10,symbol="diamond"),name=lbl))

    fig.update_layout(
        title=dict(text=f"Forest Plot — Cohen's d  (méthode: {method.upper()}, α={alpha})",
                   font=dict(size=12,family=FONT,color="#1e3a5f")),
        xaxis=dict(title="Cohen's d  (différence standardisée)",
                   gridcolor=GRID, zeroline=False,
                   tickfont=dict(size=10)),
        yaxis=dict(tickfont=dict(size=9.5), autorange="reversed"),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=180,r=60,t=55,b=60),
        font=dict(family=FONT,size=10),
        height=max(320, len(df)*30+120),
        legend=dict(orientation="h",x=0.5,xanchor="center",y=-0.15,
                    font=dict(size=10)),
    )
    return fig


def _pvalue_heatmap(pairs_df, grp_names, alpha):
    n     = len(grp_names)
    p_mat = np.ones((n,n))
    np.fill_diagonal(p_mat, np.nan)

    for _,row in pairs_df.iterrows():
        i,j = grp_names.index(row.G1), grp_names.index(row.G2)
        p_mat[i,j] = p_mat[j,i] = float(row["p_adj"])

    # Log10 transform for better visual (0→white, tiny→dark)
    log_mat = np.where(np.isnan(p_mat), np.nan,
                       -np.log10(np.clip(p_mat, 1e-10, 1.0)))

    short = [g[:16]+"…" if len(g)>16 else g for g in grp_names]
    txt   = [[f"p={p_mat[i,j]:.4f}" if not np.isnan(p_mat[i,j])
              else "—" for j in range(n)] for i in range(n)]

    # Stars overlay
    star_txt = [[("***" if p_mat[i,j]<0.001 else
                  "**"  if p_mat[i,j]<0.01  else
                  "*"   if p_mat[i,j]<alpha  else "ns")
                 if not np.isnan(p_mat[i,j]) else "—"
                 for j in range(n)] for i in range(n)]

    fig = go.Figure(go.Heatmap(
        z=log_mat, x=short, y=short,
        colorscale=[[0,"#f7fbff"],[0.3,"#c6dbef"],[0.6,"#2171b5"],[1.0,"#08306b"]],
        zmin=0, zmax=max(-np.log10(alpha)*2, 3),
        text=[[f"{txt[i][j]}<br>{star_txt[i][j]}" for j in range(n)] for i in range(n)],
        texttemplate="%{text}",
        textfont=dict(size=10,family=FONT),
        showscale=True,
        colorbar=dict(
            title=dict(text="-log₁₀(p)",font=dict(size=11,family=FONT)),
            thickness=14, tickfont=dict(size=10),
            tickvals=[0,1,2,3],
            ticktext=["p=1","p=0.1","p=0.01","p=0.001"],
        ),
        hovertemplate="<b>%{y} vs %{x}</b><br>%{text}<extra></extra>",
    ))

    # Significance threshold line annotation
    fig.update_layout(
        title=dict(text=f"p-values ajustées — plus c'est bleu, plus c'est significatif",
                   font=dict(size=11,family=FONT,color="#1e3a5f")),
        xaxis=dict(tickangle=-35,tickfont=dict(size=10,family=FONT,color="#1e3a5f")),
        yaxis=dict(tickfont=dict(size=10,family=FONT,color="#1e3a5f")),
        plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=120,r=80,t=55,b=100),
        font=dict(family=FONT,size=10),
    )
    return fig


def _letters_and_table(pairs_df, valid_grps, grp_names, alpha, method):
    # ── Letter display ────────────────────────────────────────────────
    # Groups sharing a letter are NOT significantly different
    letters = _compute_letters(pairs_df, grp_names, alpha)

    letter_rows = []
    for g in grp_names:
        vals = valid_grps[g]
        ltr  = letters.get(g,"?")
        d    = _cohens_d(vals, np.concatenate([v for k,v in valid_grps.items() if k!=g]))
        letter_rows.append(html.Tr([
            html.Td(html.Span(ltr, style={"fontWeight":"900","fontSize":"15px",
                                           "color":"#4472c4","fontFamily":FONT}),
                    style={"padding":"5px 8px","width":"40px","textAlign":"center"}),
            html.Td(g[:22], style={"padding":"5px 8px","fontWeight":"600",
                                    "color":"#1e3a5f","fontSize":"12px"}),
            html.Td(f"{vals.mean():.4g}±{vals.std(ddof=1):.3g}",
                    style={"padding":"5px 8px","fontSize":"11px","color":"#374151"}),
            html.Td(f"n={len(vals):,}",
                    style={"padding":"5px 8px","fontSize":"11px","color":"#6b7a8d"}),
        ],style={"borderBottom":"1px solid #f0f4f8"}))

    letter_section = html.Div([
        html.Div("Groupes homogènes (même lettre = pas de différence significative)",
                 style={"fontSize":"11px","color":"#6b7a8d","marginBottom":"6px",
                        "fontStyle":"italic","fontFamily":FONT}),
        html.Table(html.Tbody(letter_rows),
                   style={"width":"100%","borderCollapse":"collapse",
                          "fontFamily":FONT,"marginBottom":"14px"}),
    ])

    # ── Pairwise table ────────────────────────────────────────────────
    def _dstr(d):
        a = abs(d)
        s = "↑" if d>0 else "↓"
        lbl = ("nég.<.2" if a<.2 else "petit" if a<.5
               else "moyen" if a<.8 else "grand")
        return f"{s}{d:+.2f} ({lbl})"

    def _th(t):
        return html.Th(t,style={"padding":"4px 6px","background":"#f0f4f8",
            "color":"#6b7a8d","fontWeight":"700","fontSize":"9.5px",
            "textTransform":"uppercase","borderBottom":"2px solid #e0e4ea",
            "whiteSpace":"nowrap","textAlign":"left"})
    def _td(t,clr=None,fw=None):
        s={"padding":"4px 6px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
        if fw: s["fontWeight"]=fw
        return html.Td(t,style=s)

    rows = []
    for _,row in pairs_df.sort_values("p_adj").iterrows():
        sig_clr = "#27ae60" if row["sig"] else "#9aa5b4"
        rows.append(html.Tr([
            _td(f"{row['G1'][:14]} vs {row['G2'][:14]}"),
            _td(f"{row['diff']:+.3g}"),
            _td(_dstr(row["d"])),
            _td(f"{row['p_adj']:.4f}","#e74c3c" if row["p_adj"]<alpha else "#374151","700"),
            _td("✅" if row["sig"] else "—",sig_clr,"700"),
        ],style={"borderBottom":"1px solid #f5f5f5"}))

    table_section = html.Div([
        html.Div("Tableau des comparaisons pairwise",
                 style={"fontWeight":"700","fontSize":"11px","color":"#1e3a5f",
                        "marginBottom":"6px","fontFamily":FONT}),
        html.Table([
            html.Thead(html.Tr([_th("Paire"),_th("Δmoy"),
                                _th("Cohen's d"),_th("p adj."),_th("Sig.")])),
            html.Tbody(rows),
        ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
    ])

    return html.Div([letter_section, table_section])


def _compute_letters(pairs_df, grp_names, alpha):
    """Simple letter display: greedy CLD algorithm."""
    if len(pairs_df)==0:
        return {g:chr(97+i) for i,g in enumerate(grp_names)}

    n = len(grp_names)
    idx = {g:i for i,g in enumerate(grp_names)}
    # sig_pairs: set of (i,j) that are significantly different
    sig = set()
    for _,row in pairs_df.iterrows():
        if row["sig"]:
            i,j = idx[row["G1"]],idx[row["G2"]]
            sig.add((min(i,j),max(i,j)))

    # Greedy: assign letters
    letters = {g:set() for g in grp_names}
    letter_idx = 0
    assigned = [False]*n

    for start in range(n):
        if not assigned[start]:
            # Build group: start + all not sig-different from start
            group = [start]
            for j in range(start+1,n):
                if all((min(i,j),max(i,j)) not in sig for i in group):
                    group.append(j)
            ltr = chr(97+letter_idx)
            for i in group:
                letters[grp_names[i]].add(ltr)
                assigned[i] = True
            letter_idx += 1

    return {g:"".join(sorted(ls)) or "?" for g,ls in letters.items()}


def _hex_rgb(h):
    h=h.lstrip("#")
    return int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
