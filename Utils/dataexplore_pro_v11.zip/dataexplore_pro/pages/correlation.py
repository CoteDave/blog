"""
Matrice de Corrélation v9
  • Pearson/Spearman : précalculés sur 10k pts → INSTANTANÉ
  • Kendall/MI/PPS/PhiK : slider N ajustable (1k–20k)
  • Style corrplot R : cercles rouge↔bleu, labels rouges, taille ∝ |r|
  • Demi-matrice, seuil, reorder par clustering hiérarchique
  • Badge "n=Xk pts" dans le titre
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

FONT         = "Plus Jakarta Sans, sans-serif"
LABEL_COLOR  = "#cc0000"

CSCALE = [          # rouge → blanc → bleu (corrplot R palette)
    [0.00, "#b2182b"],[0.12,"#d6604d"],[0.28,"#f4a582"],
    [0.42,"#fddbc7"],[0.50,"#f7f7f7"],
    [0.58,"#d1e5f0"],[0.72,"#92c5de"],[0.88,"#4393c3"],[1.00,"#2166ac"],
]
CSCALE_POS = [[0.0,"#f7f7f7"],[0.5,"#92c5de"],[1.0,"#2166ac"]]


def layout(dep):
    num  = dep.num_features
    # v10: include target if numeric or binary-encoded
    all_cols = list(num)
    if dep.supervised and dep.target_name not in all_cols:
        # encode target for display
        all_cols = [dep.target_name + " [target]"] + all_cols
    n_default = min(15, len(all_cols))
    return html.Div([
        html.Div("Matrice de Corrélation", className="page-title"),
        html.Div(
            "Pearson/Spearman précalculés (instantanés). "
            "Kendall/MI/PPS : échantillon ajustable.",
            className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Méthode:", className="control-label"),
                      dcc.Dropdown(id="corr-method",
                          options=[
                              {"label":"Pearson ⚡",        "value":"pearson"},
                              {"label":"Spearman ⚡",       "value":"spearman"},
                              {"label":"Kendall",           "value":"kendall"},
                              {"label":"Phi-k (χ²)",        "value":"phik"},
                              {"label":"Mutual Information","value":"mi"},
                              {"label":"Predictive Power",  "value":"pps"},
                          ],
                          value="pearson", clearable=False, style={"width":"220px"})],
                className="control-group"),

            html.Div([html.Div("Seuil |r| ≥:", className="control-label"),
                      dcc.Slider(id="corr-threshold", min=0, max=0.9,
                                 step=0.05, value=0.0,
                                 marks={0:"0",0.3:".30",0.6:".60",0.9:".90"},
                                 tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"220px"}),

            html.Div([html.Div("Variables:", className="control-label"),
                      dcc.Dropdown(id="corr-vars",
                          options=[{"label":c,"value":c} for c in all_cols],
                          value=all_cols[:n_default], multi=True,
                          style={"minWidth":"300px"})],
                className="control-group"),

            html.Div([html.Div("N pts (méthodes lentes):", className="control-label"),
                      dcc.Slider(id="corr-n-sample",
                                 min=1000, max=20000, step=1000, value=5000,
                                 marks={1000:"1k",5000:"5k",10000:"10k",20000:"20k"},
                                 tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"260px"}),

            html.Div([html.Div("Options:", className="control-label"),
                      dcc.Checklist(id="corr-options",
                          options=[{"label":" Demi-matrice","value":"half"},
                                   {"label":" Réordonner","value":"reorder"}],
                          value=[], inline=True,
                          inputStyle={"marginRight":"4px"},
                          labelStyle={"marginRight":"14px","fontSize":"13px"})],
                className="control-group"),
        ], className="controls-row"),

        html.Div([
            html.Div([dcc.Loading(html.Div(id="corr-graph-wrap"),
                                  type="circle", color="#4472c4")],
                     className="chart-card"),
        ]),

        html.Div(id="corr-pairs-table", style={"marginTop":"16px"}),
    ], className="page-card")


def register_callbacks(app, dep):

    _memo: dict = {}

    @app.callback(
        [Output("corr-graph-wrap","children"),
         Output("corr-pairs-table","children")],
        [Input("corr-method","value"),
         Input("corr-vars","value"),
         Input("corr-threshold","value"),
         Input("corr-options","value"),
         Input("corr-n-sample","value")],
    )
    def update(method, vars_sel, threshold, options, n_sample):
        options   = options   or []
        half      = "half"    in options
        reorder   = "reorder" in options
        threshold = float(threshold or 0.0)
        method    = method or "pearson"
        n_sample  = int(n_sample or 5000)

        if not vars_sel or len(vars_sel) < 2:
            return html.Div("Sélectionnez ≥ 2 variables.",
                            style={"color":"#9aa5b4","padding":"24px"}), []

        cols = [c for c in vars_sel if c in dep.num_features][:30]
        if len(cols) < 2:
            return html.Div("Pas assez de variables numériques."), []

        memo_key = (method, tuple(cols), threshold, half, reorder, n_sample)
        if memo_key in _memo:
            fig, pairs, src_info = _memo[memo_key]
            return _wrap(fig, len(cols), src_info), pairs

        try:
            corr, is_signed, src_info = _get_corr(dep, cols, method, n_sample)
        except Exception as ex:
            return html.Div(f"Erreur: {ex}",
                            style={"color":"#e74c3c","padding":"20px"}), []

        if reorder and len(cols) > 2:
            try:
                from scipy.cluster.hierarchy import linkage, leaves_list
                from scipy.spatial.distance  import squareform
                dist  = np.clip(1-np.abs(corr.values), 0, None)
                np.fill_diagonal(dist, 0)
                Z     = linkage(squareform(dist, checks=False), method="ward")
                order = list(leaves_list(Z))
                cols  = [cols[i] for i in order]
                corr  = corr.iloc[order, order]
            except Exception:
                pass

        fig   = _corrplot(corr, cols, method, half, threshold, is_signed, src_info)
        pairs = _pairs_table(corr, cols, method, threshold, is_signed)

        _memo[memo_key] = (fig, pairs, src_info)
        return _wrap(fig, len(cols), src_info), pairs

    def _wrap(fig, n_cols, src_info):
        h = _chart_h(n_cols)
        return html.Div([
            html.Div(src_info,
                     style={"fontSize":"11px","color":"#6b7a8d","padding":"4px 8px",
                            "background":"#f0f4f8","borderRadius":"4px",
                            "display":"inline-block","marginBottom":"8px"}),
            dcc.Graph(figure=fig,
                      config={"displayModeBar":True,
                              "modeBarButtonsToRemove":["pan2d","lasso2d","select2d"]},
                      style={"height":f"{h}px"}),
        ])


# ══════════════════════════════════════════════════════════════════════
#  COMPUTATION
# ══════════════════════════════════════════════════════════════════════

def _enrich_df_with_target(dep, df, cols):
    """Add target column to df if requested as '[target]' suffix. Returns df, actual_cols."""
    tgt_key = dep.target_name + " [target]"
    actual = []
    df2 = df.copy()
    for c in cols:
        if c == tgt_key:
            # Encode target: numeric as-is, categorical → label encoded
            if dep.supervised:
                tgt_vals = dep.display_df[dep.target_name]
                if dep.is_classification:
                    from sklearn.preprocessing import LabelEncoder
                    le = LabelEncoder()
                    df2[tgt_key] = le.fit_transform(tgt_vals.astype(str))
                else:
                    df2[tgt_key] = tgt_vals.values
                actual.append(tgt_key)
        elif c in dep.num_features:
            df2[c] = df[c]
            actual.append(c)
    return df2, actual


def _get_corr(dep, cols, method, n_sample):
    """Non-blocking. Returns (corr_df, is_signed, info_str)."""
    is_signed = method in ("pearson","spearman","kendall")
    tgt_key = dep.target_name + " [target]"
    has_target = tgt_key in cols
    num_only_cols = [c for c in cols if c != tgt_key]

    if method in ("pearson","spearman") and not has_target:
        ck    = "corr_pearson" if method=="pearson" else "corr_spearman"
        cached = dep.cache.get(ck, wait=False)
        n_cached = dep.cache.get("corr_n", wait=False) or "?"
        if cached is not None:
            valid = [c for c in cols if c in cached.index]
            if len(valid) >= 2:
                info = (f"⚡ Précalculé — {method.capitalize()} "
                        f"sur {n_cached:,} pts · instantané")
                return cached.loc[valid,valid], True, info
        c = _corr_np(dep.display_df, cols, method, 5000)
        info = f"⏳ Cache en cours — {method} sur 5 000 pts (fallback)"
        return c, True, info

    # Has target or slow method: compute on enriched df
    df2, actual_cols = _enrich_df_with_target(dep, dep.display_df, cols)
    if len(actual_cols) < 2:
        raise ValueError("Pas assez de colonnes valides")

    if method in ("pearson","spearman") and has_target:
        # Fast numpy on enriched df
        c = _corr_np(df2, actual_cols, method, min(n_sample, 10000))
        n_used = min(n_sample, len(df2))
        info = f"⚡ {method.capitalize()} avec target · {n_used:,} pts"
        return c, True, info

    # Méthodes lentes : subsample ajustable (df2 inclut target si demandé)
    n_use = min(n_sample, len(df2))
    df_s  = _sub(df2, n_use)
    info  = f"⏱ {method.upper()} calculé sur {n_use:,} pts"

    if method == "kendall":
        X   = df_s[actual_cols].fillna(df_s[actual_cols].median())
        mat = X.corr(method="kendall")
        return mat, True, info
    elif method == "phik":
        X = df_s[actual_cols].fillna(df_s[actual_cols].median())
        return _phik(X, actual_cols), False, info
    elif method == "mi":
        X = df_s[actual_cols].fillna(df_s[actual_cols].median())
        return _mi(X, actual_cols), False, info
    elif method == "pps":
        X = df_s[actual_cols].fillna(df_s[actual_cols].median())
        return _pps(X, actual_cols), False, info

    return _corr_np(df2, actual_cols, "pearson", 5000), True, "Pearson (fallback)"


def _sub(df, n):
    return df.sample(n=min(n,len(df)), random_state=42) if len(df)>n else df

def _corr_np(df, cols, method, max_rows):
    df2 = _sub(df, max_rows)
    X   = df2[cols].fillna(df2[cols].median()).values.astype(np.float64)
    if method == "spearman":
        from scipy.stats import rankdata
        X = np.apply_along_axis(rankdata, 0, X).astype(np.float64)
    Xc  = X-X.mean(axis=0)
    nrm = np.linalg.norm(Xc, axis=0)
    nrm = np.where(nrm==0, 1e-9, nrm)
    mat = (Xc/nrm).T @ (Xc/nrm)
    np.fill_diagonal(mat, 1.0)
    return pd.DataFrame(mat.clip(-1,1), index=cols, columns=cols)

def _phik(X, cols):
    from itertools import combinations
    from scipy.stats import chi2_contingency
    n=len(cols); mat=np.ones((n,n))
    for i,j in combinations(range(n),2):
        try:
            xi,xj=X[cols[i]].values,X[cols[j]].values
            h,_=np.histogram2d(xi,xj,bins=8)
            chi2,_,_,_=chi2_contingency(h+1e-6)
            v=float(np.sqrt(chi2/max(len(xi)*7,1e-9)))
            mat[i,j]=mat[j,i]=min(v,1.0)
        except: mat[i,j]=mat[j,i]=0.0
    return pd.DataFrame(mat,index=cols,columns=cols)

def _mi(X, cols):
    from itertools import combinations
    from sklearn.feature_selection import mutual_info_regression
    n=len(cols); mat=np.ones((n,n)); Xv=X.values
    for i,j in combinations(range(n),2):
        try:
            mi=mutual_info_regression(Xv[:,[i]],Xv[:,j],random_state=0)[0]
            hi=mutual_info_regression(Xv[:,[i]],Xv[:,i],random_state=0)[0]
            hj=mutual_info_regression(Xv[:,[j]],Xv[:,j],random_state=0)[0]
            mat[i,j]=mat[j,i]=float(np.clip(mi/np.sqrt(max(hi*hj,1e-9)),0,1))
        except: mat[i,j]=mat[j,i]=0.0
    return pd.DataFrame(mat,index=cols,columns=cols)

def _pps(X, cols):
    from itertools import combinations
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.model_selection import cross_val_score
    n=len(cols); mat=np.zeros((n,n)); np.fill_diagonal(mat,1); Xv=X.values
    for i,j in combinations(range(n),2):
        try:
            dt=DecisionTreeRegressor(max_depth=4,min_samples_leaf=10,random_state=0)
            r2=cross_val_score(dt,Xv[:,[i]],Xv[:,j],cv=3,scoring="r2").mean()
            mat[i,j]=mat[j,i]=float(np.clip(r2,0,1))
        except: pass
    return pd.DataFrame(mat,index=cols,columns=cols)


# ══════════════════════════════════════════════════════════════════════
#  CORRPLOT FIGURE
# ══════════════════════════════════════════════════════════════════════

def _chart_h(n): return max(520, n*44+180)

def _corrplot(corr, cols, method, half, threshold, is_signed, src_info):
    n     = len(cols)
    mat   = corr.values.astype(float)
    h_px  = _chart_h(n)
    cell  = max((h_px-200)/max(n,1), 20)
    max_r = cell*0.90
    min_r = max(3.0, cell*0.07)

    xs,ys,sizes,vals,hovers = [],[],[],[],[]
    for i in range(n):
        for j in range(n):
            if half and j>i: continue
            v    = mat[i,j]
            absv = abs(v) if is_signed else float(np.clip(v,0,1))
            if i!=j and absv<threshold: continue
            sz   = max_r if i==j else min_r+absv*(max_r-min_r)
            xs.append(j); ys.append(n-1-i)
            sizes.append(sz); vals.append(float(v))
            lj = cols[j][:16]+"…" if len(cols[j])>16 else cols[j]
            li = cols[i][:16]+"…" if len(cols[i])>16 else cols[i]
            hovers.append(f"<b>{lj}</b> × <b>{li}</b><br>"
                          f"{method} = <b>{v:+.4f}</b>")

    cs   = CSCALE if is_signed else CSCALE_POS
    cmin = -1.0   if is_signed else 0.0

    fig = go.Figure()

    # Grid
    for i in range(n+1):
        for xy in ["h","v"]:
            if xy=="h":
                fig.add_shape(type="line",x0=-0.5,x1=n-0.5,y0=i-0.5,y1=i-0.5,
                              line=dict(color="#e4e8ee",width=0.7))
            else:
                fig.add_shape(type="line",x0=i-0.5,x1=i-0.5,y0=-0.5,y1=n-0.5,
                              line=dict(color="#e4e8ee",width=0.7))

    # Circles
    fig.add_trace(go.Scatter(
        x=xs, y=ys, mode="markers",
        marker=dict(
            symbol="circle", size=sizes, sizemode="diameter",
            color=vals, colorscale=cs, cmin=cmin, cmax=1.0,
            showscale=True,
            colorbar=dict(
                thickness=18, len=0.78,
                title=dict(text=method,font=dict(size=12,family=FONT)),
                tickvals=[-1,-0.5,0,0.5,1] if is_signed else [0,0.5,1],
                ticktext=(["-1","-0.5","0","+0.5","+1"] if is_signed
                          else ["0","0.5","1"]),
                tickfont=dict(size=11,family=FONT), x=1.01,
            ),
            line=dict(color="rgba(255,255,255,0.25)", width=0.4),
        ),
        text=hovers,
        hovertemplate="%{text}<extra></extra>",
        hoverlabel=dict(bgcolor="#1e3a5f",font_size=12,font_color="white",
                        bordercolor="#1e3a5f"),
        showlegend=False,
    ))

    # Value labels inside circles
    for i in range(n):
        for j in range(n):
            if half and j>i: continue
            v    = mat[i,j]
            absv = abs(v) if is_signed else float(np.clip(v,0,1))
            if i==j: continue
            if absv < max(threshold,0.25): continue
            txt_clr = "white" if absv>0.55 else "#1e3a5f"
            fig.add_annotation(x=j, y=n-1-i,
                text=f"{v:+.2f}" if is_signed else f"{v:.2f}",
                showarrow=False,
                font=dict(size=max(6,int(cell*0.20)),color=txt_clr,family=FONT))

    # Diagonal names
    for i, col in enumerate(cols):
        lbl = col if len(col)<=13 else col[:12]+"…"
        fig.add_annotation(x=i, y=n-1-i, text=f"<b>{lbl}</b>",
            showarrow=False,
            font=dict(size=max(7,int(cell*0.22)),color="#1e3a5f",family=FONT))

    xlabels = [c if len(c)<=14 else c[:13]+"…" for c in cols]
    ylabels = [c if len(c)<=14 else c[:13]+"…" for c in reversed(cols)]

    fig.update_layout(
        title=dict(
            text=f"Matrice de corrélation — {method.capitalize()}",
            font=dict(size=14,color="#1e3a5f",family=FONT)),
        plot_bgcolor="#ffffff", paper_bgcolor="#ffffff",
        xaxis=dict(tickvals=list(range(n)), ticktext=xlabels,
                   tickangle=-45,
                   tickfont=dict(size=max(9,int(cell*0.22)),
                                 color=LABEL_COLOR,family=FONT),
                   side="bottom", showgrid=False, zeroline=False,
                   range=[-0.5,n-0.5], scaleanchor="y", scaleratio=1,
                   fixedrange=True),
        yaxis=dict(tickvals=list(range(n)), ticktext=ylabels,
                   tickfont=dict(size=max(9,int(cell*0.22)),
                                 color=LABEL_COLOR,family=FONT),
                   showgrid=False, zeroline=False,
                   range=[-0.5,n-0.5], fixedrange=True),
        margin=dict(l=130,r=100,t=70,b=130),
        height=h_px, showlegend=False, dragmode=False,
        font=dict(family=FONT,size=10),
    )
    return fig


def _pairs_table(corr, cols, method, threshold, is_signed):
    mat = corr.values.astype(float)
    n   = len(cols)
    pairs = []
    for i in range(n):
        for j in range(i+1,n):
            v  = mat[i,j]
            av = abs(v) if is_signed else float(np.clip(v,0,1))
            if av >= threshold:
                pairs.append((cols[i],cols[j],v,av))
    if not pairs: return html.Div()
    pairs.sort(key=lambda x:x[3], reverse=True)
    top = pairs[:25]

    def _th(t):
        return html.Th(t,style={"padding":"5px 10px","background":"#f0f4f8",
            "color":"#6b7a8d","fontWeight":"700","fontSize":"10px",
            "textTransform":"uppercase","letterSpacing":".4px",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap"})
    def _td(t,clr=None,bold=False):
        s={"padding":"5px 10px","fontSize":"11.5px","color":clr or "#374151",
           "whiteSpace":"nowrap"}
        if bold: s["fontWeight"]="700"
        return html.Td(t,style=s)

    rows=[]
    for a,b,v,av in top:
        clr = ("#2166ac" if v>0.3 else ("#b2182b" if v<-0.3 else None)) if is_signed else (
              "#2166ac" if av>0.5 else None)
        strength = ("Très forte" if av>0.7 else "Forte" if av>0.5
                    else "Modérée" if av>0.3 else "Faible")
        rows.append(html.Tr([
            _td(a),_td(b),
            _td(f"{v:+.4f}" if is_signed else f"{v:.4f}",clr,True),
            _td(f"{av:.4f}"),
            _td(strength, "#27ae60" if av>0.5 else "#f39c12" if av>0.3 else "#9aa5b4"),
        ],style={"borderBottom":"1px solid #f5f5f5"}))

    return html.Div([
        html.Div(f"Top {len(top)} paires — |r| ≥ {threshold:.2f}",
                 className="chart-card-title"),
        html.Div(html.Table([
            html.Thead(html.Tr([_th("Variable A"),_th("Variable B"),
                                _th(method),_th("|r|"),_th("Force")])),
            html.Tbody(rows),
        ],style={"width":"100%","borderCollapse":"collapse",
                 "fontFamily":FONT,"fontSize":"11.5px"}),
        style={"overflowX":"auto"}),
    ],className="chart-card",style={"marginTop":"16px"})
