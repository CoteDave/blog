"""
Analyse Univariée v8
  • Histogramme + KDE, Box+Violin, QQ-plot, ECDF, Fit, Transformations
  • Panel stats complet et robuste
  • Memoïsation par (col, chart_type, group, n_bins)
  • display_df partout — O(1) sur 2e visite
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
FONT = "Plus Jakarta Sans, sans-serif"
BG   = "#f7f8fa"
GRID = "#e0e4ea"


def layout(dep):
    num     = dep.num_features
    default = num[0] if num else None
    return html.Div([
        html.Div("Analyse Univariée", className="page-title"),
        html.Div("Histogramme · Box/Violin · QQ-plot · ECDF · Ajustement · Transformations",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Variable:", className="control-label"),
                      dcc.Dropdown(id="uni-col",
                                   options=[{"label":c,"value":c} for c in num],
                                   value=default, clearable=False,
                                   style={"minWidth":"220px"})],
                     className="control-group"),
            html.Div([html.Div("Graphique:", className="control-label"),
                      dcc.Dropdown(id="uni-type",
                                   options=[
                                       {"label":"Histogramme + KDE","value":"hist"},
                                       {"label":"Box + Violin",     "value":"boxviolin"},
                                       {"label":"QQ-plot",          "value":"qq"},
                                       {"label":"ECDF",             "value":"ecdf"},
                                       {"label":"Ajustement distrib.","value":"fit"},
                                       {"label":"Transformations",  "value":"transform"},
                                   ],
                                   value="hist", clearable=False,
                                   style={"minWidth":"230px"})],
                     className="control-group"),
            html.Div([html.Div("Par groupe (target):", className="control-label"),
                      dcc.Dropdown(id="uni-group",
                                   options=[{"label":"Non","value":"no"},
                                            {"label":"Oui","value":"yes"}],
                                   value="no" if not dep.supervised else "yes",
                                   clearable=False, style={"width":"120px"})],
                     className="control-group"),
            html.Div([html.Div("Bins:", className="control-label"),
                      dcc.Slider(id="uni-bins", min=5, max=80, step=5, value=25,
                                 marks={5:"5",20:"20",40:"40",60:"60",80:"80"},
                                 tooltip={"placement":"bottom","always_visible":False})],
                     className="control-group", style={"minWidth":"220px"}),
        ], className="controls-row"),

        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="uni-main",
                                            config={"displayModeBar":False},
                                            style={"height":"380px"}),
                                  type="circle",color="#4472c4")],
                     className="chart-card", style={"flex":"1.5","minWidth":"0"}),

            html.Div([dcc.Loading(dcc.Graph(id="uni-secondary",
                                            config={"displayModeBar":False},
                                            style={"height":"380px"}),
                                  type="circle",color="#4472c4")],
                     className="chart-card", style={"flex":"1","minWidth":"0"}),
        ], className="charts-grid"),

        html.Div([
            html.Div(id="uni-stats-panel", className="chart-card",
                     style={"marginTop":"16px","minHeight":"80px"}),
        ]),
    ], className="page-card")


def register_callbacks(app, dep):

    _uni_memo: dict = {}

    @app.callback(
        [Output("uni-main","figure"),
         Output("uni-secondary","figure"),
         Output("uni-stats-panel","children")],
        [Input("uni-col","value"),
         Input("uni-type","value"),
         Input("uni-group","value"),
         Input("uni-bins","value")],
    )
    def update(col, chart_type, group, n_bins):
        e = go.Figure()
        empty_stats = html.Div("Sélectionnez une variable.",
                               style={"color":"#9aa5b4","padding":"16px","fontSize":"12px"})
        if col is None:
            return e, e, empty_stats

        n_bins   = n_bins or 25
        chart_type = chart_type or "hist"
        memo_key = (col, chart_type, group, n_bins)
        if memo_key in _uni_memo:
            return _uni_memo[memo_key]

        df       = dep.display_df
        s_all    = df[col].dropna()
        by_group = dep.supervised and group == "yes"

        if len(s_all) == 0:
            msg = html.Div(f"Aucune valeur valide pour '{col}'.",
                           style={"color":"#e74c3c","padding":"16px","fontSize":"12px"})
            return e, e, msg

        # ── Main chart ─────────────────────────────────────────────────────
        if   chart_type == "hist":      fig_main = _hist_kde(dep, col, s_all, by_group, n_bins)
        elif chart_type == "boxviolin": fig_main = _box_violin(dep, col, s_all, by_group)
        elif chart_type == "qq":        fig_main = _qqplot(col, s_all)
        elif chart_type == "ecdf":      fig_main = _ecdf_chart(dep, col, s_all, by_group)
        elif chart_type == "fit":       fig_main = _dist_fit(col, s_all)
        elif chart_type == "transform": fig_main = _transform_chart(col, s_all)
        else:                           fig_main = _hist_kde(dep, col, s_all, by_group, n_bins)

        # ── Secondary chart ─────────────────────────────────────────────────
        if   chart_type == "hist":      fig_sec = _ecdf_chart(dep, col, s_all, by_group)
        elif chart_type in("ecdf","qq"):fig_sec = _box_violin(dep, col, s_all, by_group)
        elif chart_type == "boxviolin": fig_sec = _hist_kde(dep, col, s_all, by_group, n_bins)
        else:                           fig_sec = _qqplot(col, s_all)

        # ── Stats panel ─────────────────────────────────────────────────────
        stats_panel = _stats_panel(dep, col, s_all, by_group)

        result = fig_main, fig_sec, stats_panel
        _uni_memo[memo_key] = result
        return result


# ══════════════════════════════════════════════════════════════════════════════
#  STATS PANEL — robuste, jamais de "nan"
# ══════════════════════════════════════════════════════════════════════════════

def _fmt(v, fmt=".4g"):
    """Format number; never output 'nan' or 'inf'."""
    try:
        if v is None or (isinstance(v, float) and (np.isnan(v) or np.isinf(v))):
            return "—"
        return format(float(v), fmt)
    except Exception:
        return "—"


def _stats_panel(dep, col, s_all, by_group):
    v  = s_all.astype(np.float64).values
    n  = len(v)

    if n == 0:
        return html.Div("Aucune donnée valide.", style={"color":"#e74c3c","padding":"12px"})

    # Core stats — all wrapped individually
    q1 = q3 = med = iqr = float("nan")
    try: q1, med, q3 = np.percentile(v, [25, 50, 75]); iqr = q3 - q1
    except Exception: pass

    mean_v = std_v = float("nan")
    try: mean_v = float(np.mean(v)); std_v = float(np.std(v, ddof=1))
    except Exception: pass

    mode_v = float("nan")
    try:
        mode_res = pd.Series(v).mode()
        if len(mode_res) > 0:
            mode_v = float(mode_res.iloc[0])
    except Exception: pass

    skw = krt = float("nan")
    try: skw = float(sp_stats.skew(v))
    except Exception: pass
    try: krt = float(sp_stats.kurtosis(v))
    except Exception: pass

    rows = [
        ("N valides",            f"{n:,}"),
        ("Moyenne ± Std",        f"{_fmt(mean_v)} ± {_fmt(std_v)}"),
        ("Médiane / Mode",       f"{_fmt(med)} / {_fmt(mode_v)}"),
        ("Q1 — Q3",              f"{_fmt(q1)} — {_fmt(q3)}"),
        ("IQR",                  _fmt(iqr)),
        ("Min — Max",            f"{_fmt(float(v.min()))} — {_fmt(float(v.max()))}"),
        ("Asymétrie (skewness)", f"{_fmt(skw, '+.4f')}"),
        ("Kurtosis (excès)",     f"{_fmt(krt, '+.4f')}"),
    ]

    # Normality tests
    if n >= 8:
        try:
            _, p_dag = sp_stats.normaltest(v)
            rows.append(("Test D'Agostino",
                         f"p={_fmt(p_dag,'.4f')}  {'✅ Normale' if p_dag>0.05 else '❌ Non-normale'}"))
        except Exception: pass
    if 3 < n <= 5000:
        try:
            _, p_sw = sp_stats.shapiro(v)
            rows.append(("Test Shapiro-Wilk",
                         f"p={_fmt(p_sw,'.4f')}  {'✅ Normale' if p_sw>0.05 else '❌ Non-normale'}"))
        except Exception: pass

    # Outliers
    try:
        if not np.isnan(q1):
            n_iqr = int(np.sum((v < q1-1.5*iqr) | (v > q3+1.5*iqr)))
            rows.append(("Outliers IQR×1.5", f"{n_iqr:,} ({n_iqr/n:.1%})"))
    except Exception: pass
    try:
        if not np.isnan(std_v) and std_v > 0:
            n_z = int(np.sum(np.abs((v - mean_v)/std_v) > 3))
            rows.append(("Outliers |Z|>3", f"{n_z:,} ({n_z/n:.1%})"))
    except Exception: pass

    # NaN rate
    try:
        pnan = dep.display_df[col].isnull().mean()
        rows.append(("% NaN", f"{pnan:.1%}"))
    except Exception: pass

    # Inter-group tests
    group_rows = []
    if by_group and dep.supervised and dep.is_classification and len(dep.classes) >= 2:
        try:
            groups = {}
            for cls in dep.classes:
                g = dep.display_df[dep.display_df[dep.target_name]==cls][col].dropna()
                if len(g) >= 3:
                    groups[cls] = g.astype(np.float64).values

            if len(groups) >= 2:
                gvals = list(groups.values())
                try:
                    _, p_lev = sp_stats.levene(*gvals)
                    group_rows.append(("Levene (variances)",
                                       f"p={_fmt(p_lev,'.4f')}  {'✅ Homogènes' if p_lev>0.05 else '❌ Hétérogènes'}"))
                except Exception: pass
                try:
                    f_stat, p_anov = sp_stats.f_oneway(*gvals)
                    group_rows.append(("ANOVA F",
                                       f"F={_fmt(f_stat,'.3f')}  p={_fmt(p_anov,'.4f')}  {'✅ Sig.' if p_anov<0.05 else '❌'}"))
                except Exception: pass
                try:
                    h_stat, p_kw = sp_stats.kruskal(*gvals)
                    group_rows.append(("Kruskal-Wallis H",
                                       f"H={_fmt(h_stat,'.3f')}  p={_fmt(p_kw,'.4f')}  {'✅ Sig.' if p_kw<0.05 else '❌'}"))
                except Exception: pass
                for cls, gv in groups.items():
                    group_rows.append((f"  Cls {cls} — Moy±Std",
                                       f"{_fmt(gv.mean())} ± {_fmt(gv.std(ddof=1))}  (n={len(gv):,})"))
        except Exception: pass

    def _row(label, val):
        return html.Tr([
            html.Td(label, style={"padding":"5px 8px","color":"#6b7a8d","fontWeight":"600",
                                   "fontSize":"11px","whiteSpace":"nowrap","width":"52%"}),
            html.Td(str(val), style={"padding":"5px 8px","color":"#1e3a5f",
                                      "fontSize":"11px","fontWeight":"500"}),
        ], style={"borderBottom":"1px solid #f5f5f5"})

    children = [
        html.Div("Statistiques descriptives", className="chart-card-title"),
        html.Div(
            html.Table(html.Tbody([_row(l,v) for l,v in rows]),
                       style={"width":"100%","borderCollapse":"collapse",
                              "fontFamily":FONT,"fontSize":"11px"}),
            style={"background":"#f7f8fa","borderRadius":"8px",
                   "overflow":"hidden","marginBottom":"10px"}),
    ]
    if group_rows:
        children += [
            html.Div("Tests inter-groupes (target)", className="chart-card-title"),
            html.Div(
                html.Table(html.Tbody([_row(l,v) for l,v in group_rows]),
                           style={"width":"100%","borderCollapse":"collapse",
                                  "fontFamily":FONT,"fontSize":"11px"}),
                style={"background":"#f0f4ff","borderRadius":"8px","overflow":"hidden"}),
        ]
    return html.Div(children)


# ══════════════════════════════════════════════════════════════════════════════
#  CHART BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _kde(vals, n=200):
    if len(vals) < 3: return np.array([]), np.array([])
    if len(vals) > 10_000:
        rng  = np.random.default_rng(42)
        vals = rng.choice(vals, 10_000, replace=False)
    try:
        kde = sp_stats.gaussian_kde(vals.astype(np.float64), bw_method="scott")
        pad = (vals.max()-vals.min())*0.1 + 1e-9
        xg  = np.linspace(vals.min()-pad, vals.max()+pad, n)
        return xg, kde(xg)
    except Exception: return np.array([]), np.array([])


def _hist_kde(dep, col, s_all, by_group, n_bins):
    v = s_all.astype(np.float64).values
    fig = go.Figure()
    if by_group and dep.supervised and dep.is_classification:
        for i, cls in enumerate(dep.classes):
            vc = dep.display_df[dep.display_df[dep.target_name]==cls][col].dropna()
            vc = vc.astype(np.float64).values
            clr = PAL[i%len(PAL)]
            if len(vc)==0: continue
            fig.add_trace(go.Histogram(
                x=vc, nbinsx=n_bins, name=f"Cls {cls}",
                marker_color=clr, opacity=0.65,
                hovertemplate=f"Cls {cls}<br>%{{x}}: %{{y}}<extra></extra>"))
            xk, yk = _kde(vc)
            if len(xk):
                scale = len(vc)*(v.max()-v.min())/n_bins if v.max()>v.min() else 1
                fig.add_trace(go.Scatter(x=xk, y=yk*scale, mode="lines",
                    line=dict(color=clr,width=2.5), name=f"KDE {cls}",
                    hovertemplate=f"KDE Cls {cls}<br>%{{x:.3g}}: %{{y:.4g}}<extra></extra>"))
        fig.update_layout(barmode="overlay")
    else:
        clr = PAL[0]
        fig.add_trace(go.Histogram(x=v, nbinsx=n_bins, marker_color=clr,
                                   opacity=0.72, name=col,
                                   hovertemplate="%{x}: %{y}<extra></extra>"))
        xk, yk = _kde(v)
        if len(xk):
            scale = len(v)*(v.max()-v.min())/n_bins if v.max()>v.min() else 1
            fig.add_trace(go.Scatter(x=xk, y=yk*scale, mode="lines",
                line=dict(color="#e07b39",width=2.5), name="KDE"))
        # IQR shading
        try:
            q1,q3 = np.percentile(v,[25,75])
            fig.add_vrect(x0=q1,x1=q3,fillcolor="rgba(68,114,196,0.10)",
                          line_width=0,annotation_text="IQR",annotation_position="top left",
                          annotation_font_size=9)
        except Exception: pass
        # Mean line
        try:
            fig.add_vline(x=float(v.mean()),line_dash="dash",line_color="#e74c3c",
                          line_width=1.5,annotation_text=f"μ={v.mean():.3g}",
                          annotation_font_size=9)
        except Exception: pass
    fig.update_layout(**_base(f"Histogramme + KDE — {col}"),
                      xaxis_title=col, yaxis_title="Fréquence")
    return fig


def _box_violin(dep, col, s_all, by_group):
    v = s_all.astype(np.float64).values
    fig = go.Figure()
    if by_group and dep.supervised and dep.is_classification:
        for i, cls in enumerate(dep.classes):
            vc = dep.display_df[dep.display_df[dep.target_name]==cls][col].dropna()
            vc = vc.astype(np.float64).values
            if len(vc)==0: continue
            clr = PAL[i%len(PAL)]
            fig.add_trace(go.Violin(y=vc, name=f"Cls {cls}", box_visible=True,
                meanline_visible=True, line_color=clr, fillcolor=clr,
                opacity=0.7, points="outliers",
                hovertemplate=f"Cls {cls}<br>%{{y:.4g}}<extra></extra>"))
    else:
        fig.add_trace(go.Violin(y=v, box_visible=True, meanline_visible=True,
            line_color=PAL[0], fillcolor=PAL[0], opacity=0.7,
            points="outliers", name=col,
            hovertemplate="%{y:.4g}<extra></extra>"))
    fig.update_layout(**_base(f"Box + Violin — {col}"),
                      yaxis_title=col, xaxis=dict(visible=False))
    return fig


def _qqplot(col, s_all):
    v = s_all.astype(np.float64).values
    fig = go.Figure()
    if len(v) < 3: return fig
    try:
        n_sub = min(len(v), 5_000)
        if len(v) > n_sub:
            rng = np.random.default_rng(42)
            v   = rng.choice(v, n_sub, replace=False)
        qq     = sp_stats.probplot(v, dist="norm")
        th_x   = np.array([qq[0][0].min(), qq[0][0].max()])
        th_y   = qq[1][1] + qq[1][0]*th_x
        fig.add_trace(go.Scatter(x=qq[0][0], y=qq[0][1], mode="markers",
            marker=dict(color=PAL[0],size=4,opacity=0.7),
            name="Quantiles obs.", hovertemplate="Théorique:%{x:.3g}<br>Obs:%{y:.3g}<extra></extra>"))
        fig.add_trace(go.Scatter(x=th_x, y=th_y, mode="lines",
            line=dict(color="#e74c3c",width=2,dash="dash"), name="Normale théorique"))
        # 95% confidence band
        n  = len(v)
        ci = 1.96*np.sqrt((qq[0][0]/n)*(1-qq[0][0]/n)/sp_stats.norm.pdf(qq[0][0]))
        fig.add_trace(go.Scatter(x=np.concatenate([qq[0][0],qq[0][0][::-1]]),
            y=np.concatenate([th_y+ci,(th_y-ci)[::-1]]),
            fill="toself",fillcolor="rgba(68,114,196,0.12)",
            line=dict(width=0), name="IC 95%", hoverinfo="skip"))
    except Exception: pass
    fig.update_layout(**_base(f"QQ-Plot — {col}"),
                      xaxis_title="Quantiles théoriques",yaxis_title="Quantiles observés")
    return fig


def _ecdf_chart(dep, col, s_all, by_group):
    v = s_all.astype(np.float64).values
    fig = go.Figure()
    def _ecdf_trace(vals, name, color):
        sv = np.sort(vals)
        ec = np.arange(1,len(sv)+1)/len(sv)
        return go.Scatter(x=sv, y=ec, mode="lines", name=name,
            line=dict(color=color,width=2),
            hovertemplate=f"{name}<br>%{{x:.4g}}: %{{y:.3f}}<extra></extra>")
    if by_group and dep.supervised and dep.is_classification:
        for i,cls in enumerate(dep.classes):
            vc = dep.display_df[dep.display_df[dep.target_name]==cls][col].dropna()
            if len(vc)==0: continue
            fig.add_trace(_ecdf_trace(vc.astype(np.float64).values, f"Cls {cls}", PAL[i%len(PAL)]))
        # KS test for 2-class
        if dep.n_classes==2:
            try:
                g1 = dep.display_df[dep.display_df[dep.target_name]==dep.classes[0]][col].dropna().values
                g2 = dep.display_df[dep.display_df[dep.target_name]==dep.classes[1]][col].dropna().values
                ks,p = sp_stats.ks_2samp(g1.astype(float), g2.astype(float))
                fig.add_annotation(x=0.02, y=0.98, xref="paper", yref="paper",
                    text=f"KS={ks:.3f}  p={p:.4f}  {'✅' if p<0.05 else '❌'}",
                    showarrow=False, font=dict(size=10,color="#1e3a5f"),
                    bgcolor="rgba(255,255,255,0.85)", bordercolor="#dde2ea",
                    borderwidth=1)
            except Exception: pass
    else:
        fig.add_trace(_ecdf_trace(v, col, PAL[0]))
    fig.update_layout(**_base(f"ECDF — {col}"),
                      xaxis_title=col, yaxis_title="F(x)")
    return fig


def _dist_fit(col, s_all):
    v = s_all.astype(np.float64).values
    fig = go.Figure()
    if len(v) < 5: return fig
    # Histogram
    fig.add_trace(go.Histogram(x=v, nbinsx=30, histnorm="probability density",
        marker_color="rgba(68,114,196,0.5)", name="Données"))
    xg = np.linspace(v.min(), v.max(), 200)
    fits = [
        ("Normale",    sp_stats.norm),
        ("Log-Normale",sp_stats.lognorm),
        ("Gamma",      sp_stats.gamma),
        ("Weibull",    sp_stats.weibull_min),
        ("Beta",       sp_stats.beta),
    ]
    for i,(name,dist) in enumerate(fits):
        try:
            params = dist.fit(v)
            ypdf   = dist.pdf(xg, *params)
            fig.add_trace(go.Scatter(x=xg,y=ypdf,mode="lines",name=name,
                line=dict(color=PAL[(i+1)%len(PAL)],width=2),
                hovertemplate=f"{name}<br>%{{x:.4g}}: %{{y:.4g}}<extra></extra>"))
        except Exception: pass
    fig.update_layout(**_base(f"Ajustement distributions — {col}"),
                      xaxis_title=col, yaxis_title="Densité")
    return fig


def _transform_chart(col, s_all):
    v = s_all.astype(np.float64).values
    v = v[v > 0] if len(v[v>0]) > 5 else v
    from plotly.subplots import make_subplots
    transforms = [("Original",v),("Log(x)",np.log1p(v-v.min()+1e-6)),
                  ("√x",np.sqrt(np.abs(v)))]
    try:
        from scipy.stats import boxcox
        bc,_ = boxcox(v-v.min()+1e-3)
        transforms.append(("Box-Cox",bc))
    except Exception: pass
    try:
        from sklearn.preprocessing import PowerTransformer
        yj = PowerTransformer("yeo-johnson").fit_transform(v.reshape(-1,1)).ravel()
        transforms.append(("Yeo-Johnson",yj))
    except Exception: pass
    cols  = min(3,len(transforms))
    rows  = (len(transforms)+cols-1)//cols
    fig   = make_subplots(rows=rows, cols=cols,
                          subplot_titles=[n for n,_ in transforms])
    for idx,(name,t) in enumerate(transforms):
        r,c = idx//cols+1, idx%cols+1
        fig.add_trace(go.Histogram(x=t,nbinsx=25,marker_color=PAL[idx%len(PAL)],
                                   opacity=0.8,name=name,showlegend=False,
                                   hovertemplate=f"{name}: %{{x:.4g}}<extra></extra>"),
                      row=r,col=c)
        xk,yk = _kde(t)
        if len(xk):
            scale = len(t)*(t.max()-t.min())/25 if t.max()>t.min() else 1
            fig.add_trace(go.Scatter(x=xk,y=yk*scale,mode="lines",
                line=dict(color="#e74c3c",width=1.5),showlegend=False,
                hovertemplate=f"KDE: %{{y:.4g}}<extra></extra>"),row=r,col=c)
    fig.update_layout(title_text=f"Transformations — {col}",
                      title_font=dict(size=12,color="#1e3a5f"),
                      plot_bgcolor=BG,paper_bgcolor="#fff",
                      font=dict(family=FONT,size=10),
                      height=260*rows,margin=dict(l=40,r=20,t=60,b=40))
    return fig


def _base(title=""):
    return dict(
        title=dict(text=title,font=dict(size=12,color="#1e3a5f")),
        plot_bgcolor=BG,paper_bgcolor="#fff",
        margin=dict(l=50,r=20,t=44,b=50),
        font=dict(family=FONT,size=11),
        xaxis=dict(gridcolor=GRID,zeroline=False),
        yaxis=dict(gridcolor=GRID,zeroline=False),
        legend=dict(font=dict(size=10),bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1,bordercolor=GRID),
    )
