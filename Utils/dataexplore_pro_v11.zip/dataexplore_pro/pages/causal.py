"""
Réseau de Corrélations Partielles v11 — "Découverte Causale"
══════════════════════════════════════════════════════════════
Visualisation d'un graphe de corrélations partielles :
  • Corrélations partielles via inverse de la matrice de corrélation (précision)
  • Seuil ajustable → filtrer les arêtes faibles
  • Layout : spring / circular / kamada-kawai (pur numpy/scipy)
  • Nœuds colorés par classe de centralité (degré, betweenness approx)
  • Arêtes bleues (positif) / rouges (négatif), épaisseur ∝ |r_partial|
  • Panneau de détails au clic sur un nœud : corrélations directes top-5
  • Table des arêtes classées par |corrélation partielle|
  • Optionnel : directions inférées via régression (parent → enfant)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
FONT = "Plus Jakarta Sans, sans-serif"
GRID = "#e0e4ea"; BG = "#f7f8fa"


def layout(dep):
    num = dep.num_features
    n_def = min(15, len(num))
    return html.Div([
        html.Div("Réseau de Corrélations Partielles", className="page-title"),
        html.Div(
            "Graphe des dépendances conditionnelles entre variables. "
            "Chaque arête représente une corrélation partielle (contrôlant toutes les autres).",
            className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Variables:", className="control-label"),
                      dcc.Dropdown(id="cau-vars",
                          options=[{"label":c,"value":c} for c in num],
                          value=num[:n_def], multi=True,
                          style={"minWidth":"300px"})],
                className="control-group"),

            html.Div([html.Div("Seuil |r_partiel| ≥:", className="control-label"),
                      dcc.Slider(id="cau-thresh", min=0.0, max=0.7, step=0.05, value=0.15,
                          marks={0:"0",0.15:"0.15",0.3:"0.3",0.5:"0.5",0.7:"0.7"},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"240px"}),

            html.Div([html.Div("Layout:", className="control-label"),
                      dcc.Dropdown(id="cau-layout",
                          options=[{"label":"Spring (Fruchterman)","value":"spring"},
                                   {"label":"Circulaire","value":"circular"},
                                   {"label":"Kamada-Kawai","value":"kk"},
                                   {"label":"Aléatoire","value":"random"}],
                          value="spring", clearable=False, style={"width":"220px"})],
                className="control-group"),

            html.Div([html.Div("Options:", className="control-label"),
                      dcc.Checklist(id="cau-options",
                          options=[{"label":" Montrer directions","value":"arrows"},
                                   {"label":" Taille ∝ centralité","value":"centrality"},
                                   {"label":" Étiquettes","value":"labels"}],
                          value=["labels","centrality"], inline=True,
                          inputStyle={"marginRight":"4px"},
                          labelStyle={"marginRight":"12px","fontSize":"13px"})],
                className="control-group"),
        ], className="controls-row"),

        # Metric cards
        html.Div(id="cau-cards", style={"marginBottom":"14px"}),

        # Graph + node detail panel
        html.Div([
            html.Div([
                dcc.Loading(dcc.Graph(id="cau-graph",
                    config={"displayModeBar":True,"scrollZoom":True},
                    style={"height":"540px"}), type="circle", color="#4472c4"),
                html.Div("Cliquer un nœud pour voir ses connexions directes →",
                    style={"fontSize":"10.5px","color":"#9aa5b4","textAlign":"center",
                           "marginTop":"4px","fontStyle":"italic"}),
            ], className="chart-card", style={"flex":"1.6","minWidth":"0"}),

            html.Div(id="cau-detail-panel", className="chart-card",
                style={"flex":"1","minWidth":"260px","maxWidth":"380px",
                       "overflowY":"auto","maxHeight":"580px"}),
        ], style={"display":"flex","gap":"16px","marginBottom":"16px",
                  "alignItems":"flex-start"}),

        # Edge table
        html.Div([
            html.Div("📋 Table des arêtes — corrélations partielles significatives",
                     className="chart-card-title"),
            html.Div(id="cau-edge-table"),
        ], className="chart-card"),

    ], className="page-card")


def register_callbacks(app, dep):

    _memo: dict = {}

    @app.callback(
        [Output("cau-cards","children"),
         Output("cau-graph","figure"),
         Output("cau-edge-table","children")],
        [Input("cau-vars","value"),
         Input("cau-thresh","value"),
         Input("cau-layout","value"),
         Input("cau-options","value")],
    )
    def update(vars_sel, thresh, layout_mode, options):
        options  = options or []
        thresh   = float(thresh or 0.15)
        layout_m = layout_mode or "spring"

        empty = go.Figure()
        if not vars_sel or len(vars_sel) < 3:
            return (_err("Sélectionnez ≥ 3 variables."), empty, html.Div())

        cols = [c for c in vars_sel if c in dep.num_features][:30]
        if len(cols) < 3:
            return (_err("Pas assez de variables numériques."), empty, html.Div())

        memo_key = (tuple(cols), thresh, layout_m, tuple(sorted(options)))
        if memo_key in _memo:
            return _memo[memo_key]

        # ── Partial correlation matrix ────────────────────────────────
        try:
            pcor, pmat = _partial_corr(dep.display_df, cols)
        except Exception as ex:
            return (_err(f"Erreur calcul: {ex}"), empty, html.Div())

        n = len(cols)

        # ── Graph edges ───────────────────────────────────────────────
        edges = []
        for i in range(n):
            for j in range(i+1, n):
                r = float(pcor[i,j])
                p = float(pmat[i,j]) if pmat is not None else 1.0
                if abs(r) >= thresh:
                    edges.append({"i":i,"j":j,"r":r,"p":p,"absr":abs(r)})

        # ── Node positions ────────────────────────────────────────────
        pos = _layout(n, edges, cols, layout_m)

        # ── Centrality (degree-weighted) ──────────────────────────────
        degree = np.zeros(n)
        strength = np.zeros(n)
        for e in edges:
            degree[e["i"]] += 1; degree[e["j"]] += 1
            strength[e["i"]] += e["absr"]; strength[e["j"]] += e["absr"]

        max_deg = max(degree.max(), 1)
        max_str = max(strength.max(), 1e-6)

        # ── Figure ────────────────────────────────────────────────────
        fig = go.Figure()

        # Edges
        for e in edges:
            xi,yi = pos[e["i"]]; xj,yj = pos[e["j"]]
            r = e["r"]
            width = 1.0 + abs(r) * 5.5
            clr   = f"rgba(33,102,172,{0.3+abs(r)*0.65})" if r>0 \
                    else f"rgba(178,24,43,{0.3+abs(r)*0.65})"
            dash  = "solid" if e["p"]<0.05 else "dot"
            fig.add_trace(go.Scatter(
                x=[xi,xj,None], y=[yi,yj,None], mode="lines",
                line=dict(color=clr, width=width, dash=dash),
                showlegend=False, hoverinfo="skip",
            ))

        # Arrow annotations for directed edges
        if "arrows" in options:
            for e in edges:
                xi,yi = pos[e["i"]]; xj,yj = pos[e["j"]]
                # Direction: lower degree node → higher (heuristic)
                if degree[e["i"]] < degree[e["j"]]:
                    ax,ay,x_,y_ = xi,yi,xj,yj
                else:
                    ax,ay,x_,y_ = xj,yj,xi,yi
                fig.add_annotation(ax=ax,ay=ay,axref="x",ayref="y",
                    x=x_*0.85+ax*0.15, y=y_*0.85+ay*0.15,
                    arrowhead=2, arrowsize=0.9, arrowwidth=1.2,
                    arrowcolor="rgba(100,100,100,0.5)", showarrow=True)

        # Nodes
        node_x = [pos[i][0] for i in range(n)]
        node_y = [pos[i][1] for i in range(n)]
        node_colors = [_centrality_color(strength[i]/max_str) for i in range(n)]
        node_sizes  = ([18+strength[i]/max_str*28 for i in range(n)]
                       if "centrality" in options else [26]*n)

        hover_texts = []
        for i in range(n):
            top_conn = sorted([(e["r"],cols[e["j"]] if e["i"]==i else cols[e["i"]])
                                for e in edges if e["i"]==i or e["j"]==i],
                               key=lambda x:abs(x[0]),reverse=True)[:4]
            conn_str = "<br>".join([f"  {c}: r={r:+.3f}" for r,c in top_conn]) or "—"
            hover_texts.append(
                f"<b>{cols[i]}</b><br>"
                f"Degré: {int(degree[i])}<br>"
                f"Force: {strength[i]:.3f}<br>"
                f"<br>Connexions:<br>{conn_str}")

        fig.add_trace(go.Scatter(
            x=node_x, y=node_y, mode="markers+text" if "labels" in options else "markers",
            marker=dict(color=node_colors, size=node_sizes,
                        line=dict(color="white", width=2.5),
                        colorscale=[[0,"#f7f7f7"],[0.4,"#92c5de"],
                                    [0.7,"#2166ac"],[1.0,"#08306b"]],
                        cmin=0, cmax=1, showscale=True,
                        colorbar=dict(title=dict(text="Force",
                                                  font=dict(size=10,family=FONT)),
                                      thickness=12, len=0.5,
                                      tickvals=[0,0.5,1],
                                      ticktext=["Faible","Moyenne","Forte"],
                                      tickfont=dict(size=9,family=FONT))),
            text=[c[:14] for c in cols],
            textposition="top center",
            textfont=dict(size=9, family=FONT, color="#1e3a5f"),
            hovertext=hover_texts,
            hovertemplate="%{hovertext}<extra></extra>",
            hoverlabel=dict(bgcolor="#1e3a5f",font_size=11,font_color="white"),
            showlegend=False,
            customdata=list(range(n)),
        ))

        # Legend traces for edge colors
        for lbl, clr in [("r > 0 (positif)","rgba(33,102,172,0.7)"),
                          ("r < 0 (négatif)","rgba(178,24,43,0.7)"),
                          ("— non sig. (p≥.05)","rgba(150,150,150,0.5)")]:
            fig.add_trace(go.Scatter(x=[None],y=[None],mode="lines",
                name=lbl,line=dict(color=clr,width=3,
                                    dash="solid" if "non" not in lbl else "dot")))

        fig.update_layout(
            showlegend=True,
            plot_bgcolor="white", paper_bgcolor="white",
            xaxis=dict(showgrid=False,zeroline=False,showticklabels=False,
                       range=[min(node_x)-0.15,max(node_x)+0.15]),
            yaxis=dict(showgrid=False,zeroline=False,showticklabels=False,
                       range=[min(node_y)-0.15,max(node_y)+0.15],scaleanchor="x"),
            margin=dict(l=20,r=80,t=30,b=20),
            font=dict(family=FONT,size=10),
            legend=dict(orientation="h",x=0.5,xanchor="center",y=-0.04,
                        font=dict(size=10)),
            dragmode="pan",
        )

        # ── Cards ─────────────────────────────────────────────────────
        n_edges  = len(edges)
        n_sig    = sum(1 for e in edges if e["p"]<0.05)
        density  = n_edges/max(n*(n-1)//2,1)
        top_hub  = cols[int(np.argmax(strength))] if n>0 else "—"
        top_str  = float(strength.max()) if n>0 else 0.0

        cards = _metric_cards(n, n_edges, n_sig, density, top_hub, thresh)

        # ── Edge table ────────────────────────────────────────────────
        edge_table = _edge_table(edges, cols)

        result = (cards, fig, edge_table)
        _memo[memo_key] = result
        return result

    # ── Node click detail ────────────────────────────────────────────
    @app.callback(
        Output("cau-detail-panel","children"),
        [Input("cau-graph","clickData"),
         Input("cau-vars","value"),
         Input("cau-thresh","value")],
    )
    def node_detail(click, vars_sel, thresh):
        if not click or not vars_sel: return _default_detail()
        pts = click.get("points",[])
        if not pts or pts[0].get("customdata") is None:
            return _default_detail()

        cols = [c for c in vars_sel if c in dep.num_features][:30]
        if len(cols)<3: return _default_detail()
        thresh = float(thresh or 0.15)
        node_i = int(pts[0]["customdata"])
        if node_i >= len(cols): return _default_detail()
        col    = cols[node_i]

        try:
            pcor, pmat = _partial_corr(dep.display_df, cols)
        except: return _default_detail()

        row = [(float(pcor[node_i,j]), float(pmat[node_i,j]) if pmat is not None else 1.0,
                cols[j]) for j in range(len(cols)) if j!=node_i]
        row.sort(key=lambda x:abs(x[0]), reverse=True)
        sig_row = [r for r in row if abs(r[0])>=thresh]

        items = []
        for r,p,c in row[:10]:
            above_thresh = abs(r)>=thresh
            clr = "#2166ac" if r>0 else "#b2182b"
            bar_w = int(abs(r)*80)
            items.append(html.Div([
                html.Div([
                    html.Span(c[:20],style={"fontSize":"11px","fontWeight":"700" if above_thresh else "400",
                        "color":"#1e3a5f" if above_thresh else "#9aa5b4","flex":"1"}),
                    html.Span(f"{r:+.3f}",style={"fontSize":"11px","fontWeight":"700",
                        "color":clr if above_thresh else "#9aa5b4"}),
                ],style={"display":"flex","justifyContent":"space-between","marginBottom":"2px"}),
                html.Div(style={"width":f"{bar_w}px","height":"4px","background":clr if above_thresh else "#ddd",
                    "borderRadius":"2px","opacity":"0.7"}),
                html.Div(f"p={p:.4f}",style={"fontSize":"9px","color":"#9aa5b4","marginTop":"1px"}),
            ],style={"marginBottom":"10px","opacity":"1.0" if above_thresh else "0.45"}))

        return html.Div([
            html.Div([
                html.Div(f"🔵 {col}",style={"fontWeight":"800","fontSize":"13px",
                    "color":"#1e3a5f","marginBottom":"4px","fontFamily":FONT}),
                html.Div(f"{len(sig_row)} connexions (seuil ≥{thresh})",
                    style={"fontSize":"10px","color":"#6b7a8d","marginBottom":"12px"}),
            ]),
            html.Div("Corrélations partielles avec les autres variables :",
                style={"fontSize":"10px","color":"#9aa5b4","fontStyle":"italic",
                       "marginBottom":"8px","fontFamily":FONT}),
            html.Div(items),
        ],style={"padding":"4px"})


# ══════════════════════════════════════════════════════════════════════════════
#  COMPUTATION
# ══════════════════════════════════════════════════════════════════════════════

def _partial_corr(df, cols, max_rows=10000):
    """Partial correlation via precision matrix (graphical lasso approach)."""
    n = min(max_rows, len(df))
    rng = np.random.default_rng(42)
    idx = rng.choice(len(df), n, replace=False) if len(df)>n else np.arange(len(df))
    X = df[cols].iloc[idx].fillna(df[cols].median()).values.astype(np.float64)

    # Standardise
    mu = X.mean(axis=0); sd = X.std(axis=0)+1e-9
    X  = (X-mu)/sd

    # Pearson correlation + precision
    C = np.corrcoef(X.T)
    # Regularise slightly for invertibility
    C += np.eye(len(cols))*0.01
    try:
        P = np.linalg.inv(C)
    except np.linalg.LinAlgError:
        P = np.linalg.pinv(C)

    # Partial correlation from precision
    d = np.sqrt(np.abs(np.diag(P)))
    pc = np.zeros_like(P)
    for i in range(len(cols)):
        for j in range(len(cols)):
            if i != j:
                pc[i,j] = -P[i,j]/(d[i]*d[j]+1e-12)
    np.fill_diagonal(pc, 1.0)
    pc = np.clip(pc, -1, 1)

    # p-values via t-distribution (df = n - len(cols) - 1)
    n_obs = len(idx); k = len(cols)
    df_t = max(n_obs - k - 1, 1)
    pmat = np.ones_like(pc)
    for i in range(k):
        for j in range(i+1, k):
            r = pc[i,j]
            t = r*np.sqrt(df_t)/np.sqrt(max(1-r**2, 1e-12))
            p = float(2*sp_stats.t.sf(abs(t), df=df_t))
            pmat[i,j] = pmat[j,i] = p

    return pc, pmat


def _layout(n, edges, cols, mode):
    """Compute node positions without networkx."""
    rng = np.random.default_rng(42)
    pos = rng.uniform(-1, 1, (n, 2))

    if mode == "circular":
        angles = np.linspace(0, 2*np.pi, n, endpoint=False)
        pos = np.column_stack([np.cos(angles), np.sin(angles)])

    elif mode in ("spring", "kk"):
        # Fruchterman-Reingold force-directed layout
        adj = np.zeros((n, n))
        for e in edges:
            adj[e["i"],e["j"]] = adj[e["j"],e["i"]] = e["absr"]

        pos = rng.uniform(-1, 1, (n, 2))
        k   = 1.0/np.sqrt(max(n, 1))
        temp = 0.5
        for _ in range(120):
            delta = np.zeros((n, 2))
            for i in range(n):
                rep = np.zeros(2)
                for j in range(n):
                    if i==j: continue
                    diff = pos[i]-pos[j]
                    dist = max(np.linalg.norm(diff), 0.01)
                    rep += (diff/dist)*(k**2/dist)
                att = np.zeros(2)
                for j in range(n):
                    if adj[i,j]==0: continue
                    diff = pos[j]-pos[i]
                    dist = max(np.linalg.norm(diff), 0.01)
                    att += (diff/dist)*(dist**2/k)*adj[i,j]
                delta[i] = rep + att
            dlen = np.linalg.norm(delta, axis=1, keepdims=True)
            dlen = np.maximum(dlen, 1e-9)
            pos += delta/dlen * np.minimum(dlen, temp)
            temp *= 0.96
        # Normalise to [-1,1]
        r = np.abs(pos).max()
        if r > 0: pos /= r

    return [(float(pos[i,0]), float(pos[i,1])) for i in range(n)]


def _centrality_color(v):
    """Map 0-1 centrality to a color value."""
    return float(np.clip(v, 0, 1))


# ══════════════════════════════════════════════════════════════════════════════
#  UI HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _metric_cards(n_nodes, n_edges, n_sig, density, top_hub, thresh):
    def _c(icon,lbl,val,sub,clr):
        return html.Div([
            html.Div(icon,style={"fontSize":"22px"}),
            html.Div(val,style={"fontSize":"20px","fontWeight":"800","color":clr,"fontFamily":FONT}),
            html.Div(lbl,style={"fontSize":"10px","fontWeight":"700","color":"#6b7a8d",
                "textTransform":"uppercase","letterSpacing":".3px"}),
            html.Div(sub,style={"fontSize":"10px","color":"#9aa5b4","marginTop":"2px"}),
        ],style={"background":"white","borderRadius":"10px","padding":"12px 16px",
                 "flex":"1","minWidth":"130px","boxShadow":"0 1px 6px rgba(0,0,0,.07)",
                 "borderLeft":f"4px solid {clr}"})
    return html.Div([
        _c("🔵","Nœuds",str(n_nodes),f"seuil |r| ≥ {thresh}","#4472c4"),
        _c("🔗","Arêtes",str(n_edges),f"{n_sig} significatives (p<.05)","#27ae60"),
        _c("📊","Densité",f"{density:.1%}","fraction d'arêtes possibles","#e07b39"),
        _c("⭐","Hub principal",top_hub[:16],"nœud le plus connecté","#9b59b6"),
    ],style={"display":"flex","gap":"10px","flexWrap":"wrap"})


def _edge_table(edges, cols):
    if not edges:
        return html.Div("Aucune arête avec ce seuil.",
                        style={"color":"#9aa5b4","padding":"12px","fontSize":"12px"})
    top = sorted(edges, key=lambda e:e["absr"], reverse=True)[:30]

    def _th(t):
        return html.Th(t,style={"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"9.5px","textTransform":"uppercase",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap","textAlign":"left"})
    def _td(t,clr=None,bold=False):
        s={"padding":"4px 8px","fontSize":"10.5px","color":clr or "#374151","whiteSpace":"nowrap"}
        if bold: s["fontWeight"]="700"
        return html.Td(t,style=s)

    rows=[]
    for e in top:
        r=e["r"]; p=e["p"]; sig=p<0.05
        clr="#2166ac" if r>0 else "#b2182b"
        stars="***" if p<0.001 else "**" if p<0.01 else "*" if sig else "ns"
        rows.append(html.Tr([
            _td(cols[e["i"]][:18]),
            _td(cols[e["j"]][:18]),
            _td(f"{r:+.4f}",clr,True),
            _td(f"{e['absr']:.4f}"),
            _td(f"{p:.4f}","#27ae60" if sig else "#9aa5b4",sig),
            _td(stars,"#27ae60" if sig else "#9aa5b4",True),
        ],style={"borderBottom":"1px solid #f5f5f5",
                 "background":"#f0f5ff" if r>0 and sig else "#fff5f5" if r<0 and sig else "#fff"}))

    return html.Div(
        html.Table([
            html.Thead(html.Tr([_th("Variable A"),_th("Variable B"),
                                _th("r partiel"),_th("|r|"),_th("p-value"),_th("Sig.")])),
            html.Tbody(rows),
        ],style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT}),
        style={"overflowX":"auto","maxHeight":"360px","overflowY":"auto"})


def _default_detail():
    return html.Div([
        html.Div("🔵 Détail nœud",style={"fontWeight":"800","fontSize":"13px",
            "color":"#1e3a5f","marginBottom":"12px","fontFamily":FONT}),
        html.Div([
            html.Div("☝️",style={"fontSize":"28px","textAlign":"center","marginBottom":"8px"}),
            html.Div("Cliquez sur un nœud du graphe pour voir ses connexions directes.",
                style={"fontSize":"12px","color":"#9aa5b4","textAlign":"center"}),
        ],style={"background":"#f7f8fa","borderRadius":"10px","padding":"20px",
                  "border":"1.5px dashed #dde2ea"}),
    ],style={"padding":"4px"})

def _err(msg):
    return html.Div(msg,style={"color":"#e74c3c","padding":"16px","fontSize":"13px","fontFamily":FONT})
