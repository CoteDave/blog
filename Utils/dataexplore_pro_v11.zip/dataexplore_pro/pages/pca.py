"""
ACP — Analyse en Composantes Principales v9

Layout professionnel :
  • 4 cards résumé (variance PC1, cumulée, nb comp. pour 80%/90%, features)
  • Biplot 2D amélioré : ellipses de confiance par classe, flèches nettes
  • Cercle des corrélations (Variables Factor Map) — le vrai graphique ACP
  • Scree plot avec coude annoté (Cattell criterion) + seuil Kaiser
  • Top loadings bar chart par PC sélectionné
  • Heatmap loadings features × PC
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep):
    num      = dep.num_features
    max_comp = min(12, len(num))
    pc_opts  = [{"label":f"PC{i}","value":i} for i in range(1,max_comp+1)]

    return html.Div([
        html.Div("ACP — Analyse en Composantes Principales", className="page-title"),
        html.Div("Réduction de dimensionnalité — biplot, cercle des corrélations, "
                 "loadings, variance expliquée.",
                 className="page-subtitle"),

        # Summary cards
        html.Div(id="pca-summary-cards", style={"marginBottom":"16px"}),

        # Controls
        html.Div([
            html.Div([html.Div("Nb composantes:", className="control-label"),
                      dcc.Slider(id="pca-n", min=2, max=max_comp, step=1,
                          value=min(5,max_comp),
                          marks={i:str(i) for i in range(2,max_comp+1,2)},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"240px"}),

            html.Div([html.Div("Axes X / Y:", className="control-label"),
                      html.Div([
                          dcc.Dropdown(id="pca-pc-x",value=1,options=pc_opts,
                              clearable=False,style={"width":"90px"}),
                          dcc.Dropdown(id="pca-pc-y",value=2,options=pc_opts,
                              clearable=False,style={"width":"90px"}),
                      ],style={"display":"flex","gap":"6px"})],
                className="control-group"),

            html.Div([html.Div("Nb flèches loadings:", className="control-label"),
                      dcc.Slider(id="pca-arrows",
                          min=0, max=min(20,len(num)), step=1,
                          value=min(10,len(num)),
                          marks={0:"0",5:"5",10:"10",15:"15",20:"20"},
                          tooltip={"placement":"bottom","always_visible":False})],
                className="control-group", style={"minWidth":"200px"}),

            html.Div([html.Div("PC pour loadings:", className="control-label"),
                      dcc.Dropdown(id="pca-pc-detail",value=1,options=pc_opts,
                          clearable=False,style={"width":"100px"})],
                className="control-group"),

            html.Div([html.Div("Options:", className="control-label"),
                      dcc.Checklist(id="pca-options",
                          options=[{"label":" Ellipses IC95%","value":"ellipse"},
                                   {"label":" Biplot 3D","value":"3d"}],
                          value=["ellipse"], inline=True,
                          inputStyle={"marginRight":"4px"},
                          labelStyle={"marginRight":"12px","fontSize":"13px"})],
                className="control-group"),
        ], className="controls-row"),

        # Row 1: Biplot + Scree
        html.Div([
            html.Div([
                html.Div("Biplot — Individus & Variables",className="chart-card-title"),
                dcc.Loading(html.Div(id="pca-biplot-wrap"),
                            type="circle",color="#4472c4"),
            ],className="chart-card"),
            html.Div([
                html.Div("Diagramme d'Éboulis (Scree Plot)",className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="pca-scree",
                    config={"displayModeBar":False},style={"height":"400px"}),
                    type="circle",color="#4472c4"),
            ],className="chart-card"),
        ],className="charts-grid",style={"marginBottom":"16px"}),

        # Row 2: Cercle des corrélations + Top loadings bar
        html.Div([
            html.Div([
                html.Div("Cercle des Corrélations (Variables Factor Map)",
                         className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="pca-circle",
                    config={"displayModeBar":False},style={"height":"440px"}),
                    type="circle",color="#4472c4"),
            ],className="chart-card"),
            html.Div([
                html.Div(id="pca-loadings-title",className="chart-card-title"),
                dcc.Loading(dcc.Graph(id="pca-loadings-bar",
                    config={"displayModeBar":False},style={"height":"440px"}),
                    type="circle",color="#4472c4"),
            ],className="chart-card"),
        ],className="charts-grid",style={"marginBottom":"16px"}),

        # Row 3: Loadings heatmap
        html.Div([
            html.Div("Matrice des Loadings — Features × Composantes",
                     className="chart-card-title"),
            dcc.Loading(dcc.Graph(id="pca-loadings-heatmap",
                config={"displayModeBar":True},style={"height":"480px"}),
                type="circle",color="#4472c4"),
        ],className="chart-card"),

    ],className="page-card")


def register_callbacks(app, dep):

    _memo: dict = {}

    @app.callback(
        [Output("pca-summary-cards","children"),
         Output("pca-biplot-wrap","children"),
         Output("pca-scree","figure"),
         Output("pca-circle","figure"),
         Output("pca-loadings-bar","figure"),
         Output("pca-loadings-title","children"),
         Output("pca-loadings-heatmap","figure")],
        [Input("pca-n","value"),
         Input("pca-pc-x","value"),
         Input("pca-pc-y","value"),
         Input("pca-arrows","value"),
         Input("pca-pc-detail","value"),
         Input("pca-options","value")],
    )
    def update(n_comp, pc_x, pc_y, n_arrows, pc_detail, options):
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler

        options  = options or []
        use_ell  = "ellipse" in options
        use_3d   = "3d"      in options
        num      = dep.num_features
        n_comp   = max(3, min(n_comp or 5, len(num)))
        pc_x     = min(pc_x or 1, n_comp)
        pc_y     = min(pc_y or 2, n_comp)
        pc_detail= min(pc_detail or 1, n_comp)
        n_arr    = n_arrows or 0

        memo_key = (n_comp, pc_x, pc_y, n_arr, pc_detail, use_ell, use_3d)
        if memo_key in _memo:
            return _memo[memo_key]

        # ── PCA computation ───────────────────────────────────────────
        pca_cache = dep.cache.get("pca", wait=False)
        use_cache = (pca_cache is not None
                     and set(num)==set(pca_cache.get("cols",[]))
                     and n_comp<=pca_cache.get("n_comp",0))
        if use_cache:
            pca    = pca_cache["pca"]
            scaler = pca_cache["scaler"]
            cols_c = pca_cache["cols"]
            X_disp = dep.display_df[cols_c].fillna(dep.display_df[cols_c].median()).values
            scores = pca.transform(scaler.transform(X_disp))
        else:
            cols_c = num
            X_raw  = dep.display_df[num].fillna(dep.display_df[num].median()).values
            scaler = StandardScaler()
            X      = scaler.fit_transform(X_raw)
            pca    = PCA(n_components=n_comp,random_state=42,svd_solver="randomized")
            scores = pca.fit_transform(X)

        loadings = pca.components_[:n_comp]   # (n_comp, n_features)
        var_r    = pca.explained_variance_ratio_[:n_comp]*100
        cum_var  = np.cumsum(var_r)
        xi,yi    = pc_x-1, pc_y-1

        # ── Summary cards ─────────────────────────────────────────────
        n80 = int(np.searchsorted(cum_var, 80)+1)
        n90 = int(np.searchsorted(cum_var, 90)+1)
        cards_data = [
            {"icon":"📊","label":"Variance PC1","value":f"{var_r[0]:.1f}%",
             "sub":f"PC2: {var_r[1]:.1f}%","clr":"#4472c4"},
            {"icon":"📈","label":"Variance cumulée","value":f"{cum_var[min(n_comp-1,4)]:.1f}%",
             "sub":f"pour {min(n_comp,5)} composantes","clr":"#27ae60"},
            {"icon":"🔑","label":"Composantes pour 80%","value":str(n80),
             "sub":f"Pour 90% : {n90} composantes","clr":"#e07b39"},
            {"icon":"🔢","label":"Features analysées","value":str(len(cols_c)),
             "sub":f"Sur {len(dep.num_features)} features num.","clr":"#9b59b6"},
        ]
        summary = html.Div([
            html.Div([
                html.Div([
                    html.Div(c["icon"],style={"fontSize":"22px"}),
                    html.Div(c["value"],style={"fontSize":"20px","fontWeight":"800",
                        "color":c["clr"],"fontFamily":FONT}),
                    html.Div(c["label"],style={"fontSize":"10px","fontWeight":"700",
                        "color":"#6b7a8d","textTransform":"uppercase","letterSpacing":".3px"}),
                    html.Div(c["sub"],style={"fontSize":"10px","color":"#9aa5b4","marginTop":"2px"}),
                ],style={"background":"white","borderRadius":"10px","padding":"12px 16px",
                         "flex":"1","minWidth":"150px",
                         "boxShadow":"0 1px 6px rgba(0,0,0,.07)",
                         "borderLeft":f"4px solid {c['clr']}"})
                for c in cards_data
            ],style={"display":"flex","gap":"10px","flexWrap":"wrap"}),
        ])

        # ── Biplot ────────────────────────────────────────────────────
        if use_3d:
            pc_z  = min(3,n_comp)
            bfig  = _biplot_3d(dep,scores,loadings,var_r,xi,yi,pc_z-1,cols_c,n_arr)
            bwrap = dcc.Graph(figure=bfig,config={"displayModeBar":True},
                              style={"height":"460px"})
        else:
            bfig  = _biplot_2d(dep,scores,loadings,var_r,xi,yi,cols_c,n_arr,use_ell)
            bwrap = dcc.Graph(figure=bfig,config={"displayModeBar":True},
                              style={"height":"420px"})

        # ── Scree ─────────────────────────────────────────────────────
        fig_scree = _scree(var_r, cum_var, n_comp, xi, yi)

        # ── Cercle des corrélations ────────────────────────────────────
        fig_circle = _correlation_circle(loadings, var_r, cols_c, xi, yi)

        # ── Top loadings bar chart ─────────────────────────────────────
        fig_bar, bar_title = _loadings_bar(loadings, cols_c, var_r, pc_detail-1)

        # ── Loadings heatmap ──────────────────────────────────────────
        fig_heat = _loadings_heatmap(loadings, cols_c, n_comp, xi, yi)

        result = (summary, bwrap, fig_scree, fig_circle,
                  fig_bar, bar_title, fig_heat)
        _memo[memo_key] = result
        return result


# ══════════════════════════════════════════════════════════════════════
#  CHART BUILDERS
# ══════════════════════════════════════════════════════════════════════

def _biplot_2d(dep, scores, loadings, var_r, xi, yi, cols, n_arrows, use_ell):
    fig = go.Figure()

    # Confidence ellipse helper
    def _ellipse_xy(x, y, n=60):
        try:
            from scipy.stats import chi2
            pts  = np.column_stack([x,y])
            mu   = pts.mean(axis=0)
            cov  = np.cov(pts.T)
            w,v  = np.linalg.eigh(cov)
            w    = np.maximum(w, 0)
            r    = np.sqrt(chi2.ppf(0.95, df=2))
            t    = np.linspace(0, 2*np.pi, n)
            ell  = np.column_stack([np.cos(t),np.sin(t)])
            ell  = ell @ (np.diag(r*np.sqrt(w)) @ v.T) + mu
            return ell[:,0].tolist(), ell[:,1].tolist()
        except: return [],[]

    if dep.supervised:
        for i,cls in enumerate(dep.classes):
            mask = dep.y==cls
            sc   = scores[mask]
            clr  = PAL[i%len(PAL)]
            r,g,b = _hex_rgb(clr)
            # Points
            fig.add_trace(go.Scatter(
                x=sc[:,xi],y=sc[:,yi],mode="markers",
                name=f"Classe {cls}",
                marker=dict(color=clr,size=6,opacity=0.70,
                            line=dict(width=0.4,color="rgba(255,255,255,.6)")),
                hovertemplate=f"Cls {cls}<br>PC{xi+1}=%{{x:.2f}}<br>PC{yi+1}=%{{y:.2f}}<extra></extra>",
            ))
            # Ellipse
            if use_ell and len(sc)>=5:
                ex,ey = _ellipse_xy(sc[:,xi],sc[:,yi])
                if ex:
                    fig.add_trace(go.Scatter(
                        x=ex+[ex[0]],y=ey+[ey[0]],mode="lines",
                        line=dict(color=clr,width=2,dash="dot"),
                        fill="toself",
                        fillcolor=f"rgba({r},{g},{b},0.07)",
                        showlegend=False,hoverinfo="skip",
                    ))
    else:
        fig.add_trace(go.Scatter(
            x=scores[:,xi],y=scores[:,yi],mode="markers",
            marker=dict(color="#4472c4",size=6,opacity=0.65,
                        line=dict(width=0.3,color="rgba(255,255,255,.6)")),
            hovertemplate=f"PC{xi+1}=%{{x:.2f}}<br>PC{yi+1}=%{{y:.2f}}<extra></extra>",
            showlegend=False,
        ))

    # Loading arrows
    if n_arrows>0:
        scale = max(abs(scores[:,xi]).max(),abs(scores[:,yi]).max())*0.45
        mag   = np.sqrt(loadings[xi,:]**2+loadings[yi,:]**2)
        top   = np.argsort(mag)[::-1][:n_arrows]
        for j in top:
            lx = float(loadings[xi,j])*scale
            ly = float(loadings[yi,j])*scale
            lbl= cols[j][:14]
            fig.add_annotation(ax=0,ay=0,axref="x",ayref="y",
                x=lx,y=ly,arrowhead=3,arrowsize=1.0,arrowwidth=2.0,
                arrowcolor="rgba(192,57,43,0.85)",showarrow=True)
            fig.add_annotation(x=lx*1.15,y=ly*1.15,text=lbl,
                showarrow=False,
                font=dict(size=9,color="#922b21",family=FONT),
                bgcolor="rgba(255,255,255,0.80)",
                borderpad=2)

    fig.update_layout(
        title=dict(text=f"Biplot ACP — PC{xi+1} ({var_r[xi]:.1f}%) × PC{yi+1} ({var_r[yi]:.1f}%)",
                   font=dict(size=12,color="#1e3a5f",family=FONT)),
        xaxis=dict(title=f"PC{xi+1} — {var_r[xi]:.1f}%",gridcolor=GRID,
                   zeroline=True,zerolinecolor="#ccc",zerolinewidth=1),
        yaxis=dict(title=f"PC{yi+1} — {var_r[yi]:.1f}%",gridcolor=GRID,
                   zeroline=True,zerolinecolor="#ccc",zerolinewidth=1),
        plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=20,t=50,b=50),
        font=dict(family=FONT,size=11),
        legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1,bordercolor=GRID),
    )
    return fig


def _biplot_3d(dep, scores, loadings, var_r, xi, yi, zi, cols, n_arrows):
    fig = go.Figure()
    if dep.supervised:
        for i,cls in enumerate(dep.classes):
            mask=dep.y==cls
            fig.add_trace(go.Scatter3d(
                x=scores[mask,xi],y=scores[mask,yi],z=scores[mask,zi],
                mode="markers",name=f"Cls {cls}",
                marker=dict(color=PAL[i%len(PAL)],size=4,opacity=0.75,
                            line=dict(width=0.2,color="rgba(255,255,255,.3)"))))
    else:
        fig.add_trace(go.Scatter3d(
            x=scores[:,xi],y=scores[:,yi],z=scores[:,zi],mode="markers",
            marker=dict(color="#4472c4",size=4,opacity=0.65),showlegend=False))
    if n_arrows>0:
        scale=max(abs(scores[:,xi]).max(),abs(scores[:,yi]).max(),abs(scores[:,zi]).max())*0.4
        mag=np.sqrt(loadings[xi,:]**2+loadings[yi,:]**2+loadings[zi,:]**2)
        for j in np.argsort(mag)[::-1][:n_arrows]:
            lx,ly,lz=(float(loadings[k,j])*scale for k in (xi,yi,zi))
            fig.add_trace(go.Scatter3d(x=[0,lx,None],y=[0,ly,None],z=[0,lz,None],
                mode="lines+text",line=dict(color="rgba(192,57,43,.8)",width=3),
                text=["",cols[j][:12],""],textfont=dict(size=9,color="#922b21"),
                showlegend=False,hoverinfo="skip"))
    fig.update_layout(
        title=dict(text=f"Biplot 3D — PC{xi+1}/{yi+1}/{zi+1}",
                   font=dict(size=12,color="#1e3a5f",family=FONT)),
        scene=dict(
            xaxis=dict(title=f"PC{xi+1} ({var_r[xi]:.1f}%)",gridcolor=GRID,backgroundcolor=BG),
            yaxis=dict(title=f"PC{yi+1} ({var_r[yi]:.1f}%)",gridcolor=GRID,backgroundcolor=BG),
            zaxis=dict(title=f"PC{zi+1} ({var_r[zi]:.1f}%)",gridcolor=GRID,backgroundcolor=BG),
            bgcolor="white"),
        paper_bgcolor="white",margin=dict(l=0,r=0,t=50,b=0),
        font=dict(family=FONT,size=11),
        legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)"),
    )
    return fig


def _scree(var_r, cum_var, n_comp, xi, yi):
    n = len(var_r)
    # Elbow detection (Cattell): max second derivative
    elbow = 0
    if n > 2:
        d2 = np.diff(np.diff(var_r))
        elbow = int(np.argmin(d2)) + 1

    fig = go.Figure()
    bar_colors = []
    for i in range(n):
        if i in (xi,yi): bar_colors.append("#4472c4")
        elif i==elbow:   bar_colors.append("#e07b39")
        elif var_r[i]>=1.0*(100/n): bar_colors.append("rgba(68,114,196,0.55)")  # Kaiser
        else:             bar_colors.append("rgba(68,114,196,0.28)")

    fig.add_trace(go.Bar(
        x=[f"PC{i+1}" for i in range(n)], y=var_r,
        marker=dict(color=bar_colors,line=dict(width=0,color="white")),
        name="Variance indiv.", text=[f"{v:.1f}%" for v in var_r],
        textposition="outside", textfont=dict(size=9),
        hovertemplate="<b>%{x}</b><br>Variance: %{y:.2f}%<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=[f"PC{i+1}" for i in range(n)], y=cum_var,
        name="Cumulée", mode="lines+markers",
        line=dict(color="#e07b39",width=2.5),
        marker=dict(size=7,color="#e07b39",symbol="circle"),
        yaxis="y2",
        hovertemplate="<b>%{x}</b><br>Cumulée: %{y:.1f}%<extra></extra>",
    ))
    # Reference lines
    fig.add_hline(y=80,line_dash="dot",line_color="#27ae60",line_width=1.5,
                  annotation_text="80%",annotation_font_size=9,
                  annotation_font_color="#27ae60",yref="y2")
    fig.add_hline(y=90,line_dash="dot",line_color="#e07b39",line_width=1.5,
                  annotation_text="90%",annotation_font_size=9,
                  annotation_font_color="#e07b39",yref="y2")
    # Kaiser criterion (mean eigenvalue = 100/n_features)
    kaiser = 100/n
    fig.add_hline(y=kaiser,line_dash="longdash",line_color="#9b59b6",line_width=1,
                  annotation_text=f"Kaiser ({kaiser:.1f}%)",
                  annotation_font_size=8,annotation_font_color="#9b59b6")
    # Elbow annotation
    if elbow>0:
        fig.add_annotation(x=f"PC{elbow+1}",y=var_r[elbow]+1,
            text="⬐ Coude",showarrow=False,
            font=dict(size=9,color="#e07b39",family=FONT))

    fig.update_layout(
        xaxis=dict(tickfont=dict(size=10),gridcolor=GRID),
        yaxis=dict(title="Variance expliquée (%)",gridcolor=GRID,
                   range=[0,max(var_r)*1.30]),
        yaxis2=dict(title="Cumulée (%)",overlaying="y",side="right",
                    range=[0,105],showgrid=False),
        plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=60,r=70,t=30,b=50),
        font=dict(family=FONT,size=11),
        legend=dict(font=dict(size=11),x=0.15,y=1.02,orientation="h"),
        barmode="group",
    )
    return fig


def _correlation_circle(loadings, var_r, cols, xi, yi):
    """
    Cercle des corrélations (Variable Factor Map).
    Coordonnées : corr(feat, PCk) = loading[k,j] * sqrt(var_r[k]/100)
    """
    n_feat = loadings.shape[1]
    cx = loadings[xi,:]*np.sqrt(var_r[xi]/100)
    cy = loadings[yi,:]*np.sqrt(var_r[yi]/100)
    mags = np.sqrt(cx**2+cy**2)

    fig = go.Figure()

    # Unit circle
    t = np.linspace(0,2*np.pi,120)
    fig.add_trace(go.Scatter(x=np.cos(t),y=np.sin(t),mode="lines",
        line=dict(color="#cccccc",width=1.5,dash="dot"),
        showlegend=False,hoverinfo="skip"))
    # Inner circle (0.5)
    fig.add_trace(go.Scatter(x=0.5*np.cos(t),y=0.5*np.sin(t),mode="lines",
        line=dict(color="#eeeeee",width=1),
        showlegend=False,hoverinfo="skip"))

    # Axes
    for ax in ["x","y"]:
        if ax=="x":
            fig.add_shape(type="line",x0=-1.1,x1=1.1,y0=0,y1=0,
                          line=dict(color="#dddddd",width=1))
        else:
            fig.add_shape(type="line",x0=0,x1=0,y0=-1.1,y1=1.1,
                          line=dict(color="#dddddd",width=1))

    # Color by quality of representation
    colors = [f"rgba({int(m*192)},{int(m*57)},{int(m*43)},{0.4+m*0.6})"
              for m in mags]

    # Arrows
    for j in range(n_feat):
        col_lbl = cols[j][:16]
        m = float(mags[j])
        clr_line = f"rgba({int(m*180)},{int(m*50)},{int(m*35)},{min(0.3+m*0.7,1.0)})"
        fig.add_annotation(ax=0,ay=0,axref="x",ayref="y",
            x=float(cx[j]),y=float(cy[j]),
            arrowhead=3,arrowsize=0.9,arrowwidth=max(1.0,m*2.5),
            arrowcolor=clr_line,showarrow=True)
        offset = 0.06
        lx,ly  = float(cx[j])*(1+offset), float(cy[j])*(1+offset)
        if abs(lx)>0.05 or abs(ly)>0.05:
            fig.add_annotation(x=lx,y=ly,text=col_lbl,showarrow=False,
                font=dict(size=max(7,int(9*m+5)),
                          color="#7b241c" if m>0.6 else "#922b21" if m>0.3 else "#aaa",
                          family=FONT),
                bgcolor="rgba(255,255,255,0.75)",borderpad=1)

    # Scatter for hover
    fig.add_trace(go.Scatter(
        x=cx,y=cy,mode="markers",
        marker=dict(color=mags,colorscale=[[0,"#fde8e8"],[0.5,"#e07b39"],[1,"#922b21"]],
                    size=[max(5,m*14) for m in mags],
                    cmin=0,cmax=1,showscale=True,
                    colorbar=dict(title=dict(text="Qualité repr.",
                                             font=dict(size=10,family=FONT)),
                                  thickness=12,len=0.6,
                                  tickvals=[0,.5,1],ticktext=["0","0.5","1.0"],
                                  tickfont=dict(size=9)),
                    line=dict(color="white",width=0.5)),
        text=[f"<b>{cols[j]}</b><br>corr PC{xi+1}={cx[j]:.3f}<br>"
              f"corr PC{yi+1}={cy[j]:.3f}<br>qualité={mags[j]:.3f}"
              for j in range(n_feat)],
        hovertemplate="%{text}<extra></extra>",
        showlegend=False,
    ))

    fig.update_layout(
        title=dict(text=f"Cercle des corrélations — PC{xi+1} × PC{yi+1}",
                   font=dict(size=12,color="#1e3a5f",family=FONT)),
        xaxis=dict(title=f"PC{xi+1} ({var_r[xi]:.1f}%)",
                   range=[-1.2,1.2],gridcolor=GRID,zeroline=False,
                   scaleanchor="y",scaleratio=1),
        yaxis=dict(title=f"PC{yi+1} ({var_r[yi]:.1f}%)",
                   range=[-1.2,1.2],gridcolor=GRID,zeroline=False),
        plot_bgcolor="white",paper_bgcolor="white",
        margin=dict(l=60,r=80,t=50,b=60),
        font=dict(family=FONT,size=10),
        showlegend=False,
    )
    return fig


def _loadings_bar(loadings, cols, var_r, pc_idx):
    """Horizontal bar chart — top features for selected PC."""
    ld     = loadings[pc_idx,:]
    sorted_idx = np.argsort(np.abs(ld))[::-1][:20]
    vals   = ld[sorted_idx]
    labels = [cols[i][:28] for i in sorted_idx]
    colors = ["#2166ac" if v>0 else "#b2182b" for v in vals]

    fig = go.Figure(go.Bar(
        x=vals, y=labels, orientation="h",
        marker=dict(color=colors,
                    line=dict(width=0.5,color="rgba(255,255,255,.5)")),
        text=[f"{v:+.3f}" for v in vals],
        textposition="outside",
        textfont=dict(size=9,family=FONT),
        hovertemplate="<b>%{y}</b><br>Loading: %{x:+.4f}<extra></extra>",
    ))
    fig.add_vline(x=0,line_color="#cccccc",line_width=1.5)
    fig.add_vline(x=0.3,line_dash="dot",line_color="rgba(68,114,196,.35)",line_width=1)
    fig.add_vline(x=-0.3,line_dash="dot",line_color="rgba(68,114,196,.35)",line_width=1)

    title_text = (f"Top loadings — PC{pc_idx+1} "
                  f"({var_r[pc_idx]:.1f}% variance) · bleu=positif, rouge=négatif")
    fig.update_layout(
        xaxis=dict(title="Loading",gridcolor=GRID,zeroline=False,
                   range=[min(vals.min()*1.2,-0.4), max(vals.max()*1.2,0.4)]),
        yaxis=dict(autorange="reversed",tickfont=dict(size=10,family=FONT)),
        plot_bgcolor=BG,paper_bgcolor="white",
        margin=dict(l=180,r=80,t=20,b=50),
        font=dict(family=FONT,size=10),
        showlegend=False,
    )
    return fig, title_text


def _loadings_heatmap(loadings, cols, n_comp, xi, yi):
    load_mat = loadings.T   # (n_feat, n_comp)
    load_df  = pd.DataFrame(load_mat, index=cols,
                             columns=[f"PC{i+1}" for i in range(n_comp)])
    order    = np.argsort(np.abs(load_df["PC1"]))[::-1]
    load_df  = load_df.iloc[order]
    z        = load_df.values
    mx       = max(abs(z).max(), 1e-6)

    fig = go.Figure(go.Heatmap(
        z=z, x=list(load_df.columns),
        y=[f[:30] for f in load_df.index],
        colorscale=[[0,"#b2182b"],[0.5,"#f7f7f7"],[1,"#2166ac"]],
        zmid=0, zmin=-mx, zmax=mx,
        text=[[f"{v:+.2f}" for v in row] for row in z],
        texttemplate="%{text}",
        textfont=dict(size=8,family=FONT),
        hovertemplate="<b>%{y}</b> → %{x}: <b>%{z:+.4f}</b><extra></extra>",
        colorbar=dict(
            title=dict(text="Loading",font=dict(size=10,family=FONT)),
            thickness=14,tickfont=dict(size=9),
            tickvals=[-mx,0,mx],ticktext=[f"{-mx:.2f}","0",f"+{mx:.2f}"],
        ),
    ))
    # Highlight selected PCs
    for pc_i in set([xi,yi]):
        fig.add_shape(type="rect",
            x0=pc_i-0.5,y0=-0.5,x1=pc_i+0.5,y1=len(cols)-0.5,
            line=dict(color="#1e3a5f",width=2,dash="dot"),
            fillcolor="transparent",layer="above")

    fig.update_layout(
        title=dict(text="Loadings features × composantes (trié par |PC1|)",
                   font=dict(size=11,color="#1e3a5f",family=FONT)),
        plot_bgcolor="white",paper_bgcolor="white",
        margin=dict(l=190,r=70,t=50,b=80),
        font=dict(family=FONT,size=9),
        xaxis=dict(side="top",tickangle=0,
                   tickfont=dict(size=11,color="#1e3a5f",family=FONT)),
        yaxis=dict(tickfont=dict(size=9)),
        height=max(380,len(cols)*26+100),
    )
    return fig


def _hex_rgb(h):
    h=h.lstrip("#")
    return int(h[:2],16),int(h[2:4],16),int(h[4:6],16)
