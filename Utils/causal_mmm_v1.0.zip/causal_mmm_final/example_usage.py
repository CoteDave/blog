"""
example_usage.py — CausalMMM full demonstration on synthetic data.
Run:  python example_usage.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd

def main():
    from causal_mmm import CausalMMM
    from causal_mmm.transforms import geometric_adstock, hill_saturation

    # ── 1. Synthetic data (ground-truth params known) ─────────────────────
    np.random.seed(42)
    n = 156  # 3 years weekly
    t = np.arange(n)

    tv      = np.abs(np.random.normal(500, 150, n)) * (1 + 0.3 * np.sin(2*np.pi*t/52))
    digital = np.abs(np.random.normal(300, 100, n)) * (1 + 0.2 * np.cos(2*np.pi*t/52))
    radio   = np.abs(np.random.normal(100,  40, n))

    def _t(x, alpha, sa, sg):
        return hill_saturation(geometric_adstock(x, alpha), sa, sg)

    y = (3000
         + 1200 * _t(tv,      0.70, 2.0, 0.40)
         +  800 * _t(digital, 0.30, 1.5, 0.50)
         +  400 * _t(radio,   0.10, 1.0, 0.60)
         -   30 * np.random.normal(50, 5, n)   # price proxy
         +  150 * (np.random.rand(n) < 0.05)   # holidays
         + np.random.normal(0, 60, n))

    price   = np.random.default_rng(99).normal(50, 5, n)
    holiday = (np.random.default_rng(77).random(n) < 0.05).astype(float)

    X = pd.DataFrame({"tv": tv, "digital": digital, "radio": radio,
                      "price": price, "holiday": holiday})

    # ── 2. Fit ────────────────────────────────────────────────────────────
    mmm = CausalMMM(
        media_channels=["tv", "digital", "radio"],
        control_vars=["price", "holiday"],
        adstock_type="geometric",
        saturation_type="hill",
        ridge_alpha=1.0,
        n_trials=200,
        cv_folds=5,
        n_jobs=-1,
        verbose=True,
    )
    mmm.fit(X, y)

    # ── 3. Summary + ROI ──────────────────────────────────────────────────
    mmm.summary()
    print("\n── Marginal ROI ──────────────────────────────────")
    print(mmm.marginal_roi().to_string(float_format="{:.4f}".format))

    # ── 4. Scenarios ──────────────────────────────────────────────────────
    print("\n── Scenario: double TV spend ─────────────────────")
    r1 = mmm.scenario({"tv": 2.0})
    print(r1.drop(columns=["changed"]).to_string(float_format="{:,.1f}".format))
    print(f"\n  ΔRevenue = {r1.attrs['delta_revenue']:+,.0f}  ({r1.attrs['delta_revenue_pct']:+.2f}%)")

    print("\n── Scenario: shift $50k Radio → Digital ──────────")
    r2 = mmm.scenario({"radio": -50_000, "digital": 50_000}, mode="delta")
    print(r2.drop(columns=["changed"]).to_string(float_format="{:,.1f}".format))
    print(f"\n  ΔRevenue = {r2.attrs['delta_revenue']:+,.0f}")

    # ── 5. Budget optimiser ───────────────────────────────────────────────
    print("\n── Budget optimisation: $2M total ────────────────")
    alloc = mmm.optimize_budget(2_000_000, n_restarts=20)
    print(alloc.to_string(float_format="{:,.0f}".format))
    print(f"\n  Revenue uplift: {alloc.attrs['revenue_uplift']:+,.0f}  ({alloc.attrs['revenue_uplift_pct']:+.1f}%)")

    print("\n✅  All checks passed.")

if __name__ == "__main__":
    main()
