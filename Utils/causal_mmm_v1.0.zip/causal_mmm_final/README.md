# causal_mmm — Causal Marketing Mix Model

Production-grade Python package for Marketing Mix Modelling with causal
effect isolation, scenario analysis, and budget optimisation.

**Requires:** numpy · scipy · scikit-learn · pandas (all standard)

---

## Quick start

```python
from causal_mmm import CausalMMM

mmm = CausalMMM(
    media_channels=["tv", "digital", "radio"],
    control_vars=["price", "holiday"],
    adstock_type="geometric",   # or "weibull" | "delayed"
    saturation_type="hill",     # or "logistic" | "log"
    n_trials=300,
    cv_folds=5,
    n_jobs=-1,
)
mmm.fit(X_df, y)
mmm.summary()

# Causal ROI
print(mmm.marginal_roi())

# Scenario: double TV spend
result = mmm.scenario({"tv": 2.0})
print(f"ΔRevenue = {result.attrs['delta_revenue']:+,.0f}")

# Budget optimiser: redistribute $2M for maximum revenue
alloc = mmm.optimize_budget(2_000_000)
```

---

## Architecture

```
causal_mmm/
├── __init__.py        Public API
├── transforms.py      Adstock + saturation (vectorised, fixed reference)
├── optimization.py    Differential Evolution + bidirectional CV
├── decomposition.py   Contribution decomp + marginal ROI + ROI curves
├── scenarios.py       What-if engine + SLSQP budget optimiser
├── seasonality.py     Fourier features / trend / AR lags generator
├── model.py           CausalMMM sklearn estimator (main class)
└── diagnostics.py     15-test suite (run: python -m causal_mmm.diagnostics)
```

---

## How lags and seasonality work

### Adstock (media carryover / lag)

Media spend doesn't generate revenue only in the week it runs — it has a
**carryover effect** that decays over subsequent periods.  Three models:

| Type | Formula | Best for |
|------|---------|----------|
| `geometric` | adstock[t] = x[t] + α · adstock[t-1] | Most channels. α ∈ [0,0.9): higher = longer memory |
| `weibull` | Weibull PDF kernel convolved over past lags | Channels with **delayed peak** (e.g. TV brand awareness) |
| `delayed` | Geometric starting at lag θ | When effect starts θ periods after spend |

Parameters are **discovered automatically** by Differential Evolution — you
don't need to specify them.

### Saturation (diminishing returns)

At high spend levels, each additional dollar generates less incremental
revenue. Three models:

| Type | Formula | Shape |
|------|---------|-------|
| `hill` | x^α / (x^α + γ^α) | S-curve; α>1 → inflection point |
| `logistic` | 1 − exp(−λ·x) | Concave, always |
| `log` | log(1 + λ·x) | Concave, always |

**Critical implementation detail:** saturation normalises by a *fixed reference*
(`_x_max_ref = max adstocked training value`) set after fitting.  Without this
anchor, scenarios would re-normalise by the scenario's own max → ΔRevenue = 0.

### Seasonality (Fourier features)

Repeating seasonal patterns in the KPI (unrelated to media) are modelled
via Fourier sin/cos pairs added as control variables:

```python
from causal_mmm.seasonality import SeasonalityFeatures

sf = SeasonalityFeatures(
    n_fourier_terms={"annual": (52, 3), "quarterly": (13, 2)},
    trend="linear",
    ar_lags=[1, 52],   # AR lags of y (optional)
)
X_baseline = sf.fit_transform(n_periods=len(y), y=y)

# Concatenate with your data
import pandas as pd
X_full = pd.concat([X_media_and_controls, X_baseline], axis=1)
control_vars = list(X_full.columns.difference(media_channels))
```

Fourier features are estimated **jointly** with media parameters inside the
same constrained Ridge — so media coefficients are automatically
orthogonalised against seasonality.  This is superior to preprocessing
approaches (STL, Prophet) that subtract seasonality before fitting the MMM.

### AR lags

Lagged values of y (AR terms) can capture autocorrelation in the baseline
that is not explained by media or seasonality:

```python
sf = SeasonalityFeatures(trend="linear", ar_lags=[1, 2, 52])
```

---

## Optimisation strategy

**Differential Evolution** (scipy global optimiser) searches over all
adstock + saturation parameters simultaneously.

- **Sobol quasi-random** initialisation for full coverage
- **best1bin** mutation strategy
- **Final L-BFGS-B polish** on best solution
- **Bidirectional CV objective** = mean(SMAPE_expanding, SMAPE_rolling)
  → avoids models that generalise well in only one temporal direction
- **Non-negative Ridge** inner loop: media coefs ≥ 0 (spend can't hurt)

---

## Diagnostic test suite (15 tests)

```bash
python -m causal_mmm.diagnostics         # full suite
python -m causal_mmm.diagnostics --fast  # quick subset (9 tests)
```

Tests include: parameter recovery, all 9 transform combos, scenario
monotonicity, budget feasibility, noise robustness, short series, high
collinearity, seasonality, benchmark vs naive baselines, OOS prediction,
ROI curve monotonicity, scenario identity modes, single-channel edge case,
contribution decomposition identity.

---

## API reference

### `CausalMMM`

```python
CausalMMM(
    media_channels,          # list of spend column names
    control_vars=[],         # list of control column names
    adstock_type="geometric",
    saturation_type="hill",
    ridge_alpha=1.0,
    n_trials=300,            # optimisation budget (~evals = pop×dims×generations)
    cv_folds=5,
    n_jobs=-1,               # -1 = all cores
    verbose=True,
)

.fit(X, y)                   # X: DataFrame or ndarray, y: 1-D array
.predict(X)                  # → ndarray
.summary()                   # print structured summary
.marginal_roi()              # → DataFrame (avg_roi, marginal_roi per channel)
.roi_curves()                # → dict of DataFrames (spend, contribution, roi)
.scenario(changes, mode, period_slice)
.optimize_budget(total_budget, bounds, n_restarts)
.plot_contributions()
.plot_saturation_curves()
.plot_roi_curves()
.plot_scenario(result)

# Key attributes after fit:
.coef_              # [media coefs | control coefs | intercept]
.channel_params_    # {channel: {adstock: {...}, saturation: {...}}}
.contributions_     # DataFrame: per-period decomposition
.cv_detail_         # per-fold SMAPE + R²
.r2_, .mape_, .cv_score_
```

### `scenario(changes, mode, period_slice)`

```python
mmm.scenario({"tv": 2.0})                         # double TV (multiplier)
mmm.scenario({"tv": 0.5, "digital": 1.5})         # rebalance
mmm.scenario({"tv": 500_000}, mode="absolute")    # set TV to $500k total
mmm.scenario({"radio": -100_000}, mode="delta")   # cut radio by $100k
mmm.scenario({"tv": 2.0}, period_slice=slice(52, 104))  # Q2 only
```

Result DataFrame has `delta_contribution`, `incremental_roi` per channel.
`result.attrs` contains `delta_revenue`, `delta_revenue_pct`.

### `optimize_budget(total_budget, bounds, n_restarts)`

```python
mmm.optimize_budget(
    total_budget=2_000_000,
    bounds={"tv": (100_000, 1_500_000), "digital": (50_000, 800_000)},
    n_restarts=20,
)
```

---

## Diagnostic results (reference run)

| Test | Result | Key metric |
|------|--------|-----------|
| T01 Parameter recovery | ✅ | R²=0.97, alpha_err=0.07 |
| T02 All 9 transform combos | ✅ | min R²=0.21 |
| T03 Scenario monotonicity | ✅ | identity ΔRev=0.00% |
| T04 Budget optimizer | ✅ | budget_err=0.00%, uplift=+51% |
| T05 Noise robustness | ✅ | R²=0.72 at 50% noise |
| T06 Short series | ✅ | R²=0.90 at n=52 |
| T07 High collinearity | ✅ | R²=0.99, all coefs ≥ 0 |
| T08 No controls | ✅ | R²=0.42 |
| T09 Seasonality | ✅ | +23pp R² with Fourier |
| T10 Benchmark | ✅ | +18pp vs linear, +110pp vs mean |
| T11 ROI monotonicity | ✅ | 0 violations |
| T12 OOS prediction | ✅ | R²_oos=0.91 |
| T13 Scenario modes | ✅ | identity err <0.001% |
| T14 Single channel | ✅ | fits cleanly |
| T15 Decomp identity | ✅ | max_err=0.000 |
