from setuptools import setup, find_packages
setup(
    name="causal_mmm",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["numpy>=1.24", "scipy>=1.10", "scikit-learn>=1.2", "pandas>=1.5"],
    python_requires=">=3.9",
    description="Causal Marketing Mix Model — sklearn-compatible",
    author="causal_mmm",
)
