"""
causal_mmm.diagnostics
~~~~~~~~~~~~~~~~~~~~~~
Comprehensive test & benchmark suite for CausalMMM.

14 tests covering:
  parameter recovery · all transform combos · scenario correctness
  budget optimizer · noise robustness · short series · high collinearity
  seasonality · benchmark vs naive baselines · OOS prediction
  ROI monotonicity · scenario modes · single channel · contribution decomp

Run:
    python -m causal_mmm.diagnostics          # full
    python -m causal_mmm.diagnostics --fast   # quick subset
"""
from __future__ import annotations
import time, traceback, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

__all__ = ["run_diagnostics", "DiagnosticResult"]


# ──────────────────────────────  DATA FACTORY  ─────────────────────────────

def _make_data(n=156, seed=42, noise_pct=0.05, channel_corr=0.0,
               adstock_alphas=(0.70, 0.30, 0.10),
               sat_alphas=(2.0, 1.5, 1.0),
               sat_gammas=(0.40, 0.50, 0.60),
               coefs=(1200., 800., 400.),
               baseline=3000., with_seasonality=False):
    from causal_mmm.transforms import geometric_adstock, hill_saturation
    rng = np.random.default_rng(seed)
    t   = np.arange(n, dtype=float)
    nc  = len(coefs)

    if channel_corr > 0:
        common = rng.normal(0, 1, n)
        w = channel_corr ** 0.5
        spends = [np.abs(rng.normal(300, 80, n) + w * common * 200) for _ in range(nc)]
    else:
        means = [500, 300, 100, 200, 150][:nc]
        stds  = [150, 100,  40,  80,  60][:nc]
        spends = [np.abs(rng.normal(m, s, n)) for m, s in zip(means, stds)]

    ch_names = [f"ch{i+1}" for i in range(nc)]
    media_c  = np.zeros(n)
    for x, aa, sa, sg, c in zip(spends, adstock_alphas, sat_alphas, sat_gammas, coefs):
        media_c += c * hill_saturation(geometric_adstock(x, aa), sa, sg)

    price   = rng.normal(50, 5, n)
    holiday = (rng.random(n) < 0.05).astype(float)
    ctrl_c  = -30. * price + 150. * holiday
    seas    = (200. * np.sin(2*np.pi*t/52) + 80. * np.cos(2*np.pi*t/26)
               if with_seasonality else 0.)

    signal  = baseline + media_c + ctrl_c + seas
    noise   = float(np.std(signal)) * noise_pct * rng.normal(0, 1, n)
    y       = signal + noise

    X = pd.DataFrame({ch: sp for ch, sp in zip(ch_names, spends)})
    X["price"]   = price
    X["holiday"] = holiday

    gt = dict(adstock_alphas=adstock_alphas, sat_alphas=sat_alphas,
              sat_gammas=sat_gammas, coefs=coefs, baseline=baseline,
              snr=float(np.std(signal)/(np.std(noise)+1e-8)))
    return X, y, gt


def _fit(X, y, ch, n_trials=80, cv_folds=3, n_jobs=1, **kw):
    """Lightweight fit: n_jobs=1 by default to avoid MP overhead in tests."""
    from causal_mmm import CausalMMM
    mmm = CausalMMM(
        media_channels=ch,
        control_vars=kw.get("control_vars", []),
        adstock_type=kw.get("adstock_type", "geometric"),
        saturation_type=kw.get("saturation_type", "hill"),
        ridge_alpha=kw.get("ridge_alpha", 1.0),
        n_trials=n_trials, cv_folds=cv_folds,
        n_jobs=n_jobs, verbose=False,
    )
    mmm.fit(X, y)
    return mmm


# ──────────────────────────────  RESULT  ───────────────────────────────────

@dataclass
class DiagnosticResult:
    name: str
    passed: bool
    duration_s: float
    metrics: Dict = field(default_factory=dict)
    notes: str = ""
    error: str = ""

    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        m = "  ".join(
            f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}"
            for k, v in self.metrics.items()
        )
        return f"{status}  [{self.duration_s:5.1f}s]  {self.name:<48}  {m}"


def _run(name, fn):
    t0 = time.perf_counter()
    try:
        metrics, notes = fn()
        passed = metrics.pop("__pass__", True)
        return DiagnosticResult(name, passed, time.perf_counter()-t0, metrics, notes)
    except Exception as e:
        return DiagnosticResult(name, False, time.perf_counter()-t0,
                                error=f"{type(e).__name__}: {e}\n{traceback.format_exc()}")


# ──────────────────────────────  TESTS  ────────────────────────────────────

def T01_parameter_recovery():
    """Alpha recovery + coef sign + in-sample R²."""
    X, y, gt = _make_data(n=156, noise_pct=0.04, seed=42)
    ch   = ["ch1","ch2","ch3"]
    ctrl = ["price","holiday"]
    mmm  = _fit(X[ch+ctrl], y, ch, n_trials=250, cv_folds=5,
                control_vars=ctrl, n_jobs=1)
    errs = [abs(mmm.channel_params_[c]["adstock"]["alpha"] - gt["adstock_alphas"][i])
            for i, c in enumerate(ch)]
    mae_alpha   = float(np.mean(errs))
    coef_pos    = all(float(mmm.coef_[i]) >= 0 for i in range(len(ch)))
    price_neg   = float(mmm.coef_[len(ch)]) < 0      # price coef should be negative
    return {
        "__pass__": mae_alpha < 0.22 and coef_pos and mmm.r2_ > 0.80,
        "r2": mmm.r2_, "mape": mmm.mape_, "cv_smape": mmm.cv_score_,
        "mae_alpha": mae_alpha, "coef_pos": int(coef_pos), "price_neg": int(price_neg),
    }, f"true_alphas={gt['adstock_alphas']}"


def T02_transform_combos():
    """All 9 adstock×saturation combos must fit without error and R²>0.20."""
    from causal_mmm.transforms import ADSTOCK_TYPES, SATURATION_TYPES
    X, y, _ = _make_data(n=130, noise_pct=0.08, seed=11)
    ch = ["ch1","ch2","ch3"]
    results = {}
    for ads in ADSTOCK_TYPES:
        for sat in SATURATION_TYPES:
            k = f"{ads}×{sat}"
            try:
                m = _fit(X[ch], y, ch, adstock_type=ads, saturation_type=sat,
                         n_trials=60, cv_folds=3, n_jobs=1)
                results[k] = round(m.r2_, 3)
            except Exception as e:
                results[k] = -9.0
    min_r2 = min(results.values())
    return {
        "__pass__": min_r2 > 0.20 and len(results) == 9,
        "n_combos": len(results), "min_r2": min_r2,
        "mean_r2": round(float(np.mean(list(results.values()))),3),
    }, "  ".join(f"{k}:{v}" for k,v in results.items())


def T03_scenario_monotonicity():
    """Revenue must increase monotonically with spend: double > 1x > half > 0."""
    X, y, _ = _make_data(n=130, seed=99)
    ch   = ["ch1","ch2"]
    ctrl = ["price","holiday"]
    mmm  = _fit(X[ch+ctrl], y, ch, n_trials=100, cv_folds=4, control_vars=ctrl, n_jobs=1)

    deltas = {m: mmm.scenario({"ch1": v}).attrs["delta_revenue"]
              for m, v in [("x2",2.0),("x1",1.0),("x0.5",0.5),("x0",0.0)]}

    monotone   = deltas["x2"] > deltas["x1"] > deltas["x0.5"] > deltas["x0"]
    identity   = abs(deltas["x1"]) < abs(mmm.contributions_["fitted"].sum()) * 0.001
    double_pos = deltas["x2"] > 0
    zero_neg   = deltas["x0"] < 0

    return {
        "__pass__": monotone and double_pos and zero_neg and identity,
        "Δx2": round(deltas["x2"],1), "Δx1": round(deltas["x1"],2),
        "Δx0.5": round(deltas["x0.5"],1), "Δx0": round(deltas["x0"],1),
        "monotone": int(monotone), "identity_ok": int(identity),
    }, ""


def T04_budget_optimizer():
    """Optimizer must conserve budget within 0.5% and generate revenue uplift."""
    X, y, _ = _make_data(n=130, seed=77)
    ch   = ["ch1","ch2","ch3"]
    ctrl = ["price","holiday"]
    mmm  = _fit(X[ch+ctrl], y, ch, n_trials=100, cv_folds=4, control_vars=ctrl, n_jobs=1)

    budget = 300_000.
    alloc  = mmm.optimize_budget(budget, n_restarts=15)
    total  = float(alloc["optimal_spend"].sum())
    err_pct = abs(total - budget) / budget * 100

    return {
        "__pass__": err_pct < 0.5 and alloc.attrs["revenue_uplift"] > 0,
        "budget_err_pct": round(err_pct, 4),
        "uplift_pct": round(alloc.attrs["revenue_uplift_pct"], 2),
        "all_nonneg": int(bool((alloc["optimal_spend"] >= -1).all())),
    }, f"target={budget:,.0f}  allocated={total:,.0f}"


def T05_noise_robustness():
    """R² must degrade gracefully (not crash) across noise levels 5%→50%."""
    X0, _, _ = _make_data(n=130, seed=55)
    ch, ctrl = ["ch1","ch2"], ["price","holiday"]
    r2s = {}
    for pct in [0.05, 0.15, 0.30, 0.50]:
        _, y, _ = _make_data(n=130, noise_pct=pct, seed=55)
        m = _fit(X0[ch+ctrl], y, ch, n_trials=70, cv_folds=3, control_vars=ctrl, n_jobs=1)
        r2s[pct] = round(m.r2_, 3)
    all_finite  = all(np.isfinite(v) for v in r2s.values())
    all_pos_low = r2s[0.05] > 0.50
    return {
        "__pass__": all_finite and all_pos_low,
        "r2_5pct": r2s[0.05], "r2_15pct": r2s[0.15],
        "r2_30pct": r2s[0.30], "r2_50pct": r2s[0.50],
    }, ""


def T06_short_series():
    """Must fit on 52/78/104 week series without errors."""
    ch, ctrl = ["ch1","ch2"], ["price","holiday"]
    r2s = {}
    for n in [52, 78, 104]:
        X, y, _ = _make_data(n=n, coefs=(1200.,800.), adstock_alphas=(0.7,0.3),
                              sat_alphas=(2.,1.5), sat_gammas=(0.4,0.5), seed=7)
        m = _fit(X[ch+ctrl], y, ch, n_trials=50, cv_folds=3, control_vars=ctrl, n_jobs=1)
        r2s[n] = round(m.r2_, 3)
    return {
        "__pass__": all(v > -0.5 for v in r2s.values()),
        "r2_52": r2s[52], "r2_78": r2s[78], "r2_104": r2s[104],
    }, ""


def T07_high_collinearity():
    """Non-negativity constraint + Ridge must handle ρ=0.85 correlation."""
    X, y, _ = _make_data(n=156, channel_corr=0.85, seed=55)
    ch, ctrl = ["ch1","ch2","ch3"], ["price","holiday"]
    mmm = _fit(X[ch+ctrl], y, ch, n_trials=100, cv_folds=4, control_vars=ctrl, n_jobs=1)
    coef_pos = all(float(mmm.coef_[i]) >= 0 for i in range(len(ch)))
    finite   = bool(np.all(np.isfinite(mmm.coef_)))
    return {
        "__pass__": coef_pos and finite and mmm.r2_ > 0.15,
        "r2": round(mmm.r2_,3), "coef_pos": int(coef_pos), "finite": int(finite),
    }, ""


def T08_no_controls():
    """Must fit without any control variables."""
    X, y, _ = _make_data(n=130, seed=13)
    ch = ["ch1","ch2","ch3"]
    mmm = _fit(X[ch], y, ch, n_trials=70, cv_folds=3, n_jobs=1)
    return {
        "__pass__": np.isfinite(mmm.r2_) and mmm.r2_ > 0.0,
        "r2": round(mmm.r2_,3), "mape": round(mmm.mape_,2),
    }, ""


def T09_seasonality():
    """Fourier terms should improve R² on seasonally-driven data."""
    from causal_mmm.seasonality import SeasonalityFeatures
    X, y, _ = _make_data(n=156, with_seasonality=True, noise_pct=0.04, seed=88)
    ch, ctrl = ["ch1","ch2","ch3"], ["price","holiday"]

    mmm_base = _fit(X[ch+ctrl], y, ch, control_vars=ctrl, n_trials=80, cv_folds=3, n_jobs=1)

    sf   = SeasonalityFeatures({"annual":(52,3),"quarterly":(13,2)}, trend="linear")
    Xs   = sf.fit_transform(n_periods=len(y))
    Xaug = pd.concat([X[ch+ctrl].reset_index(drop=True), Xs], axis=1)
    ctrl_aug = ctrl + list(Xs.columns)
    mmm_seas = _fit(Xaug, y, ch, control_vars=ctrl_aug, n_trials=80, cv_folds=3, n_jobs=1)

    r2_imp = mmm_seas.r2_ - mmm_base.r2_
    return {
        "__pass__": r2_imp > -0.05,       # tolerance: must not hurt by more than 5pp
        "r2_base": round(mmm_base.r2_,3), "r2_seas": round(mmm_seas.r2_,3),
        "r2_delta": round(r2_imp,3),
    }, ""


def T10_benchmark_vs_naive():
    """CausalMMM must beat mean-predictor and no-adstock linear by clear margins."""
    from causal_mmm.optimization import solve_linear
    X, y, _ = _make_data(n=156, noise_pct=0.07, seed=42)
    ch, ctrl = ["ch1","ch2","ch3"], ["price","holiday"]
    from sklearn.model_selection import TimeSeriesSplit
    tss    = TimeSeriesSplit(n_splits=5, test_size=26)
    splits = list(tss.split(np.arange(len(y))))

    def cv_r2(pred_fn):
        r2s = []
        for tr, va in splits:
            yp = pred_fn(tr, va)
            ss_r = np.sum((y[va]-yp)**2); ss_t = np.sum((y[va]-y[va].mean())**2)
            r2s.append(1.0 - ss_r/(ss_t+1e-8))
        return float(np.mean(r2s))

    Xm = X[ch+ctrl].to_numpy(float)
    def naive_mean(tr, va): return np.full(len(va), y[tr].mean())
    def linear_raw(tr, va):
        c = solve_linear(Xm[tr,:len(ch)], Xm[tr,len(ch):], y[tr], 1.)
        n_c = len(ctrl); ones = np.ones((len(va),1))
        Xv  = np.hstack([Xm[va,:len(ch)], Xm[va,len(ch):], ones])
        return Xv @ c

    mmm     = _fit(X[ch+ctrl], y, ch, control_vars=ctrl, n_trials=200, cv_folds=5, n_jobs=1)
    r2_mean = cv_r2(naive_mean)
    r2_lin  = cv_r2(linear_raw)
    r2_mmm  = mmm.r2_

    beats_mean = r2_mmm > max(r2_mean, 0.) + 0.10
    beats_lin  = r2_mmm > r2_lin          + 0.03

    return {
        "__pass__": beats_mean and beats_lin,
        "r2_naive_mean": round(r2_mean,3), "r2_linear_noads": round(r2_lin,3),
        "r2_causal_mmm": round(r2_mmm,3),
        "beats_mean": int(beats_mean), "beats_linear": int(beats_lin),
    }, ""


def T11_roi_monotonicity():
    """ROI curves must be non-decreasing (diminishing returns → slope ≥ 0)."""
    X, y, _ = _make_data(n=130, seed=33)
    ch, ctrl = ["ch1","ch2"], ["price","holiday"]
    mmm = _fit(X[ch+ctrl], y, ch, control_vars=ctrl, n_trials=80, cv_folds=3, n_jobs=1)
    issues = 0
    for c, df in mmm.roi_curves().items():
        diffs = np.diff(df["contribution"].to_numpy())
        issues += int(np.any(diffs < -0.5))   # tiny tolerance
    return {
        "__pass__": issues == 0,
        "channels_checked": 2, "violations": issues,
    }, ""


def T12_oos_prediction():
    """OOS prediction must be finite and plausible."""
    X, y, _ = _make_data(n=180, seed=21)
    ch, ctrl = ["ch1","ch2","ch3"], ["price","holiday"]
    mmm = _fit(X.iloc[:130][ch+ctrl], y[:130], ch, control_vars=ctrl,
               n_trials=120, cv_folds=4, n_jobs=1)
    yp  = mmm.predict(X.iloc[130:][ch+ctrl])
    y_t = y[130:]
    ss_r = np.sum((y_t-yp)**2); ss_t = np.sum((y_t-y_t.mean())**2)
    r2_oos = float(1-ss_r/(ss_t+1e-8))
    return {
        "__pass__": bool(np.all(np.isfinite(yp))) and r2_oos > -1.,
        "r2_train": round(mmm.r2_,3), "r2_oos": round(r2_oos,3),
        "finite": int(bool(np.all(np.isfinite(yp)))),
    }, f"OOS window = {len(y_t)} periods"


def T13_scenario_modes():
    """Identity ops (×1.0, +0, absolute=current) must produce ~zero ΔRevenue."""
    X, y, _ = _make_data(n=130, seed=44)
    ch, ctrl = ["ch1","ch2"], ["price","holiday"]
    mmm = _fit(X[ch+ctrl], y, ch, control_vars=ctrl, n_trials=80, cv_folds=3, n_jobs=1)
    base = abs(mmm.contributions_["fitted"].sum())
    cur  = float(X["ch1"].sum())
    checks = {
        "mul×1":  abs(mmm.scenario({"ch1":1.0}).attrs["delta_revenue"]) / base,
        "delta+0":abs(mmm.scenario({"ch1":0.0}, mode="delta").attrs["delta_revenue"]) / base,
        "abs=cur":abs(mmm.scenario({"ch1":cur}, mode="absolute").attrs["delta_revenue"]) / base,
    }
    all_near_zero = all(v < 0.01 for v in checks.values())
    return {
        "__pass__": all_near_zero,
        **{k: round(v*100,4) for k,v in checks.items()},
    }, "values are % of baseline revenue"


def T14_single_channel():
    """Single-channel fit must complete without error."""
    X, y, _ = _make_data(n=104, coefs=(1200.,), adstock_alphas=(0.7,),
                         sat_alphas=(2.,), sat_gammas=(0.4,), seed=5)
    mmm = _fit(X[["ch1"]], y, ["ch1"], n_trials=60, cv_folds=3, n_jobs=1)
    return {
        "__pass__": np.isfinite(mmm.r2_) and float(mmm.coef_[0]) >= 0,
        "r2": round(mmm.r2_,3), "coef": round(float(mmm.coef_[0]),4),
    }, ""


def T15_contribution_sum():
    """Sum of contributions must equal fitted values (decomposition identity)."""
    X, y, _ = _make_data(n=130, seed=66)
    ch, ctrl = ["ch1","ch2","ch3"], ["price","holiday"]
    mmm = _fit(X[ch+ctrl], y, ch, control_vars=ctrl, n_trials=80, cv_folds=3, n_jobs=1)
    df  = mmm.contributions_
    recon_cols = ["baseline"] + ch + ctrl
    recon  = df[recon_cols].sum(axis=1)
    fitted = df["fitted"]
    max_err = float(np.max(np.abs(recon - fitted)))
    return {
        "__pass__": max_err < 1e-6,
        "max_reconstr_err": max_err,
        "r2": round(mmm.r2_, 3),
    }, "Decomposition identity: Σ contributions = fitted"


# ──────────────────────────────  SUITE  ────────────────────────────────────

ALL_TESTS = [
    ("T01 Parameter recovery",             T01_parameter_recovery),
    ("T02 All 9 transform combos",         T02_transform_combos),
    ("T03 Scenario monotonicity",          T03_scenario_monotonicity),
    ("T04 Budget optimizer feasibility",   T04_budget_optimizer),
    ("T05 Noise robustness sweep",         T05_noise_robustness),
    ("T06 Short series (52/78/104 wks)",   T06_short_series),
    ("T07 High channel collinearity",      T07_high_collinearity),
    ("T08 No control variables",           T08_no_controls),
    ("T09 Seasonality Fourier features",   T09_seasonality),
    ("T10 Benchmark vs naive baselines",   T10_benchmark_vs_naive),
    ("T11 ROI curve monotonicity",         T11_roi_monotonicity),
    ("T12 OOS prediction",                 T12_oos_prediction),
    ("T13 Scenario modes (mul/delta/abs)", T13_scenario_modes),
    ("T14 Single channel edge case",       T14_single_channel),
    ("T15 Contribution decomp identity",   T15_contribution_sum),
]

FAST_SUBSET = [0, 2, 3, 5, 7, 10, 12, 13, 14]


def run_diagnostics(fast=False, verbose=True):
    tests  = [ALL_TESTS[i] for i in FAST_SUBSET] if fast else ALL_TESTS
    W      = 100
    header = f"  CausalMMM Diagnostic Suite — {'FAST' if fast else 'FULL'}  ({len(tests)} tests)"
    print("=" * W);  print(header);  print("=" * W)

    results, t0 = [], time.perf_counter()
    for name, fn in tests:
        print(f"  ⏳  {name} …", flush=True)
        res = _run(name, fn)
        results.append(res)
        print(f"  {str(res)}")
        if res.notes:
            print(f"      notes: {res.notes[:120]}")
        if not res.passed and res.error:
            for line in res.error.splitlines()[-6:]:
                print(f"      {line}")
        print()

    elapsed = time.perf_counter() - t0
    n_pass  = sum(r.passed for r in results)
    n_fail  = len(results) - n_pass

    print("=" * W)
    print(f"  {'✅ ALL PASSED' if n_fail==0 else f'❌ {n_fail} FAILED'} "
          f"  {n_pass}/{len(results)} passed  "
          f"  total: {elapsed:.1f}s")
    print("=" * W)
    return results


if __name__ == "__main__":
    fast = "--fast" in sys.argv
    results = run_diagnostics(fast=fast)
    sys.exit(0 if all(r.passed for r in results) else 1)
