"""
causal_mmm.transforms
~~~~~~~~~~~~~~~~~~~~~
Vectorized adstock and saturation transforms.

CRITICAL DESIGN NOTE — saturation normalisation
------------------------------------------------
Saturation functions normalize spend by a fixed reference (x_max_ref).
This reference is set to the MAX of the adstocked training series after fit,
ensuring that scenario/budget calls see the SAME saturation curve as training.

Without a fixed reference, doubling spend would double x.max() → x_norm stays
unchanged → ΔRevenue = 0 (wrong).  The reference anchors the curve.
"""

from __future__ import annotations

import numpy as np
from scipy.signal import lfilter, lfilter_zi, fftconvolve
from scipy.stats import weibull_min
from typing import Dict, Optional

__all__ = [
    "geometric_adstock",
    "weibull_adstock",
    "delayed_adstock",
    "apply_adstock",
    "hill_saturation",
    "logistic_saturation",
    "log_saturation",
    "apply_transforms",
    "compute_adstock_ref",
    "ADSTOCK_TYPES",
    "SATURATION_TYPES",
]

ADSTOCK_TYPES = ("geometric", "weibull", "delayed")
SATURATION_TYPES = ("hill", "logistic", "log")


# ─────────────────────────────  ADSTOCK  ──────────────────────────────────

def geometric_adstock(x: np.ndarray, alpha: float, zi_val: float = 0.0) -> np.ndarray:
    """Geometric adstock via IIR filter.  O(n).
    adstock[t] = x[t] + alpha * adstock[t-1]
    """
    alpha = float(np.clip(alpha, 0.0, 0.9999))
    zi = lfilter_zi([1.0], [1.0, -alpha]) * zi_val
    out, _ = lfilter([1.0], [1.0, -alpha], x.astype(np.float64), zi=zi)
    return out


def weibull_adstock(
    x: np.ndarray,
    shape: float,
    scale: float,
    max_lag: int = 13,
) -> np.ndarray:
    """Weibull-kernel adstock via FFT convolution.  O(n log n).
    shape < 1 → monotone decay;  shape > 1 → delayed peak.
    """
    lags = np.arange(1, max_lag + 1, dtype=np.float64)
    w = weibull_min.pdf(lags, c=float(max(shape, 1e-3)), scale=float(max(scale, 1e-3)))
    total = w.sum()
    if total < 1e-12:
        return x.copy().astype(np.float64)
    w = w / total
    kernel = np.concatenate([[0.0], w])   # causal: no instantaneous term
    return fftconvolve(x.astype(np.float64), kernel, mode="full")[: len(x)]


def delayed_adstock(x: np.ndarray, alpha: float, theta: int) -> np.ndarray:
    """Delayed geometric adstock: effect peaks theta periods after spend."""
    theta = int(max(0, theta))
    if theta == 0:
        return geometric_adstock(x, alpha)
    padded = np.concatenate([np.zeros(theta), x.astype(np.float64)])
    ads = geometric_adstock(padded, alpha)
    return ads[theta: theta + len(x)]


def apply_adstock(
    x: np.ndarray,
    adstock_type: str,
    adstock_params: Dict,
) -> np.ndarray:
    """Dispatch to the correct adstock function."""
    if adstock_type == "geometric":
        return geometric_adstock(x, adstock_params["alpha"])
    elif adstock_type == "weibull":
        return weibull_adstock(
            x, adstock_params["shape"], adstock_params["scale"],
            int(adstock_params.get("max_lag", 13)),
        )
    elif adstock_type == "delayed":
        return delayed_adstock(x, adstock_params["alpha"], int(adstock_params["theta"]))
    raise ValueError(f"Unknown adstock_type '{adstock_type}'")


def compute_adstock_ref(
    x: np.ndarray,
    adstock_type: str,
    adstock_params: Dict,
) -> float:
    """Return max of adstocked training series — used as saturation reference."""
    ads = apply_adstock(x, adstock_type, adstock_params)
    return float(max(float(ads.max()), 1e-12))


# ─────────────────────────────  SATURATION  ───────────────────────────────

def hill_saturation(
    x: np.ndarray,
    alpha: float,
    gamma: float,
    x_max_ref: Optional[float] = None,
) -> np.ndarray:
    """
    Hill (S-curve):  f(x) = x_norm^α / (x_norm^α + γ^α)

    x_norm = x / x_max_ref   (fixed training reference)
    gamma = half-saturation in normalised space ∈ (0, 1).
    """
    x = np.maximum(x, 0.0)
    ref = x_max_ref if x_max_ref is not None else float(x.max())
    if ref < 1e-12:
        return np.zeros_like(x)
    x_norm = x / ref
    a = float(max(alpha, 1e-3))
    g = float(np.clip(gamma, 1e-3, 1 - 1e-3))
    xa = np.power(x_norm, a)
    ga = g ** a
    return (xa / (xa + ga)).astype(np.float64)


def logistic_saturation(
    x: np.ndarray,
    lam: float,
    x_max_ref: Optional[float] = None,
) -> np.ndarray:
    """Logistic saturation: 1 − exp(−λ·x_norm)"""
    x = np.maximum(x, 0.0)
    ref = x_max_ref if x_max_ref is not None else float(x.max())
    if ref < 1e-12:
        return np.zeros_like(x)
    return (1.0 - np.exp(-float(max(lam, 1e-3)) * (x / ref))).astype(np.float64)


def log_saturation(
    x: np.ndarray,
    lam: float = 1.0,
    x_max_ref: Optional[float] = None,
) -> np.ndarray:
    """Logarithmic saturation: log(1 + λ·x_norm)"""
    x = np.maximum(x, 0.0)
    ref = x_max_ref if x_max_ref is not None else float(x.max())
    if ref < 1e-12:
        return np.zeros_like(x)
    return np.log1p(float(max(lam, 1e-3)) * (x / ref)).astype(np.float64)


# ─────────────────────────────  DISPATCHER  ───────────────────────────────

def apply_transforms(
    x: np.ndarray,
    adstock_type: str,
    adstock_params: Dict,
    saturation_type: str,
    saturation_params: Dict,
    adstock_zi: float = 0.0,
) -> np.ndarray:
    """
    Apply adstock → saturation to a single spend series.

    saturation_params may contain '_x_max_ref' (set after fit) to anchor
    the saturation curve to the training distribution.
    Without it, normalization uses current x.max() (fine during search,
    wrong for scenarios → always set after fit).
    """
    # ── Adstock ──────────────────────────────────────────
    if adstock_type == "geometric":
        x_ads = geometric_adstock(x, adstock_params["alpha"], zi_val=adstock_zi)
    elif adstock_type == "weibull":
        x_ads = weibull_adstock(
            x, adstock_params["shape"], adstock_params["scale"],
            int(adstock_params.get("max_lag", 13)),
        )
    elif adstock_type == "delayed":
        x_ads = delayed_adstock(x, adstock_params["alpha"], int(adstock_params["theta"]))
    else:
        raise ValueError(f"Unknown adstock_type '{adstock_type}'. Choose from {ADSTOCK_TYPES}.")

    # Fixed reference (set after fit; None during optimization → uses current max)
    ref = saturation_params.get("_x_max_ref", None)

    # ── Saturation ────────────────────────────────────────
    if saturation_type == "hill":
        return hill_saturation(x_ads, saturation_params["alpha"], saturation_params["gamma"], ref)
    elif saturation_type == "logistic":
        return logistic_saturation(x_ads, saturation_params["lam"], ref)
    elif saturation_type == "log":
        return log_saturation(x_ads, saturation_params.get("lam", 1.0), ref)
    else:
        raise ValueError(f"Unknown saturation_type '{saturation_type}'. Choose from {SATURATION_TYPES}.")
