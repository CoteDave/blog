"""
causal_mmm.optimization
~~~~~~~~~~~~~~~~~~~~~~~
Global hyperparameter search via scipy Differential Evolution.

Parallelism: ``workers=-1`` uses multiprocessing.Pool.
The objective must be top-level picklable → _DEObjective class (not a closure).

Bidirectional CV objective = mean(SMAPE_expanding, SMAPE_rolling).
Inner loop: constrained Ridge solved analytically by lsq_linear (BVLS).
"""

from __future__ import annotations

import warnings
from typing import Callable, Dict, List, Tuple

import numpy as np
from scipy.optimize import differential_evolution, lsq_linear
from sklearn.model_selection import TimeSeriesSplit

__all__ = ["optimize_params", "transform_media_matrix", "solve_linear"]


# ──────────────────────────────  LINEAR SOLVER  ────────────────────────────

def solve_linear(
    X_media_t: np.ndarray,
    X_control: np.ndarray,
    y: np.ndarray,
    ridge_alpha: float,
) -> np.ndarray:
    """
    Constrained Ridge:  min ‖Xβ−y‖² + α‖β‖²   s.t. β_media ≥ 0
    Returns coef = [β_media…|β_control…|intercept]
    """
    n, n_media = X_media_t.shape
    n_ctrl = X_control.shape[1] if X_control.ndim == 2 else 0
    n_total = n_media + n_ctrl + 1
    ones = np.ones((n, 1), dtype=np.float64)
    X_full = np.hstack([X_media_t, X_control, ones]) if n_ctrl > 0 else np.hstack([X_media_t, ones])
    sqrt_a = float(np.sqrt(max(ridge_alpha, 0.0)))
    reg = np.zeros(n_total); reg[:n_media + n_ctrl] = sqrt_a
    X_aug = np.vstack([X_full, np.diag(reg)])
    y_aug = np.concatenate([y, np.zeros(n_total)])
    lb = np.array([0.0] * n_media + [-np.inf] * (n_ctrl + 1))
    ub = np.full(n_total, np.inf)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = lsq_linear(X_aug, y_aug, bounds=(lb, ub), method="bvls", max_iter=3000)
    return res.x


# ──────────────────────────────  TRANSFORM MATRIX  ─────────────────────────

def transform_media_matrix(
    X_media: np.ndarray,
    media_channels: List[str],
    params: Dict,
    adstock_type: str,
    saturation_type: str,
    apply_fn: Callable,
) -> np.ndarray:
    n = X_media.shape[0]
    out = np.empty((n, len(media_channels)), dtype=np.float64)
    for i, ch in enumerate(media_channels):
        out[:, i] = apply_fn(
            X_media[:, i],
            adstock_type, params[ch]["adstock"],
            saturation_type, params[ch]["saturation"],
        )
    return out


# ──────────────────────────────  PARAM ENCODING  ───────────────────────────

def _build_bounds(
    media_channels: List[str],
    adstock_type: str,
    saturation_type: str,
) -> Tuple[List[Tuple[float, float]], List[str]]:
    bounds, names = [], []
    for ch in media_channels:
        if adstock_type == "geometric":
            bounds.append((0.0, 0.90)); names.append(f"{ch}__alpha")
        elif adstock_type == "weibull":
            bounds += [(0.1, 5.0), (0.1, 5.0)]
            names += [f"{ch}__wb_shape", f"{ch}__wb_scale"]
        elif adstock_type == "delayed":
            bounds += [(0.0, 0.90), (0.0, 6.0)]
            names += [f"{ch}__alpha", f"{ch}__theta"]
        if saturation_type == "hill":
            bounds += [(0.1, 5.0), (0.05, 0.95)]
            names += [f"{ch}__sat_alpha", f"{ch}__sat_gamma"]
        elif saturation_type in ("logistic", "log"):
            bounds.append((0.1, 20.0)); names.append(f"{ch}__sat_lam")
    return bounds, names


def _decode(x: np.ndarray, media_channels: List[str], adstock_type: str, saturation_type: str) -> Dict:
    params: Dict = {}
    idx = 0
    for ch in media_channels:
        ap: Dict = {}
        if adstock_type == "geometric":
            ap["alpha"] = float(x[idx]); idx += 1
        elif adstock_type == "weibull":
            ap["shape"] = float(x[idx]); idx += 1
            ap["scale"] = float(x[idx]); idx += 1
        elif adstock_type == "delayed":
            ap["alpha"] = float(x[idx]); idx += 1
            ap["theta"] = int(round(float(x[idx]))); idx += 1
        sp: Dict = {}
        if saturation_type == "hill":
            sp["alpha"] = float(x[idx]); idx += 1
            sp["gamma"] = float(x[idx]); idx += 1
        elif saturation_type in ("logistic", "log"):
            sp["lam"] = float(x[idx]); idx += 1
        params[ch] = {"adstock": ap, "saturation": sp}
    return params


# ──────────────────────────────  CV  ───────────────────────────────────────

def _smape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    return float(np.mean(np.where(denom > 1e-8, np.abs(y_true - y_pred) / denom, 0.0)))


def _build_splits(n: int, cv_folds: int, mode: str) -> List[Tuple[np.ndarray, np.ndarray]]:
    test_sz = max(1, n // (cv_folds + 1))
    tss = TimeSeriesSplit(n_splits=cv_folds, test_size=test_sz)
    splits = list(tss.split(np.arange(n)))
    if mode == "rolling":
        win = splits[0][0].size
        splits = [(np.arange(max(0, tr[-1] - win + 1), tr[-1] + 1), va) for tr, va in splits]
    return splits


def _score_splits(
    X_media, X_control, y, params, media_channels,
    adstock_type, saturation_type, ridge_alpha, splits, apply_fn,
) -> float:
    from causal_mmm.optimization import transform_media_matrix, solve_linear
    X_t = transform_media_matrix(X_media, media_channels, params, adstock_type, saturation_type, apply_fn)
    n_ctrl = X_control.shape[1] if X_control.ndim == 2 else 0
    smapes = []
    for tr, va in splits:
        coef = solve_linear(X_t[tr], X_control[tr], y[tr], ridge_alpha)
        ones = np.ones((len(va), 1))
        Xv = np.hstack([X_t[va], X_control[va], ones]) if n_ctrl > 0 else np.hstack([X_t[va], ones])
        smapes.append(_smape(y[va], Xv @ coef))
    return float(np.mean(smapes))


# ─────────────────────  PICKLABLE TOP-LEVEL OBJECTIVE  ─────────────────────

class _DEObjective:
    """
    Top-level callable so multiprocessing.Pool can pickle it.
    scipy DE with workers>1 requires a picklable function — a closure doesn't work.
    """
    def __init__(
        self,
        X_media, X_control, y,
        media_channels, adstock_type, saturation_type,
        ridge_alpha, splits_exp, splits_rol, apply_fn,
    ):
        self.X_media = X_media
        self.X_control = X_control
        self.y = y
        self.media_channels = media_channels
        self.adstock_type = adstock_type
        self.saturation_type = saturation_type
        self.ridge_alpha = ridge_alpha
        self.splits_exp = splits_exp
        self.splits_rol = splits_rol
        self.apply_fn = apply_fn

    def __call__(self, x: np.ndarray) -> float:
        params = _decode(x, self.media_channels, self.adstock_type, self.saturation_type)
        s_exp = _score_splits(
            self.X_media, self.X_control, self.y, params, self.media_channels,
            self.adstock_type, self.saturation_type, self.ridge_alpha,
            self.splits_exp, self.apply_fn,
        )
        s_rol = _score_splits(
            self.X_media, self.X_control, self.y, params, self.media_channels,
            self.adstock_type, self.saturation_type, self.ridge_alpha,
            self.splits_rol, self.apply_fn,
        )
        return (s_exp + s_rol) / 2.0


# ──────────────────────────────  MAIN ENTRY  ───────────────────────────────

def optimize_params(
    X_media: np.ndarray,
    X_control: np.ndarray,
    y: np.ndarray,
    media_channels: List[str],
    adstock_type: str,
    saturation_type: str,
    ridge_alpha: float,
    n_trials: int,
    cv_folds: int,
    n_jobs: int,
    apply_fn: Callable,
    verbose: bool = True,
) -> Tuple[Dict, float, object, Dict]:
    """
    Differential Evolution search — bidirectional CV objective.

    Returns (best_params, best_score, de_result, cv_detail).
    """
    n = len(y)
    splits_exp = _build_splits(n, cv_folds, "expanding")
    splits_rol = _build_splits(n, cv_folds, "rolling")
    bounds, _ = _build_bounds(media_channels, adstock_type, saturation_type)
    n_params = len(bounds)

    popsize = max(10, min(25, n_params * 4))
    maxiter = max(15, n_trials // popsize)

    if verbose:
        print(
            f"  DE optimizer: {n_params} dims  ·  pop={popsize}  ·  "
            f"max_gen={maxiter}  ·  max_evals≈{popsize * n_params * maxiter:,}"
        )

    from causal_mmm.transforms import apply_transforms as _at
    objective = _DEObjective(
        X_media=X_media, X_control=X_control, y=y,
        media_channels=media_channels,
        adstock_type=adstock_type,
        saturation_type=saturation_type,
        ridge_alpha=ridge_alpha,
        splits_exp=splits_exp,
        splits_rol=splits_rol,
        apply_fn=_at,   # always use module-level fn (picklable)
    )

    workers_val = n_jobs if n_jobs not in (0, 1) else 1

    result = differential_evolution(
        objective,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=1e-7,
        mutation=(0.5, 1.2),
        recombination=0.75,
        seed=42,
        polish=True,
        init="sobol",
        workers=workers_val,
        disp=False,
        updating="deferred",
    )

    best_params = _decode(result.x, media_channels, adstock_type, saturation_type)

    if verbose:
        print(f"  DE converged — best CV SMAPE: {result.fun:.5f}  (nfev={result.nfev:,})")

    # ── Detailed per-fold scoring for the winner ───────────────────────────
    from causal_mmm.transforms import apply_transforms
    X_t_best = transform_media_matrix(
        X_media, media_channels, best_params, adstock_type, saturation_type, apply_transforms
    )
    n_ctrl = X_control.shape[1] if X_control.ndim == 2 else 0

    def _fold_rows(splits, label):
        rows = []
        for k, (tr, va) in enumerate(splits):
            coef = solve_linear(X_t_best[tr], X_control[tr], y[tr], ridge_alpha)
            ones = np.ones((len(va), 1))
            Xv = (np.hstack([X_t_best[va], X_control[va], ones]) if n_ctrl > 0
                  else np.hstack([X_t_best[va], ones]))
            yp = Xv @ coef
            ss_res = float(np.sum((y[va] - yp) ** 2))
            ss_tot = float(np.sum((y[va] - y[va].mean()) ** 2))
            rows.append({
                "mode": label, "fold": k + 1,
                "train_size": int(len(tr)), "val_size": int(len(va)),
                "smape": float(_smape(y[va], yp)),
                "r2": float(1.0 - ss_res / (ss_tot + 1e-12)),
            })
        return rows

    cv_detail = {"folds": _fold_rows(splits_exp, "expanding") + _fold_rows(splits_rol, "rolling")}
    return best_params, float(result.fun), result, cv_detail
