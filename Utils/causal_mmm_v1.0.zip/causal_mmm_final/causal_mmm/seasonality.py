"""
causal_mmm.seasonality
~~~~~~~~~~~~~~~~~~~~~~
Automatic feature generation for trend, seasonality, and lags.

Design philosophy
-----------------
These are **deterministic** transforms of the time index (or of exogenous
series) that feed into X_control — i.e. they explain the *baseline* of the
KPI independently of media spend.

Components
----------
1. Trend          : linear, log, or piecewise-linear (breakpoints auto-detected
                    or user-supplied).  Captures long-run level changes.
2. Fourier        : K pairs of sin/cos at chosen periods (default: annual=52 and
                    quarterly=13 for weekly data).  Captures repeating seasonality
                    without over-parameterising.
3. Lag features   : shifted versions of control variables or y itself (AR terms).
                    Important when y has autocorrelation unexplained by media.
4. Holiday dummies: passed through unchanged (user supplies 0/1 columns).

Key difference vs Robyn/Meridian
---------------------------------
Robyn and Meridian require the user to hand-specify seasonality parameters and
rely on external decomposition (STL / Prophet).  Here seasonality is jointly
estimated inside the MMM fit via the same constrained Ridge, so media coefs are
automatically orthogonalised against seasonal patterns.

Usage
-----
>>> from causal_mmm.seasonality import SeasonalityFeatures
>>> sf = SeasonalityFeatures(
...     n_fourier_terms={"annual": 3, "quarterly": 2},
...     trend="linear",
...     ar_lags=[1, 2],
... )
>>> X_seas = sf.fit_transform(n_periods=156)
>>> # Then concatenate with your control variables:
>>> X_full = pd.concat([X_original_controls, X_seas], axis=1)
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union

__all__ = ["SeasonalityFeatures", "add_fourier_terms", "add_trend", "add_ar_lags"]


# ─────────────────────────────  PRIMITIVE BUILDERS  ────────────────────────

def add_fourier_terms(
    n: int,
    period: float,
    k: int,
    t: Optional[np.ndarray] = None,
) -> pd.DataFrame:
    """
    Generate K Fourier sin/cos pairs for a given period.

    Parameters
    ----------
    n      : number of observations
    period : cycle length in same units as observations (e.g. 52 for yearly
             seasonality with weekly data)
    k      : number of Fourier pairs (harmonics).  k=1 → one sin+cos.
             Rule of thumb: k ≤ period/2.  Higher k → more flexible shape.
    t      : time index (0-based integers).  Default: np.arange(n).

    Returns
    -------
    DataFrame with columns  sin_p{period}_k{1..k}, cos_p{period}_k{1..k}
    """
    if t is None:
        t = np.arange(n, dtype=np.float64)
    else:
        t = np.asarray(t, dtype=np.float64)

    cols: Dict[str, np.ndarray] = {}
    for i in range(1, k + 1):
        angle = 2.0 * np.pi * i * t / float(period)
        cols[f"sin_p{int(period)}_k{i}"] = np.sin(angle)
        cols[f"cos_p{int(period)}_k{i}"] = np.cos(angle)
    return pd.DataFrame(cols)


def add_trend(
    n: int,
    kind: str = "linear",
    breakpoints: Optional[List[int]] = None,
    t: Optional[np.ndarray] = None,
) -> pd.DataFrame:
    """
    Generate trend feature(s).

    Parameters
    ----------
    n            : number of observations
    kind         : 'linear'     → single normalised linear slope
                   'log'        → log(1+t) trend (slower growth)
                   'piecewise'  → linear spline with given breakpoints
    breakpoints  : list of integer indices where slope can change (piecewise only)

    Returns
    -------
    DataFrame with one or more trend columns
    """
    if t is None:
        t = np.arange(n, dtype=np.float64)
    else:
        t = np.asarray(t, dtype=np.float64)

    t_norm = t / max(float(t.max()), 1.0)

    cols: Dict[str, np.ndarray] = {}
    if kind == "linear":
        cols["trend"] = t_norm
    elif kind == "log":
        cols["trend_log"] = np.log1p(t)
    elif kind == "piecewise":
        cols["trend"] = t_norm
        bps = sorted(set(breakpoints or []))
        for bp in bps:
            bp = int(bp)
            cols[f"trend_bp{bp}"] = np.where(t >= bp, (t - bp) / max(float(t.max()), 1.0), 0.0)
    else:
        raise ValueError(f"Unknown trend kind '{kind}'. Choose: linear, log, piecewise.")
    return pd.DataFrame(cols)


def add_ar_lags(
    y: np.ndarray,
    lags: List[int],
    fill: float = 0.0,
) -> pd.DataFrame:
    """
    Generate lagged AR features from y.

    Parameters
    ----------
    y    : target series (n,)
    lags : list of positive integers, e.g. [1, 2, 52]
    fill : value used for the initial unobserved periods

    Returns
    -------
    DataFrame with columns  y_lag{k} for k in lags
    """
    y = np.asarray(y, dtype=np.float64)
    n = len(y)
    cols: Dict[str, np.ndarray] = {}
    for k in lags:
        k = int(k)
        arr = np.full(n, fill, dtype=np.float64)
        if k < n:
            arr[k:] = y[:n - k]
        cols[f"y_lag{k}"] = arr
    return pd.DataFrame(cols)


def add_control_lags(
    X: pd.DataFrame,
    columns: List[str],
    lags: List[int],
    fill: float = 0.0,
) -> pd.DataFrame:
    """
    Add lagged versions of specific control columns.

    Returns
    -------
    DataFrame with new lag columns appended.
    """
    new_cols: Dict[str, np.ndarray] = {}
    n = len(X)
    for col in columns:
        x = X[col].to_numpy(dtype=np.float64)
        for k in lags:
            arr = np.full(n, fill, dtype=np.float64)
            if k < n:
                arr[k:] = x[:n - k]
            new_cols[f"{col}_lag{k}"] = arr
    return pd.concat([X, pd.DataFrame(new_cols, index=X.index)], axis=1)


# ─────────────────────────────  HIGH-LEVEL API  ────────────────────────────

class SeasonalityFeatures:
    """
    One-stop feature generator for trend + Fourier seasonality + AR lags.

    Generates deterministic features from the time index (and optionally y)
    that model the *non-media baseline* of the KPI.  These are meant to be
    concatenated with user-supplied control variables before passing to
    CausalMMM's ``control_vars``.

    Parameters
    ----------
    n_fourier_terms : dict
        {nickname: (period, k)} — multiple seasonalities supported.
        Preset shortcuts: ``'weekly'`` (period=7), ``'annual'`` (period=52),
        ``'quarterly'`` (period=13), ``'monthly'`` (period=4).
        Example: ``{'annual': (52, 3), 'quarterly': (13, 2)}``
        Passing ``{'annual': 3}`` uses int shorthand → auto-lookup period.
    trend : str or None
        'linear', 'log', 'piecewise', or None.
    trend_breakpoints : list[int], optional
        Breakpoint indices for piecewise trend.
    ar_lags : list[int], optional
        AR lags of y to include (requires calling fit_transform with y).
    data_freq : str
        'weekly' (default) or 'daily' or 'monthly'.
        Used to resolve named period shortcuts.

    Examples
    --------
    >>> sf = SeasonalityFeatures(
    ...     n_fourier_terms={'annual': (52, 3), 'quarterly': (13, 2)},
    ...     trend='linear',
    ... )
    >>> X_baseline = sf.fit_transform(n_periods=156)  # shape (156, 8)

    >>> # With AR lags (need y)
    >>> sf2 = SeasonalityFeatures(trend='linear', ar_lags=[1, 52])
    >>> X_baseline2 = sf2.fit_transform(n_periods=156, y=y_train)
    """

    PERIOD_LOOKUP = {
        "weekly":    ("weekly",    7),
        "annual":    ("annual",   52),
        "quarterly": ("quarterly",13),
        "biannual":  ("biannual", 26),
        "monthly":   ("monthly",   4),
    }

    def __init__(
        self,
        n_fourier_terms: Optional[Dict[str, Union[int, Tuple[float, int]]]] = None,
        trend: Optional[str] = "linear",
        trend_breakpoints: Optional[List[int]] = None,
        ar_lags: Optional[List[int]] = None,
        data_freq: str = "weekly",
    ):
        self.n_fourier_terms = n_fourier_terms or {"annual": (52, 3)}
        self.trend = trend
        self.trend_breakpoints = trend_breakpoints
        self.ar_lags = ar_lags or []
        self.data_freq = data_freq
        self.feature_names_: List[str] = []

    def fit_transform(
        self,
        n_periods: int,
        y: Optional[np.ndarray] = None,
        t: Optional[np.ndarray] = None,
    ) -> pd.DataFrame:
        """
        Generate all features for a sequence of ``n_periods`` observations.

        Parameters
        ----------
        n_periods : int
        y         : array-like (n_periods,) — required if ``ar_lags`` is set
        t         : custom time index (default: 0, 1, …, n−1)

        Returns
        -------
        pd.DataFrame  shape (n_periods, n_features)
        """
        parts: List[pd.DataFrame] = []

        # ── Trend ───────────────────────────────────────────────────
        if self.trend is not None:
            df_trend = add_trend(
                n_periods, kind=self.trend,
                breakpoints=self.trend_breakpoints, t=t,
            )
            parts.append(df_trend)

        # ── Fourier ──────────────────────────────────────────────────
        for name, spec in self.n_fourier_terms.items():
            if isinstance(spec, int):
                # shorthand: int → number of pairs, look up period
                k = spec
                period = self.PERIOD_LOOKUP.get(name, ("?", 52))[1]
            else:
                period, k = spec
            df_f = add_fourier_terms(n_periods, period=float(period), k=int(k), t=t)
            parts.append(df_f)

        # ── AR lags ──────────────────────────────────────────────────
        if self.ar_lags:
            if y is None:
                raise ValueError("ar_lags requires y to be passed to fit_transform().")
            df_ar = add_ar_lags(np.asarray(y), self.ar_lags)
            parts.append(df_ar)

        if not parts:
            return pd.DataFrame(np.zeros((n_periods, 0)))

        result = pd.concat(parts, axis=1).reset_index(drop=True)
        self.feature_names_ = list(result.columns)
        return result
