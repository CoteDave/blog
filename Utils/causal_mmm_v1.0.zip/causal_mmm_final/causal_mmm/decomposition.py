"""
causal_mmm.decomposition
~~~~~~~~~~~~~~~~~~~~~~~~
Revenue contribution decomposition and marginal ROI calculation.
"""

from __future__ import annotations

from typing import Callable, Dict, List

import numpy as np
import pandas as pd

__all__ = ["decompose_contributions", "marginal_roi", "roi_curves"]


def decompose_contributions(
    X_media_t: np.ndarray,
    X_control: np.ndarray,
    coef: np.ndarray,
    media_channels: List[str],
    control_vars: List[str],
    y: np.ndarray,
) -> pd.DataFrame:
    """
    Decompose fitted values into per-channel contributions.

    Output columns
    --------------
    baseline          : intercept contribution
    <channel_i>       : media contribution per period
    <control_j>       : control variable contribution per period
    fitted            : sum of all contributions
    actual            : y
    """
    n = X_media_t.shape[0]
    n_media = len(media_channels)
    n_ctrl = len(control_vars)
    coef_media = coef[:n_media]
    coef_ctrl = coef[n_media: n_media + n_ctrl] if n_ctrl else np.array([])
    intercept = coef[-1]

    df = pd.DataFrame(index=np.arange(n))
    df["baseline"] = intercept

    for i, ch in enumerate(media_channels):
        df[ch] = X_media_t[:, i] * coef_media[i]

    for i, cv in enumerate(control_vars):
        df[cv] = (X_control[:, i] if X_control.shape[1] > 0 else np.zeros(n)) * coef_ctrl[i]

    media_sum = df[media_channels].sum(axis=1) if media_channels else 0
    ctrl_sum = df[control_vars].sum(axis=1) if control_vars else 0
    df["fitted"] = df["baseline"] + media_sum + ctrl_sum
    df["actual"] = y

    return df


def marginal_roi(
    X_media: np.ndarray,
    coef: np.ndarray,
    channel_params: Dict,
    media_channels: List[str],
    adstock_type: str,
    saturation_type: str,
    apply_fn: Callable,
    eps_fraction: float = 0.01,
) -> pd.DataFrame:
    """
    Compute average and marginal ROI per channel at current spend levels.

    Method: numerical perturbation — uniformly add ε to all periods
    and measure ΔRevenue / ΔSpend.  Works for any transform combination.

    Returns
    -------
    DataFrame indexed by channel with columns:
      total_spend, total_contribution, avg_roi, marginal_roi
    """
    n_media = len(media_channels)
    coef_media = coef[:n_media]

    records = []
    for i, ch in enumerate(media_channels):
        x = X_media[:, i]
        eps = max(float(x.mean()) * eps_fraction, 1.0)

        x_t_base = apply_fn(x, adstock_type, channel_params[ch]["adstock"],
                            saturation_type, channel_params[ch]["saturation"])
        x_t_pert = apply_fn(x + eps, adstock_type, channel_params[ch]["adstock"],
                            saturation_type, channel_params[ch]["saturation"])

        contrib_base = float((x_t_base * coef_media[i]).sum())
        contrib_pert = float((x_t_pert * coef_media[i]).sum())

        total_spend = float(x.sum())
        delta_rev = contrib_pert - contrib_base
        delta_sp = eps * len(x)

        records.append(
            {
                "channel": ch,
                "total_spend": total_spend,
                "total_contribution": contrib_base,
                "avg_roi": contrib_base / total_spend if total_spend > 0 else 0.0,
                "marginal_roi": delta_rev / delta_sp,
                "coef": float(coef_media[i]),
            }
        )

    return pd.DataFrame(records).set_index("channel")


def roi_curves(
    X_media: np.ndarray,
    coef: np.ndarray,
    channel_params: Dict,
    media_channels: List[str],
    adstock_type: str,
    saturation_type: str,
    apply_fn: Callable,
    spend_multipliers: np.ndarray | None = None,
) -> Dict[str, pd.DataFrame]:
    """
    Compute ROI curves (revenue vs spend) for each channel.

    Parameters
    ----------
    spend_multipliers : array of multipliers to apply to current spend.
                        Default: np.linspace(0, 3, 31).

    Returns
    -------
    dict of {channel: DataFrame(spend, contribution, roi, marginal_roi)}
    """
    if spend_multipliers is None:
        spend_multipliers = np.linspace(0.0, 3.0, 61)

    n_media = len(media_channels)
    coef_media = coef[:n_media]
    curves: Dict[str, pd.DataFrame] = {}

    for i, ch in enumerate(media_channels):
        x_base = X_media[:, i]
        rows = []
        prev_contrib = 0.0
        prev_spend = 0.0
        for m in spend_multipliers:
            x_sc = x_base * m
            x_t = apply_fn(x_sc, adstock_type, channel_params[ch]["adstock"],
                           saturation_type, channel_params[ch]["saturation"])
            contrib = float((x_t * coef_media[i]).sum())
            spend = float(x_sc.sum())
            avg_roi = contrib / spend if spend > 0 else 0.0
            if spend > prev_spend:
                marg = (contrib - prev_contrib) / (spend - prev_spend)
            else:
                marg = avg_roi
            rows.append({"multiplier": m, "spend": spend, "contribution": contrib,
                          "avg_roi": avg_roi, "marginal_roi": marg})
            prev_contrib, prev_spend = contrib, spend
        curves[ch] = pd.DataFrame(rows)

    return curves
