"""
causal_mmm.model
~~~~~~~~~~~~~~~~
Main CausalMMM estimator — sklearn-compatible interface.
"""

from __future__ import annotations

import warnings
from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.utils.validation import check_is_fitted

from .transforms import apply_transforms, ADSTOCK_TYPES, SATURATION_TYPES
from .optimization import optimize_params, transform_media_matrix, solve_linear
from .decomposition import decompose_contributions, marginal_roi, roi_curves
from .scenarios import ScenarioEngine

__all__ = ["CausalMMM"]


class CausalMMM(BaseEstimator, RegressorMixin):
    """
    Causal Marketing Mix Model.

    Decomposes revenue into baseline + per-channel media contributions
    while estimating causal parameters (adstock, saturation) via
    bidirectional time-series cross-validation + Optuna TPE search.

    Parameters
    ----------
    media_channels : list[str]
        Column names of media spend variables in X.
    control_vars : list[str], optional
        Column names of control variables (price, holidays, trend, …).
        Controls are regularised but **not** constrained to be positive.
    adstock_type : {'geometric', 'weibull', 'delayed'}
        Carry-over model.
    saturation_type : {'hill', 'logistic', 'log'}
        Diminishing-returns model.
    ridge_alpha : float
        Ridge regularisation on linear coefficients.
    n_trials : int
        Optuna trials for transform hyperparameter search.
    cv_folds : int
        Number of time-series CV folds (used in both expanding + rolling).
    n_jobs : int
        Parallelism for Optuna (−1 = all cores).
    verbose : bool
        Show Optuna progress bar and fit summary.

    Attributes
    ----------
    coef_ : ndarray
        [media coefs … | control coefs … | intercept]
    channel_params_ : dict
        Best adstock + saturation params per channel.
    contributions_ : DataFrame
        Per-period decomposition: baseline, channels, controls, fitted, actual.
    cv_detail_ : dict
        Per-fold SMAPE + R² for expanding and rolling CV.
    study_ : optuna.Study
        Full Optuna study (inspect with study_.trials_dataframe()).
    r2_ : float
    mape_ : float
    cv_score_ : float

    Examples
    --------
    >>> import pandas as pd
    >>> from causal_mmm import CausalMMM
    >>>
    >>> mmm = CausalMMM(
    ...     media_channels=["tv", "digital", "radio"],
    ...     control_vars=["price", "holiday"],
    ...     adstock_type="geometric",
    ...     saturation_type="hill",
    ...     n_trials=300,
    ... )
    >>> mmm.fit(X_df, y)
    >>> print(mmm.summary())
    >>> print(mmm.marginal_roi())
    >>>
    >>> # What if we double TV spend?
    >>> result = mmm.scenario({"tv": 2.0})
    >>> print(result)
    >>> print(f"Revenue delta: {result.attrs['delta_revenue']:+,.0f}")
    >>>
    >>> # Find optimal allocation of $1 M
    >>> alloc = mmm.optimize_budget(1_000_000)
    >>> print(alloc)
    """

    def __init__(
        self,
        media_channels: List[str],
        control_vars: Optional[List[str]] = None,
        adstock_type: str = "geometric",
        saturation_type: str = "hill",
        ridge_alpha: float = 1.0,
        n_trials: int = 300,
        cv_folds: int = 5,
        n_jobs: int = -1,
        verbose: bool = True,
    ) -> None:
        self.media_channels = media_channels
        self.control_vars = control_vars or []
        self.adstock_type = adstock_type
        self.saturation_type = saturation_type
        self.ridge_alpha = ridge_alpha
        self.n_trials = n_trials
        self.cv_folds = cv_folds
        self.n_jobs = n_jobs
        self.verbose = verbose

    # ─────────────────────────  INPUT VALIDATION  ──────────────────────────

    def _parse_X(
        self, X: Union[pd.DataFrame, np.ndarray], y: Optional[np.ndarray] = None
    ):
        if isinstance(X, pd.DataFrame):
            missing = [c for c in self.media_channels + self.control_vars if c not in X.columns]
            if missing:
                raise ValueError(f"Missing columns in X: {missing}")
            X_media = X[self.media_channels].to_numpy(dtype=np.float64)
            X_ctrl = (
                X[self.control_vars].to_numpy(dtype=np.float64)
                if self.control_vars
                else np.empty((len(X), 0), dtype=np.float64)
            )
        else:
            X = np.asarray(X, dtype=np.float64)
            nm = len(self.media_channels)
            X_media = X[:, :nm]
            X_ctrl = X[:, nm:] if X.shape[1] > nm else np.empty((len(X), 0), dtype=np.float64)

        if not np.all(np.isfinite(X_media)):
            raise ValueError("X_media contains NaN or Inf.")
        if y is not None:
            y = np.asarray(y, dtype=np.float64).ravel()
            if len(y) != len(X_media):
                raise ValueError(f"X ({len(X_media)}) and y ({len(y)}) length mismatch.")
            if not np.all(np.isfinite(y)):
                raise ValueError("y contains NaN or Inf.")

        return X_media, X_ctrl, y

    # ─────────────────────────  FIT  ───────────────────────────────────────

    def fit(self, X, y):
        """
        Fit the CausalMMM.

        Parameters
        ----------
        X : DataFrame or ndarray (n_samples, n_features)
            Must contain all media_channels and control_vars.
        y : array-like (n_samples,)
            Target (revenue, sales, etc.).

        Returns
        -------
        self
        """
        if self.adstock_type not in ADSTOCK_TYPES:
            raise ValueError(f"adstock_type must be one of {ADSTOCK_TYPES}")
        if self.saturation_type not in SATURATION_TYPES:
            raise ValueError(f"saturation_type must be one of {SATURATION_TYPES}")

        X_media, X_ctrl, y = self._parse_X(X, y)

        n_ch = len(self.media_channels)
        n_params_per_ch = {
            "geometric": 3,   # alpha + sat_alpha + sat_gamma (hill)
            "weibull": 4,
            "delayed": 4,
        }[self.adstock_type]
        total_params = n_ch * n_params_per_ch

        if self.verbose:
            print(
                f"\n{'─'*60}\n"
                f"  CausalMMM — fitting {n_ch} channels\n"
                f"  adstock: {self.adstock_type}  ·  saturation: {self.saturation_type}\n"
                f"  search space: ~{total_params} dims  ·  trials: {self.n_trials}\n"
                f"  CV: {self.cv_folds}-fold expanding + rolling (bidirectional)\n"
                f"{'─'*60}"
            )

        best_params, best_score, study, cv_detail = optimize_params(
            X_media=X_media,
            X_control=X_ctrl,
            y=y,
            media_channels=self.media_channels,
            adstock_type=self.adstock_type,
            saturation_type=self.saturation_type,
            ridge_alpha=self.ridge_alpha,
            n_trials=self.n_trials,
            cv_folds=self.cv_folds,
            n_jobs=self.n_jobs,
            apply_fn=apply_transforms,
            verbose=self.verbose,
        )

        self.cv_score_: float = best_score
        self.study_ = study
        self.cv_detail_: Dict = cv_detail

        # ── Anchor saturation normalisation to training distribution ──────────
        # After optimisation the params lack a fixed x_max_ref → saturation
        # would re-normalise by scenario-specific max → ΔRevenue = 0.
        # We inject _x_max_ref = max(adstocked training series) per channel.
        from .transforms import apply_adstock
        for ch in self.media_channels:
            i = self.media_channels.index(ch)
            ads = apply_adstock(X_media[:, i], self.adstock_type, best_params[ch]["adstock"])
            ref = float(max(float(ads.max()), 1e-12))
            best_params[ch]["saturation"]["_x_max_ref"] = ref

        self.channel_params_: Dict = best_params

        # Final fit on full data
        X_t = transform_media_matrix(
            X_media, self.media_channels, best_params,
            self.adstock_type, self.saturation_type, apply_transforms,
        )
        self.coef_ = solve_linear(X_t, X_ctrl, y, self.ridge_alpha)

        # Store raw data for scenarios / ROI
        self.X_media_: np.ndarray = X_media
        self.X_control_: np.ndarray = X_ctrl
        self.y_: np.ndarray = y
        self.X_media_t_: np.ndarray = X_t

        # Contribution decomposition
        self.contributions_: pd.DataFrame = decompose_contributions(
            X_t, X_ctrl, self.coef_,
            self.media_channels, self.control_vars, y,
        )

        # Metrics
        yp = self.contributions_["fitted"].to_numpy()
        ss_res = float(np.sum((y - yp) ** 2))
        ss_tot = float(np.sum((y - y.mean()) ** 2))
        self.r2_ = float(1.0 - ss_res / (ss_tot + 1e-12))
        self.mape_ = float(np.mean(np.abs((y - yp) / (np.abs(y) + 1e-8))) * 100)

        if self.verbose:
            print(
                f"\n  ✅  R² = {self.r2_:.4f}  ·  MAPE = {self.mape_:.2f}%  "
                f"·  CV SMAPE = {best_score:.4f}\n{'─'*60}\n"
            )

        return self

    # ─────────────────────────  PREDICT  ───────────────────────────────────

    def predict(self, X) -> np.ndarray:
        """
        Predict with fitted model.

        For **in-sample** data the result is identical to contributions_['fitted'].
        For **out-of-sample** data adstock is computed from scratch on X only
        (no warm-start from training history).  For warm-start OOS, pass the
        concatenated train+test series and slice the result.

        Parameters
        ----------
        X : DataFrame or ndarray (n_samples, n_features)

        Returns
        -------
        y_pred : ndarray (n_samples,)
        """
        check_is_fitted(self, ["coef_", "channel_params_"])
        X_media, X_ctrl, _ = self._parse_X(X)
        n = len(X_media)

        X_t = transform_media_matrix(
            X_media, self.media_channels, self.channel_params_,
            self.adstock_type, self.saturation_type, apply_transforms,
        )
        ones = np.ones((n, 1), dtype=np.float64)
        if X_ctrl.shape[1] > 0:
            X_full = np.hstack([X_t, X_ctrl, ones])
        else:
            X_full = np.hstack([X_t, ones])
        return X_full @ self.coef_

    # ─────────────────────────  ROI  ───────────────────────────────────────

    def marginal_roi(self) -> pd.DataFrame:
        """
        Compute average and marginal ROI for each media channel
        at current observed spend levels.

        Returns
        -------
        DataFrame(total_spend, total_contribution, avg_roi, marginal_roi, coef)
        """
        check_is_fitted(self)
        return marginal_roi(
            self.X_media_, self.coef_, self.channel_params_,
            self.media_channels, self.adstock_type, self.saturation_type,
            apply_transforms,
        )

    def roi_curves(self, spend_multipliers: Optional[np.ndarray] = None) -> Dict:
        """
        Return revenue-vs-spend curves for each channel.

        Parameters
        ----------
        spend_multipliers : array, default np.linspace(0, 3, 61)

        Returns
        -------
        dict of {channel: DataFrame(multiplier, spend, contribution, avg_roi, marginal_roi)}
        """
        check_is_fitted(self)
        return roi_curves(
            self.X_media_, self.coef_, self.channel_params_,
            self.media_channels, self.adstock_type, self.saturation_type,
            apply_transforms, spend_multipliers,
        )

    # ─────────────────────────  SCENARIO  ──────────────────────────────────

    def scenario(
        self,
        changes: Dict[str, float],
        mode: str = "multiplier",
        period_slice: Optional[slice] = None,
    ) -> pd.DataFrame:
        """
        What-if scenario: change spend on one or more channels.

        Parameters
        ----------
        changes : dict
            {channel_name: value}
        mode    : 'multiplier' | 'absolute' | 'delta'
            - multiplier : 2.0 = double spend, 0.5 = halve spend
            - absolute   : value is new TOTAL spend for the window
            - delta      : value is additional total spend (can be negative)
        period_slice : slice, optional
            Restrict to a sub-window, e.g. slice(52, 104).

        Returns
        -------
        DataFrame per channel with delta_contribution, incremental_roi.
        attrs carry scalar totals (baseline_revenue, delta_revenue, …).

        Examples
        --------
        >>> result = mmm.scenario({"tv": 2.0})                 # double TV
        >>> result = mmm.scenario({"tv": 0.5, "digital": 1.5}) # rebalance
        >>> result = mmm.scenario({"tv": 500_000}, mode="absolute")
        >>> result = mmm.scenario({"radio": -100_000}, mode="delta")
        """
        check_is_fitted(self)
        return ScenarioEngine(self).what_if(changes, mode=mode, period_slice=period_slice)

    def optimize_budget(
        self,
        total_budget: float,
        bounds: Optional[Dict[str, tuple]] = None,
        n_restarts: int = 15,
    ) -> pd.DataFrame:
        """
        Find the budget allocation that maximises media-driven revenue.

        Parameters
        ----------
        total_budget : float   Total spend to allocate.
        bounds : dict, optional  {channel: (min_spend, max_spend)}.
        n_restarts : int   Random restarts for the SLSQP optimiser.

        Returns
        -------
        DataFrame with current_spend, optimal_spend, delta_spend, pct columns.
        attrs carry revenue_uplift and revenue_uplift_pct.
        """
        check_is_fitted(self)
        return ScenarioEngine(self).optimize_budget(total_budget, bounds, n_restarts)

    # ─────────────────────────  SUMMARY  ───────────────────────────────────

    def summary(self, return_str: bool = False) -> Optional[str]:
        """
        Print a structured summary of the fitted model.

        Parameters
        ----------
        return_str : bool
            If True, return the string instead of printing it.
        """
        check_is_fitted(self)

        nc = len(self.media_channels)
        coef_media = self.coef_[:nc]
        coef_ctrl = self.coef_[nc: nc + len(self.control_vars)]
        intercept = float(self.coef_[-1])
        total_y = float(self.y_.sum())

        W = 70
        lines = [
            "=" * W,
            "  CausalMMM — Model Summary".center(W),
            "=" * W,
            f"  adstock      : {self.adstock_type}",
            f"  saturation   : {self.saturation_type}",
            f"  R²           : {self.r2_:.4f}",
            f"  MAPE         : {self.mape_:.2f}%",
            f"  CV SMAPE     : {self.cv_score_:.4f}  (bidirectional, {self.cv_folds}-fold)",
            "",
            "  Media Channels",
            "  " + "-" * (W - 2),
            f"  {'Channel':<18} {'Coef':>8}  {'Params':<30}  {'Contrib %':>9}",
            "  " + "-" * (W - 2),
        ]

        for i, ch in enumerate(self.media_channels):
            p = self.channel_params_[ch]
            ads_s = "  ".join(f"{k}={v:.3f}" for k, v in p["adstock"].items())
            sat_s = "  ".join(
                f"{k}={v:.3f}" for k, v in p["saturation"].items()
                if k != "_x_max_ref"
            )
            pstr = f"{ads_s}  |  {sat_s}"
            pct = self.contributions_[ch].sum() / total_y * 100
            lines.append(
                f"  {ch:<18} {coef_media[i]:>8.4f}  {pstr:<30}  {pct:>8.1f}%"
            )

        if self.control_vars:
            lines += [
                "",
                "  Control Variables",
                "  " + "-" * (W - 2),
                f"  {'Variable':<18} {'Coef':>8}",
                "  " + "-" * (W - 2),
            ]
            for i, cv in enumerate(self.control_vars):
                lines.append(f"  {cv:<18} {coef_ctrl[i]:>8.4f}")

        lines += [
            "",
            f"  Intercept    : {intercept:.4f}",
            "",
            "  Revenue Decomposition",
            "  " + "-" * (W - 2),
        ]
        bl_pct = self.contributions_["baseline"].sum() / total_y * 100
        lines.append(f"  {'Baseline':<18}  {bl_pct:>6.1f}%")
        for ch in self.media_channels:
            pct = self.contributions_[ch].sum() / total_y * 100
            lines.append(f"  {ch:<18}  {pct:>6.1f}%")
        if self.control_vars:
            ctrl_pct = sum(
                self.contributions_[cv].sum() for cv in self.control_vars
            ) / total_y * 100
            lines.append(f"  {'Controls (total)':<18}  {ctrl_pct:>6.1f}%")

        # CV fold table
        lines += [
            "",
            "  Bidirectional CV Detail",
            "  " + "-" * (W - 2),
            f"  {'Mode':<12}  {'Fold':>4}  {'Train':>7}  {'Val':>5}  {'SMAPE':>7}  {'R²':>6}",
            "  " + "-" * (W - 2),
        ]
        for row in self.cv_detail_["folds"]:
            lines.append(
                f"  {row['mode']:<12}  {row['fold']:>4}  {row['train_size']:>7}  "
                f"{row['val_size']:>5}  {row['smape']:>7.4f}  {row['r2']:>6.3f}"
            )

        lines.append("=" * W)
        text = "\n".join(lines)
        if return_str:
            return text
        print(text)
        return None

    # ─────────────────────────  PLOTS  ─────────────────────────────────────

    def plot_contributions(self, figsize=(15, 7), show: bool = True):
        """Stacked-area chart of contribution decomposition + residuals."""
        check_is_fitted(self)
        try:
            import matplotlib.pyplot as plt
            import matplotlib.cm as cm
        except ImportError:
            raise ImportError("pip install matplotlib")

        df = self.contributions_
        cols = ["baseline"] + self.media_channels + self.control_vars

        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [3, 1]}, sharex=True
        )

        colors = cm.tab20(np.linspace(0, 1, len(cols)))
        df[cols].plot.area(ax=ax1, color=colors, alpha=0.85, linewidth=0)
        ax1.plot(df["actual"].values, color="black", linewidth=1.5, label="Actual", zorder=10)
        ax1.set_title("Revenue Decomposition", fontsize=13, fontweight="bold")
        ax1.set_ylabel("Revenue")
        ax1.legend(loc="upper left", fontsize=8, ncol=3)
        ax1.grid(alpha=0.3)

        resid = df["actual"].values - df["fitted"].values
        ax2.bar(range(len(resid)), resid, color="steelblue", alpha=0.6, width=1.0)
        ax2.axhline(0, color="black", linewidth=0.8)
        ax2.set_title(
            f"Residuals  (R²={self.r2_:.3f}  MAPE={self.mape_:.1f}%)", fontsize=10
        )
        ax2.set_ylabel("Residual")
        ax2.grid(alpha=0.3)

        plt.tight_layout()
        if show:
            plt.show()
        return fig

    def plot_saturation_curves(self, figsize=(14, 4), show: bool = True):
        """Saturation curves with current operating point marked."""
        check_is_fitted(self)
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("pip install matplotlib")

        from .transforms import hill_saturation, logistic_saturation, log_saturation
        from .transforms import geometric_adstock, weibull_adstock, delayed_adstock

        nc = len(self.media_channels)
        fig, axes = plt.subplots(1, nc, figsize=figsize)
        if nc == 1:
            axes = [axes]

        for i, ch in enumerate(self.media_channels):
            ax = axes[i]
            x_raw = self.X_media_[:, i]
            p = self.channel_params_[ch]
            ref = p["saturation"].get("_x_max_ref", float(self.X_media_t_[:, i].max()))

            # Plot curve over [0, 2×ref] to show saturation beyond training range
            x_range = np.linspace(0, ref * 2.0, 300)

            if self.saturation_type == "hill":
                y_curve = hill_saturation(x_range, p["saturation"]["alpha"], p["saturation"]["gamma"], ref)
            elif self.saturation_type == "logistic":
                y_curve = logistic_saturation(x_range, p["saturation"]["lam"], ref)
            else:
                y_curve = log_saturation(x_range, p["saturation"].get("lam", 1.0), ref)

            ax.plot(x_range, y_curve, "b-", linewidth=2.2, label="Saturation curve")

            # Mark mean adstocked spend
            mean_ads = float(self.X_media_t_[:, i].mean())
            if self.saturation_type == "hill":
                y_op = float(hill_saturation(np.array([mean_ads]), p["saturation"]["alpha"], p["saturation"]["gamma"], ref)[0])
            elif self.saturation_type == "logistic":
                y_op = float(logistic_saturation(np.array([mean_ads]), p["saturation"]["lam"], ref)[0])
            else:
                y_op = float(log_saturation(np.array([mean_ads]), p["saturation"].get("lam", 1.0), ref)[0])

            ax.axvline(mean_ads, color="red", linestyle="--", alpha=0.7, label=f"Mean ({mean_ads:.0f})")
            ax.scatter([mean_ads], [y_op], color="red", s=60, zorder=10)
            ax.set_title(ch, fontweight="bold")
            ax.set_xlabel("Adstocked Spend")
            ax.set_ylabel("Saturation Index")
            ax.legend(fontsize=8)
            ax.grid(alpha=0.3)

        plt.suptitle(
            f"Saturation Curves — {self.saturation_type}", fontsize=12, fontweight="bold"
        )
        plt.tight_layout()
        if show:
            plt.show()
        return fig

    def plot_roi_curves(self, figsize=(14, 4), show: bool = True):
        """Revenue vs spend curves with current allocation marked."""
        check_is_fitted(self)
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("pip install matplotlib")

        curves = self.roi_curves()
        nc = len(self.media_channels)
        fig, axes = plt.subplots(1, nc, figsize=figsize)
        if nc == 1:
            axes = [axes]

        for i, ch in enumerate(self.media_channels):
            ax = axes[i]
            df = curves[ch]
            ax.plot(df["spend"], df["contribution"], "b-", linewidth=2, label="Revenue")
            ax2 = ax.twinx()
            ax2.plot(df["spend"], df["marginal_roi"], "r--", linewidth=1.5, alpha=0.8, label="mROI")
            ax2.set_ylabel("Marginal ROI", color="red")
            ax2.tick_params(axis="y", labelcolor="red")

            # Mark current spend
            cur_sp = float(self.X_media_[:, i].sum())
            ax.axvline(cur_sp, color="green", linestyle=":", alpha=0.8, label="Current spend")

            ax.set_title(ch, fontweight="bold")
            ax.set_xlabel("Total Spend")
            ax.set_ylabel("Revenue Contribution")
            ax.legend(fontsize=8, loc="upper left")
            ax.grid(alpha=0.3)

        plt.suptitle("ROI Curves by Channel", fontsize=12, fontweight="bold")
        plt.tight_layout()
        if show:
            plt.show()
        return fig

    def plot_scenario(self, result: pd.DataFrame, show: bool = True):
        """
        Visualise a scenario result (output of .scenario()).

        Parameters
        ----------
        result : DataFrame returned by mmm.scenario(...)
        """
        check_is_fitted(self)
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("pip install matplotlib")

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Spend comparison
        ax = axes[0]
        x = np.arange(len(result))
        w = 0.35
        ax.bar(x - w / 2, result["baseline_spend"], w, label="Baseline", color="steelblue", alpha=0.8)
        ax.bar(x + w / 2, result["scenario_spend"], w, label="Scenario", color="coral", alpha=0.8)
        ax.set_xticks(x)
        ax.set_xticklabels(result.index, rotation=30, ha="right")
        ax.set_title("Spend: Baseline vs Scenario", fontweight="bold")
        ax.set_ylabel("Total Spend")
        ax.legend()
        ax.grid(alpha=0.3, axis="y")

        # Contribution delta
        ax = axes[1]
        colors = ["green" if v >= 0 else "red" for v in result["delta_contribution"]]
        ax.bar(result.index, result["delta_contribution"], color=colors, alpha=0.8)
        ax.axhline(0, color="black", linewidth=0.8)
        dr = result.attrs.get("delta_revenue", 0)
        ax.set_title(
            f"Contribution Delta  (ΔRevenue = {dr:+,.0f})", fontweight="bold"
        )
        ax.set_ylabel("ΔContribution")
        ax.set_xticklabels(result.index, rotation=30, ha="right")
        ax.grid(alpha=0.3, axis="y")

        plt.tight_layout()
        if show:
            plt.show()
        return fig
