"""
causal_mmm
~~~~~~~~~~
Production-grade Causal Marketing Mix Model.

Sklearn-compatible API with:
  • Adstock: geometric, Weibull, delayed
  • Saturation: Hill, logistic, log
  • Causal effect isolation (non-negative Ridge, contribution decomposition)
  • Bidirectional time-series CV (expanding + rolling) via Optuna TPE
  • Scenario engine: what-if + budget optimiser
  • Full visualisation suite

Quick start
-----------
>>> from causal_mmm import CausalMMM
>>> mmm = CausalMMM(
...     media_channels=["tv", "digital", "radio"],
...     control_vars=["price", "holiday"],
...     adstock_type="geometric",
...     saturation_type="hill",
...     n_trials=300,
... )
>>> mmm.fit(X_df, y)
>>> mmm.summary()
>>> mmm.marginal_roi()
>>> mmm.scenario({"tv": 2.0})
>>> mmm.optimize_budget(1_000_000)
"""

from .model import CausalMMM
from .transforms import (
    geometric_adstock,
    weibull_adstock,
    delayed_adstock,
    hill_saturation,
    logistic_saturation,
    log_saturation,
    apply_transforms,
    ADSTOCK_TYPES,
    SATURATION_TYPES,
)
from .decomposition import decompose_contributions, marginal_roi, roi_curves
from .scenarios import ScenarioEngine

__version__ = "1.0.0"
__all__ = [
    "CausalMMM",
    "ScenarioEngine",
    # transforms
    "geometric_adstock",
    "weibull_adstock",
    "delayed_adstock",
    "hill_saturation",
    "logistic_saturation",
    "log_saturation",
    "apply_transforms",
    "ADSTOCK_TYPES",
    "SATURATION_TYPES",
    # decomposition utilities (for power users)
    "decompose_contributions",
    "marginal_roi",
    "roi_curves",
]

from .seasonality import SeasonalityFeatures, add_fourier_terms, add_trend, add_ar_lags
