"""
causal_mmm.scenarios
~~~~~~~~~~~~~~~~~~~~
What-if scenario engine and budget optimizer for CausalMMM.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.optimize import minimize

if TYPE_CHECKING:
    from .model import CausalMMM

__all__ = ["ScenarioEngine"]


class ScenarioEngine:
    """
    What-if scenarios and budget optimisation built on a fitted CausalMMM.

    All methods are **pure** with respect to the model — nothing is modified in-place.
    """

    def __init__(self, mmm: "CausalMMM") -> None:
        self._mmm = mmm

    # ─────────────────────────  WHAT-IF  ───────────────────────────────────

    def what_if(
        self,
        changes: Dict[str, float],
        mode: str = "multiplier",
        period_slice: Optional[slice] = None,
    ) -> pd.DataFrame:
        """
        Simulate the effect of changing media spend on one or more channels.

        Parameters
        ----------
        changes : dict
            {channel_name: value}
        mode    : str
            ``'multiplier'``  – 2.0 = double spend; 0.5 = halve spend.
            ``'absolute'``    – value is the NEW total spend for the window.
            ``'delta'``       – value is additional total spend (+ or –).
        period_slice : slice or None
            Restrict the scenario to a sub-window (e.g. ``slice(52, 104)``).

        Returns
        -------
        DataFrame indexed by channel with columns:
            baseline_spend, scenario_spend, delta_spend,
            baseline_contribution, scenario_contribution, delta_contribution,
            incremental_roi
        Plus DataFrame.attrs carrying totals (revenue_delta, etc.).
        """
        mmm = self._mmm
        sl = period_slice or slice(None)

        X_base = mmm.X_media_[sl].copy()
        X_ctrl = mmm.X_control_[sl]
        y_base = mmm.y_[sl]

        X_scen = X_base.copy()
        for ch, val in changes.items():
            if ch not in mmm.media_channels:
                raise ValueError(
                    f"Unknown channel '{ch}'. Available: {mmm.media_channels}"
                )
            idx = mmm.media_channels.index(ch)
            x = X_base[:, idx]

            if mode == "multiplier":
                X_scen[:, idx] = np.maximum(0, x * float(val))
            elif mode == "absolute":
                total = float(x.sum())
                ratio = float(val) / total if total > 0 else 0.0
                X_scen[:, idx] = np.maximum(0, x * ratio)
            elif mode == "delta":
                # distribute delta proportional to original pattern
                total = float(x.sum())
                if total > 0:
                    X_scen[:, idx] = np.maximum(0, x + x * float(val) / total)
                else:
                    X_scen[:, idx] = max(0.0, float(val)) / max(len(x), 1)
            else:
                raise ValueError(f"Unknown mode '{mode}'. Choose: multiplier, absolute, delta.")

        df_base = self._contributions(X_base, X_ctrl, y_base)
        df_scen = self._contributions(X_scen, X_ctrl, y_base)

        rows = []
        for ch in mmm.media_channels:
            i = mmm.media_channels.index(ch)
            bs = float(X_base[:, i].sum())
            ss = float(X_scen[:, i].sum())
            bc = float(df_base[ch].sum())
            sc = float(df_scen[ch].sum())
            ds = ss - bs
            dc = sc - bc
            iroi = dc / ds if abs(ds) > 1e-8 else np.nan
            rows.append(
                dict(
                    channel=ch,
                    baseline_spend=bs,
                    scenario_spend=ss,
                    delta_spend=ds,
                    baseline_contribution=bc,
                    scenario_contribution=sc,
                    delta_contribution=dc,
                    incremental_roi=iroi,
                    changed=ch in changes,
                )
            )

        result = pd.DataFrame(rows).set_index("channel")

        # Totals in attrs
        bl_rev = float(df_base["fitted"].sum())
        sc_rev = float(df_scen["fitted"].sum())
        result.attrs["baseline_revenue"] = bl_rev
        result.attrs["scenario_revenue"] = sc_rev
        result.attrs["delta_revenue"] = sc_rev - bl_rev
        result.attrs["delta_revenue_pct"] = (sc_rev - bl_rev) / (abs(bl_rev) + 1e-8) * 100
        result.attrs["baseline_total_spend"] = float(X_base.sum())
        result.attrs["scenario_total_spend"] = float(X_scen.sum())
        result.attrs["scenario_df_base"] = df_base
        result.attrs["scenario_df_scen"] = df_scen

        return result

    # ─────────────────────────  BUDGET OPTIMISER  ──────────────────────────

    def optimize_budget(
        self,
        total_budget: float,
        bounds: Optional[Dict[str, Tuple[float, float]]] = None,
        n_restarts: int = 15,
        seed: int = 42,
    ) -> pd.DataFrame:
        """
        Find the budget allocation that maximises total media revenue.

        Spend is distributed uniformly within each channel window (approximation
        suitable for planning; if spend is seasonal, the caller should use
        ``what_if`` with per-period changes instead).

        Parameters
        ----------
        total_budget : float   Total budget to allocate.
        bounds       : dict    {channel: (min_spend, max_spend)}.
        n_restarts   : int     Random SLSQP restarts for global coverage.
        seed         : int     RNG seed.

        Returns
        -------
        DataFrame indexed by channel with optimal allocation + expected uplift.
        """
        from .transforms import apply_transforms  # local import avoids circularity

        mmm = self._mmm
        nc = len(mmm.media_channels)
        n_periods = mmm.X_media_.shape[0]
        coef_media = mmm.coef_[:nc]

        if bounds is None:
            bnds = []
            for i in range(nc):
                cur = float(mmm.X_media_[:, i].sum())
                hi = max(cur * 4.0, total_budget * 0.8)
                bnds.append((0.0, min(hi, total_budget)))
        else:
            bnds = [bounds.get(ch, (0.0, total_budget)) for ch in mmm.media_channels]

        def neg_rev(spend_totals: np.ndarray) -> float:
            rev = 0.0
            for i, ch in enumerate(mmm.media_channels):
                x_u = np.full(n_periods, spend_totals[i] / n_periods)
                x_t = apply_transforms(
                    x_u,
                    mmm.adstock_type, mmm.channel_params_[ch]["adstock"],
                    mmm.saturation_type, mmm.channel_params_[ch]["saturation"],
                )
                rev += float(x_t.sum() * coef_media[i])
            return -rev

        def jac(spend_totals: np.ndarray, eps: float = 1e-4) -> np.ndarray:
            g = np.empty(nc)
            f0 = neg_rev(spend_totals)
            for j in range(nc):
                sp2 = spend_totals.copy()
                sp2[j] += eps
                g[j] = (neg_rev(sp2) - f0) / eps
            return g

        constraints = [{"type": "eq", "fun": lambda s: s.sum() - total_budget}]
        rng = np.random.default_rng(seed)

        best_val = np.inf
        best_x = None

        for _ in range(n_restarts):
            # Smart initialisation: Dirichlet weighted by current allocation
            cur = np.array([mmm.X_media_[:, i].sum() for i in range(nc)], dtype=float)
            cur = cur / cur.sum() if cur.sum() > 0 else np.ones(nc) / nc
            x0 = rng.dirichlet(cur * 5 + 0.1) * total_budget
            # Clip to bounds + rescale to satisfy constraint
            lo = np.array([b[0] for b in bnds])
            hi = np.array([b[1] for b in bnds])
            x0 = np.clip(x0, lo, hi)
            excess = x0.sum() - total_budget
            if abs(excess) > 0:
                # redistribute excess from largest channel
                order = np.argsort(-x0)
                for j in order:
                    adj = min(abs(excess), x0[j] - lo[j]) * np.sign(excess)
                    x0[j] -= adj
                    excess -= adj
                    if abs(excess) < 1e-8:
                        break

            res = minimize(
                neg_rev, x0, jac=jac,
                method="SLSQP",
                bounds=bnds,
                constraints=constraints,
                options={"ftol": 1e-10, "maxiter": 1000, "disp": False},
            )
            if res.fun < best_val:
                best_val = res.fun
                best_x = res.x.copy()

        opt = best_x if best_x is not None else np.array([total_budget / nc] * nc)
        cur_sp = np.array([mmm.X_media_[:, i].sum() for i in range(nc)])

        df = pd.DataFrame(
            {
                "channel": mmm.media_channels,
                "current_spend": cur_sp,
                "optimal_spend": opt,
                "delta_spend": opt - cur_sp,
                "current_pct": cur_sp / cur_sp.sum() * 100 if cur_sp.sum() > 0 else 0.0,
                "optimal_pct": opt / total_budget * 100,
            }
        ).set_index("channel")

        cur_rev = -neg_rev(cur_sp)
        opt_rev = -neg_rev(opt)
        df.attrs["current_revenue"] = cur_rev
        df.attrs["optimal_revenue"] = opt_rev
        df.attrs["revenue_uplift"] = opt_rev - cur_rev
        df.attrs["revenue_uplift_pct"] = (opt_rev - cur_rev) / (abs(cur_rev) + 1e-8) * 100
        df.attrs["total_budget"] = total_budget

        return df

    # ─────────────────────────  HELPERS  ───────────────────────────────────

    def _contributions(
        self,
        X_media: np.ndarray,
        X_control: np.ndarray,
        y: np.ndarray,
    ) -> pd.DataFrame:
        from .decomposition import decompose_contributions
        from .optimization import transform_media_matrix
        from .transforms import apply_transforms

        mmm = self._mmm
        X_t = transform_media_matrix(
            X_media,
            mmm.media_channels,
            mmm.channel_params_,
            mmm.adstock_type,
            mmm.saturation_type,
            apply_transforms,
        )
        return decompose_contributions(
            X_t, X_control, mmm.coef_,
            mmm.media_channels, mmm.control_vars,
            y,
        )
