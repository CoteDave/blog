"""
Analyse de Clusters v8
  • K-Means + DBSCAN — display_df ≤50k — ScatterGL WebGL
  • Hull convexe · silhouette · profile radar
  • NOUVEAU v8: Lasso select → panel Sélection vs Reste
    - Target : Cramér V + Chi² (classif) ou Welch t-test + Cohen d (régression)
    - Features : Mann-Whitney U + Cohen's d, forest plot + tableau coloré
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy.spatial import ConvexHull
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def _hex_alpha(h, a):
    h = h.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{a})"


def _hull_trace(x, y, color, name=""):
    pts = np.column_stack([x, y])
    pts = pts[~np.isnan(pts).any(axis=1)]
    if len(pts) < 3:
        return None
    try:
        hull = ConvexHull(pts)
        hx = np.append(pts[hull.vertices, 0], pts[hull.vertices[0], 0])
        hy = np.append(pts[hull.vertices, 1], pts[hull.vertices[0], 1])
        return go.Scatter(
            x=hx, y=hy, fill="toself",
            fillcolor=_hex_alpha(color, 0.13),
            line=dict(color=color, width=2, dash="dot"),
            mode="lines", name=f"Hull {name}",
            showlegend=False, hoverinfo="skip",
        )
    except Exception:
        return None


def layout(dep):
    num = dep.num_features
    return html.Div([
        html.Div("Analyse de Clusters", className="page-title"),
        html.Div(
            "K-Means · DBSCAN · hull convexe · silhouette · profile · "
            "⬅ lasso/box pour panel Sélection vs Reste.",
            className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Algorithme:", className="control-label"),
                      dcc.Dropdown(id="cl-algo",
                                   options=[{"label":"K-Means","value":"kmeans"},
                                            {"label":"DBSCAN", "value":"dbscan"}],
                                   value="kmeans", clearable=False,
                                   style={"width":"160px"})],
                     className="control-group", style={"maxWidth":"180px"}),
            html.Div([html.Div("K (K-Means):", className="control-label"),
                      dcc.Slider(id="cl-k", min=2, max=10, step=1, value=3,
                                 marks={i:str(i) for i in range(2,11)})],
                     className="control-group", style={"minWidth":"260px"}),
            html.Div([html.Div("Variables (PCA input):", className="control-label"),
                      dcc.Dropdown(id="cl-vars",
                                   options=[{"label":c,"value":c} for c in num],
                                   value=num[:min(10,len(num))], multi=True,
                                   style={"minWidth":"300px"})],
                     className="control-group"),
            html.Div([html.Div("Hull:", className="control-label"),
                      dcc.Dropdown(id="cl-hull",
                                   options=[{"label":"Convexe","value":"convex"},
                                            {"label":"Aucun",  "value":"none"}],
                                   value="convex", clearable=False,
                                   style={"width":"140px"})],
                     className="control-group", style={"maxWidth":"160px"}),
        ], className="controls-row"),

        # Scatter + lasso panel
        html.Div([
            html.Div([
                dcc.Loading(
                    dcc.Graph(id="cl-scatter",
                              config={"displayModeBar":True,
                                      "modeBarButtonsToAdd":["lasso2d","select2d"],
                                      "scrollZoom":True},
                              style={"height":"440px"}),
                    type="circle", color="#4472c4"),
                html.Div("Lasso / Box → panel de comparaison ➡",
                         style={"fontSize":"10.5px","color":"#9aa5b4","marginTop":"4px",
                                "textAlign":"center","fontStyle":"italic"}),
            ], className="chart-card", style={"flex":"1.5","minWidth":"0"}),

            html.Div(id="cl-lasso-panel", className="chart-card",
                     style={"flex":"1","minWidth":"280px","maxWidth":"460px",
                            "overflowY":"auto","maxHeight":"520px"}),
        ], style={"display":"flex","gap":"16px","marginBottom":"16px","alignItems":"flex-start"}),

        # Elbow + Silhouette
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-elbow",
                                            config={"displayModeBar":False},
                                            style={"height":"300px"}),
                                  type="circle",color="#4472c4")],
                     className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-sil",
                                            config={"displayModeBar":False},
                                            style={"height":"300px"}),
                                  type="circle",color="#4472c4")],
                     className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # Radar profile
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-profile",
                                            config={"displayModeBar":False},
                                            style={"height":"320px"}),
                                  type="circle",color="#4472c4")],
                     className="chart-card"),
        ]),

        # Store labels for O(1) lasso lookup
        dcc.Store(id="cl-labels-store"),
    ], className="page-card")


def register_callbacks(app, dep):

    # ── Main clustering callback ─────────────────────────────────────────────
    @app.callback(
        [Output("cl-scatter","figure"), Output("cl-elbow","figure"),
         Output("cl-sil","figure"),    Output("cl-profile","figure"),
         Output("cl-labels-store","data")],
        [Input("cl-k","value"), Input("cl-vars","value"),
         Input("cl-hull","value"), Input("cl-algo","value")],
    )
    def update(k, vars_sel, hull_mode, algo):
        from sklearn.cluster       import KMeans, DBSCAN
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler, MinMaxScaler
        from sklearn.metrics       import silhouette_samples
        from sklearn.neighbors     import NearestNeighbors

        algo = algo or "kmeans"
        empty = go.Figure()
        if not vars_sel or len(vars_sel) < 2:
            return empty, empty, empty, empty, None

        cols  = [c for c in vars_sel if c in dep.num_features]
        df    = dep.display_df
        X_raw = df[cols].fillna(df[cols].median()).values
        X     = StandardScaler().fit_transform(X_raw)

        # ── Clustering ────────────────────────────────────────────────
        if algo == "dbscan":
            nbrs = NearestNeighbors(n_neighbors=min(5,len(X)-1)).fit(X)
            dk, _ = nbrs.kneighbors(X)
            eps_auto = float(np.percentile(np.sort(dk[:,-1]), 85))
            db     = DBSCAN(eps=eps_auto,
                            min_samples=max(3,len(X)//60)).fit(X)
            labels = db.labels_
            n_cls  = len(set(labels)) - (1 if -1 in labels else 0)
            yd = np.sort(dk[:,-1])
            fig_elbow = go.Figure([go.Scatter(
                x=list(range(len(yd))), y=yd, mode="lines",
                line=dict(color="#4472c4",width=2),
                hovertemplate="idx=%{x}<br>dist=%{y:.4f}<extra></extra>")])
            fig_elbow.add_hline(y=eps_auto, line_dash="dash", line_color="#e74c3c",
                                annotation_text=f"ε={eps_auto:.3f}",
                                annotation_font_size=10)
            fig_elbow.update_layout(
                **_base(f"DBSCAN k-distance  |  ε={eps_auto:.3f}  →  {n_cls} clusters"),
                xaxis_title="Points triés",
                yaxis_title=f"k-NN distance (k={min(5,len(X)-1)})")
        else:
            max_k = min(11, len(X))
            ks, inertias = list(range(2,max_k)), []
            for ki in ks:
                km_i = KMeans(n_clusters=ki, random_state=42, n_init=5, max_iter=100)
                km_i.fit(X)
                inertias.append(km_i.inertia_)
            fig_elbow = go.Figure([go.Scatter(
                x=ks, y=inertias, mode="lines+markers",
                line=dict(color="#4472c4",width=2),
                marker=dict(size=8,color="#e07b39"),
                hovertemplate="K=%{x}<br>Inertie: %{y:,.0f}<extra></extra>")])
            fig_elbow.add_vline(x=k, line_dash="dash", line_color="#e74c3c",
                                annotation_text=f"K={k}", annotation_font_size=10)
            fig_elbow.update_layout(
                **_base("Courbe d'Inertie — Méthode du Coude"),
                xaxis_title="Nombre de clusters K", yaxis_title="Inertie")
            km     = KMeans(n_clusters=k, random_state=42, n_init=10, max_iter=200)
            labels = km.fit_predict(X)
            n_cls  = k

        # ── PCA 2D ────────────────────────────────────────────────────
        pca = PCA(n_components=2, random_state=42)
        X2  = pca.fit_transform(X)
        v1, v2 = pca.explained_variance_ratio_[:2] * 100

        fig_sc = go.Figure()
        unique_labels = [l for l in sorted(set(labels)) if l != -1]
        if -1 in labels:
            noise = X2[labels==-1]
            fig_sc.add_trace(go.Scattergl(
                x=noise[:,0], y=noise[:,1], mode="markers",
                name="Bruit (-1)", marker=dict(color="#aaa",size=5,opacity=0.5),
                hovertemplate="Bruit<br>PC1:%{x:.2f}<br>PC2:%{y:.2f}<extra></extra>"))

        for ci in unique_labels:
            mask = labels == ci
            clr  = PAL[ci % len(PAL)]
            n_c  = int(mask.sum())
            pt_idxs = np.where(mask)[0]
            fig_sc.add_trace(go.Scattergl(
                x=X2[mask,0], y=X2[mask,1], mode="markers",
                name=f"Cluster {ci}  (n={n_c:,})",
                marker=dict(color=clr,size=7,opacity=0.82,
                            line=dict(width=0.5,color="rgba(255,255,255,.6)")),
                customdata=pt_idxs,
                hovertemplate=(f"Cluster {ci}<br>PC1:%{{x:.2f}}<br>"
                               f"PC2:%{{y:.2f}}<extra></extra>")))
            if hull_mode == "convex" and n_c >= 3:
                h = _hull_trace(X2[mask,0], X2[mask,1], clr, str(ci))
                if h: fig_sc.add_trace(h)

        for ci in unique_labels:
            cx, cy = X2[labels==ci].mean(axis=0)
            fig_sc.add_trace(go.Scatter(
                x=[cx], y=[cy], mode="markers+text",
                marker=dict(symbol="x",size=13,color=PAL[ci%len(PAL)],
                            line=dict(width=2,color="white")),
                text=[str(ci)], textposition="top center",
                textfont=dict(size=11,color="white",family=FONT),
                showlegend=False, hoverinfo="skip"))

        fig_sc.update_layout(
            **_base(f"Clusters PCA 2D  |  PC1={v1:.1f}%  PC2={v2:.1f}%"),
            xaxis_title=f"PC1 ({v1:.1f}%)", yaxis_title=f"PC2 ({v2:.1f}%)",
            dragmode="lasso")

        # ── Silhouette ────────────────────────────────────────────────
        try:
            valid = (labels != -1)
            if len(set(labels[valid])) >= 2 and valid.sum() >= 4:
                # Cap silhouette at 5k points for speed (O(N²) memory)
                sil_idx  = np.arange(valid.sum())
                if len(sil_idx) > 5_000:
                    rng2 = np.random.default_rng(42)
                    sil_idx = rng2.choice(len(sil_idx), 5_000, replace=False)
                X_sil = X[valid][sil_idx]
                l_sil = labels[valid][sil_idx]
                sil_vals_full = silhouette_samples(X[valid], labels[valid])
                sil_vals = sil_vals_full
                sil_avg  = float(sil_vals.mean())
                fig_sil  = go.Figure()
                y_lo = 0
                for ci in unique_labels:
                    sil_ci = np.sort(sil_vals[labels[valid]==ci])
                    clr    = PAL[ci%len(PAL)]
                    y_hi   = y_lo + len(sil_ci)
                    fig_sil.add_trace(go.Bar(
                        x=sil_ci, y=list(range(y_lo,y_hi)),
                        orientation="h", name=f"Cls {ci}",
                        marker_color=clr, opacity=0.82,
                        hovertemplate=f"Cluster {ci}<br>Sil: %{{x:.3f}}<extra></extra>"))
                    y_lo = y_hi + 4
                fig_sil.add_vline(x=sil_avg, line_dash="dash", line_color="#e74c3c",
                                  annotation_text=f"moy={sil_avg:.3f}",
                                  annotation_font_size=10)
                fig_sil.update_layout(
                    **_base(f"Silhouette  |  score moyen = {sil_avg:.3f}"),
                    xaxis_title="Coefficient silhouette",
                    yaxis=dict(visible=False), showlegend=True)
            else:
                fig_sil = go.Figure()
        except Exception:
            fig_sil = go.Figure()

        # ── Profile radar ──────────────────────────────────────────────
        try:
            top_cols = cols[:min(8,len(cols))]
            from sklearn.preprocessing import MinMaxScaler
            X_norm = MinMaxScaler().fit_transform(
                df[top_cols].fillna(df[top_cols].median()).values)
            fig_prof = go.Figure()
            for ci in unique_labels:
                mask  = labels == ci
                means = X_norm[mask].mean(axis=0)
                theta = top_cols + [top_cols[0]]
                r     = list(means) + [means[0]]
                fig_prof.add_trace(go.Scatterpolar(
                    r=r, theta=theta, fill="toself",
                    name=f"Cluster {ci}", line_color=PAL[ci%len(PAL)],
                    opacity=0.8,
                    hovertemplate=f"Cluster {ci}<br>%{{theta}}: %{{r:.2f}}<extra></extra>"))
            fig_prof.update_layout(
                polar=dict(radialaxis=dict(visible=True,range=[0,1],
                                           gridcolor=GRID,tickfont=dict(size=9))),
                showlegend=True,
                title=dict(text="Profile Radar des clusters (normalisé)",
                           font=dict(size=12)),
                paper_bgcolor="#fff", font=dict(family=FONT,size=11),
                margin=dict(l=50,r=50,t=50,b=30),
                legend=dict(font=dict(size=11)))
        except Exception:
            fig_prof = go.Figure()

        return fig_sc, fig_elbow, fig_sil, fig_prof, {"labels": labels.tolist(), "cols": cols}


    # ── Lasso panel ─────────────────────────────────────────────────────────
    @app.callback(
        Output("cl-lasso-panel","children"),
        [Input("cl-scatter","selectedData"),
         Input("cl-labels-store","data")],
    )
    def lasso_panel(selected, store):
        if not selected or not selected.get("points") or not store:
            return _placeholder()

        idxs = []
        for pt in selected["points"]:
            cd = pt.get("customdata")
            if cd is not None:
                try: idxs.append(int(cd))
                except: pass

        if not idxs:
            return _placeholder()

        df      = dep.display_df.reset_index(drop=True)
        n_total = len(df)
        sel_set = set(idxs)
        rst_idx = [i for i in range(n_total) if i not in sel_set]
        if not rst_idx:
            return _placeholder()

        sel_df = df.iloc[sorted(sel_set)]
        rst_df = df.iloc[rst_idx]
        n_sel  = len(sel_df)
        n_rst  = len(rst_df)

        out = [
            html.Div([
                html.Span("🔍 Sélection Lasso",
                          style={"fontWeight":"800","color":"#1e3a5f","fontSize":"13px"}),
                html.Span(f"  {n_sel:,} pts  vs  {n_rst:,} reste",
                          style={"fontSize":"11px","color":"#6b7a8d","marginLeft":"6px"}),
            ], style={"marginBottom":"12px","paddingBottom":"10px",
                       "borderBottom":"2px solid #e0e4ea"}),
        ]

        # ── Target ────────────────────────────────────────────────────
        if dep.supervised:
            out.append(html.Div("🎯 Target — Sélection vs Reste",
                                 className="chart-card-title",
                                 style={"marginBottom":"8px"}))
            tgt = dep.target_name
            if dep.is_classification:
                try:
                    from scipy.stats import chi2_contingency
                    g = pd.Series(["Sél."]*n_sel + ["Reste"]*n_rst)
                    t = pd.concat([sel_df[tgt].astype(str),
                                   rst_df[tgt].astype(str)], ignore_index=True)
                    ct = pd.crosstab(g, t)
                    chi2, p, dof, _ = chi2_contingency(ct)
                    k  = min(ct.shape)-1
                    v  = float(np.sqrt(chi2/max((n_sel+n_rst)*k,1e-9)))
                    sig= "✅" if p<0.05 else "❌"
                    clr= "#27ae60" if p<0.05 else "#e74c3c"
                    # Props bar
                    fig = go.Figure()
                    for i, cls in enumerate(dep.classes):
                        c = PAL[i%len(PAL)]
                        fig.add_trace(go.Bar(
                            x=[f"Cls {cls}"],
                            y=[sel_df[tgt].eq(cls).mean()*100],
                            name="Sélection", marker_color=c,
                            showlegend=(i==0), legendgroup="sel"))
                        fig.add_trace(go.Bar(
                            x=[f"Cls {cls}"],
                            y=[rst_df[tgt].eq(cls).mean()*100],
                            name="Reste", marker_color=c, opacity=0.35,
                            showlegend=(i==0), legendgroup="rst"))
                    fig.update_layout(barmode="group",plot_bgcolor=BG,paper_bgcolor="#fff",
                                      height=160,margin=dict(l=30,r=10,t=16,b=30),
                                      font=dict(family=FONT,size=10),
                                      yaxis=dict(title="%",gridcolor=GRID),
                                      legend=dict(font=dict(size=9)))
                    out += [
                        dcc.Graph(figure=fig,config={"displayModeBar":False},
                                  style={"height":"160px"}),
                        html.Div([
                            _sr("Cramér V", f"{v:.3f}"),
                            _sr("Chi² p-value", f"{p:.4f}", clr),
                            _sr("Significatif ?", sig+" (p<.05)" if p<0.05 else sig+" (p≥.05)", clr),
                        ], style=_stat_box()),
                    ]
                except Exception:
                    pass
            else:
                try:
                    a = sel_df[tgt].dropna().values
                    b = rst_df[tgt].dropna().values
                    if len(a)>=3 and len(b)>=3:
                        _, p = sp_stats.ttest_ind(a, b, equal_var=False)
                        pooled = np.sqrt(((len(a)-1)*a.std(ddof=1)**2+
                                          (len(b)-1)*b.std(ddof=1)**2)/
                                         max(len(a)+len(b)-2,1)+1e-12)
                        d   = (a.mean()-b.mean())/pooled
                        clr = "#27ae60" if p<0.05 else "#e74c3c"
                        fig = go.Figure()
                        fig.add_trace(go.Box(y=a,name="Sélection",
                                             marker_color="#4472c4",boxmean=True))
                        fig.add_trace(go.Box(y=b,name="Reste",
                                             marker_color="#e07b39",boxmean=True,opacity=0.7))
                        fig.update_layout(plot_bgcolor=BG,paper_bgcolor="#fff",
                                          height=160,margin=dict(l=30,r=10,t=16,b=30),
                                          font=dict(family=FONT,size=10),
                                          yaxis=dict(title=tgt[:18],gridcolor=GRID),
                                          legend=dict(font=dict(size=9)))
                        out += [
                            dcc.Graph(figure=fig,config={"displayModeBar":False},
                                      style={"height":"160px"}),
                            html.Div([
                                _sr(f"Moy. Sél. ({tgt[:14]})", f"{a.mean():.4g}"),
                                _sr("Moy. Reste", f"{b.mean():.4g}"),
                                _sr("Cohen's d", f"{d:+.3f}"),
                                _sr("Welch t p-value", f"{p:.4f}", clr),
                            ], style=_stat_box()),
                        ]
                except Exception:
                    pass

        # ── Feature stats ─────────────────────────────────────────────
        out.append(html.Div("📊 Features — Sélection vs Reste",
                             className="chart-card-title",
                             style={"margin":"12px 0 8px"}))

        feat_rows = []
        for col in [c for c in dep.num_features
                    if c in df.columns and c != dep.target_name][:20]:
            a = sel_df[col].dropna().values
            b = rst_df[col].dropna().values
            if len(a)<3 or len(b)<3: continue
            try:
                _, p_mw = sp_stats.mannwhitneyu(a, b, alternative="two-sided")
                sd      = np.sqrt((a.std(ddof=1)**2+b.std(ddof=1)**2)/2+1e-12)
                d       = (a.mean()-b.mean())/sd
                feat_rows.append((col, a.mean(), b.mean(), d, p_mw))
            except Exception:
                pass

        feat_rows.sort(key=lambda r: abs(r[3]), reverse=True)
        top = feat_rows[:15]

        if top:
            # Forest plot
            lbls  = [r[0][:18] for r in top]
            dvals = [r[3] for r in top]
            clrs  = ["#e07b39" if d>0 else "#4472c4" for d in dvals]
            opac  = [1.0 if (abs(r[3])>=0.2 and r[4]<0.05) else 0.38 for r in top]
            h_fp  = max(180, len(top)*22+40)
            fig_f = go.Figure()
            for i,(lbl,d,c,op) in enumerate(zip(lbls,dvals,clrs,opac)):
                fig_f.add_trace(go.Bar(y=[i],x=[d],orientation="h",
                    marker=dict(color=c,opacity=op),showlegend=False,
                    hovertemplate=f"{lbl}<br>d={d:+.3f}<extra></extra>"))
            fig_f.add_vline(x=0, line_color="#9aa5b4", line_width=1.5)
            fig_f.add_vline(x=0.5, line_dash="dot", line_color="#27ae60",
                             line_width=1)
            fig_f.add_vline(x=-0.5, line_dash="dot", line_color="#27ae60",
                             line_width=1)
            fig_f.update_layout(
                plot_bgcolor=BG, paper_bgcolor="#fff", height=h_fp,
                margin=dict(l=130,r=50,t=16,b=28),
                xaxis=dict(title="Cohen's d  (sél − reste)",
                           gridcolor=GRID,zeroline=False),
                yaxis=dict(tickvals=list(range(len(lbls))),
                           ticktext=lbls,gridcolor=GRID,autorange="reversed"),
                font=dict(family=FONT,size=10))
            out.append(dcc.Graph(figure=fig_f,config={"displayModeBar":False},
                                  style={"height":f"{h_fp}px"}))

            # Table
            hdr = html.Tr([html.Th(h,style=_th()) for h in
                           ["Variable","Moy.Sél","Moy.Reste","Cohen d","p (MW)","Sig."]])
            bdy = []
            for r in top:
                is_sig = abs(r[3])>=0.2 and r[4]<0.05
                bdy.append(html.Tr([
                    html.Td(r[0][:18], style={**_td(),"fontWeight":"700","color":"#1e3a5f"}),
                    html.Td(f"{r[1]:.3g}", style=_td()),
                    html.Td(f"{r[2]:.3g}", style=_td()),
                    html.Td(f"{r[3]:+.3f}",
                            style=_td("#e07b39" if r[3]>0.2 else
                                      "#4472c4" if r[3]<-0.2 else None)),
                    html.Td(f"{r[4]:.4f}",
                            style=_td("#27ae60" if r[4]<0.05 else None)),
                    html.Td("✅" if is_sig else "—", style=_td()),
                ], style={"borderBottom":"1px solid #f5f5f5",
                           "background":"#fff5f0" if is_sig and r[3]>0 else
                                        "#f0f5ff" if is_sig and r[3]<0 else "#fff"}))
            out.append(html.Div(
                html.Table([html.Thead(hdr),html.Tbody(bdy)],
                           style={"width":"100%","borderCollapse":"collapse",
                                  "fontSize":"11px","fontFamily":FONT}),
                style={"overflowX":"auto","marginTop":"10px"}))

        return html.Div(out, style={"padding":"4px"})


# ── helpers ───────────────────────────────────────────────────────────────────

def _placeholder():
    return html.Div([
        html.Div("🔍 Panel Sélection Lasso",
                 style={"fontWeight":"800","color":"#1e3a5f","fontSize":"13px",
                        "marginBottom":"14px"}),
        html.Div([
            html.Div("←", style={"fontSize":"28px","textAlign":"center","marginBottom":"8px"}),
            html.Div("Sélectionnez des points avec l'outil lasso ou box.",
                     style={"fontSize":"12px","color":"#9aa5b4","textAlign":"center"}),
            html.Ul([
                html.Li("Comparaison Target (Cramér V / t-test)"),
                html.Li("Forest plot Cohen's d par feature"),
                html.Li("Tableau Mann-Whitney + significativité"),
            ], style={"fontSize":"11px","color":"#bbb","paddingLeft":"16px",
                       "lineHeight":"2","marginTop":"10px"}),
        ], style={"background":"#f7f8fa","borderRadius":"10px",
                   "padding":"18px","border":"1.5px dashed #dde2ea"}),
    ], style={"padding":"4px"})


def _sr(label, value, color=None):
    return html.Div([
        html.Span(label, style={"fontSize":"11px","color":"#6b7a8d",
                                  "fontWeight":"600","flex":"1"}),
        html.Span(value, style={"fontSize":"11px","fontWeight":"700",
                                  "color":color or "#1e3a5f"}),
    ], style={"display":"flex","justifyContent":"space-between",
               "padding":"3px 0","borderBottom":"1px solid #f5f5f5"})


def _stat_box():
    return {"background":"#f7f8fa","borderRadius":"6px","padding":"6px 8px",
            "marginBottom":"10px","border":"1.5px solid #e0e4ea"}


def _th():
    return {"padding":"5px 6px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10px","textTransform":"uppercase",
            "letterSpacing":".3px","textAlign":"left",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap"}


def _td(color=None):
    s = {"padding":"4px 6px","fontSize":"11px","color":"#374151","whiteSpace":"nowrap"}
    if color:
        s["color"] = color
        s["fontWeight"] = "700"
    return s


def _base(title=""):
    return dict(
        title=dict(text=title,font=dict(size=12,color="#1e3a5f")),
        plot_bgcolor=BG, paper_bgcolor="#fff",
        margin=dict(l=50,r=16,t=44,b=50),
        font=dict(family=FONT,size=11),
        xaxis=dict(gridcolor=GRID,zeroline=False),
        yaxis=dict(gridcolor=GRID,zeroline=False),
        legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1,bordercolor=GRID))
