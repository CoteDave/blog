"""
Importance des Variables — multi-metric feature importance dashboard.

Metrics:
  Pearson |r|, Spearman |ρ|, F-statistic, Mutual Information,
  Phi-k, PPS, Information Value (IV/WoE), global normalized score.

Outputs:
  • One horizontal bar chart per metric
  • Global normalized score bar chart
  • Summary table: all metrics × all features
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats as sp_stats

# ─────────────────────────────────────────────────────────────────────────────
PALETTE = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6",
           "#1abc9c","#f39c12","#16a085","#c0392b","#8e44ad"]
GRID  = "#e0e4ea"
BG    = "#f7f8fa"
FONT  = "Plus Jakarta Sans, sans-serif"

# ═════════════════════════════════════════════════════════════════════════════
#  METRIC COMPUTERS
# ═════════════════════════════════════════════════════════════════════════════

def _safe_norm(arr: np.ndarray) -> np.ndarray:
    """Normalize array to [0, 1], handle all-zero case."""
    mn, mx = arr.min(), arr.max()
    if mx - mn < 1e-12:
        return np.zeros_like(arr)
    return (arr - mn) / (mx - mn)


def _pearson(X: pd.DataFrame, y: pd.Series) -> np.ndarray:
    scores = []
    for col in X.columns:
        vals = X[col].dropna()
        idx  = vals.index.intersection(y.dropna().index)
        if len(idx) < 5:
            scores.append(0.0); continue
        r, _ = sp_stats.pearsonr(vals.loc[idx], y.loc[idx])
        scores.append(abs(float(r)))
    return np.array(scores)


def _spearman(X: pd.DataFrame, y: pd.Series) -> np.ndarray:
    scores = []
    for col in X.columns:
        vals = X[col].dropna()
        idx  = vals.index.intersection(y.dropna().index)
        if len(idx) < 5:
            scores.append(0.0); continue
        r, _ = sp_stats.spearmanr(vals.loc[idx], y.loc[idx])
        scores.append(abs(float(r)))
    return np.array(scores)


def _fstat(X: pd.DataFrame, y: pd.Series, is_cls: bool) -> np.ndarray:
    from sklearn.feature_selection import f_classif, f_regression
    Xf = X.fillna(X.median())
    yf = y.fillna(y.mode().iloc[0] if is_cls else y.median())
    idx = Xf.index.intersection(yf.index)
    fn  = f_classif if is_cls else f_regression
    try:
        F, _ = fn(Xf.loc[idx].values, yf.loc[idx].values)
        return _safe_norm(np.nan_to_num(F, nan=0.0))
    except Exception:
        return np.zeros(len(X.columns))


def _mi(X: pd.DataFrame, y: pd.Series, is_cls: bool) -> np.ndarray:
    from sklearn.feature_selection import mutual_info_classif, mutual_info_regression
    Xf = X.fillna(X.median())
    yf = y.fillna(y.mode().iloc[0] if is_cls else y.median())
    idx = Xf.index.intersection(yf.index)
    fn  = mutual_info_classif if is_cls else mutual_info_regression
    try:
        mi = fn(Xf.loc[idx].values, yf.loc[idx].values, random_state=0)
        return _safe_norm(mi)
    except Exception:
        return np.zeros(len(X.columns))


def _phik_scores(X: pd.DataFrame, y: pd.Series) -> np.ndarray:
    """Phi-k between each feature and target via 2D histogram chi²."""
    scores = []
    y_clean = y.dropna()
    for col in X.columns:
        xi = X[col].dropna()
        idx = xi.index.intersection(y_clean.index)
        if len(idx) < 8:
            scores.append(0.0); continue
        xv = xi.loc[idx].values
        yv = y_clean.loc[idx].values
        try:
            n_bins_x = min(8, max(2, len(np.unique(xv))))
            n_bins_y = min(8, max(2, len(np.unique(yv))))
            hist, _, _ = np.histogram2d(xv.astype(float), yv.astype(float),
                                         bins=[n_bins_x, n_bins_y])
            chi2, _, _, _ = sp_stats.chi2_contingency(hist + 1e-6)
            k    = min(n_bins_x, n_bins_y) - 1
            phik = float(np.sqrt(chi2 / max(len(idx) * k, 1e-9)))
            scores.append(min(float(phik), 1.0))
        except Exception:
            scores.append(0.0)
    return np.array(scores)


def _pps_scores(X: pd.DataFrame, y: pd.Series, is_cls: bool) -> np.ndarray:
    from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
    from sklearn.model_selection import cross_val_score
    Xf  = X.fillna(X.median())
    yf  = y.fillna(y.mode().iloc[0] if is_cls else y.median())
    idx = Xf.index.intersection(yf.index)
    scores = []
    for col in X.columns:
        xi = Xf.loc[idx, col].values.reshape(-1, 1)
        yi = yf.loc[idx].values
        try:
            dt  = (DecisionTreeClassifier(max_depth=4, min_samples_leaf=10, random_state=0)
                   if is_cls else
                   DecisionTreeRegressor(max_depth=4, min_samples_leaf=10, random_state=0))
            sc  = "roc_auc" if (is_cls and len(np.unique(yi)) == 2) else \
                  "f1_weighted" if is_cls else "r2"
            cvs = cross_val_score(dt, xi, yi, cv=3, scoring=sc)
            scores.append(float(max(np.mean(cvs), 0)))
        except Exception:
            scores.append(0.0)
    return _safe_norm(np.array(scores))


def _iv_scores(X: pd.DataFrame, y: pd.Series) -> np.ndarray:
    """
    Information Value (WoE/IV) — standard binary classification metric.
    Falls back to 0 for non-binary targets.
    """
    if y.nunique() != 2:
        return np.zeros(len(X.columns))

    y_bin = (y == y.unique()[1]).astype(int)
    scores = []
    for col in X.columns:
        xi = X[col].fillna(X[col].median())
        try:
            binned = pd.qcut(xi, q=10, duplicates="drop")
            total_events     = y_bin.sum()
            total_nonevents  = (1 - y_bin).sum()
            iv_total = 0.0
            for bucket in binned.cat.categories:
                mask     = binned == bucket
                events   = y_bin[mask].sum()
                nonevents= (1 - y_bin[mask]).sum()
                dist_e   = events   / max(total_events, 1)
                dist_ne  = nonevents/ max(total_nonevents, 1)
                if dist_e > 0 and dist_ne > 0:
                    iv_total += (dist_e - dist_ne) * np.log(dist_e / dist_ne)
            scores.append(min(float(abs(iv_total)), 5.0))  # cap at 5
        except Exception:
            scores.append(0.0)
    return _safe_norm(np.array(scores))


def _rf_scores(X: pd.DataFrame, y: pd.Series, is_cls: bool) -> np.ndarray:
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    Xf = X.fillna(X.median())
    yf = y.fillna(y.mode().iloc[0] if is_cls else y.median())
    idx = Xf.index.intersection(yf.index)
    try:
        rf = (RandomForestClassifier(n_estimators=100, max_depth=8,
                                      random_state=42, n_jobs=-1)
              if is_cls else
              RandomForestRegressor(n_estimators=100, max_depth=8,
                                     random_state=42, n_jobs=-1))
        rf.fit(Xf.loc[idx].values, yf.loc[idx].values)
        return _safe_norm(rf.feature_importances_)
    except Exception:
        return np.zeros(len(X.columns))


# ─────────────────────────────────────────────────────────────────────────────
#  MASTER COMPUTE
# ─────────────────────────────────────────────────────────────────────────────

METRICS_SUPERVISED = [
    ("Pearson |r|",    "pearson"),
    ("Spearman |ρ|",   "spearman"),
    ("F-Statistic",    "fstat"),
    ("Mutual Info",    "mi"),
    ("Phi-k",          "phik"),
    ("PPS",            "pps"),
    ("IV (WoE)",       "iv"),
    ("Random Forest",  "rf"),
]

METRICS_UNSUPERVISED = [
    ("Pearson |r| (var.)", "pearson"),
    ("Spearman |ρ|",       "spearman"),
    ("Variance normalisée","var"),
]

METRIC_COLORS = {
    "pearson":  "#4472c4",
    "spearman": "#e07b39",
    "fstat":    "#27ae60",
    "mi":       "#e74c3c",
    "phik":     "#9b59b6",
    "pps":      "#1abc9c",
    "iv":       "#f39c12",
    "rf":       "#16a085",
    "var":      "#4472c4",
}

METRIC_DESCRIPTIONS = {
    "pearson":  "Corrélation de Pearson — linéaire",
    "spearman": "Corrélation de Spearman — monotone",
    "fstat":    "F-Statistic ANOVA / régression",
    "mi":       "Information Mutuelle (normalisée)",
    "phik":     "Phi-k — association non-linéaire via χ²",
    "pps":      "Predictive Power Score (arbre décisionnel)",
    "iv":       "Information Value / WoE (binaire uniquement)",
    "rf":       "Importance Random Forest (impureté Gini)",
    "var":      "Variance normalisée",
}


def _compute_all(dep) -> pd.DataFrame:
    """Fast fallback compute: skip PPS/phik, cap at 10k rows."""
    import warnings
    num = dep.num_features

    # Cap at 10k for fallback speed
    df_samp = dep.display_df
    if len(df_samp) > 10_000:
        df_samp = df_samp.sample(n=10_000, random_state=42)
    X = df_samp[num].copy()

    if not dep.supervised:
        vals_var  = np.std(X.fillna(X.median()).values, axis=0)
        vals_var  = _safe_norm(vals_var)
        return pd.DataFrame({"var": vals_var}, index=num)

    y       = df_samp[dep.target_name]
    is_cls  = dep.is_classification

    results = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        results["pearson"]  = _pearson(X, y.astype(float) if not is_cls else y)
        results["spearman"] = _spearman(X, y.astype(float) if not is_cls else y)
        results["fstat"]    = _fstat(X, y, is_cls)
        results["mi"]       = _mi(X, y, is_cls)
        results["rf"]       = _rf_scores(X, y, is_cls)  # fast: 10k rows
        if not is_cls or dep.n_classes == 2:
            results["iv"]   = _iv_scores(X, y)

    df_res = pd.DataFrame(results, index=num)
    df_res["global"] = _safe_norm(df_res.mean(axis=1).values)

    return df_res.round(4)


# ═════════════════════════════════════════════════════════════════════════════
#  LAYOUT
# ═════════════════════════════════════════════════════════════════════════════

def layout(dep) -> html.Div:
    num    = dep.num_features
    is_sup = dep.supervised

    return html.Div([
        html.Div("Importance des Variables", className="page-title"),
        html.Div(
            "Analyse multi-métriques de la relation entre chaque feature et la target.",
            className="page-subtitle"),

        html.Div([
            html.Div([
                html.Div("Top N features:", className="control-label"),
                dcc.Slider(id="imp-topn", min=5, max=min(40, len(num)),
                           step=5, value=min(20, len(num)),
                           marks={5:"5",10:"10",20:"20",30:"30",40:"40"},
                           tooltip={"placement":"bottom","always_visible":False}),
            ], className="control-group", style={"minWidth":"260px"}),

            html.Div([
                html.Div("Trier par:", className="control-label"),
                dcc.Dropdown(
                    id="imp-sort-by",
                    options=[{"label":"Score Global","value":"global"},
                             {"label":"Pearson |r|","value":"pearson"},
                             {"label":"Random Forest","value":"rf"},
                             {"label":"MI","value":"mi"}],
                    value="global", clearable=False,
                    style={"width":"200px"}),
            ], className="control-group"),

            html.Div([
                html.Div("Vue:", className="control-label"),
                dcc.Dropdown(
                    id="imp-view",
                    options=[{"label":"Graphiques par métrique","value":"charts"},
                             {"label":"Tableau récapitulatif","value":"table"},
                             {"label":"Score global uniquement","value":"global"}],
                    value="charts", clearable=False,
                    style={"width":"240px"}),
            ], className="control-group"),
        ], className="controls-row"),

        dcc.Loading(
            html.Div(id="imp-content"),
            type="dot", color="#4472c4",
        ),
    ], className="page-card")


# ═════════════════════════════════════════════════════════════════════════════
#  CALLBACKS
# ═════════════════════════════════════════════════════════════════════════════

def register_callbacks(app, dep) -> None:

    # v8: read precompute cache first (fast), only fallback to _compute_all if missing
    _scores_cache: list = []

    def _get_scores():
        """Try precompute cache; fall back to fast compute on display_df."""
        if _scores_cache:
            return _scores_cache[0]

        # --- Try precompute cache (available after background thread finishes) ---
        imp = dep.cache.get("importance", wait=True)   # wait up to 120s
        if imp is not None and "cols" in imp:
            cols = imp["cols"]
            data = {}
            for key in ("pearson","spearman","fstat","mi","rf","global"):
                if key in imp and len(imp[key]) == len(cols):
                    data[key] = imp[key]
            if data:
                result = pd.DataFrame(data, index=cols).round(4)
                _scores_cache.append(result)
                return result

        # --- Fallback: fast compute on display_df (skip PPS/phik, cap 10k) ---
        result = _compute_all(dep)
        _scores_cache.append(result)
        return result

    @app.callback(
        Output("imp-content", "children"),
        [Input("imp-topn",    "value"),
         Input("imp-sort-by", "value"),
         Input("imp-view",    "value")],
    )
    def update(top_n, sort_by, view):
        top_n = top_n or 20

        try:
            df_scores = _get_scores()
        except Exception as e:
            return html.Div(f"Erreur: {e}",
                            style={"color":"#e74c3c","padding":"20px"})

        # Sort features
        sort_col = sort_by if sort_by in df_scores.columns else df_scores.columns[0]
        df_sorted = df_scores.sort_values(sort_col, ascending=False).head(top_n)
        features  = list(df_sorted.index)

        if view == "table":
            return _render_table(df_sorted)

        if view == "global":
            return _render_global_only(df_sorted, features, sort_col)

        return _render_charts(df_scores, df_sorted, features, dep)


# ─────────────────────────────────────────────────────────────────────────────
#  RENDERERS
# ─────────────────────────────────────────────────────────────────────────────

def _render_global_only(df_sorted, features, sort_col):
    """Single global score bar chart."""
    vals   = df_sorted["global"].values if "global" in df_sorted.columns \
             else df_sorted.iloc[:, 0].values
    norm   = vals / max(vals.max(), 1e-9)
    colors = [_score_to_color(v) for v in norm]

    fig = go.Figure(go.Bar(
        y=features[::-1], x=vals[::-1],
        orientation="h",
        marker=dict(color=colors[::-1],
                    line=dict(width=0.5, color="rgba(255,255,255,.5)")),
        text=[f"{v:.3f}" for v in vals[::-1]],
        textposition="outside",
    ))
    fig.update_layout(**_bar_layout("Score Global Normalisé (moyenne toutes métriques)"),
                      height=max(300, len(features)*26+80),
                      margin=dict(l=160, r=80, t=50, b=40))
    return html.Div([dcc.Graph(figure=fig, config={"displayModeBar":False},
                               style={"height":f"{max(300,len(features)*26+80)}px"})])


def _render_charts(df_all, df_sorted, features, dep):
    """Grid of horizontal bar charts: one per metric + global."""
    metric_cols = [c for c in df_sorted.columns if c != "global"]
    has_global  = "global" in df_sorted.columns

    items = []

    # ── Global score first (full width) ──────────────────────────────────────
    if has_global:
        vals  = df_sorted["global"].values
        norm  = vals / max(vals.max(), 1e-9)
        colors= [_score_to_color(v) for v in norm]
        h_g   = max(280, len(features)*22+80)
        fig_g = go.Figure(go.Bar(
            y=features[::-1], x=vals[::-1], orientation="h",
            marker=dict(color=colors[::-1],
                        line=dict(width=0.5, color="rgba(255,255,255,.4)")),
            text=[f"{v:.3f}" for v in vals[::-1]], textposition="outside",
        ))
        fig_g.update_layout(**_bar_layout("⭐ Score Global (moyenne normalisée)"),
                            height=h_g, margin=dict(l=160, r=80, t=45, b=40))
        items.append(html.Div([
            dcc.Graph(figure=fig_g, config={"displayModeBar":False},
                      style={"height":f"{h_g}px"}),
        ], className="chart-card", style={"marginBottom":"16px","gridColumn":"1 / -1"}))

    # ── One chart per metric ──────────────────────────────────────────────────
    metric_items = []
    h_m = max(240, len(features)*18+70)

    for metric in metric_cols:
        label = next((l for l,k in
                      (METRICS_SUPERVISED + METRICS_UNSUPERVISED) if k == metric),
                     metric.upper())
        desc  = METRIC_DESCRIPTIONS.get(metric, "")
        clr   = METRIC_COLORS.get(metric, "#4472c4")

        vals  = df_sorted[metric].values
        norm  = vals / max(vals.max(), 1e-9)
        bar_clr = [
            f"rgba({_hex_to_rgb(clr)},{0.45 + 0.55*n:.2f})"
            for n in norm
        ]

        fig = go.Figure(go.Bar(
            y=features[::-1], x=vals[::-1], orientation="h",
            marker=dict(color=bar_clr[::-1],
                        line=dict(width=0.4, color="rgba(255,255,255,.4)")),
            text=[f"{v:.3f}" for v in vals[::-1]], textposition="outside",
            hovertemplate=f"<b>%{{y}}</b><br>{label}: %{{x:.4f}}<extra></extra>",
        ))
        fig.update_layout(**_bar_layout(label), height=h_m,
                          margin=dict(l=150, r=70, t=40, b=30))

        metric_items.append(html.Div([
            html.Div(desc, style={"fontSize":"10.5px","color":"#6b7a8d",
                                   "marginBottom":"6px","fontStyle":"italic"}),
            dcc.Graph(figure=fig, config={"displayModeBar":False},
                      style={"height":f"{h_m}px"}),
        ], className="chart-card"))

    # 2-column grid for metric charts
    items.append(html.Div(metric_items,
                          style={"display":"grid",
                                 "gridTemplateColumns":"1fr 1fr",
                                 "gap":"14px","marginBottom":"16px"}))

    # ── Radar / Spider for top 10 features ────────────────────────────────────
    top10 = list(df_sorted.head(10).index)
    if len(metric_cols) >= 3 and len(top10) >= 3:
        fig_rad = _radar_chart(df_sorted.loc[top10], metric_cols, top10)
        items.append(html.Div([
            html.Div("🕸️ Radar — Top 10 features × métriques",
                     className="chart-card-title"),
            dcc.Graph(figure=fig_rad, config={"displayModeBar":False},
                      style={"height":"440px"}),
        ], className="chart-card", style={"marginBottom":"16px"}))

    return html.Div(items)


def _render_table(df_sorted):
    """Rich summary table: features × all metrics."""
    cols    = list(df_sorted.columns)
    headers = ["Feature"] + [
        next((l for l,k in METRICS_SUPERVISED+METRICS_UNSUPERVISED if k==c),
             c.upper())
        for c in cols
    ]

    th_style = {"padding":"6px 10px","background":"#f0f4f8","color":"#6b7a8d",
                "fontWeight":"700","fontSize":"10.5px","textTransform":"uppercase",
                "letterSpacing":".4px","borderBottom":"2px solid #e0e4ea",
                "textAlign":"right","whiteSpace":"nowrap"}
    td_style = {"padding":"5px 10px","fontSize":"11.5px","textAlign":"right",
                "whiteSpace":"nowrap","fontVariantNumeric":"tabular-nums"}

    def _cell_bg(val):
        if val >= 0.7: return "#fff0ee"
        if val >= 0.4: return "#fffbf0"
        return "white"

    header_row = html.Tr([
        html.Th("Feature", style={**th_style,"textAlign":"left"}),
        *[html.Th(h, style=th_style) for h in headers[1:]],
    ])

    body_rows = []
    for feat in df_sorted.index:
        cells = [html.Td(feat, style={**td_style,"textAlign":"left",
                                       "fontWeight":"700","color":"#1e3a5f"})]
        for col in cols:
            val = df_sorted.loc[feat, col]
            is_global = col == "global"
            bg = _cell_bg(val) if is_global else "white"
            bar_w = int(val * 60)
            cells.append(html.Td(
                html.Div([
                    html.Div(style={
                        "width":f"{bar_w}px","height":"4px",
                        "background": METRIC_COLORS.get(col,"#4472c4"),
                        "borderRadius":"2px","marginBottom":"2px","opacity":"0.7",
                    }),
                    html.Span(f"{val:.4f}", style={"fontSize":"11px"}),
                ]),
                style={**td_style,"background":bg}
            ))
        body_rows.append(html.Tr(cells,
                                  style={"borderBottom":"1px solid #f0f4f8"}))

    return html.Div([
        html.Div("📊 Tableau récapitulatif — toutes métriques",
                 className="chart-card-title", style={"marginBottom":"12px"}),
        html.Div(
            html.Table([html.Thead(header_row), html.Tbody(body_rows)],
                       style={"width":"100%","borderCollapse":"collapse",
                              "fontFamily":FONT,"fontSize":"12px"}),
            style={"overflowX":"auto","overflowY":"auto","maxHeight":"600px"}),
    ], className="chart-card")


def _radar_chart(df: pd.DataFrame, metric_cols: list, features: list) -> go.Figure:
    """Spider chart: each feature = one trace, axes = metrics."""
    labels  = [next((l for l,k in METRICS_SUPERVISED+METRICS_UNSUPERVISED if k==m),
                    m.upper()) for m in metric_cols]
    labels += [labels[0]]  # close polygon

    fig = go.Figure()
    for i, feat in enumerate(features[:10]):
        vals = [float(df.loc[feat, m]) for m in metric_cols]
        vals += [vals[0]]
        clr   = PALETTE[i % len(PALETTE)]
        fig.add_trace(go.Scatterpolar(
            r=vals, theta=labels, fill="toself",
            fillcolor=_hex_alpha(clr, 0.08),
            line=dict(color=clr, width=1.8),
            name=feat[:20],
        ))
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0,1],
                            tickfont=dict(size=9),
                            gridcolor=GRID),
            angularaxis=dict(tickfont=dict(size=10, family=FONT)),
            bgcolor=BG,
        ),
        plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=60, r=60, t=40, b=40),
        font=dict(family=FONT, size=10),
        legend=dict(font=dict(size=10), orientation="v",
                    x=1.05, y=1),
        showlegend=True,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
#  STYLE HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _bar_layout(title=""):
    return dict(
        title=dict(text=title, font=dict(size=13, color="#1e3a5f", family=FONT)),
        plot_bgcolor=BG, paper_bgcolor="white",
        font=dict(family=FONT, size=10),
        xaxis=dict(gridcolor=GRID, zeroline=False, range=[0, 1.12]),
        yaxis=dict(gridcolor=GRID, tickfont=dict(size=10)),
        showlegend=False,
    )


def _score_to_color(norm_val: float) -> str:
    """Map 0→1 to blue→orange gradient."""
    r = int(68  + (224-68)  * norm_val)
    g = int(114 + (123-114) * norm_val)
    b = int(196 + (57-196)  * norm_val)
    return f"rgb({r},{g},{b})"


def _hex_to_rgb(hex_color: str) -> str:
    h = hex_color.lstrip("#")
    return f"{int(h[0:2],16)},{int(h[2:4],16)},{int(h[4:6],16)}"


def _hex_alpha(hex_color: str, alpha: float) -> str:
    return f"rgba({_hex_to_rgb(hex_color)},{alpha})"
