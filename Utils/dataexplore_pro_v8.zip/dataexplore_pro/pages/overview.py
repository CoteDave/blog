"""
Aperçu Global — Variable catalog + rich interactive detail panel.
Click any variable name to open a dtype-aware analysis panel on the right.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output, ALL, ctx, no_update
import plotly.graph_objects as go
from scipy import stats as sp_stats

# ─────────────────────────────────────────────────────────────────────────────
PALETTE  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID     = "#e0e4ea"
BG       = "#f7f8fa"
RARE_THR_FREQ  = 0.01
RARE_THR_COUNT = 10
MAX_CAT_SHOWN  = 40

IV_LABELS = {0.0:"—", 0.02:"Faible", 0.1:"Moyen", 0.3:"Fort", 0.5:"Très fort"}

def _iv_label(iv: float) -> str:
    if iv < 0.02: return "Nul"
    if iv < 0.10: return "Faible"
    if iv < 0.30: return "Moyen"
    if iv < 0.50: return "Fort"
    return "Très fort"

def _compute_iv_feature(dep, col: str) -> float:
    """
    Information Value for one feature vs. the target.
    - Binary classification   → classic WoE/IV
    - Multiclass / regression → η² (ANOVA eta-squared), range [0,1]
    - Unsupervised            → 0.0
    """
    if not dep.supervised:
        return 0.0
    # v8: use display_df for fast IV fallback compute
    s   = dep.display_df[col]
    tgt = dep.display_df[dep.target_name]

    if dep.is_classification and dep.n_classes == 2:
        # Binary IV
        y_bin = (tgt == dep.classes[-1]).astype(int)
        total_ev  = max(y_bin.sum(), 1)
        total_nev = max((1 - y_bin).sum(), 1)

        # Binning for numerics
        if _is_numeric_dtype(_classify_col(s)):
            try:
                s_binned = pd.qcut(s.dropna(), q=10, duplicates="drop")
                aligned  = s_binned.reindex(s.index)
                cats     = aligned.dropna().cat.categories.tolist()
                get_mask = lambda c: aligned == c
            except Exception:
                return 0.0
        else:
            cats = s.dropna().astype(str).unique().tolist()
            s_str = s.fillna("__NaN__").astype(str)
            get_mask = lambda c: s_str == str(c)

        iv_total = 0.0
        for cat in cats:
            mask = get_mask(cat)
            ev   = y_bin[mask].sum()
            nev  = (1 - y_bin[mask]).sum()
            d_ev  = ev  / total_ev
            d_nev = nev / total_nev
            if d_ev > 0 and d_nev > 0:
                woe = float(np.log(d_ev / d_nev))
                iv_total += (d_ev - d_nev) * woe
        return float(np.clip(iv_total, 0, 3))

    else:
        # η² via one-way ANOVA
        try:
            if _is_numeric_dtype(_classify_col(s)):
                s_binned = pd.qcut(s.dropna(), q=min(10, s.nunique()), duplicates="drop")
                groups_s = s_binned.reindex(s.index)
            else:
                groups_s = s.fillna("__NaN__").astype(str)

            tgt_num = tgt if not dep.is_classification else \
                      tgt.map({c: i for i, c in enumerate(dep.classes)}).fillna(0)
            tgt_num = tgt_num.fillna(tgt_num.median())

            groups = [tgt_num[groups_s == cat].dropna().values
                      for cat in groups_s.dropna().unique()
                      if (groups_s == cat).sum() >= 3]
            if len(groups) < 2:
                return 0.0
            f, p = sp_stats.f_oneway(*groups)
            n_all = sum(len(g) for g in groups)
            k     = len(groups)
            if f > 0:
                eta2 = (f * (k - 1)) / (f * (k - 1) + (n_all - k))
                return float(np.clip(eta2, 0, 1))
        except Exception:
            pass
        return 0.0


def _compute_iv_all(dep) -> dict[str, float]:
    """Compute IV for all non-target features. Cached per dep instance."""
    cols = [c for c in dep.df.columns if c != dep.target_name]
    return {col: _compute_iv_feature(dep, col) for col in cols}


# ══════════════════════════════════════════════════════════════════════════════
#  Dtype helper
# ══════════════════════════════════════════════════════════════════════════════
def _classify_col(series: pd.Series) -> str:
    if pd.api.types.is_bool_dtype(series):
        return "Booléen"
    if pd.api.types.is_integer_dtype(series):
        return "Entier"
    if pd.api.types.is_float_dtype(series):
        return "Flottant"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "Date/Heure"
    if pd.api.types.is_categorical_dtype(series):
        return "Catégoriel"
    if series.nunique() <= 30 and pd.api.types.is_object_dtype(series):
        return "Catégoriel"
    # Free text heuristic: average word count > 5
    try:
        sample = series.dropna().astype(str).head(200)
        avg_words = sample.str.split().apply(len).mean()
        if avg_words > 5:
            return "Texte"
    except Exception:
        pass
    return "Catégoriel"


def _is_numeric_dtype(lbl: str) -> bool:
    return lbl in ("Flottant", "Entier")


def _is_cat_dtype(lbl: str) -> bool:
    return lbl in ("Catégoriel", "Booléen")


# ══════════════════════════════════════════════════════════════════════════════
#  Layout
# ══════════════════════════════════════════════════════════════════════════════
def layout(dep) -> html.Div:
    df   = dep.df
    cols = [c for c in df.columns if c != dep.target_name]

    # Metric cards
    n_rows   = len(df)
    n_miss   = int(df.isnull().sum().sum())
    miss_pct = n_miss / max(1, n_rows * len(df.columns)) * 100

    metric_cards = html.Div([
        _mcard("Observations",      f"{n_rows:,}",              "lignes"),
        _mcard("Var. numériques",   f"{len(dep.num_features)}",  "colonnes"),
        _mcard("Var. catégorielles",f"{len(dep.cat_features)}",  "colonnes"),
        _mcard("Valeurs NaN",       f"{n_miss:,}",              f"{miss_pct:.1f}%",
               accent=n_miss > 0),
        _mcard("Target",
               f"{dep.n_classes} classes" if dep.supervised and dep.is_classification
               else dep.target_name if dep.supervised else "—",
               "supervisé" if dep.supervised else "non supervisé"),
    ], className="metric-cards")

    all_cols       = cols
    col_opts_panel = [{"label": c, "value": c} for c in all_cols]

    # ── Always-in-DOM detail panel ──────────────────────────────────────────
    detail_panel = html.Div([
        # Header row
        html.Div([
            html.Div(id="ov-panel-varname",
                     style={"fontWeight":"800","fontSize":"15px","color":"#1e3a5f",
                            "flex":"1","overflow":"hidden","textOverflow":"ellipsis",
                            "whiteSpace":"nowrap"}),
            html.Button("✕", id="ov-panel-close", n_clicks=0,
                        style={"background":"none","border":"none","fontSize":"20px",
                               "cursor":"pointer","color":"#6b7a8d","lineHeight":"1",
                               "padding":"0 4px","flexShrink":"0"}),
        ], style={"display":"flex","alignItems":"center","gap":"8px",
                  "marginBottom":"10px","paddingBottom":"10px",
                  "borderBottom":"2px solid #e0e4ea"}),

        # Variable dropdown
        html.Div([
            html.Div("Variable :", style={"fontSize":"11px","fontWeight":"700",
                                           "color":"#6b7a8d","marginBottom":"4px"}),
            dcc.Dropdown(id="ov-var-dropdown", options=col_opts_panel,
                         value=all_cols[0] if all_cols else None,
                         clearable=False, style={"fontSize":"12px"}),
        ], style={"marginBottom":"12px"}),

        # Metric radio
        html.Div([
            html.Div("Mesure :", style={"fontSize":"12px","fontWeight":"700",
                                         "color":"#6b7a8d","marginBottom":"4px"}),
            dcc.RadioItems(
                id="ov-metric",
                options=[{"label":" Target",     "value":"target"},
                         {"label":" Mean Diff",  "value":"meandiff"},
                         {"label":" WoE",        "value":"woe"},
                         {"label":" Fréquence",  "value":"freq"},
                         {"label":" Count",      "value":"count"}],
                value="target", inline=True,
                inputStyle={"marginRight":"4px"},
                labelStyle={"marginRight":"14px","fontSize":"12px","cursor":"pointer"},
            ),
        ], id="ov-metric-wrap", style={"marginBottom":"10px"}),

        # Sort order
        html.Div([
            html.Div("Trier par :", style={"fontSize":"11px","fontWeight":"700",
                                            "color":"#6b7a8d","marginBottom":"4px"}),
            dcc.Dropdown(
                id="ov-sort-by",
                options=[
                    {"label":"Mesure (desc)",    "value":"metric_desc"},
                    {"label":"Mesure (asc)",     "value":"metric_asc"},
                    {"label":"Fréquence (desc)", "value":"freq_desc"},
                    {"label":"Fréquence (asc)",  "value":"freq_asc"},
                    {"label":"Alphabétique",     "value":"alpha"},
                ],
                value="metric_desc", clearable=False, style={"fontSize":"12px"},
            ),
        ], id="ov-sort-wrap", style={"marginBottom":"12px"}),

        # Bin controls (numeric only) — method first, then n slider conditionally
        html.Div([
            html.Div([
                html.Div("Méthode :", style={"fontSize":"12px","fontWeight":"700",
                                              "color":"#6b7a8d","marginBottom":"4px"}),
                dcc.Dropdown(id="ov-bin-method",
                             options=[{"label":"Quantiles",           "value":"quantile"},
                                      {"label":"Intervalles égaux",   "value":"equal"},
                                      {"label":"Arbre décisionnel",   "value":"dtree"}],
                             value="quantile", clearable=False,
                             style={"fontSize":"12px","minWidth":"170px"}),
            ]),
            # n-bins slider (hidden when dtree)
            html.Div([
                html.Div("N bins :", style={"fontSize":"12px","fontWeight":"700",
                                             "color":"#6b7a8d","whiteSpace":"nowrap"}),
                dcc.Slider(id="ov-bin-n", min=3, max=30, step=1, value=10,
                           marks={3:"3",10:"10",20:"20",30:"30"},
                           tooltip={"placement":"bottom","always_visible":False}),
            ], id="ov-bin-n-wrap", style={"flex":"1","minWidth":"180px"}),
            # dtree-specific params (shown only when dtree)
            html.Div([
                html.Div([
                    html.Div("Min samples :", style={"fontSize":"11px","fontWeight":"700",
                                                      "color":"#6b7a8d","marginBottom":"2px"}),
                    dcc.Slider(id="ov-dtree-min-samples", min=5, max=100, step=5, value=20,
                               marks={5:"5",20:"20",50:"50",100:"100"},
                               tooltip={"placement":"bottom","always_visible":False}),
                ]),
                html.Div([
                    html.Div("Max depth :", style={"fontSize":"11px","fontWeight":"700",
                                                    "color":"#6b7a8d","marginBottom":"2px"}),
                    dcc.Slider(id="ov-dtree-max-depth", min=1, max=8, step=1, value=3,
                               marks={1:"1",3:"3",5:"5",8:"8"},
                               tooltip={"placement":"bottom","always_visible":False}),
                ]),
                html.Div([
                    html.Div("Max feuilles :", style={"fontSize":"11px","fontWeight":"700",
                                                       "color":"#6b7a8d","marginBottom":"2px"}),
                    dcc.Slider(id="ov-dtree-max-leaves", min=2, max=20, step=1, value=6,
                               marks={2:"2",6:"6",10:"10",20:"20"},
                               tooltip={"placement":"bottom","always_visible":False}),
                ]),
            ], id="ov-dtree-params-wrap",
               style={"display":"none","flexDirection":"column","gap":"8px",
                      "flex":"2","minWidth":"220px"}),
        ], id="ov-bin-controls",
           style={"display":"none","gap":"16px","alignItems":"flex-end",
                  "marginBottom":"14px","flexWrap":"wrap"}),

        # Dynamic content
        html.Div(id="ov-panel-content", style={"overflowY":"auto","flex":"1"}),
    ], id="ov-detail-panel",
       style={"display":"none","flexDirection":"column","padding":"18px",
              "background":"white","borderRadius":"12px",
              "border":"1.5px solid #e0e4ea","boxShadow":"0 4px 18px rgba(0,0,0,.10)",
              "width":"580px","minWidth":"580px","flexShrink":"0",
              "position":"sticky","top":"0",
              "maxHeight":"calc(100vh - 80px)","overflowY":"hidden"})

    return html.Div([
        dcc.Store(id="ov-selected-var",   data=None),
        dcc.Store(id="ov-catalog-sort",   data={"col":"iv","asc":False}),

        html.Div("Aperçu Global — Catalogue des Variables", className="page-title"),
        html.Div("Cliquez sur un nom de variable pour afficher son analyse détaillée.",
                 className="page-subtitle"),

        metric_cards,

        html.Div("📋 Catalogue des Variables",
                 style={"fontWeight":"800","fontSize":"17px","color":"#1e3a5f",
                        "marginBottom":"14px","marginTop":"8px"}),

        # Flex container: catalog (left) + panel (right)
        html.Div([
            # Unified sortable table
            html.Div([
                html.Div(id="ov-catalog-table-wrap")
            ], id="ov-catalog-wrap", className="chart-card",
               style={"flex":"1","minWidth":"0","overflow":"auto"}),
            detail_panel,
        ], style={"display":"flex","gap":"18px","alignItems":"flex-start"}),
    ], className="page-card")


# ══════════════════════════════════════════════════════════════════════════════
#  Callbacks
# ══════════════════════════════════════════════════════════════════════════════
def register_callbacks(app, dep) -> None:

    # v8: IV lazy — lu au premier appel callback, jamais bloquant au démarrage
    _iv_cache_holder: list = [None]
    def _iv_cache_get():
        if _iv_cache_holder[0] is None:
            c = dep.cache.get("iv", default=None, wait=False)
            _iv_cache_holder[0] = c if c is not None else {}
        return _iv_cache_holder[0]
    # Alias compat: _iv_cache is a property-like getter
    class _IVProxy:
        def get(self, k, d=0.0):
            return _iv_cache_get().get(k, d)
    _iv_cache = _IVProxy()

    # ── 0. Render catalog table (sortable) ────────────────────────────────────
    @app.callback(
        Output("ov-catalog-table-wrap", "children"),
        [Input("ov-catalog-sort", "data"),
         Input({"type":"ov-col-sort","index":ALL}, "n_clicks")],
    )
    def render_catalog(sort_data, _clicks):
        sort_data = sort_data or {"col":"iv","asc":False}
        sort_col  = sort_data.get("col","iv")
        sort_asc  = sort_data.get("asc", False)

        df = dep.df
        cols = [c for c in df.columns if c != dep.target_name]

        # Build rows data
        rows_data = []
        for col in cols:
            s    = df[col]
            dtype_lbl = _classify_col(s)
            iv   = _iv_cache.get(col, 0.0)
            pct_nan = s.isnull().mean() * 100
            rows_data.append({
                "col": col, "dtype": dtype_lbl,
                "iv": iv, "pct_nan": pct_nan,
            })

        # Sort
        reverse = not sort_asc
        if sort_col == "iv":
            rows_data.sort(key=lambda r: r["iv"], reverse=reverse)
        elif sort_col == "name":
            rows_data.sort(key=lambda r: r["col"].lower(), reverse=reverse)
        elif sort_col == "type":
            rows_data.sort(key=lambda r: r["dtype"], reverse=reverse)

        TYPE_COLORS = {
            "Flottant":"#4472c4","Entier":"#27ae60","Catégoriel":"#e07b39",
            "Booléen":"#9b59b6","Date/Heure":"#1abc9c","Texte":"#e74c3c",
        }
        TYPE_ICONS = {"Flottant":"🔢","Entier":"🔢","Catégoriel":"🏷️",
                      "Booléen":"🔘","Date/Heure":"📅","Texte":"📝"}

        def _sort_arrow(key):
            if sort_col != key: return " ⇅"
            return " ↑" if sort_asc else " ↓"

        def _sort_style(key):
            base = {"padding":"7px 10px","background":"#f0f4f8","color":"#4472c4" if sort_col==key else "#6b7a8d",
                    "fontWeight":"700","fontSize":"11px","textTransform":"uppercase",
                    "letterSpacing":".4px","borderBottom":"2px solid #e0e4ea",
                    "textAlign":"left","whiteSpace":"nowrap","cursor":"pointer",
                    "userSelect":"none"}
            return base

        header = html.Tr([
            html.Th(
                html.Span(f"Variable{_sort_arrow('name')}",
                          id={"type":"ov-col-sort","index":"name"}, n_clicks=0),
                style={**_sort_style("name"), "width":"52%"}),
            html.Th(
                html.Span(f"Type{_sort_arrow('type')}",
                          id={"type":"ov-col-sort","index":"type"}, n_clicks=0),
                style={**_sort_style("type"), "width":"24%"}),
            html.Th(
                html.Span(f"IV{_sort_arrow('iv')}",
                          id={"type":"ov-col-sort","index":"iv"}, n_clicks=0),
                style={**_sort_style("iv"), "width":"24%"}),
        ])

        table_rows = []
        for rd in rows_data:
            col      = rd["col"]
            dtype_lbl= rd["dtype"]
            iv       = rd["iv"]
            pct_nan  = rd["pct_nan"]
            badge_clr = TYPE_COLORS.get(dtype_lbl, "#6b7a8d")
            iv_lbl   = _iv_label(iv)
            iv_color = ("#e74c3c" if iv >= 0.3 else "#e07b39" if iv >= 0.1
                        else "#4472c4" if iv >= 0.02 else "#9aa5b4")

            # IV mini bar background
            bar_pct = min(int(iv / 0.5 * 100), 100)

            table_rows.append(html.Tr([
                # Variable name
                html.Td(html.Div([
                    html.Span(col,
                              id={"type":"ov-var-click","index":col},
                              n_clicks=0,
                              style={"fontWeight":"700","color":"#4472c4",
                                     "fontSize":"12.5px","cursor":"pointer",
                                     "textDecoration":"underline dotted",
                                     "textUnderlineOffset":"3px"}),
                ]), style={"padding":"6px 10px"}),
                # Type badge
                html.Td(html.Div([
                    html.Span(TYPE_ICONS.get(dtype_lbl,"📊"),
                              style={"marginRight":"4px","fontSize":"12px"}),
                    html.Span(dtype_lbl,
                              style={"background":badge_clr+"22","color":badge_clr,
                                     "borderRadius":"4px","padding":"2px 6px",
                                     "fontSize":"10px","fontWeight":"700",
                                     "border":f"1px solid {badge_clr}44"}),
                ], style={"display":"flex","alignItems":"center","gap":"2px"}),
                    style={"padding":"6px 10px"}),
                # IV with mini bar
                html.Td(html.Div([
                    html.Div(style={
                        "width":f"{bar_pct}%","height":"100%",
                        "background":iv_color+"33","borderRadius":"3px",
                        "position":"absolute","left":"0","top":"0","zIndex":"0",
                    }),
                    html.Span(f"{iv:.3f}",
                              style={"position":"relative","fontWeight":"700",
                                     "color":iv_color,"fontSize":"11.5px",
                                     "marginRight":"4px","zIndex":"1"}),
                    html.Span(iv_lbl,
                              style={"position":"relative","fontSize":"9.5px",
                                     "color":iv_color,"opacity":"0.8","zIndex":"1"}),
                ], style={"position":"relative","display":"flex","alignItems":"center",
                          "gap":"4px","height":"22px"}),
                    style={"padding":"4px 10px","minWidth":"80px"}),
            ], style={"borderBottom":"1px solid #f0f4f8","transition":"background .12s"},
               className="var-row"))

        return html.Table([html.Thead(header), html.Tbody(table_rows)],
                          style={"width":"100%","borderCollapse":"collapse",
                                 "fontSize":"12px",
                                 "fontFamily":"Plus Jakarta Sans, sans-serif"})

    # ── 0b. Update catalog sort state on header click ─────────────────────────
    from dash import State as _State
    @app.callback(
        Output("ov-catalog-sort", "data"),
        [Input({"type":"ov-col-sort","index":ALL}, "n_clicks")],
        [_State("ov-catalog-sort", "data")],
        prevent_initial_call=True,
    )
    def update_sort(n_clicks_list, current_sort):
        triggered = ctx.triggered_id
        if not isinstance(triggered, dict):
            return current_sort or {"col":"iv","asc":False}
        key = triggered.get("index","iv")
        cur = current_sort or {"col":"iv","asc":False}
        if cur.get("col") == key:
            return {"col": key, "asc": not cur.get("asc", False)}
        return {"col": key, "asc": False}

    # ── 1. Select / deselect variable ─────────────────────────────────────────
    @app.callback(
        [Output("ov-selected-var", "data"),
         Output("ov-var-dropdown", "value")],
        [Input({"type":"ov-var-click","index":ALL}, "n_clicks"),
         Input("ov-panel-close",   "n_clicks"),
         Input("ov-var-dropdown",  "value")],
        prevent_initial_call=True,
    )
    def select_var(var_clicks, close_click, dropdown_val):
        triggered = ctx.triggered_id
        if triggered == "ov-panel-close":
            return None, no_update
        if triggered == "ov-var-dropdown":
            return dropdown_val, no_update
        if isinstance(triggered, dict) and triggered.get("type") == "ov-var-click":
            col = triggered["index"]
            return col, col
        return no_update, no_update

    # ── 2. Panel visibility + controls ────────────────────────────────────────
    @app.callback(
        [Output("ov-detail-panel",  "style"),
         Output("ov-catalog-wrap",  "style"),
         Output("ov-panel-varname", "children"),
         Output("ov-bin-controls",  "style"),
         Output("ov-metric-wrap",   "style"),
         Output("ov-sort-wrap",     "style")],
        Input("ov-selected-var", "data"),
    )
    def toggle_panel(col):
        panel_show = {
            "display":"flex","flexDirection":"column","padding":"18px",
            "background":"white","borderRadius":"12px",
            "border":"1.5px solid #e0e4ea","boxShadow":"0 4px 18px rgba(0,0,0,.10)",
            "width":"580px","minWidth":"580px","flexShrink":"0",
            "position":"sticky","top":"0",
            "maxHeight":"calc(100vh - 80px)","overflowY":"hidden",
        }
        cat_style = {"flex":"1","minWidth":"0","overflow":"auto"}
        if col is None:
            return ({"display":"none"}, {**cat_style, "className":"chart-card"},
                    "", {"display":"none"}, {"marginBottom":"10px"}, {"display":"none"})

        dtype   = _classify_col(dep.df[col])
        is_num  = _is_numeric_dtype(dtype)
        badge_clr = {"Flottant":"#4472c4","Entier":"#27ae60","Catégoriel":"#e07b39",
                     "Booléen":"#9b59b6","Texte":"#e74c3c","Date/Heure":"#1abc9c"
                     }.get(dtype,"#6b7a8d")
        title_el = html.Div([
            html.Span(col, style={"fontWeight":"800","color":"#1e3a5f"}),
            html.Span(f" {dtype}",
                      style={"background":badge_clr,"color":"white","borderRadius":"6px",
                             "padding":"1px 8px","fontSize":"11px","fontWeight":"700",
                             "marginLeft":"8px"}),
        ])
        bin_style = ({"display":"flex","gap":"16px","alignItems":"flex-end",
                      "marginBottom":"14px","flexWrap":"wrap"}
                     if is_num else {"display":"none"})
        metric_style = {"marginBottom":"10px"} if dtype != "Texte" else {"display":"none"}
        return (panel_show, cat_style, title_el,
                bin_style, metric_style, {"marginBottom":"12px"})

    # ── 3. Hide N-bins slider when dtree, show dtree params ───────────────────
    @app.callback(
        [Output("ov-bin-n-wrap",          "style"),
         Output("ov-dtree-params-wrap",   "style")],
        Input("ov-bin-method", "value"),
    )
    def toggle_bin_n(method):
        if method == "dtree":
            return ({"display":"none"},
                    {"display":"flex","flexDirection":"column","gap":"8px",
                     "flex":"2","minWidth":"220px"})
        return ({"flex":"1","minWidth":"180px"},
                {"display":"none"})

    # ── 4. Build panel content ─────────────────────────────────────────────────
    @app.callback(
        Output("ov-panel-content", "children"),
        [Input("ov-selected-var",       "data"),
         Input("ov-metric",             "value"),
         Input("ov-bin-n",              "value"),
         Input("ov-bin-method",         "value"),
         Input("ov-sort-by",            "value"),
         Input("ov-dtree-min-samples",  "value"),
         Input("ov-dtree-max-depth",    "value"),
         Input("ov-dtree-max-leaves",   "value")],
    )
    def build_panel(col, metric, n_bins, bin_method, sort_by,
                    dtree_min_samples, dtree_max_depth, dtree_max_leaves):
        if col is None or col not in dep.df.columns:
            return []
        dtype = _classify_col(dep.df[col])
        dtree_params = {
            "min_samples": dtree_min_samples or 20,
            "max_depth":   dtree_max_depth   or 3,
            "max_leaves":  dtree_max_leaves  or 6,
        }
        if _is_cat_dtype(dtype):
            return _build_cat_panel(dep, col, metric or "target",
                                    sort_by or "metric_desc",
                                    _iv_cache.get(col, 0.0))
        elif _is_numeric_dtype(dtype):
            return _build_num_panel(dep, col, metric or "target",
                                    n_bins or 10, bin_method or "quantile",
                                    sort_by or "metric_desc",
                                    _iv_cache.get(col, 0.0),
                                    dtree_params=dtree_params)
        elif dtype == "Texte":
            return _build_text_panel(dep, col)
        return [html.Div(f"Type {dtype} non supporté.",
                         style={"color":"#6b7a8d","fontSize":"13px","padding":"20px"})]


# ══════════════════════════════════════════════════════════════════════════════
#  STATS HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _target_type(dep) -> str:
    """Returns: 'none', 'binary', 'multiclass', 'numeric'"""
    if not dep.supervised:
        return "none"
    if not dep.is_classification:
        return "numeric"
    return "binary" if dep.n_classes == 2 else "multiclass"


def _cramers_v(x: pd.Series, y: pd.Series):
    from scipy.stats import chi2_contingency
    ct = pd.crosstab(x.astype(str), y.astype(str))
    chi2, p, dof, _ = chi2_contingency(ct)
    n = len(x)
    k = min(ct.shape) - 1
    v = float(np.sqrt(chi2 / max(n * k, 1e-9)))
    return float(chi2), float(p), int(dof), min(v, 1.0)


def _welch_posthoc(groups: dict) -> pd.DataFrame:
    """Pairwise Welch t-tests + Holm-Bonferroni correction."""
    keys = [k for k, v in groups.items() if len(v) >= 3]
    if len(keys) < 2:
        return pd.DataFrame()
    rows = []
    for k1, k2 in combinations(keys, 2):
        g1, g2 = groups[k1], groups[k2]
        t, p = sp_stats.ttest_ind(g1, g2, equal_var=False)
        rows.append({"G1":str(k1)[:22],"G2":str(k2)[:22],
                     "ΔMoy":g1.mean()-g2.mean(), "p_raw":p,
                     "N1":len(g1),"N2":len(g2)})
    df_r = pd.DataFrame(rows).sort_values("p_raw").reset_index(drop=True)
    m = len(df_r)
    adj = []
    max_seen = 0.0
    for rank, (_, row) in enumerate(df_r.iterrows()):
        a = min(1.0, row["p_raw"] * (m - rank))
        a = max(a, max_seen)
        max_seen = a
        adj.append(a)
    df_r["p_holm"] = adj
    df_r["Sig"]    = df_r["p_holm"].apply(lambda p: "✅ p<.05" if p < 0.05 else "❌")
    df_r["ΔMoy"]   = df_r["ΔMoy"].apply(lambda x: f"{x:+.3g}")
    df_r["p (Holm)"] = df_r["p_holm"].apply(lambda p: f"{p:.4f}")
    return df_r[["G1","G2","N1","N2","ΔMoy","p (Holm)","Sig"]]


def _normality_report(s: pd.Series) -> list:
    """Return list of (label, value) tuples describing distribution."""
    vals = s.dropna().values
    n    = len(vals)
    if n < 3:
        return [("N", str(n)), ("Statut", "Insuffisant (<3 obs)")]

    rows = []
    rows.append(("N valides", f"{n:,}"))
    rows.append(("Moyenne ± Std", f"{vals.mean():.4g} ± {vals.std():.4g}"))
    rows.append(("Médiane", f"{np.median(vals):.4g}"))

    # Skewness
    skw = float(sp_stats.skew(vals))
    if   abs(skw) < 0.5:  skw_lbl = "Symétrique"
    elif skw > 2:          skw_lbl = f"Forte asymétrie droite ({skw:+.2f})"
    elif skw > 0:          skw_lbl = f"Légère asymétrie droite ({skw:+.2f})"
    elif skw < -2:         skw_lbl = f"Forte asymétrie gauche ({skw:+.2f})"
    else:                  skw_lbl = f"Légère asymétrie gauche ({skw:+.2f})"
    rows.append(("Asymétrie (skewness)", skw_lbl))

    # Kurtosis
    kurt = float(sp_stats.kurtosis(vals))
    if   abs(kurt) < 1:   kurt_lbl = f"Mésokurtique ≈ normale ({kurt:+.2f})"
    elif kurt > 0:         kurt_lbl = f"Leptokurtique — queues épaisses ({kurt:+.2f})"
    else:                  kurt_lbl = f"Platykurtique — queues fines ({kurt:+.2f})"
    rows.append(("Kurtosis (excès)", kurt_lbl))

    # Normality
    if n >= 8:
        stat_n, p_n = sp_stats.normaltest(vals)
        norm_lbl = ("✅ Normale (p=%.4f)" % p_n if p_n > 0.05
                    else "❌ Non-normale (p=%.4f)" % p_n)
        rows.append(("Test normalité D'Agostino-Pearson", norm_lbl))
    else:
        rows.append(("Test normalité", "N/A (n<8)"))

    # Outliers IQR
    q1, q3 = np.percentile(vals, 25), np.percentile(vals, 75)
    iqr     = q3 - q1
    n_iqr   = int(np.sum((vals < q1 - 1.5*iqr) | (vals > q3 + 1.5*iqr)))
    rows.append((f"Outliers IQR×1.5", f"{n_iqr} ({n_iqr/n:.1%})"))

    # Outliers Z>3
    if vals.std() > 0:
        n_z = int(np.sum(np.abs((vals - vals.mean()) / vals.std()) > 3))
        rows.append((f"Outliers |Z|>3", f"{n_z} ({n_z/n:.1%})"))

    # Levene heteroscedasticity (split into quartile groups)
    if n >= 20:
        try:
            qt = pd.qcut(vals, q=4, duplicates="drop")
            grps = [vals[qt == c] for c in qt.cat.categories if (qt == c).sum() >= 3]
            if len(grps) >= 2:
                lev_stat, lev_p = sp_stats.levene(*grps)
                lev_lbl = ("✅ Homoscédastique (p=%.4f)" % lev_p if lev_p > 0.05
                           else "❌ Hétéroscédastique (p=%.4f)" % lev_p)
                rows.append(("Hétéroscédasticité (Levene)", lev_lbl))
        except Exception:
            pass

    return rows


def _cohens_d(g1: np.ndarray, g2: np.ndarray) -> float:
    """Cohen's d effect size between two groups."""
    n1, n2 = len(g1), len(g2)
    if n1 < 2 or n2 < 2:
        return 0.0
    pooled_std = np.sqrt(((n1 - 1) * g1.std(ddof=1)**2 +
                          (n2 - 1) * g2.std(ddof=1)**2) / (n1 + n2 - 2))
    if pooled_std < 1e-12:
        return 0.0
    return float((g1.mean() - g2.mean()) / pooled_std)


def _kde_values(vals: np.ndarray, n_pts=200):
    """Compute KDE and return (x_grid, density). Sub-sampled to ≤10k for speed."""
    if len(vals) < 3:
        return np.array([]), np.array([])
    # v7: cap KDE samples at 10k — negligible impact on density estimate
    if len(vals) > 10_000:
        rng  = np.random.default_rng(42)
        vals = rng.choice(vals, size=10_000, replace=False)
    try:
        kde  = sp_stats.gaussian_kde(vals, bw_method="scott")
        xmin, xmax = vals.min(), vals.max()
        pad  = (xmax - xmin) * 0.1 + 1e-6
        xg   = np.linspace(xmin - pad, xmax + pad, n_pts)
        return xg, kde(xg)
    except Exception:
        return np.array([]), np.array([])


# ══════════════════════════════════════════════════════════════════════════════
#  HORIZONTAL BAR CHART (freq / count)
# ══════════════════════════════════════════════════════════════════════════════

def _bar_chart_h(cats, counts, freqs, metric,
                 title="", is_ordered_by_value=False,
                 sort_by="metric_desc") -> go.Figure:
    """Clean horizontal bar chart for freq / count metrics."""
    df_plot = pd.DataFrame({
        "cat":   list(cats),
        "count": [counts[c] for c in cats],
        "freq":  [freqs[c]  for c in cats],
    })
    df_plot["rare"] = ((df_plot["freq"] < RARE_THR_FREQ) |
                       (df_plot["count"] < RARE_THR_COUNT))

    if metric == "count":
        df_plot["xval"] = df_plot["count"].astype(float)
        x_title = "Effectif (n)"
        x_fmt   = lambda v: f"{int(v):,}"
        ref_val = float(df_plot["xval"].mean())
        ref_lbl = f"μ={ref_val:.0f}"
    else:  # freq
        df_plot["xval"] = df_plot["freq"] * 100.0
        x_title = "Fréquence (%)"
        x_fmt   = lambda v: f"{v:.1f}%"
        ref_val = float(df_plot["xval"].mean())
        ref_lbl = f"μ={ref_val:.1f}%"

    df_plot = _apply_sort(df_plot, sort_by, is_ordered_by_value)
    df_plot = df_plot.head(MAX_CAT_SHOWN).reset_index(drop=True)

    n_rows   = len(df_plot)
    y_labels = [str(c)[:38] for c in df_plot["cat"]]

    colors = [
        "rgba(190,195,210,0.55)" if r else "#4472c4"
        for r in df_plot["rare"]
    ]
    texts = [x_fmt(v) for v in df_plot["xval"]]

    fig = go.Figure(go.Bar(
        x=df_plot["xval"].tolist(),
        y=list(range(n_rows)),
        orientation="h",
        marker=dict(
            color=colors,
            line=dict(color="rgba(68,114,196,0.4)", width=0.8),
        ),
        text=texts,
        textposition="outside",
        textfont=dict(size=9.5, color="#374151", family="Plus Jakarta Sans"),
        hovertemplate=[
            f"<b>{str(r['cat'])[:40]}</b><br>"
            f"{x_title}: {x_fmt(r['xval'])}<br>"
            f"Rare: {'oui' if r['rare'] else 'non'}"
            "<extra></extra>"
            for _, r in df_plot.iterrows()
        ],
        cliponaxis=False,
    ))

    # Reference mean line
    fig.add_vline(x=ref_val, line_dash="dot", line_color="#e07b39",
                  line_width=1.8,
                  annotation_text=ref_lbl,
                  annotation_position="top right",
                  annotation_font=dict(size=9, color="#e07b39",
                                       family="Plus Jakarta Sans"))

    # x range: add 30% right for text labels
    x_max = float(df_plot["xval"].max()) if len(df_plot) > 0 else 1.0
    x_range = [0, x_max * 1.35]

    max_lbl_len = max((len(l) for l in y_labels), default=10)
    left_margin = min(max(max_lbl_len * 6, 130), 200)

    fig.update_layout(
        title=dict(text=title, font=dict(size=11, color="#1e3a5f",
                                         family="Plus Jakarta Sans")),
        xaxis=dict(title=x_title, gridcolor=GRID, gridwidth=0.7,
                   tickfont=dict(size=10), range=x_range,
                   zeroline=True, zerolinecolor="#cdd3db"),
        yaxis=dict(
            tickmode="array", tickvals=list(range(n_rows)), ticktext=y_labels,
            tickfont=dict(size=10.5, color="#1e3a5f",
                          family="Plus Jakarta Sans", weight="bold"),
            autorange="reversed", showgrid=False,
            range=[n_rows - 0.5, -0.5],
        ),
        plot_bgcolor="#fafbfc", paper_bgcolor="white",
        margin=dict(l=left_margin, r=16, t=42, b=48),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
        height=max(300, min(n_rows * 32 + 100, 620)),
        hoverlabel=dict(bgcolor="#1e3a5f", font_size=11, font_color="white",
                        bordercolor="#1e3a5f", font_family="Plus Jakarta Sans"),
        showlegend=False,
    )
    return fig


# ══════════════════════════════════════════════════════════════════════════════
#  BUBBLE CHART (target / meandiff / woe)
# ══════════════════════════════════════════════════════════════════════════════

def _woe_values(dep, series: pd.Series, cats: list) -> dict:
    """
    Weight of Evidence per category.
    Works for both binary target (classic WoE) and continuous target (correlation-based).
    Returns dict {cat: woe_value}.
    """
    woe = {}
    if not dep.supervised:
        return woe
    tgt = dep.display_df[dep.target_name]  # v8: display_df
    if dep.is_classification and dep.n_classes == 2:
        y_bin = (tgt == dep.classes[-1]).astype(int)
        total_events    = max(y_bin.sum(), 1)
        total_nonevents = max((1 - y_bin).sum(), 1)
        for cat in cats:
            mask = series == cat
            ev  = y_bin[mask].sum()
            nev = (1 - y_bin[mask]).sum()
            dist_e  = ev  / total_events
            dist_ne = nev / total_nonevents
            if dist_e > 0 and dist_ne > 0:
                woe[cat] = float(np.log(dist_e / dist_ne))
            else:
                woe[cat] = 0.0
    else:
        # Continuous: mean of target in group vs global mean (log-ratio)
        global_mean = tgt.dropna().mean()
        for cat in cats:
            mask = series == cat
            grp_mean = tgt[mask].dropna().mean()
            if pd.isna(grp_mean) or global_mean == 0:
                woe[cat] = 0.0
            else:
                ratio = grp_mean / max(abs(global_mean), 1e-9)
                woe[cat] = float(np.log(max(ratio, 1e-9)))
    return woe


def _apply_sort(df_plot: pd.DataFrame, sort_by: str, is_ordered_by_value: bool) -> pd.DataFrame:
    """Sort df_plot rows according to the sort_by parameter."""
    if is_ordered_by_value:
        return df_plot  # bins: keep natural order
    if sort_by == "metric_desc":
        return df_plot.sort_values("xval", ascending=False, na_position="last")
    elif sort_by == "metric_asc":
        return df_plot.sort_values("xval", ascending=True, na_position="first")
    elif sort_by == "freq_desc":
        return df_plot.sort_values("freq", ascending=False)
    elif sort_by == "freq_asc":
        return df_plot.sort_values("freq", ascending=True)
    elif sort_by == "alpha":
        df_plot = df_plot.copy()
        df_plot["_sort_key"] = df_plot["cat"].astype(str)
        return df_plot.sort_values("_sort_key").drop(columns=["_sort_key"])
    else:
        return df_plot.sort_values("xval", ascending=True, na_position="first")


def _bubble_chart(dep, cats, counts, freqs, metric,
                  target_means=None, target_cis=None,
                  target_props=None,
                  target_groups=None,
                  woe_values=None,
                  global_target_mean=None,
                  title="", is_ordered_by_value=False,
                  sort_by="metric_desc") -> go.Figure:
    """Router: freq/count → bar chart, others → bubble/dot chart."""
    if metric in ("freq", "count"):
        return _bar_chart_h(cats, counts, freqs, metric,
                            title=title,
                            is_ordered_by_value=is_ordered_by_value,
                            sort_by=sort_by)
    return _dot_chart(dep, cats, counts, freqs, metric,
                      target_means=target_means, target_cis=target_cis,
                      target_props=target_props, target_groups=target_groups,
                      woe_values=woe_values, global_target_mean=global_target_mean,
                      title=title, is_ordered_by_value=is_ordered_by_value,
                      sort_by=sort_by)


def _dot_chart(dep, cats, counts, freqs, metric,
               target_means=None, target_cis=None,
               target_props=None, target_groups=None,
               woe_values=None, global_target_mean=None,
               title="", is_ordered_by_value=False,
               sort_by="metric_desc") -> go.Figure:
    """Horizontal dot/bubble chart for target / meandiff / woe metrics."""
    df_plot = pd.DataFrame({
        "cat":   list(cats),
        "count": [counts[c] for c in cats],
        "freq":  [freqs[c]  for c in cats],
    })
    df_plot["rare"] = ((df_plot["freq"] < RARE_THR_FREQ) |
                       (df_plot["count"] < RARE_THR_COUNT))

    # ── Compute x-values ──────────────────────────────────────────────────────
    if metric == "count":
        df_plot["xval"] = df_plot["count"].astype(float)

    elif metric == "freq":
        df_plot["xval"] = df_plot["freq"] * 100.0

    elif metric == "woe" and woe_values:
        df_plot["xval"] = df_plot["cat"].map(woe_values).fillna(0.0)

    elif metric == "meandiff" and target_groups is not None and global_target_mean is not None:
        all_vals = (np.concatenate(list(target_groups.values()))
                    if target_groups else np.array([]))
        diffs, sigs, ds, pvals = {}, {}, {}, {}
        for cat in cats:
            grp = target_groups.get(cat, np.array([]))
            if len(grp) >= 2:
                diff        = grp.mean() - global_target_mean
                d           = _cohens_d(grp, all_vals)
                _, p        = sp_stats.ttest_1samp(grp, global_target_mean)
                diffs[cat]  = diff
                sigs[cat]   = (p < 0.05 and abs(d) >= 0.2)
                ds[cat]     = d
                pvals[cat]  = p
            else:
                diffs[cat] = 0.0; sigs[cat] = False
                ds[cat]    = 0.0; pvals[cat] = 1.0
        df_plot["xval"]     = df_plot["cat"].map(diffs).fillna(0.0)
        df_plot["sig"]      = df_plot["cat"].map(sigs).fillna(False)
        df_plot["cohens_d"] = df_plot["cat"].map(ds).fillna(0.0)
        df_plot["pval"]     = df_plot["cat"].map(pvals).fillna(1.0)

    elif metric == "target" and target_means is not None:
        df_plot["xval"] = df_plot["cat"].map(target_means).fillna(np.nan)

    elif metric == "target" and target_props is not None:
        df_plot["xval"] = df_plot["cat"].map(
            lambda c: target_props.get(c, {}).get("cls1", np.nan))
    else:
        df_plot["xval"] = df_plot["freq"] * 100.0

    # ── Sort & cap ────────────────────────────────────────────────────────────
    df_plot = _apply_sort(df_plot, sort_by, is_ordered_by_value)
    df_plot = df_plot.head(MAX_CAT_SHOWN).reset_index(drop=True)

    n_rows      = len(df_plot)
    y_pos       = list(range(n_rows))
    # Truncate but keep readable label lengths
    y_labels    = [str(c)[:38] for c in df_plot["cat"]]
    valid_xvals = df_plot["xval"].dropna()

    # Bubble sizes ∝ frequency
    max_freq = df_plot["freq"].max() if df_plot["freq"].max() > 0 else 1.0
    sizes    = (df_plot["freq"] / max_freq * 22 + 9).clip(7, 32).tolist()

    # ── Reference line value (metric-dependent) ───────────────────────────────
    if metric == "meandiff":
        ref_x     = 0.0
        ref_label = "Δ=0 (ref.)"
        ref_color = "#6b7a8d"
        ref_dash  = "dash"
    elif metric == "woe":
        ref_x     = 0.0
        ref_label = "WoE=0"
        ref_color = "#6b7a8d"
        ref_dash  = "dash"
    elif metric == "target" and global_target_mean is not None:
        ref_x     = global_target_mean
        ref_label = f"Moy. globale {global_target_mean:.3g}"
        ref_color = "#4472c4"
        ref_dash  = "dot"
    elif len(valid_xvals) > 0:
        ref_x     = float(valid_xvals.mean())
        ref_label = f"μ={ref_x:.3g}"
        ref_color = "#6b7a8d"
        ref_dash  = "dot"
    else:
        ref_x = None

    fig = go.Figure()

    # ── MEANDIFF — two traces + significance annotation bands ─────────────────
    if metric == "meandiff" and "sig" in df_plot.columns:
        # Background shading for significant positive / negative
        sig_pos = df_plot[(df_plot["sig"]) & (df_plot["xval"] > 0)]
        sig_neg = df_plot[(df_plot["sig"]) & (df_plot["xval"] < 0)]

        for is_sig in [False, True]:
            sub = df_plot[df_plot["sig"] == is_sig]
            if len(sub) == 0:
                continue
            sub_y   = [y_pos[i] for i in sub.index]
            sub_sz  = [sizes[i]  for i in sub.index]

            if is_sig:
                # Significant: bold colour (orange if positive, blue if negative)
                sub_clr = [
                    "#e07b39" if row["xval"] > 0 else "#4472c4"
                    for _, row in sub.iterrows()
                ]
                marker_line_clr  = "white"
                marker_line_wid  = 2.0
                marker_opacity   = 1.0
                marker_sym       = "diamond"
                trace_name       = "★ Sig. (p<.05 & |d|≥.2)"
            else:
                sub_clr = [
                    "rgba(190,195,210,0.55)" if row["rare"] else "rgba(150,162,185,0.62)"
                    for _, row in sub.iterrows()
                ]
                marker_line_clr  = "rgba(200,208,220,0.5)"
                marker_line_wid  = 0.8
                marker_opacity   = 0.75
                marker_sym       = "circle"
                trace_name       = "Non sig."

            texts = [
                f"<b>{str(r['cat'])[:40]}</b><br>"
                f"Δ = {r['xval']:+.4g}<br>"
                f"Cohen d = {r['cohens_d']:+.3f}   p = {r['pval']:.4f}<br>"
                f"Fréq: {r['freq']:.1%}   n={r['count']:,}<br>"
                f"{'<b>✅ SIGNIFICATIF</b>' if r['sig'] else '❌ Non significatif'}"
                for _, r in sub.iterrows()
            ]
            fig.add_trace(go.Scatter(
                x=sub["xval"].tolist(), y=sub_y,
                mode="markers",
                name=trace_name,
                marker=dict(
                    symbol=marker_sym,
                    size=sub_sz,
                    color=sub_clr,
                    line=dict(width=marker_line_wid, color=marker_line_clr),
                    opacity=marker_opacity,
                ),
                text=texts,
                hovertemplate="%{text}<extra></extra>",
                showlegend=True,
            ))

        # Reference line at 0
        fig.add_vline(x=0, line_dash="dash", line_color="#aab0bc",
                      line_width=1.8)
        # Annotation on top
        fig.add_annotation(
            x=0, y=-0.8, xanchor="center",
            text=f"<b>μ_global={global_target_mean:.3g}</b>",
            showarrow=False,
            font=dict(size=9, color="#6b7a8d", family="Plus Jakarta Sans"),
            bgcolor="rgba(255,255,255,0.8)", borderpad=2,
        )

    # ── WoE ──────────────────────────────────────────────────────────────────
    elif metric == "woe":
        clrs = [
            "rgba(190,195,210,0.5)" if row["rare"] else
            ("#4472c4" if row["xval"] >= 0 else "#e74c3c")
            for _, row in df_plot.iterrows()
        ]
        fig.add_trace(go.Scatter(
            x=df_plot["xval"].tolist(), y=y_pos,
            mode="markers",
            marker=dict(symbol="circle", size=sizes, color=clrs,
                        line=dict(width=0.8, color="rgba(255,255,255,0.6)"),
                        opacity=0.9),
            text=[
                f"<b>{str(r['cat'])[:40]}</b><br>"
                f"WoE = {r['xval']:+.4f}<br>"
                f"Fréq: {r['freq']:.1%}   n={r['count']:,}"
                for _, r in df_plot.iterrows()
            ],
            hovertemplate="%{text}<extra></extra>",
            showlegend=False,
        ))
        if ref_x is not None:
            fig.add_vline(x=ref_x, line_dash=ref_dash,
                          line_color=ref_color, line_width=1.8)

    # ── Standard (target / freq / count) ─────────────────────────────────────
    else:
        clrs = [
            "rgba(190,195,210,0.5)" if r else "rgba(68,114,196,0.85)"
            for r in df_plot["rare"]
        ]
        err_x = None
        if metric == "target" and target_cis is not None:
            err_vals = [target_cis.get(c, 0) for c in df_plot["cat"]]
            err_x = dict(type="data", array=err_vals, visible=True,
                         color="rgba(68,114,196,0.4)", thickness=1.5, width=5)
        texts = [
            f"<b>{str(r['cat'])[:40]}</b><br>"
            f"Valeur: {r['xval']:.4g}<br>"
            f"Fréq: {r['freq']:.1%}   n={r['count']:,}"
            for _, r in df_plot.iterrows()
        ]
        fig.add_trace(go.Scatter(
            x=df_plot["xval"].tolist(), y=y_pos,
            mode="markers",
            marker=dict(size=sizes, color=clrs,
                        line=dict(width=0.8, color="rgba(68,114,196,0.45)")),
            error_x=err_x,
            text=texts, hovertemplate="%{text}<extra></extra>",
            showlegend=False,
        ))
        # Reference line (metric-specific mean)
        if ref_x is not None:
            fig.add_vline(x=ref_x, line_dash=ref_dash,
                          line_color=ref_color, line_width=1.8,
                          annotation_text=ref_label,
                          annotation_position="top right",
                          annotation_font=dict(size=9, color=ref_color,
                                               family="Plus Jakarta Sans"))

    # ── Value annotations — always RIGHT of bubble ────────────────────────────
    if len(valid_xvals) > 1:
        span = float(valid_xvals.max() - valid_xvals.min()) or 1.0
    else:
        span = 1.0

    for i, row in df_plot.iterrows():
        xv = row["xval"]
        if pd.isna(xv):
            continue
        sz = sizes[i]
        is_rare_row = bool(row["rare"])
        is_sig_row  = bool(row.get("sig", False))

        if metric == "meandiff":
            if is_sig_row:
                lbl = f" <b>{xv:+.3g}</b> ★d={row['cohens_d']:+.2f}"
                font_color = "#e07b39" if xv > 0 else "#4472c4"
                font_size  = 9.5
            else:
                lbl = f" {xv:+.3g}"
                font_color = "#9aa5b4" if is_rare_row else "#6b7a8d"
                font_size  = 8.5
        elif metric == "woe":
            lbl = f" {xv:+.3f}"
            font_color = "#9aa5b4" if is_rare_row else (
                "#4472c4" if xv >= 0 else "#e74c3c")
            font_size = 9
        else:
            lbl = f" {xv:.3g} ({row['freq']:.1%})"
            font_color = "#9aa5b4" if is_rare_row else "#374151"
            font_size  = 8.5

        fig.add_annotation(
            x=xv, y=y_pos[i],
            text=lbl, showarrow=False,
            xanchor="left",
            xshift=int(sz / 2) + 4,
            yshift=0,
            font=dict(size=font_size, color=font_color,
                      family="Plus Jakarta Sans"),
        )

    # ── Layout ────────────────────────────────────────────────────────────────
    x_title_map = {
        "count":    "Effectif",
        "freq":     "Fréquence (%)",
        "target":   "Target moyen / proportion",
        "meandiff": "Δ Mean (groupe − global)",
        "woe":      "Weight of Evidence (WoE)",
    }

    if len(valid_xvals) > 0:
        x_lo  = float(valid_xvals.min())
        x_hi  = float(valid_xvals.max())
        sp    = (x_hi - x_lo) or 1.0
        # Extra right space for annotations (≈35% of span)
        x_rng = [x_lo - sp * 0.06, x_hi + sp * 0.42]
    else:
        x_rng = None

    # Left margin: longest label × ~6px/char, min 140 max 220
    max_lbl_len = max((len(l) for l in y_labels), default=10)
    left_margin = min(max(max_lbl_len * 6, 140), 220)

    fig.update_layout(
        title=dict(text=title, font=dict(size=11, color="#1e3a5f",
                                         family="Plus Jakarta Sans")),
        xaxis=dict(
            title=x_title_map.get(metric, metric),
            gridcolor=GRID, gridwidth=0.8,
            tickfont=dict(size=10, color="#374151"),
            zeroline=(metric in ("meandiff", "woe")),
            zerolinecolor="#cdd3db", zerolinewidth=1,
            range=x_rng,
        ),
        yaxis=dict(
            tickmode="array",
            tickvals=y_pos,
            ticktext=y_labels,
            tickfont=dict(size=10.5, color="#1e3a5f",
                          family="Plus Jakarta Sans", weight="bold"),
            autorange="reversed",
            showgrid=False,
            # keep a small pad above/below first and last row
            range=[n_rows - 0.5, -0.5],
        ),
        plot_bgcolor="#fafbfc",
        paper_bgcolor="white",
        margin=dict(l=left_margin, r=16, t=42, b=48),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
        height=max(300, min(n_rows * 32 + 100, 620)),
        legend=dict(
            font=dict(size=10), orientation="h",
            x=0.0, y=1.06,
            bgcolor="rgba(255,255,255,.9)",
            bordercolor="#e0e4ea", borderwidth=1,
        ),
        showlegend=(metric == "meandiff"),
        hoverlabel=dict(bgcolor="#1e3a5f", font_size=11,
                        font_color="white", bordercolor="#1e3a5f",
                        font_family="Plus Jakarta Sans"),
    )
    return fig


# ══════════════════════════════════════════════════════════════════════════════
#  CATEGORICAL PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _build_cat_panel(dep, col: str, metric: str, sort_by: str = "metric_desc",
                     iv: float = 0.0) -> list:
    # v8: display_df for panel charts (fast)
    s     = dep.display_df[col].fillna("__NaN__").astype(str)
    n_tot = len(s)
    vc    = s.value_counts()

    cats   = list(vc.index)
    counts = vc.to_dict()
    freqs  = {c: counts[c] / n_tot for c in cats}

    tt = _target_type(dep)
    target_means = None
    target_cis   = None
    target_props = None

    # Compute target stats per category
    if tt == "numeric":
        target_means, target_cis = {}, {}
        tgt = dep.display_df[dep.target_name]  # v8
        for cat in cats:
            mask = s == str(cat)
            vals = tgt[mask].dropna().values
            if len(vals) < 1:
                target_means[cat] = np.nan; target_cis[cat] = 0; continue
            m = vals.mean()
            ci = (sp_stats.t.ppf(0.975, len(vals)-1) * vals.std(ddof=1) / np.sqrt(len(vals))
                  if len(vals) >= 2 else 0.0)
            target_means[cat] = m
            target_cis[cat]   = ci

    elif tt in ("binary", "multiclass"):
        target_props = {}
        tgt = dep.display_df[dep.target_name]  # v8
        for cat in cats:
            mask = s == str(cat)
            grp  = tgt[mask].dropna()
            props = {}
            for cls in dep.classes:
                props[f"cls_{cls}"] = (grp == cls).mean()
            props["cls1"] = props.get(f"cls_{dep.classes[-1]}", 0.0)
            target_props[cat] = props

    # Compute target_groups for meandiff/woe, and global_target_mean for all metrics
    target_groups      = None
    global_target_mean = None
    if dep.supervised:
        tgt_s = dep.display_df[dep.target_name]  # v8
        if dep.is_classification:
            from sklearn.preprocessing import LabelEncoder
            le      = LabelEncoder()
            tgt_num = pd.Series(le.fit_transform(tgt_s.fillna(tgt_s.mode().iloc[0])),
                                index=tgt_s.index)
        else:
            tgt_num = tgt_s.fillna(tgt_s.median())
        global_target_mean = float(tgt_num.mean())
        if metric in ("meandiff", "woe"):
            target_groups = {cat: tgt_num[s == cat].dropna().values for cat in cats}

    # WoE values
    woe_vals = _woe_values(dep, s, cats) if metric == "woe" else None

    # Build bubble chart
    fig_bubble = _bubble_chart(
        dep, cats, counts, freqs, metric,
        target_means=target_means, target_cis=target_cis,
        target_props=target_props,
        target_groups=target_groups,
        woe_values=woe_vals,
        global_target_mean=global_target_mean,
        title=f"Distribution de '{col}' — mesure: {metric}",
        sort_by=sort_by,
    )

    elements = []

    # ── Basic info table ──────────────────────────────────────────────────────
    n_rare   = sum(1 for c in cats
                   if freqs[c] < RARE_THR_FREQ or counts[c] < RARE_THR_COUNT)
    pct_nan  = dep.df[col].isnull().mean()  # full pass for accuracy
    info_rows = [
        ("N catégories",         f"{len(cats)}"),
        ("N catégories rares",   f"{n_rare}  (<1% ou <10 obs)"),
        ("Mode (plus fréquent)", f"{cats[0]}  ({freqs[cats[0]]:.1%})"),
        ("2ème fréquent",        f"{cats[1]}  ({freqs[cats[1]]:.1%})" if len(cats)>1 else "—"),
        ("% NaN",                f"{pct_nan:.1%}"
                                 + (" ⚠️" if pct_nan > 0.05 else "")),
        ("IV (Information Value)", f"{iv:.4f}  → {_iv_label(iv)}"),
    ]
    if tt in ("binary","multiclass") and target_props:
        chi2, p_chi2, dof, v = _cramers_v(
            s.rename(col), dep.display_df[dep.target_name].astype(str))  # v8
        assoc = ("Nulle" if v < 0.1 else "Faible" if v < 0.2 else
                 "Modérée" if v < 0.4 else "Forte")
        info_rows += [
            ("Chi² (df=%d)" % dof,   f"{chi2:.3f}  (p={p_chi2:.4f})"),
            ("V de Cramér",          f"{v:.4f}  → {assoc}"),
            ("Chi² significatif",    "✅ Oui (p<.05)" if p_chi2 < 0.05 else "❌ Non (p≥.05)"),
        ]
    elif tt == "numeric" and target_means:
        grps = {c: dep.display_df[dep.target_name][s == c].dropna().values
                for c in cats if (s == c).sum() >= 3}
        if len(grps) >= 2:
            try:
                f_stat, p_anova = sp_stats.f_oneway(*grps.values())
                info_rows += [
                    ("ANOVA F-stat", f"{f_stat:.3f}  (p={p_anova:.4f})"),
                    ("ANOVA significatif", "✅ Oui" if p_anova < 0.05 else "❌ Non"),
                ]
            except Exception:
                pass

    elements.append(_info_table(info_rows, "ℹ️ Informations"))
    elements.append(_graph(fig_bubble, height=fig_bubble.layout.height or 320))

    # ── Post-hoc / Chi2 detail ────────────────────────────────────────────────
    if tt == "numeric" and target_means and len(cats) >= 2:
        grps = {c: dep.display_df[dep.target_name][s == c].dropna().values
                for c in cats}  # v8
        ph_df = _welch_posthoc(grps)
        if not ph_df.empty:
            elements.append(html.Div("🔬 Tests post-hoc (Welch + Holm-Bonferroni)",
                                     className="chart-card-title",
                                     style={"marginTop":"16px"}))
            elements.append(_df_table(ph_df.head(30)))

    # ── KDE overlay of target by category ────────────────────────────────────
    if tt == "numeric" and target_means:
        top_cats = [c for c in cats if counts.get(c,0) >= RARE_THR_COUNT][:6]
        fig_kde = go.Figure()
        tgt = dep.display_df[dep.target_name]
        for i, cat in enumerate(top_cats):
            vals = tgt[s == cat].dropna().values
            if len(vals) < 5: continue
            xg, dens = _kde_values(vals)
            if len(xg) == 0: continue
            clr = PALETTE[i % len(PALETTE)]
            fig_kde.add_trace(go.Scatter(
                x=xg, y=dens, fill="tozeroy",
                fillcolor=_hex_alpha(clr, 0.12),
                line=dict(color=clr, width=2),
                name=str(cat)[:25],
            ))
        fig_kde.update_layout(
            title=f"Distribution du target par catégorie (top {len(top_cats)})",
            xaxis=dict(title=dep.target_name, gridcolor=GRID, zeroline=False),
            yaxis=dict(title="Densité", gridcolor=GRID, zeroline=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=36,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_kde, height=240, mt=14))

    # ── KDE overlay of variable distribution per class (if classification) ───
    if tt in ("binary","multiclass"):
        tgt = dep.display_df[dep.target_name]  # v8
        # proportions stacked bar per category
        top_cats = [c for c in cats if counts.get(c,0) >= RARE_THR_COUNT][:25]
        fig_stack = go.Figure()
        for i, cls in enumerate(dep.classes):
            y_vals = [(dep.display_df[col].fillna("__NaN__").astype(str) == c) & (tgt == cls)  # v8
                      for c in top_cats]
            props  = [v.sum() / max(counts.get(c,1), 1) for v, c in zip(y_vals, top_cats)]
            fig_stack.add_trace(go.Bar(
                x=[str(c)[:30] for c in top_cats],
                y=props,
                name=f"Cls {cls}",
                marker_color=PALETTE[i % len(PALETTE)],
            ))
        fig_stack.update_layout(
            barmode="stack",
            title="Proportion des classes par catégorie",
            xaxis=dict(tickangle=-35, gridcolor=GRID, tickfont=dict(size=9)),
            yaxis=dict(title="Proportion", gridcolor=GRID, range=[0,1.05]),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=36,b=80),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_stack, height=260, mt=14))

    return elements


# ══════════════════════════════════════════════════════════════════════════════
#  NUMERIC PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _bin_series(series: pd.Series, target, n_bins: int, method: str,
                dtree_params: dict = None) -> pd.Series:
    s = series.dropna()
    if method == "dtree" and target is not None:
        try:
            from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
            p   = dtree_params or {}
            msl = p.get("min_samples", 20)
            md  = p.get("max_depth",   3)
            mln = p.get("max_leaves",  6)
            X   = s.values.reshape(-1, 1)
            y   = target.loc[s.index].fillna(target.median()).values
            is_cls = y.dtype.kind not in ("f",) or len(np.unique(y)) <= 20
            dt = (DecisionTreeClassifier(max_depth=md, max_leaf_nodes=mln,
                                          min_samples_leaf=msl, random_state=42)
                  if is_cls else
                  DecisionTreeRegressor(max_depth=md, max_leaf_nodes=mln,
                                         min_samples_leaf=msl, random_state=42))
            dt.fit(X, y)
            thrs = sorted(set(dt.tree_.threshold[dt.tree_.threshold > -2]))
            cuts = [-np.inf] + thrs + [np.inf]
            return pd.cut(s, bins=cuts, duplicates="drop")
        except Exception:
            pass
    if method == "quantile":
        return pd.qcut(s, q=n_bins, duplicates="drop")
    return pd.cut(s, bins=n_bins, duplicates="drop")


def _build_num_panel(dep, col: str, metric: str, n_bins: int, method: str,
                     sort_by: str = "metric_desc", iv: float = 0.0,
                     dtree_params: dict = None) -> list:
    # v8: display_df for all panel analysis (fast)
    s   = dep.display_df[col].dropna()
    tt  = _target_type(dep)
    pct_nan = dep.df[col].isnull().mean()

    elements = []

    # ── Distribution stats table ──────────────────────────────────────────────
    dist_rows = _normality_report(s)
    dist_rows += [
        ("% NaN", f"{pct_nan:.1%}" + (" ⚠️" if pct_nan > 0.05 else "")),
        ("IV (Information Value)", f"{iv:.4f}  → {_iv_label(iv)}"),
    ]
    elements.append(_info_table(dist_rows, "📊 Statistiques de distribution"))

    # ── KDE of the variable itself ────────────────────────────────────────────
    xg, dens = _kde_values(s.values)
    fig_kde_self = go.Figure()
    if len(xg) > 0:
        fig_kde_self.add_trace(go.Scatter(
            x=xg, y=dens, fill="tozeroy",
            fillcolor="rgba(68,114,196,0.12)",
            line=dict(color="#4472c4", width=2),
            name=col, showlegend=False,
        ))
        # Rug
        fig_kde_self.add_trace(go.Scatter(
            x=s.sample(min(500, len(s)), random_state=42).values,
            y=np.zeros(min(500, len(s))),
            mode="markers", marker=dict(symbol="line-ns",size=8,
                                         color="rgba(68,114,196,0.35)",
                                         line=dict(width=1,color="rgba(68,114,196,0.5)")),
            showlegend=False, hoverinfo="x",
        ))
    q1,q3  = s.quantile([0.25,0.75])
    fig_kde_self.add_vrect(x0=q1, x1=q3,
        fillcolor="rgba(68,114,196,0.07)",
        line_width=0,
        annotation_text="IQR", annotation_position="top left",
        annotation_font_size=9)
    fig_kde_self.update_layout(
        title=f"Distribution de '{col}'",
        xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
        yaxis=dict(title="Densité", gridcolor=GRID, zeroline=False),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=50,r=20,t=36,b=40),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
    )
    elements.append(_graph(fig_kde_self, height=220, mt=14))

    # ── KDE by class (classification target) ─────────────────────────────────
    if tt in ("binary", "multiclass"):
        fig_kde_cls = go.Figure()
        tgt = dep.display_df[dep.target_name]
        for i, cls in enumerate(dep.classes):
            vals = s[dep.display_df[dep.target_name] == cls].values
            if len(vals) < 5: continue
            xg_c, dens_c = _kde_values(vals)
            if len(xg_c) == 0: continue
            clr = PALETTE[i % len(PALETTE)]
            fig_kde_cls.add_trace(go.Scatter(
                x=xg_c, y=dens_c, fill="tozeroy",
                fillcolor=_hex_alpha(clr, 0.13),
                line=dict(color=clr, width=2),
                name=f"Classe {cls}",
            ))
        fig_kde_cls.update_layout(
            title=f"Distribution de '{col}' par classe",
            xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
            yaxis=dict(title="Densité", gridcolor=GRID, zeroline=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=36,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_kde_cls, height=220, mt=14))

    # ── Scatter + spline (numeric target) ────────────────────────────────────
    if tt == "numeric":
        tgt    = dep.display_df[dep.target_name].dropna()
        common = s.index.intersection(tgt.index)
        xs     = s.loc[common].values
        ys     = tgt.loc[common].values

        # Pearson + Spearman
        r_pear, p_pear   = sp_stats.pearsonr(xs, ys)
        r_spear, p_spear = sp_stats.spearmanr(xs, ys)

        # R²
        from scipy.stats import linregress
        slope, intercept, r_val, _, _ = linregress(xs, ys)
        r2 = r_val ** 2

        # Polynomial spline (deg 3)
        sort_idx = np.argsort(xs)
        xs_s, ys_s = xs[sort_idx], ys[sort_idx]
        n_knots = min(max(int(len(xs)/30), 3), 15)
        try:
            from scipy.interpolate import make_smoothing_spline
            spl = make_smoothing_spline(xs_s, ys_s)
            xg_sp = np.linspace(xs_s.min(), xs_s.max(), 300)
            yg_sp = spl(xg_sp)
        except Exception:
            xg_sp = np.linspace(xs_s.min(), xs_s.max(), 300)
            yg_sp = slope * xg_sp + intercept

        fig_scat = go.Figure()
        samp = np.random.choice(len(xs), min(500, len(xs)), replace=False)
        fig_scat.add_trace(go.Scatter(
            x=xs[samp], y=ys[samp], mode="markers",
            marker=dict(color="rgba(68,114,196,0.45)", size=5),
            name="Observations", hoverinfo="x+y",
        ))
        fig_scat.add_trace(go.Scatter(
            x=xg_sp, y=yg_sp, mode="lines",
            line=dict(color="#e07b39", width=2.5),
            name="Spline",
        ))
        fig_scat.update_layout(
            title=(f"Scatter '{col}' vs '{dep.target_name}'  ·  "
                   f"R²={r2:.3f}  r={r_pear:.3f} (p={p_pear:.3f})  "
                   f"ρ={r_spear:.3f}"),
            xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
            yaxis=dict(title=dep.target_name, gridcolor=GRID, zeroline=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=50,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_scat, height=260, mt=14))

        # Correlation summary
        corr_rows = [
            ("Pearson r",     f"{r_pear:.4f}  (p={p_pear:.4f})"),
            ("Spearman ρ",    f"{r_spear:.4f}  (p={p_spear:.4f})"),
            ("R² (linéaire)", f"{r2:.4f}"),
            ("Pearson sig.",  "✅ Oui (p<.05)" if p_pear < 0.05 else "❌ Non"),
        ]
        elements.append(_info_table(corr_rows, "📐 Corrélation avec target"))

    # ── Binned bubble chart ───────────────────────────────────────────────────
    tgt_series = (dep.display_df[dep.target_name] if dep.supervised else None)  # v8
    try:
        binned = _bin_series(s, tgt_series, n_bins, method, dtree_params=dtree_params)
    except Exception:
        binned = pd.cut(s, bins=min(n_bins, s.nunique()), duplicates="drop")

    bin_labels = [str(b) for b in binned.cat.categories]
    bin_counts = binned.value_counts().reindex(binned.cat.categories).fillna(0)
    n_tot_bin  = bin_counts.sum()
    bin_freqs  = (bin_counts / n_tot_bin).to_dict()
    bin_cnts   = bin_counts.to_dict()

    # Use bin category labels as keys
    cats_bin   = [str(c) for c in bin_counts.index]
    bin_freqs  = {str(k): v for k, v in bin_freqs.items()}
    bin_cnts   = {str(k): int(v) for k, v in bin_cnts.items()}

    bm_means, bm_cis = None, None
    if tt == "numeric" and tgt_series is not None:
        bm_means, bm_cis = {}, {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = binned == b
            vals = tgt_series[mask.reindex(dep.df.index, fill_value=False)].dropna().values
            if len(vals) < 1:
                bm_means[cat] = np.nan; bm_cis[cat] = 0; continue
            m  = vals.mean()
            ci = (sp_stats.t.ppf(0.975, len(vals)-1) * vals.std(ddof=1) / np.sqrt(len(vals))
                  if len(vals) >= 2 else 0.0)
            bm_means[cat] = m
            bm_cis[cat]   = ci

    bm_props = None
    if tt in ("binary","multiclass") and tgt_series is not None:
        bm_props = {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = (binned == b).reindex(dep.df.index, fill_value=False)
            grp  = tgt_series[mask].dropna()
            props = {f"cls_{cls}": (grp == cls).mean() for cls in dep.classes}
            props["cls1"] = props.get(f"cls_{dep.classes[-1]}", 0.0)
            bm_props[cat] = props

    # Compute meandiff groups for bins
    bm_groups      = None
    global_bm_mean = None
    if dep.supervised and metric in ("meandiff", "woe") and tgt_series is not None:
        if dep.is_classification:
            from sklearn.preprocessing import LabelEncoder
            le      = LabelEncoder()
            tgt_num = pd.Series(
                le.fit_transform(tgt_series.fillna(tgt_series.mode().iloc[0])),
                index=tgt_series.index)
        else:
            tgt_num = tgt_series.fillna(tgt_series.median())
        global_bm_mean = float(tgt_num.mean())
        bm_groups = {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = (binned == b).reindex(dep.df.index, fill_value=False)
            bm_groups[cat] = tgt_num[mask].dropna().values

    # WoE for bins (treat bin labels as categories on binned series)
    bm_woe = None
    if metric == "woe" and tgt_series is not None:
        binned_str = binned.astype(str).reindex(dep.df.index)
        bm_woe = _woe_values(dep, binned_str, cats_bin)

    fig_bin = _bubble_chart(
        dep, cats_bin, bin_cnts, bin_freqs, metric,
        target_means=bm_means, target_cis=bm_cis,
        target_props=bm_props,
        target_groups=bm_groups,
        woe_values=bm_woe,
        global_target_mean=global_bm_mean,
        title=(f"'{col}' — bins (dtree: depth={dtree_params.get('max_depth',3)}, "
               f"leaves={dtree_params.get('max_leaves',6)}, "
               f"min_n={dtree_params.get('min_samples',20)})"
               if method == "dtree" else
               f"'{col}' — bins ({method}, n={n_bins})"),
        is_ordered_by_value=True,
        sort_by=sort_by,
    )
    elements.append(html.Div("📊 Analyse par Bins", className="chart-card-title",
                             style={"marginTop":"18px"}))
    elements.append(_graph(fig_bin, height=fig_bin.layout.height or 300))

    # Post-hoc on bins
    if tt == "numeric" and bm_means and len(cats_bin) >= 2:
        grps_bin = {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = (binned == b).reindex(dep.df.index, fill_value=False)
            vals = tgt_series[mask].dropna().values
            if len(vals) >= 3:
                grps_bin[cat] = vals
        ph_df = _welch_posthoc(grps_bin)
        if not ph_df.empty:
            elements.append(html.Div("🔬 Tests post-hoc bins (Welch + Holm-Bonferroni)",
                                     className="chart-card-title", style={"marginTop":"14px"}))
            elements.append(_df_table(ph_df.head(20)))

    return elements


# ══════════════════════════════════════════════════════════════════════════════
#  TEXT PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _build_text_panel(dep, col: str) -> list:
    s       = dep.df[col].dropna().astype(str)
    n       = len(s)
    lengths = s.str.split().apply(len)

    elements = []

    # Basic word stats
    info_rows = [
        ("N documents",       f"{n:,}"),
        ("Mots moy. / doc",   f"{lengths.mean():.1f}"),
        ("Mots médiane",      f"{lengths.median():.0f}"),
        ("Mots max",          f"{lengths.max():,}"),
        ("Mots min",          f"{lengths.min():,}"),
        ("Vocabulaire total", f"{len(set(' '.join(s.tolist()).split())):,}"),
    ]
    elements.append(_info_table(info_rows, "📝 Statistiques textuelles"))

    # Word length distribution
    fig_wl = go.Figure(go.Histogram(
        x=lengths, nbinsx=30,
        marker_color="#4472c4", opacity=0.85,
    ))
    fig_wl.update_layout(
        title="Distribution du nombre de mots par document",
        xaxis=dict(title="Nb mots", gridcolor=GRID, zeroline=False),
        yaxis=dict(title="Count",   gridcolor=GRID),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=50,r=20,t=36,b=40),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
    )
    elements.append(_graph(fig_wl, height=200, mt=14))

    # Token-target correlation
    tt = _target_type(dep)
    if tt != "none":
        try:
            from sklearn.feature_extraction.text import CountVectorizer
            vec  = CountVectorizer(max_features=200, min_df=3, stop_words="english")
            X_tf = vec.fit_transform(s.tolist()).toarray()
            tgt  = dep.df.loc[s.index, dep.target_name].values

            corrs = []
            for i, token in enumerate(vec.get_feature_names_out()):
                if tt == "numeric":
                    r, p = sp_stats.pearsonr(X_tf[:, i], tgt)
                else:
                    r, p = sp_stats.pointbiserialr(
                        X_tf[:, i], (tgt == dep.classes[-1]).astype(float))
                corrs.append((token, r, p))

            corrs.sort(key=lambda x: abs(x[1]), reverse=True)
            top_n = min(20, len(corrs))
            tokens  = [c[0] for c in corrs[:top_n]]
            rvals   = [c[1] for c in corrs[:top_n]]
            colors  = ["#4472c4" if r >= 0 else "#e07b39" for r in rvals]

            fig_tok = go.Figure(go.Bar(
                y=tokens[::-1], x=rvals[::-1],
                orientation="h",
                marker_color=colors[::-1],
                text=[f"{r:.3f}" for r in rvals[::-1]],
                textposition="outside",
            ))
            fig_tok.add_vline(x=0, line_color="#999", line_width=1)
            fig_tok.update_layout(
                title=f"Top tokens — corrélation avec target ({dep.target_name})",
                xaxis=dict(title="Corrélation", gridcolor=GRID, zeroline=False),
                yaxis=dict(gridcolor=GRID, tickfont=dict(size=9)),
                plot_bgcolor=BG, paper_bgcolor="white",
                margin=dict(l=130,r=70,t=36,b=40),
                font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            )
            elements.append(_graph(fig_tok, height=max(220, top_n*22+60), mt=14))
        except Exception as e:
            elements.append(html.Div(f"Analyse tokens indisponible : {e}",
                                     style={"color":"#6b7a8d","fontSize":"12px"}))

    return elements


# ══════════════════════════════════════════════════════════════════════════════
#  UI COMPONENT HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _mcard(label, value, sub, accent=False):
    return html.Div([
        html.Div(label, className="metric-label"),
        html.Div(value, className="metric-value" + (" metric-accent" if accent else "")),
        html.Div(sub,   className="metric-sub"),
    ], className="metric-card")


def _var_table(df: pd.DataFrame, cols: list, dtype_lbl: str) -> html.Table:
    """Compact 2-column table: clickable name + type badge only. NaN info is in the right panel."""
    TYPE_COLORS = {
        "Flottant": "#4472c4", "Entier": "#27ae60", "Catégoriel": "#e07b39",
        "Booléen": "#9b59b6", "Date/Heure": "#1abc9c", "Texte": "#e74c3c",
    }
    badge_clr = TYPE_COLORS.get(dtype_lbl, "#6b7a8d")

    header = html.Tr([
        html.Th("Variable", style={**_th(), "width": "70%"}),
        html.Th("Type",     style={**_th(), "width": "30%"}),
    ])
    rows = []
    for col in cols:
        s = df[col]
        rows.append(html.Tr([
            html.Td(
                html.Span(col,
                          id={"type": "ov-var-click", "index": col},
                          n_clicks=0,
                          style={"fontWeight": "700", "color": "#4472c4",
                                 "fontSize": "12.5px", "cursor": "pointer",
                                 "textDecoration": "underline dotted",
                                 "textUnderlineOffset": "3px"}),
                style={"padding": "6px 10px"},
            ),
            html.Td(
                html.Span(str(s.dtype),
                          style={"background": badge_clr + "22",
                                 "color": badge_clr,
                                 "borderRadius": "4px", "padding": "2px 7px",
                                 "fontSize": "10.5px", "fontWeight": "700",
                                 "border": f"1px solid {badge_clr}44"}),
                style={"padding": "6px 10px"},
            ),
        ], style={"borderBottom": "1px solid #f0f4f8",
                  "transition": "background .12s"},
           className="var-row"))

    return html.Table([html.Thead(header), html.Tbody(rows)],
                      style={"width": "100%", "borderCollapse": "collapse",
                             "fontSize": "12px",
                             "fontFamily": "Plus Jakarta Sans, sans-serif"})


def _info_table(rows: list, title: str = "") -> html.Div:
    tr_els = [
        html.Tr([
            html.Td(lbl, style={"padding":"5px 10px","color":"#6b7a8d",
                                 "fontWeight":"600","fontSize":"11.5px",
                                 "whiteSpace":"nowrap","width":"52%"}),
            html.Td(val, style={"padding":"5px 10px","color":"#1e3a5f",
                                 "fontWeight":"500","fontSize":"11.5px"}),
        ], style={"borderBottom":"1px solid #f0f4f8"})
        for lbl, val in rows
    ]
    children = []
    if title:
        children.append(html.Div(title, className="chart-card-title",
                                  style={"marginBottom":"8px"}))
    children.append(
        html.Table(html.Tbody(tr_els),
                   style={"width":"100%","borderCollapse":"collapse",
                          "background":"#f7f8fa","borderRadius":"8px",
                          "overflow":"hidden","marginBottom":"10px"})
    )
    return html.Div(children)


def _df_table(df_data: pd.DataFrame) -> html.Div:
    if df_data.empty:
        return html.Div()
    header = html.Tr([html.Th(c, style=_th()) for c in df_data.columns])
    body   = [
        html.Tr([
            html.Td(str(df_data.iloc[i][c])[:30], style=_td())
            for c in df_data.columns
        ], style={"borderBottom":"1px solid #f0f4f8",
                  "background":"#fff5f0" if df_data.iloc[i].get("Sig","") == "✅ p<.05"
                               else "white"})
        for i in range(len(df_data))
    ]
    return html.Div(
        html.Table([html.Thead(header), html.Tbody(body)],
                   style={"width":"100%","borderCollapse":"collapse",
                          "fontSize":"11px","fontFamily":"Plus Jakarta Sans, sans-serif",
                          "marginBottom":"12px","overflowX":"auto","display":"block"}),
        style={"overflowX":"auto","marginBottom":"12px"},
    )


def _graph(fig, height=260, mt=0) -> html.Div:
    return html.Div(
        dcc.Graph(figure=fig, config={"displayModeBar":False},
                  style={"height":f"{height}px"}),
        style={"marginTop":f"{mt}px","marginBottom":"4px"},
    )


def _th():
    return {"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10.5px","textTransform":"uppercase",
            "letterSpacing":".4px","textAlign":"left","borderBottom":"2px solid #e0e4ea",
            "whiteSpace":"nowrap"}

def _td():
    return {"padding":"4px 8px","color":"#374151","fontSize":"11px","whiteSpace":"nowrap"}


def _hex_alpha(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return f"rgba({r},{g},{b},{alpha})"
