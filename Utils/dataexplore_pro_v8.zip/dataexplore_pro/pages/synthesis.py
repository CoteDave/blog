"""
Synthèse & Conclusions v8
  • Score qualité dataset (jauge + sous-scores)
  • Alertes automatiques catégorisées
  • Tableau récapitulatif features (IV, skew, NaN, outliers)
  • Distribution des classes (si supervisé)
  • NOUVEAU v8: Section "Contributions Features → Target"
    - Lit cache["importance"] pour RF/MI/fstat/pearson/spearman
    - Bar chart horizontal ranking multi-métriques
    - Tableau récap avec effet et significativité (t-test ou ANOVA)
    - Top features par type (linéaire, non-linéaire, arbre)
  • NOUVEAU v8: Recommandations actionnables personnalisées
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep):
    return html.Div([
        html.Div("Synthèse & Conclusions", className="page-title"),
        html.Div("Rapport automatique — qualité · alertes · contributions · recommandations.",
                 className="page-subtitle"),
        dcc.Loading(html.Div(id="synth-content"), type="dot", color="#4472c4"),
    ], className="page-card")


def register_callbacks(app, dep):
    @app.callback(
        Output("synth-content","children"),
        Input("synth-content","id"),
    )
    def render(_):
        return _build(dep)


def _build(dep):
    # ── Cache reads (non-blocking) ──────────────────────────────────
    # v8: wait for precomputed cache (computed once in background thread)
    fst_cache = dep.cache.get("fstats",     wait=True)
    imp_cache = dep.cache.get("importance", wait=True)
    iv_cache  = dep.cache.get("iv",        wait=True) or {}

    df  = dep.df
    ddf = dep.display_df
    num = dep.num_features
    n   = len(df)
    p   = len(num)

    # ── Quality scores ───────────────────────────────────────────────
    pct_nan   = df.isnull().mean().mean() * 100
    n_dup     = int(df.duplicated().sum())
    pct_dup   = n_dup / max(n,1) * 100

    # Use display_df for corr/var (fast, representative)
    X_d      = ddf[num].fillna(ddf[num].median()) if num else pd.DataFrame()
    stds     = X_d.std() if not X_d.empty else pd.Series(dtype=float)
    n_low_var= int((stds < stds.quantile(0.1)).sum()) if len(stds)>0 else 0
    if not X_d.empty and len(num)>1:
        corr_m = X_d.corr().abs()
        np.fill_diagonal(corr_m.values, 0)
        n_high_corr = int((corr_m > 0.9).sum().sum() // 2)
    else:
        n_high_corr = 0

    s_nan   = max(0, 100 - pct_nan * 5)
    s_dup   = max(0, 100 - pct_dup * 10)
    s_var   = max(0, 100 - n_low_var / max(p,1) * 100)
    s_corr  = max(0, 100 - n_high_corr / max(p,1) * 50)
    s_size  = min(100, n / 100 * 10)
    score   = float(np.mean([s_nan, s_dup, s_var, s_corr, s_size]))

    # ── Gauge ─────────────────────────────────────────────────────────
    clr_g = "#27ae60" if score>=75 else ("#f39c12" if score>=50 else "#e74c3c")
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=round(score,1),
        title={"text":"Score Qualité Dataset","font":{"size":15,"family":FONT}},
        delta={"reference":80},
        number={"font":{"size":36,"family":FONT,"color":clr_g}},
        gauge={"axis":{"range":[0,100],"tickwidth":1},
               "bar":{"color":clr_g,"thickness":0.3},
               "steps":[{"range":[0,50],"color":"#fde8e8"},
                        {"range":[50,75],"color":"#fff8e1"},
                        {"range":[75,100],"color":"#e8f5e9"}],
               "threshold":{"line":{"color":"#1e3a5f","width":3},
                            "thickness":0.75,"value":80}}))
    fig_gauge.update_layout(height=220,margin=dict(l=30,r=30,t=30,b=20),
                             paper_bgcolor="#fff",font=dict(family=FONT))

    fig_sub = go.Figure(go.Bar(
        x=["NaN","Doublons","Variance","Corrélation","Taille"],
        y=[s_nan,s_dup,s_var,s_corr,s_size],
        marker_color=["#27ae60" if s>=75 else ("#f39c12" if s>=50 else "#e74c3c")
                      for s in [s_nan,s_dup,s_var,s_corr,s_size]],
        text=[f"{s:.0f}" for s in [s_nan,s_dup,s_var,s_corr,s_size]],
        textposition="outside",
        hovertemplate="%{x}: %{y:.1f}/100<extra></extra>"))
    fig_sub.update_layout(plot_bgcolor=BG,paper_bgcolor="#fff",
                           yaxis=dict(range=[0,118],visible=False),
                           margin=dict(l=10,r=10,t=10,b=30),
                           height=160,font=dict(family=FONT,size=11),showlegend=False)

    # ── Alerts ────────────────────────────────────────────────────────
    alerts = []
    def _alert(cls, icon, msg):
        alerts.append(html.Div([
            html.Span(icon, style={"fontSize":"16px","flexShrink":"0"}),
            html.Span(msg,  style={"fontSize":"12.5px"}),
        ], className=f"alert-item {cls}"))

    if pct_nan>20:   _alert("alert-error","🚨",f"{pct_nan:.1f}% valeurs manquantes — imputation requise.")
    elif pct_nan>5:  _alert("alert-warn","⚠️",f"{pct_nan:.1f}% valeurs manquantes — vérifier imputation.")
    else:            _alert("alert-ok","✅",f"Valeurs manquantes faibles ({pct_nan:.1f}%).")
    if n_dup>0:      _alert("alert-warn","⚠️",f"{n_dup:,} doublons ({pct_dup:.1f}%) — supprimer avant modélisation.")
    else:            _alert("alert-ok","✅","Aucun doublon détecté.")
    if n_high_corr>0: _alert("alert-warn","⚠️",f"{n_high_corr} paire(s) corrélées >0.9 — multicolinéarité.")
    if n_low_var>0:   _alert("alert-warn","⚠️",f"{n_low_var} variable(s) à faible variance (bottom 10%).")
    if n<100:         _alert("alert-warn","⚠️",f"Dataset petit (n={n:,}) — risque sur-apprentissage.")
    elif n>=10_000:   _alert("alert-ok","✅",f"Dataset taille suffisante (n={n:,}).")
    if n>=1_000_000:  _alert("alert-ok","⚡",f"Dataset large ({n:,}) — optimisations v8 actives (display={len(ddf):,}).")

    if dep.supervised and dep.is_classification:
        cnts  = pd.Series([(df[dep.target_name]==c).sum() for c in dep.classes],
                          index=dep.classes)
        max_r = float(cnts.max()/cnts.sum())
        min_r = float(cnts.min()/cnts.sum())
        if max_r>0.85:   _alert("alert-error","🚨",f"Déséquilibre sévère (max={max_r:.1%}) — SMOTE conseillé.")
        elif max_r>0.70: _alert("alert-warn","⚠️",f"Déséquilibre modéré (max={max_r:.1%}).")
        else:            _alert("alert-ok","✅",f"Classes équilibrées (min={min_r:.1%} max={max_r:.1%}).")

    # Skewness (fast: from fstats cache or compute on display_df)
    if fst_cache and "skew" in fst_cache and "cols" in fst_cache:
        high_skew = [(fst_cache["cols"][i], float(fst_cache["skew"][i]))
                     for i in range(len(fst_cache["cols"]))
                     if abs(fst_cache["skew"][i]) > 3]
    else:
        high_skew = [(c, float(sp_stats.skew(ddf[c].dropna())))
                     for c in num[:30]
                     if len(ddf[c].dropna()) > 3 and abs(sp_stats.skew(ddf[c].dropna())) > 3]
    if high_skew:
        names = ", ".join(f"{c} ({s:+.1f})" for c,s in high_skew[:5])
        _alert("alert-warn","⚠️",f"Asymétrie élevée (|skew|>3) : {names}{'…' if len(high_skew)>5 else ''}")

    # ── Class balance chart ───────────────────────────────────────────
    cls_section = html.Div()
    if dep.supervised and dep.is_classification:
        cnts  = [(c, int((df[dep.target_name]==c).sum())) for c in dep.classes]
        total = sum(v for _,v in cnts)
        fig_cls = go.Figure(go.Bar(
            x=[str(c) for c,_ in cnts],
            y=[v for _,v in cnts],
            marker_color=[PAL[i%len(PAL)] for i in range(len(cnts))],
            text=[f"{v:,} ({v/total:.1%})" for _,v in cnts],
            textposition="outside",
            hovertemplate="Classe %{x}<br>N=%{y:,}<extra></extra>"))
        fig_cls.update_layout(
            title=dict(text="Distribution des classes (target)",font=dict(size=12)),
            plot_bgcolor=BG, paper_bgcolor="#fff",
            yaxis=dict(visible=False,range=[0,max(v for _,v in cnts)*1.2]),
            xaxis=dict(gridcolor=GRID),
            margin=dict(l=20,r=20,t=40,b=30),
            height=200,font=dict(family=FONT,size=11),showlegend=False)
        cls_section = html.Div([
            html.Div("Distribution des classes",className="chart-card-title"),
            dcc.Graph(figure=fig_cls,config={"displayModeBar":False},
                      style={"height":"200px"}),
        ], className="chart-card", style={"marginBottom":"16px"})

    # ── Feature contribution section (v8 NEW) ─────────────────────────
    contrib_section = _build_contributions(dep, imp_cache, iv_cache, ddf, num)

    # ── Feature summary table ─────────────────────────────────────────
    rows = []
    for col in num[:30]:
        v    = ddf[col].dropna().values
        pnan = df[col].isnull().mean()*100
        skw  = float(sp_stats.skew(v)) if len(v)>3 else 0.0
        q1,q3= np.percentile(v,[25,75])
        iqr  = q3-q1
        n_out= int(np.sum((v<q1-1.5*iqr)|(v>q3+1.5*iqr)))
        pout = n_out/max(len(v),1)*100
        iv_v = float(iv_cache.get(col, 0.0))
        rows.append(html.Tr([
            html.Td(col[:22],style={"fontWeight":"600","color":"#1e3a5f",
                                     "fontSize":"11px","padding":"5px 8px",
                                     "maxWidth":"160px","overflow":"hidden",
                                     "textOverflow":"ellipsis","whiteSpace":"nowrap"}),
            html.Td(f"{v.mean():.3g}",  style=_td()),
            html.Td(f"{v.std():.3g}",   style=_td()),
            html.Td(f"{skw:+.2f}",      style=_td(_skw_clr(skw))),
            html.Td(f"{pnan:.1f}%",     style=_td("#e74c3c" if pnan>10 else None)),
            html.Td(f"{pout:.1f}%",     style=_td("#f39c12" if pout>5 else None)),
            html.Td(f"{iv_v:.3f}",      style=_td("#27ae60" if iv_v>=0.1 else None)),
        ], style={"borderBottom":"1px solid #f5f5f5"}))

    table = html.Table([
        html.Thead(html.Tr([
            html.Th(h, style={"padding":"5px 8px","background":"#f0f4f8",
                               "fontSize":"10.5px","fontWeight":"700","color":"#6b7a8d",
                               "textTransform":"uppercase","letterSpacing":".4px"})
            for h in ["Variable","Moyenne","Std","Skewness","% NaN","% Outliers","IV/η²"]
        ])),
        html.Tbody(rows),
    ], style={"width":"100%","borderCollapse":"collapse","fontFamily":FONT,"fontSize":"11px"})

    # ── Recommendations (v8) ─────────────────────────────────────────
    recs = _recommendations(dep, pct_nan, n_dup, n_high_corr, n_low_var,
                             n, score, imp_cache, iv_cache, num)

    return html.Div([
        # Row 1: gauge + sub-scores
        html.Div([
            html.Div([
                html.Div("Score global de qualité",className="chart-card-title"),
                dcc.Graph(figure=fig_gauge,config={"displayModeBar":False},
                          style={"height":"220px"}),
            ], className="chart-card"),
            html.Div([
                html.Div("Scores par dimension",className="chart-card-title"),
                dcc.Graph(figure=fig_sub,config={"displayModeBar":False},
                          style={"height":"160px"}),
                html.Div([
                    html.Div([html.Div(html.B(f"{n:,}"),className="metric-value"),
                              html.Div("observations",className="metric-label")],
                             className="metric-card"),
                    html.Div([html.Div(html.B(f"{p}"),className="metric-value"),
                              html.Div("variables num.",className="metric-label")],
                             className="metric-card"),
                ], style={"display":"grid","gridTemplateColumns":"1fr 1fr",
                           "gap":"10px","marginTop":"12px"}),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        cls_section,

        html.Div([
            html.Div("Alertes & Recommandations automatiques",className="chart-card-title"),
            html.Div(alerts),
        ], className="chart-card", style={"marginBottom":"16px"}),

        # ── v8: Feature contributions ──────────────────────────────────
        contrib_section,

        # ── v8: Recommendations ───────────────────────────────────────
        recs,

        html.Div([
            html.Div("Récapitulatif des features (top 30)",className="chart-card-title"),
            html.Div(table,style={"overflowX":"auto","maxHeight":"420px","overflowY":"auto"}),
        ], className="chart-card"),
    ])


# ══════════════════════════════════════════════════════════════════════════════
#  v8 NEW: Feature contributions section
# ══════════════════════════════════════════════════════════════════════════════

def _build_contributions(dep, imp_cache, iv_cache, ddf, num):
    if not dep.supervised or not num:
        return html.Div()

    title = html.Div("⭐ Contributions Features → Target",
                      className="chart-card-title", style={"marginBottom":"10px"})

    # Build scores dict from cache or compute quickly on display_df
    metrics = {}
    if imp_cache is not None:
        imp_cols = imp_cache.get("cols", num)
        for key in ["pearson","spearman","fstat","mi","rf","global"]:
            if key in imp_cache and len(imp_cache[key]) == len(imp_cols):
                metrics[key] = dict(zip(imp_cols, imp_cache[key]))

    # Fill IV from cache
    if iv_cache:
        metrics["iv"] = {c: float(iv_cache.get(c,0)) for c in num}

    # Fallback: fast Pearson on display_df
    if "pearson" not in metrics and dep.supervised:
        try:
            tgt = ddf[dep.target_name]
            if dep.is_classification:
                from sklearn.preprocessing import LabelEncoder
                tgt = pd.Series(LabelEncoder().fit_transform(
                    tgt.fillna(tgt.mode().iloc[0])), index=tgt.index)
            metrics["pearson"] = {
                c: abs(float(ddf[c].corr(tgt)))
                for c in num[:50] if ddf[c].notna().sum() > 5
            }
        except Exception:
            pass

    if not metrics:
        return html.Div()

    # Build ranked DataFrame (top 20 by best available score)
    all_cols = list(dict.fromkeys(
        c for d in metrics.values() for c in d.keys()
    ))
    score_keys = ["global","rf","mi","fstat","pearson","spearman","iv"]
    main_key   = next((k for k in score_keys if k in metrics), None)
    if not main_key:
        return html.Div()

    df_imp = pd.DataFrame({
        k: pd.Series(v) for k,v in metrics.items() if isinstance(v, dict)
    }).fillna(0).reindex(all_cols).fillna(0)

    df_sorted = df_imp.sort_values(main_key, ascending=False).head(25)

    # ── Multi-metric bar chart ────────────────────────────────────────
    n_feat = len(df_sorted)
    metric_display = {
        "global":"Score Global","rf":"Random Forest","mi":"Mutual Info",
        "fstat":"F-stat","pearson":"Pearson |r|","spearman":"Spearman |ρ|","iv":"IV/η²"
    }
    avail = [k for k in score_keys if k in df_sorted.columns][:5]

    fig_imp = go.Figure()
    for i, mk in enumerate(avail):
        vals = df_sorted[mk].values
        clr  = PAL[i % len(PAL)]
        fig_imp.add_trace(go.Bar(
            y=list(range(n_feat)),
            x=vals,
            orientation="h",
            name=metric_display.get(mk, mk),
            marker=dict(color=clr, opacity=0.75 if mk!="global" else 1.0,
                        line=dict(width=0)),
            hovertemplate="%{y}<br>" + metric_display.get(mk,mk) +
                          ": %{x:.4f}<extra></extra>",
        ))

    fig_imp.update_layout(
        barmode="group",
        title=dict(text=f"Importance des features — top {n_feat}  "
                        f"(meilleur score: {metric_display.get(main_key,main_key)})",
                   font=dict(size=12,color="#1e3a5f")),
        plot_bgcolor=BG, paper_bgcolor="#fff",
        height=max(320, n_feat*28+80),
        margin=dict(l=160,r=20,t=44,b=40),
        xaxis=dict(title="Score (normalisé [0,1])",gridcolor=GRID,zeroline=False),
        yaxis=dict(tickvals=list(range(n_feat)),
                   ticktext=[c[:22] for c in df_sorted.index],
                   gridcolor=GRID,autorange="reversed"),
        font=dict(family=FONT,size=10),
        legend=dict(font=dict(size=10),orientation="h",
                    x=0.0,y=1.04,bgcolor="rgba(255,255,255,.9)"))

    # ── Significance tests per feature (fast, display_df) ────────────
    sig_rows = []
    tgt_series = ddf[dep.target_name] if dep.supervised else None
    for col in df_sorted.index[:20]:
        if col not in ddf.columns: continue
        v = ddf[col].dropna().values
        if len(v) < 5: continue
        score_v = float(df_sorted.loc[col, main_key]) if col in df_sorted.index else 0
        iv_v    = float(iv_cache.get(col, 0))

        # Statistical test
        test_lbl, p_val, effect = "—", float("nan"), 0.0
        if dep.supervised and tgt_series is not None:
            try:
                if dep.is_classification:
                    groups = [ddf.loc[ddf[dep.target_name]==cls, col].dropna().values
                              for cls in dep.classes]
                    groups = [g for g in groups if len(g)>=3]
                    if len(groups)>=2:
                        f, p_val = sp_stats.f_oneway(*groups)
                        n_all = sum(len(g) for g in groups)
                        k     = len(groups)
                        effect = float(f*(k-1)/(f*(k-1)+max(n_all-k,1)+1e-9))  # η²
                        test_lbl = f"ANOVA η²={effect:.3f}"
                else:
                    common = ddf[[col,dep.target_name]].dropna()
                    r, p_val = sp_stats.pearsonr(common[col].values,
                                                  common[dep.target_name].values)
                    effect = r**2
                    test_lbl = f"Pearson R²={effect:.3f}"
            except Exception:
                pass

        cat = ("🔴 Très fort" if score_v>=0.7 else "🟠 Fort" if score_v>=0.4
               else "🟡 Moyen" if score_v>=0.15 else "⚪ Faible")
        sig = "✅" if (not np.isnan(p_val) and p_val<0.05) else "—"
        sig_rows.append((col, score_v, iv_v, test_lbl, p_val, sig, cat))

    if sig_rows:
        hdr = html.Tr([html.Th(h,style=_th()) for h in
                       ["Feature","Score","IV/η²","Test","p-value","Sig.","Niveau"]])
        bdy = []
        for r in sig_rows:
            p_clr = "#27ae60" if (not np.isnan(r[4]) and r[4]<0.05) else None
            bdy.append(html.Tr([
                html.Td(r[0][:20],style={**_td(),"fontWeight":"700","color":"#1e3a5f"}),
                html.Td(f"{r[1]:.3f}",style=_td("#e07b39" if r[1]>=0.4 else
                                                  "#4472c4" if r[1]>=0.15 else None)),
                html.Td(f"{r[2]:.3f}",style=_td("#27ae60" if r[2]>=0.1 else None)),
                html.Td(r[3][:22],    style=_td()),
                html.Td(f"{r[4]:.4f}" if not np.isnan(r[4]) else "—",
                        style=_td(p_clr)),
                html.Td(r[5],         style=_td(p_clr)),
                html.Td(r[6],         style=_td()),
            ], style={"borderBottom":"1px solid #f5f5f5",
                       "background":"#fffdf0" if r[1]>=0.4 else "#fff"}))
        sig_table = html.Div(
            html.Table([html.Thead(hdr),html.Tbody(bdy)],
                       style={"width":"100%","borderCollapse":"collapse",
                              "fontSize":"11px","fontFamily":FONT}),
            style={"overflowX":"auto","marginTop":"12px"})
    else:
        sig_table = html.Div()

    # ── Top 3 callout cards ───────────────────────────────────────────
    top3 = df_sorted.head(3)
    cards = []
    for rank,(col,row) in enumerate(top3.iterrows()):
        s   = float(row[main_key])
        iv  = float(iv_cache.get(col, 0))
        clr = PAL[rank % len(PAL)]
        cards.append(html.Div([
            html.Div(f"#{rank+1}", style={"fontSize":"22px","fontWeight":"900",
                                            "color":clr,"lineHeight":"1"}),
            html.Div(col[:24],     style={"fontWeight":"800","color":"#1e3a5f",
                                            "fontSize":"13px","marginTop":"2px",
                                            "overflow":"hidden","textOverflow":"ellipsis",
                                            "whiteSpace":"nowrap"}),
            html.Div([
                html.Span(f"Score: {s:.3f}",
                          style={"fontSize":"10.5px","color":"#6b7a8d","marginRight":"10px"}),
                html.Span(f"IV: {iv:.3f}",
                          style={"fontSize":"10.5px","color":"#6b7a8d"}),
            ], style={"marginTop":"4px"}),
            html.Div(_importance_bar(s, clr), style={"marginTop":"8px"}),
        ], style={"padding":"12px 14px","borderRadius":"10px",
                   "border":f"2px solid {clr}33","background":"#fff",
                   "flex":"1","minWidth":"120px"}))

    cards_row = html.Div(cards,
                          style={"display":"flex","gap":"12px","marginBottom":"14px",
                                 "flexWrap":"wrap"})

    # ── Note on cache status ──────────────────────────────────────────
    cache_note = html.Div(
        ("⚡ Scores depuis cache parallèle (full-pass)."
         if imp_cache else
         "⏳ Cache pas encore prêt — scores calculés sur display_df."),
        style={"fontSize":"10px","color":"#27ae60" if imp_cache else "#f39c12",
               "fontWeight":"700","marginTop":"8px"})

    return html.Div([
        title, cards_row,
        dcc.Graph(figure=fig_imp,config={"displayModeBar":False},
                  style={"height":f"{max(320,n_feat*28+80)}px"}),
        sig_table,
        cache_note,
    ], className="chart-card", style={"marginBottom":"16px"})


def _importance_bar(score, color):
    w = max(4, int(score * 100))
    return html.Div([
        html.Div(style={"width":f"{w}%","height":"6px","background":color,
                         "borderRadius":"99px","transition":"width .3s"})
    ], style={"background":"#f0f4f8","borderRadius":"99px","overflow":"hidden","height":"6px"})


def _recommendations(dep, pct_nan, n_dup, n_high_corr, n_low_var,
                      n, score, imp_cache, iv_cache, num):
    recs = []

    def _rec(icon, title, body, level="info"):
        c = {"info":"#4472c4","warn":"#f39c12","action":"#27ae60","risk":"#e74c3c"}
        recs.append(html.Div([
            html.Span(icon, style={"fontSize":"18px","flexShrink":"0","marginTop":"1px"}),
            html.Div([
                html.Div(title, style={"fontWeight":"700","fontSize":"12.5px",
                                        "color":"#1e3a5f","marginBottom":"2px"}),
                html.Div(body,  style={"fontSize":"11.5px","color":"#6b7a8d",
                                        "lineHeight":"1.5"}),
            ])
        ], style={"display":"flex","gap":"10px","padding":"10px 12px",
                   "borderRadius":"8px","border":f"1.5px solid {c.get(level,'#dde2ea')}33",
                   "background":f"{c.get(level,'#4472c4')}08","marginBottom":"8px"}))

    if pct_nan > 10:
        _rec("🧹","Imputation requise",
             f"{pct_nan:.1f}% de NaN — utiliser KNN imputation ou median fill avant modélisation.","risk")
    if n_dup > 0:
        _rec("🗑️","Supprimer les doublons",
             f"{n_dup:,} lignes dupliquées — risque de data leakage et biais.","risk")
    if n_high_corr > 0:
        _rec("✂️","Réduction dimensionnelle",
             f"{n_high_corr} paires >0.9 — PCA ou sélection features recommandée.","warn")
    if dep.supervised:
        # Top feature recommendation
        if imp_cache and "global" in imp_cache and "cols" in imp_cache:
            top = imp_cache["cols"][int(np.argmax(imp_cache["global"]))]
            _rec("🏆","Feature la plus discriminante",
                 f"'{top}' obtient le meilleur score global. Prioriser dans le modèle.","action")
        elif iv_cache:
            top = max(iv_cache, key=iv_cache.get)
            _rec("🏆","Feature la plus discriminante (IV)",
                 f"'{top}' (IV={iv_cache[top]:.3f}). Prioriser dans le modèle.","action")

        if dep.is_classification and dep.n_classes==2:
            _rec("⚖️","Seuil de décision",
                 "Pour classification binaire, tester différents seuils (ROC AUC) selon le coût métier.","info")
        if n > 50_000:
            _rec("⚡","Modèles recommandés",
                 f"Pour n={n:,} : XGBoost / LightGBM pour la vitesse, ou RandomForest avec n_jobs=-1.","info")
    if score >= 80:
        _rec("🟢","Dataset prêt pour la modélisation",
             f"Score qualité {score:.0f}/100 — pipeline standard conseillé.","action")
    elif score >= 60:
        _rec("🟡","Nettoyage conseillé avant modélisation",
             f"Score {score:.0f}/100 — corriger les alertes ci-dessus pour améliorer les performances.","warn")
    else:
        _rec("🔴","Qualité insuffisante",
             f"Score {score:.0f}/100 — corriger impérativement les problèmes critiques.","risk")

    if not recs:
        return html.Div()
    return html.Div([
        html.Div("💡 Recommandations actionnables",className="chart-card-title"),
        html.Div(recs),
    ], className="chart-card", style={"marginBottom":"16px"})


# ── helpers ───────────────────────────────────────────────────────────────────

def _td(color=None):
    s = {"padding":"5px 8px","fontSize":"11px","color":"#1e3a5f","fontWeight":"500",
         "textAlign":"right"}
    if color:
        s["color"] = color
        s["fontWeight"] = "700"
    return s

def _th():
    return {"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10px","textTransform":"uppercase",
            "letterSpacing":".4px","textAlign":"left",
            "borderBottom":"2px solid #e0e4ea","whiteSpace":"nowrap"}

def _skw_clr(skw):
    if abs(skw) > 3:   return "#e74c3c"
    if abs(skw) > 1.5: return "#f39c12"
    return None
