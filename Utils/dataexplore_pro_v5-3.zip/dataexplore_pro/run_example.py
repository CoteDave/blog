#!/usr/bin/env python3
"""
run_example.py
==============
Demo script: launch DataExplore Pro with a real sklearn dataset.

Usage
-----
  python run_example.py                      # breast cancer (supervised)
  python run_example.py --dataset iris       # iris dataset
  python run_example.py --dataset diabetes   # regression dataset
  python run_example.py --dataset blobs      # unsupervised blobs
  python run_example.py --port 8080          # custom port
"""

import argparse
import sys
import os

# Allow running from root without pip install
sys.path.insert(0, os.path.dirname(__file__))

from dataexplore_pro import DataExplorePro


def load_dataset(name: str):
    """Return (X_df, y, feature_names, target_name) for the given dataset name."""
    import pandas as pd
    import numpy as np

    if name == "breast_cancer":
        from sklearn.datasets import load_breast_cancer
        d = load_breast_cancer()
        return d.data, d.target, list(d.feature_names), "Malignant"

    elif name == "iris":
        from sklearn.datasets import load_iris
        d = load_iris()
        return d.data, d.target, list(d.feature_names), "Species"

    elif name == "wine":
        from sklearn.datasets import load_wine
        d = load_wine()
        return d.data, d.target, list(d.feature_names), "Cultivar"

    elif name == "diabetes":
        from sklearn.datasets import load_diabetes
        d = load_diabetes()
        return d.data, d.target, list(d.feature_names), "Progression"

    elif name == "blobs":
        # Unsupervised only
        from sklearn.datasets import make_blobs
        X, _ = make_blobs(n_samples=400, centers=4, n_features=6, random_state=42)
        feat_names = [f"Feature_{i}" for i in range(X.shape[1])]
        return X, None, feat_names, "Target"

    elif name == "salary":
        # Synthetic salary-vs-age dataset (like the mockup)
        rng = np.random.RandomState(42)
        n = 300
        age_0 = rng.uniform(18, 55, size=150)
        sal_0 = age_0 * 900 + rng.normal(0, 8000, 150) + 5000
        age_1 = rng.uniform(30, 70, size=150)
        sal_1 = age_1 * 2200 + rng.normal(0, 12000, 150) + 30000
        age = np.concatenate([age_0, age_1])
        salary = np.concatenate([sal_0, sal_1])
        y = np.array([0] * 150 + [1] * 150)
        extra_feats = rng.randn(n, 4)
        X = np.column_stack([age, salary, extra_feats])
        feat_names = ["Age", "Salaire Annuel (USD)", "Education", "Experience", "Score_A", "Score_B"]
        return X, y, feat_names, "Target"

    else:
        raise ValueError(f"Unknown dataset: {name!r}. "
                         "Choices: breast_cancer, iris, wine, diabetes, blobs, salary")


def main():
    parser = argparse.ArgumentParser(description="DataExplore Pro demo launcher")
    parser.add_argument("--dataset", default="breast_cancer",
                        choices=["breast_cancer", "iris", "wine", "diabetes", "blobs", "salary"],
                        help="Dataset to load (default: breast_cancer)")
    parser.add_argument("--port", type=int, default=8050, help="Port (default: 8050)")
    parser.add_argument("--no-browser", action="store_true", help="Do not open browser")
    parser.add_argument("--debug", action="store_true", help="Enable Dash debug mode")
    args = parser.parse_args()

    print(f"\nLoading dataset: {args.dataset} …")
    X, y, feat_names, target_name = load_dataset(args.dataset)

    dep = DataExplorePro(
        X=X,
        y=y,
        feature_names=feat_names,
        target_name=target_name,
        title="DataExplore Pro",
    )

    dep.run(
        port=args.port,
        debug=args.debug,
        open_browser=not args.no_browser,
    )


if __name__ == "__main__":
    main()
