from setuptools import setup, find_packages

setup(
    name="dataexplore-pro",
    version="1.0.0",
    description="Interactive ML data exploration dashboard from X, y or X only",
    author="DataExplore Pro",
    packages=find_packages(),
    include_package_data=True,
    package_data={"dataexplore_pro": ["assets/*.css"]},
    install_requires=[
        "dash>=2.14.0",
        "dash-bootstrap-components>=1.5.0",
        "plotly>=5.18.0",
        "pandas>=1.5.0",
        "numpy>=1.23.0",
        "scikit-learn>=1.2.0",
        "scipy>=1.10.0",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "dataexplore=dataexplore_pro.cli:main",
        ],
    },
)
