# DataExplore Pro 🚀

**Interactive ML data-exploration dashboard** — generate a rich Dash UI from any `X, y` (supervised) or `X` only (unsupervised) dataset in one line of Python.

---

## ⚡ Quick Start

### 1 — Install dependencies

```bash
pip install dash dash-bootstrap-components plotly scikit-learn
```

Or use the all-in-one launcher:

```bash
bash install_and_run.sh
```

---

### 2 — Use in your Python code

```python
from dataexplore_pro import DataExplorePro

# Supervised (classification / regression)
dep = DataExplorePro(X, y, feature_names=['age', 'salary', ...])
dep.run()   # opens http://127.0.0.1:8050 in your browser

# Unsupervised
dep = DataExplorePro(X, feature_names=[...])
dep.run()
```

### 3 — Run the built-in demo

```bash
# Default: breast cancer dataset
python run_example.py

# Other datasets
python run_example.py --dataset iris
python run_example.py --dataset salary        # mimics the mockup exactly
python run_example.py --dataset blobs         # unsupervised
python run_example.py --dataset wine
python run_example.py --port 8080
```

---

## 🗂 Project Structure

```
dataexplore_pro/
├── __init__.py          ← exports DataExplorePro
├── core.py              ← DataExplorePro class
├── app_factory.py       ← Dash app + layout + routing
├── assets/
│   └── custom.css       ← dark-navy sidebar, orange accents
└── pages/
    ├── overview.py      ← Aperçu Global
    ├── scatter.py       ← Diagrammes de Dispersion  ★ core page
    ├── correlation.py   ← Matrices de Corrélation
    ├── univariate.py    ← Analyse Univariée
    ├── analysis_3d.py   ← Analyses 3D
    ├── importance.py    ← Importance des Variables
    ├── missing.py       ← Valeurs Manquantes (NaN)
    ├── clusters.py      ← Analyse de Clusters (K-Means + elbow)
    ├── pca.py           ← ACP biplot + scree
    └── stubs.py         ← Placeholder for future pages
```

---

## 🖱 Dashboard Pages

| Section | Features |
|---|---|
| **Aperçu Global** | Summary metrics, box plots, target distribution, descriptive stats table |
| **Diagrammes de Dispersion ★** | X/Y variable picker, target filter, **lasso selection**, live stats panel & mini charts |
| **Matrices de Corrélation** | Pearson/Spearman/Kendall heatmap, variable selector |
| **Analyses 3D** | Interactive 3-D scatter, point-size slider |
| **Importance des Variables** | Random Forest, |r|, or variance-based importance bar chart |
| **Valeurs Manquantes** | Missing-value heatmap + per-column % bar chart |
| **Analyse de Clusters** | K-Means with elbow curve, PCA projection, cluster coloring |
| **ACP** | Biplot (scores + loadings), scree plot, cumulative variance |
| **Analyse Univariée** | Histogram / Box / Violin / ECDF, grouped by target |

---

## 🎨 Design

Matches the provided mockup:

- **Dark navy sidebar** (`#1e3a5f`) with active-item highlight
- **White content area** with card layout
- **Class 0 = blue**, **Class 1 = orange** scatter points
- **Lasso selection** → real-time stats panel (count, means, target rate, mini bar + histogram)
- Google Font: *Plus Jakarta Sans*

---

## DataExplorePro API

```python
DataExplorePro(
    X,                          # DataFrame or array  (required)
    y=None,                     # labels / target     (optional)
    feature_names=None,         # list[str]           (optional if X is DataFrame)
    target_name='Target',       # str
    title='DataExplore Pro',    # str — browser tab title
)

.run(
    host='127.0.0.1',
    port=8050,
    debug=False,
    open_browser=True,
)
```

---

## Requirements

- Python ≥ 3.8
- dash ≥ 2.14
- dash-bootstrap-components ≥ 1.5
- plotly ≥ 5.18
- pandas ≥ 1.5
- numpy ≥ 1.23
- scikit-learn ≥ 1.2
