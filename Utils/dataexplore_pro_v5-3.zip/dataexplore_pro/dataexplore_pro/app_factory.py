"""
app_factory.py — assembles the full Dash application.
"""
from __future__ import annotations
import os
import dash
from dash import dcc, html, Input, Output, ctx
import dash_bootstrap_components as dbc

DEFAULT_PAGE = "overview"

# (page_id, emoji, label)
SIDEBAR_ITEMS = [
    ("overview",      "🏠",  "Aperçu Global"),
    ("univariate",    "📊",  "Analyse Univariée"),
    ("scatter",       "🔵",  "Dispersion Bivariée"),
    ("correlation",   "🔲",  "Matrice de Corrélation"),
    ("analysis3d",    "🔷",  "Analyses 3D"),
    ("importance",    "📈",  "Importance des Variables"),
    ("missing",       "❓",  "Valeurs Manquantes"),
    ("clusters",      "🫧",  "Analyse de Clusters"),
    ("pca",           "🔮",  "ACP / Réduction de Dimension"),
    ("corr_clusters", "🔗",  "Clusters de Corrélation"),
    ("posthoc",       "🔬",  "Analyses Post-Hoc"),
    ("causal",        "→",   "Découverte Causale"),
    ("anova",         "∿",   "ANOVA Fonctionnelle"),
    ("synthesis",     "⭐",  "Synthèse & Conclusions"),
]

SIDEBAR_DIVIDERS_AFTER = {"scatter", "pca", "missing"}
STUB_PAGES = {"causal", "anova"}


def create_app(dep):
    assets_dir = os.path.join(os.path.dirname(__file__), "assets")
    app = dash.Dash(
        __name__,
        external_stylesheets=[
            dbc.themes.BOOTSTRAP,
            "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap",
        ],
        suppress_callback_exceptions=True,
        title=dep.title,
        assets_folder=assets_dir,
    )
    app.layout = _build_layout(dep)
    _register_callbacks(app, dep)
    return app


def _build_layout(dep):
    n_obs  = len(dep.df)
    n_feat = len(dep.num_features)
    mode_txt = (f"Supervisé · {dep.n_classes} classes" if dep.supervised
                else "Non supervisé")

    return html.Div([
        dcc.Store(id="active-page", data=DEFAULT_PAGE),

        # ── Header ──────────────────────────────────────────────────────
        html.Header([
            html.Div([
                html.Div(
                    html.Span("◰", style={"fontSize": "20px", "color": "white",
                                          "lineHeight": "1"}),
                    className="logo-icon-wrap",
                ),
                html.Span(
                    ["Data", html.Span("Explore", style={"color": "#e07b39"}), " Pro"],
                    className="logo-text",
                ),
            ], className="logo"),

            # Dataset info chip (right side)
            html.Div([
                html.Span(f"{n_obs:,} obs", style={"fontWeight": "700"}),
                html.Span(" · "),
                html.Span(f"{n_feat} vars"),
                html.Span(" · ", style={"margin": "0 4px"}),
                html.Span(mode_txt, style={"color": "#e07b39", "fontWeight": "600"}),
            ], style={
                "marginLeft": "auto",
                "fontSize": "12px", "color": "#6b7a8d",
                "background": "#f0f4f8", "borderRadius": "99px",
                "padding": "5px 14px", "border": "1px solid #e0e4ea",
            }),
        ], className="app-header"),

        # ── Body ─────────────────────────────────────────────────────────
        html.Div([
            html.Aside(_build_sidebar(), className="sidebar", id="sidebar"),
            html.Main(
                dcc.Loading(
                    html.Div(id="page-content", className="page-content-inner"),
                    id="page-loading",
                    type="circle",
                    color="#4472c4",
                    style={"minHeight": "200px"},
                ),
                className="page-content",
            ),
        ], className="app-body"),
    ], className="app-wrapper")


def _build_sidebar():
    items = []
    for page_id, symbol, label in SIDEBAR_ITEMS:
        is_active = (page_id == DEFAULT_PAGE)
        items.append(html.Div(
            [
                html.Span(symbol, className="sb-icon"),
                html.Span(label,  className="sb-label"),
            ],
            id={"type": "sidebar-item", "index": page_id},
            className="sidebar-item" + (" active" if is_active else ""),
            n_clicks=0,
            title=label,
        ))
        if page_id in SIDEBAR_DIVIDERS_AFTER:
            items.append(html.Hr(className="sb-divider"))
    return items


def _register_callbacks(app, dep):
    from .pages.scatter       import register_callbacks as scatter_cb
    from .pages.overview      import register_callbacks as overview_cb
    from .pages.correlation   import register_callbacks as correlation_cb
    from .pages.univariate    import register_callbacks as univariate_cb
    from .pages.analysis_3d   import register_callbacks as analysis3d_cb
    from .pages.importance    import register_callbacks as importance_cb
    from .pages.missing       import register_callbacks as missing_cb
    from .pages.clusters      import register_callbacks as clusters_cb
    from .pages.pca           import register_callbacks as pca_cb
    from .pages.corr_clusters import register_callbacks as corr_clusters_cb
    from .pages.posthoc       import register_callbacks as posthoc_cb
    from .pages.synthesis     import register_callbacks as synthesis_cb

    scatter_cb(app, dep)
    overview_cb(app, dep)
    correlation_cb(app, dep)
    univariate_cb(app, dep)
    analysis3d_cb(app, dep)
    importance_cb(app, dep)
    missing_cb(app, dep)
    clusters_cb(app, dep)
    pca_cb(app, dep)
    corr_clusters_cb(app, dep)
    posthoc_cb(app, dep)
    synthesis_cb(app, dep)

    # ── Navigation ────────────────────────────────────────────────────
    @app.callback(
        [Output("active-page", "data"),
         Output({"type": "sidebar-item", "index": dash.ALL}, "className")],
        Input({"type": "sidebar-item", "index": dash.ALL}, "n_clicks"),
        prevent_initial_call=True,
    )
    def navigate(_clicks):
        triggered = ctx.triggered_id
        if not triggered or not isinstance(triggered, dict):
            return DEFAULT_PAGE, _sb_classes(DEFAULT_PAGE)
        page_id = triggered.get("index", DEFAULT_PAGE)
        return page_id, _sb_classes(page_id)

    @app.callback(
        Output("page-content-inner", "children"),
        Input("active-page", "data"),
    )
    def render_page(page_id):
        return _get_page(dep, page_id or DEFAULT_PAGE)


def _sb_classes(active_id):
    return [
        "sidebar-item active" if pid == active_id else "sidebar-item"
        for pid, _, _ in SIDEBAR_ITEMS
    ]


def _get_page(dep, page_id):
    from .pages.scatter       import layout as sc
    from .pages.overview      import layout as ov
    from .pages.correlation   import layout as co
    from .pages.univariate    import layout as un
    from .pages.analysis_3d   import layout as a3
    from .pages.importance    import layout as im
    from .pages.missing       import layout as mi
    from .pages.clusters      import layout as cl
    from .pages.pca           import layout as pc
    from .pages.corr_clusters import layout as cc
    from .pages.posthoc       import layout as ph
    from .pages.synthesis     import layout as sy
    from .pages.stubs         import layout as st

    pages = {
        "scatter":       sc,  "overview":      ov,
        "correlation":   co,  "univariate":    un,
        "analysis3d":    a3,  "importance":    im,
        "missing":       mi,  "clusters":      cl,
        "pca":           pc,  "corr_clusters": cc,
        "posthoc":       ph,  "synthesis":     sy,
    }

    if page_id in pages:
        return pages[page_id](dep)
    if page_id in STUB_PAGES:
        return st(dep, page_id)
    return ov(dep)
