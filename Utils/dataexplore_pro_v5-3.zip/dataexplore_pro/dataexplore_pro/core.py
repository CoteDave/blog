"""
DataExplore Pro — core.py
Main class that wraps data and launches the Dash app.
"""

from __future__ import annotations

import threading
import time
import webbrowser
from typing import List, Optional, Union

import numpy as np
import pandas as pd


class DataExplorePro:
    """
    Interactive ML data-exploration dashboard.

    Works with supervised (X, y) **or** unsupervised (X only) data and
    auto-launches a rich Dash interface in your browser.

    Parameters
    ----------
    X : pd.DataFrame | np.ndarray | array-like
        Feature matrix.  If a DataFrame, column names are kept as-is.
    y : array-like, optional
        Target labels.  Can be binary, multi-class, or continuous.
        When omitted, only unsupervised analyses are available.
    feature_names : list[str], optional
        Column names to use when X is not a DataFrame.
    target_name : str, default ``'Target'``
        Display name for the target column.
    title : str, default ``'DataExplore Pro'``
        Dashboard title shown in the browser tab and header.

    Examples
    --------
    >>> from sklearn.datasets import load_breast_cancer
    >>> from dataexplore_pro import DataExplorePro
    >>> data = load_breast_cancer()
    >>> dep = DataExplorePro(data.data, data.target,
    ...                      feature_names=data.feature_names)
    >>> dep.run()

    Unsupervised:
    >>> from sklearn.datasets import load_iris
    >>> data = load_iris()
    >>> dep = DataExplorePro(data.data, feature_names=data.feature_names)
    >>> dep.run()
    """

    # ------------------------------------------------------------------ #
    #  Construction                                                        #
    # ------------------------------------------------------------------ #

    def __init__(
        self,
        X,
        y=None,
        feature_names: Optional[List[str]] = None,
        target_name: str = "Target",
        title: str = "DataExplore Pro",
    ):
        # --- Feature matrix ---
        if isinstance(X, pd.DataFrame):
            self.df = X.reset_index(drop=True).copy()
            self.feature_names: List[str] = list(X.columns)
        else:
            arr = np.asarray(X, dtype=float)
            if feature_names is None:
                feature_names = [f"Feature_{i}" for i in range(arr.shape[1])]
            self.feature_names = list(feature_names)
            self.df = pd.DataFrame(arr, columns=self.feature_names)

        # --- Target ---
        self.supervised: bool = y is not None
        self.target_name: str = target_name

        if y is not None:
            self.y = np.asarray(y)
            self.df[target_name] = self.y
            self.classes: List = sorted(np.unique(self.y).tolist())
            self.n_classes: int = len(self.classes)
            # Detect regression vs classification
            self.is_classification: bool = (
                self.n_classes <= 20
                and not np.issubdtype(self.y.dtype, np.floating)
                or self.n_classes == 2
            )
        else:
            self.y = None
            self.classes = []
            self.n_classes = 0
            self.is_classification = False

        # Numeric columns (excludes target)
        self.num_features: List[str] = [
            c
            for c in self.df.columns
            if c != target_name and pd.api.types.is_numeric_dtype(self.df[c])
        ]
        # Categorical columns (excludes target)
        self.cat_features: List[str] = [
            c
            for c in self.df.columns
            if c != target_name and not pd.api.types.is_numeric_dtype(self.df[c])
        ]

        self.title: str = title
        self._app = None

    # ------------------------------------------------------------------ #
    #  Launch                                                              #
    # ------------------------------------------------------------------ #

    def run(
        self,
        host: str = "127.0.0.1",
        port: int = 8050,
        debug: bool = False,
        open_browser: bool = True,
    ) -> None:
        """
        Start the Dash server and (optionally) open the browser.

        Parameters
        ----------
        host : str
        port : int
        debug : bool
            Enable Dash hot-reloading / verbose errors.
        open_browser : bool
            Automatically open the default browser after 1.5 s.
        """
        from .app_factory import create_app  # lazy import to avoid circular

        self._app = create_app(self)

        if open_browser:
            def _open() -> None:
                time.sleep(1.5)
                webbrowser.open(f"http://{host}:{port}")

            threading.Thread(target=_open, daemon=True).start()

        n = len(self.df)
        f = len(self.num_features)
        mode = (
            f"Supervised · {self.n_classes} classes"
            if self.supervised
            else "Unsupervised"
        )

        sep = "─" * 52
        print(f"\n  {sep}")
        print(f"  🚀  {self.title}")
        print(f"  {sep}")
        print(f"  URL   : http://{host}:{port}")
        print(f"  Data  : {n:,} rows  ×  {f} numeric features")
        print(f"  Mode  : {mode}")
        print(f"  {sep}")
        print("  Press  Ctrl+C  to stop\n")

        self._app.run(host=host, port=port, debug=debug)
