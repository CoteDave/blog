"""
Analyse en Composantes Principales (ACP)
  • Scree plot (variance individuelle + cumulée)
  • Biplot 2D interactif (avec flèches de loadings)
  • Biplot 3D interactif
  • Matrice Features × PC (heatmap des loadings)
  • Tableau de contributions par composante
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


# ═══════════════════════════════════════════════════════════════════════════
#  LAYOUT
# ═══════════════════════════════════════════════════════════════════════════

def layout(dep) -> html.Div:
    num      = dep.num_features
    max_comp = min(10, len(num))
    pc_opts  = [{"label": f"PC{i}", "value": i} for i in range(1, max_comp + 1)]

    return html.Div([
        html.Div("Analyse en Composantes Principales (ACP)", className="page-title"),
        html.Div(
            "Réduction de dimensionnalité — biplot 2D/3D, matrice de loadings, scree plot.",
            className="page-subtitle"),

        # ── Controls ───────────────────────────────────────────────────────
        html.Div([
            html.Div([
                html.Div("Nb composantes:", className="control-label"),
                dcc.Slider(id="pca-n", min=2, max=max_comp, step=1,
                           value=min(5, max_comp),
                           marks={i: str(i) for i in range(2, max_comp + 1)},
                           tooltip={"placement":"bottom","always_visible":False}),
            ], className="control-group", style={"minWidth":"260px"}),

            html.Div([
                html.Div("Axes biplot X / Y / Z:", className="control-label"),
                html.Div([
                    dcc.Dropdown(id="pca-pc-x", value=1, options=pc_opts,
                                 clearable=False, style={"width":"100px"}),
                    dcc.Dropdown(id="pca-pc-y", value=2, options=pc_opts,
                                 clearable=False, style={"width":"100px"}),
                    dcc.Dropdown(id="pca-pc-z", value=3, options=pc_opts,
                                 clearable=False, style={"width":"100px"}),
                ], style={"display":"flex","gap":"8px"}),
            ], className="control-group"),

            html.Div([
                html.Div("Mode biplot:", className="control-label"),
                dcc.RadioItems(
                    id="pca-mode",
                    options=[{"label":" 2D","value":"2d"},
                             {"label":" 3D","value":"3d"}],
                    value="2d", inline=True,
                    inputStyle={"marginRight":"4px"},
                    labelStyle={"marginRight":"14px","fontSize":"13px","cursor":"pointer"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Max flèches loadings:", className="control-label"),
                dcc.Slider(id="pca-arrows", min=0, max=min(20,len(num)),
                           step=1, value=min(10,len(num)),
                           marks={0:"0",5:"5",10:"10",15:"15",20:"20"},
                           tooltip={"placement":"bottom","always_visible":False}),
            ], className="control-group", style={"minWidth":"220px"}),
        ], className="controls-row"),

        # ── Biplot + Scree ──────────────────────────────────────────────────
        html.Div([
            html.Div([
                dcc.Loading(html.Div(id="pca-biplot-wrap"), type="circle", color="#4472c4"),
            ], className="chart-card"),
            html.Div([
                dcc.Loading(dcc.Graph(id="pca-scree", config={"displayModeBar":False},
                          style={"height":"420px"}), type="circle", color="#4472c4"),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # ── Loadings heatmap ────────────────────────────────────────────────
        html.Div([
            html.Div("🗺️ Matrice des Loadings — Features × Composantes",
                     className="chart-card-title"),
            dcc.Loading(dcc.Graph(id="pca-loadings-heatmap",
                      config={"displayModeBar":True},
                      style={"height":"520px"}), type="circle", color="#4472c4"),
        ], className="chart-card", style={"marginBottom":"16px"}),

        # ── Contribution table ───────────────────────────────────────────────
        html.Div([
            html.Div("📋 Contributions des features par composante (top 10)",
                     className="chart-card-title"),
            html.Div(id="pca-contrib-table"),
        ], className="chart-card"),

    ], className="page-card")


# ═══════════════════════════════════════════════════════════════════════════
#  CALLBACKS
# ═══════════════════════════════════════════════════════════════════════════

def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("pca-biplot-wrap",       "children"),
         Output("pca-scree",             "figure"),
         Output("pca-loadings-heatmap",  "figure"),
         Output("pca-contrib-table",     "children")],
        [Input("pca-n",      "value"),
         Input("pca-pc-x",   "value"),
         Input("pca-pc-y",   "value"),
         Input("pca-pc-z",   "value"),
         Input("pca-mode",   "value"),
         Input("pca-arrows", "value")],
    )
    def update(n_comp, pc_x, pc_y, pc_z, mode, n_arrows):
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler

        num   = dep.num_features
        n_comp = max(3, min(n_comp or 5, len(num)))
        pc_x   = min(pc_x or 1, n_comp)
        pc_y   = min(pc_y or 2, n_comp)
        pc_z   = min(pc_z or 3, n_comp)
        n_arr  = n_arrows or 0

        X_raw = dep.df[num].fillna(dep.df[num].median()).values
        X     = StandardScaler().fit_transform(X_raw)

        pca      = PCA(n_components=n_comp, random_state=42)
        scores   = pca.fit_transform(X)
        loadings = pca.components_          # shape (n_comp, n_features)
        var_r    = pca.explained_variance_ratio_ * 100

        xi, yi, zi = pc_x-1, pc_y-1, pc_z-1

        # ── Biplot ──────────────────────────────────────────────────────────
        if mode == "3d":
            biplot_fig = _biplot_3d(dep, scores, loadings, var_r,
                                     xi, yi, zi, num, n_arr)
            biplot_el  = dcc.Graph(figure=biplot_fig,
                                    config={"displayModeBar":True},
                                    style={"height":"480px"})
        else:
            biplot_fig = _biplot_2d(dep, scores, loadings, var_r,
                                     xi, yi, num, n_arr)
            biplot_el  = dcc.Graph(figure=biplot_fig,
                                    config={"displayModeBar":True},
                                    style={"height":"420px"})

        # ── Scree ────────────────────────────────────────────────────────────
        cum_var = np.cumsum(var_r)
        fig_sc  = go.Figure()
        fig_sc.add_trace(go.Bar(
            x=[f"PC{i+1}" for i in range(n_comp)],
            y=var_r, name="Variance indiv.",
            marker=dict(
                color=[
                    "#4472c4" if i in (xi, yi, zi) else "rgba(68,114,196,0.45)"
                    for i in range(n_comp)
                ],
                line=dict(width=0.5, color="white"),
            ),
            text=[f"{v:.1f}%" for v in var_r], textposition="outside",
        ))
        fig_sc.add_trace(go.Scatter(
            x=[f"PC{i+1}" for i in range(n_comp)], y=cum_var,
            name="Cumulée", mode="lines+markers",
            line=dict(color="#e07b39", width=2.5),
            marker=dict(size=7, color="#e07b39"),
            yaxis="y2",
        ))
        fig_sc.add_hline(y=80, line_dash="dot", line_color="#6b7a8d",
                          annotation_text="80%", line_width=1,
                          yref="y2")
        fig_sc.update_layout(
            title="Diagramme d'Éboulis (Scree Plot)",
            xaxis=dict(title="Composante", gridcolor=GRID),
            yaxis=dict(title="Variance expliquée (%)", gridcolor=GRID,
                       range=[0, max(var_r)*1.25]),
            yaxis2=dict(title="Variance cumulée (%)", overlaying="y", side="right",
                        range=[0, 110], showgrid=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=60, r=70, t=50, b=50),
            font=dict(family=FONT, size=11),
            legend=dict(font=dict(size=11), x=0.3, y=1.12, orientation="h"),
        )

        # ── Loadings heatmap ─────────────────────────────────────────────────
        # Matrix: rows = features, cols = PCs
        # Color = loading value (signed), size indication via text
        load_mat = loadings.T   # (n_features, n_comp)
        load_df  = pd.DataFrame(load_mat, index=num,
                                 columns=[f"PC{i+1}" for i in range(n_comp)])

        # Sort features by contribution to PC1
        sort_order = np.argsort(np.abs(load_df["PC1"]))[::-1]
        load_df    = load_df.iloc[sort_order]

        z_heat  = load_df.values
        max_abs = max(abs(z_heat).max(), 1e-6)

        fig_heat = go.Figure(go.Heatmap(
            z=z_heat,
            x=list(load_df.columns),
            y=[f[:28] for f in load_df.index],
            colorscale=[[0,"#e74c3c"],[0.5,"#ffffff"],[1,"#4472c4"]],
            zmid=0, zmin=-max_abs, zmax=max_abs,
            text=[[f"{v:.2f}" for v in row] for row in z_heat],
            texttemplate="%{text}",
            textfont=dict(size=9),
            hovertemplate="<b>%{y}</b> → %{x}: <b>%{z:.4f}</b><extra></extra>",
            colorbar=dict(title="Loading", thickness=14, tickfont=dict(size=10)),
        ))

        # Highlight selected PC columns
        for pc_idx in set([xi, yi, zi]):
            fig_heat.add_shape(
                type="rect",
                x0=pc_idx-0.5, y0=-0.5,
                x1=pc_idx+0.5, y1=len(num)-0.5,
                line=dict(color="#1e3a5f", width=2.5, dash="dot"),
                fillcolor="transparent", layer="above",
            )

        fig_heat.update_layout(
            title=f"Loadings features × composantes (trié par |PC1|)",
            plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=180, r=60, t=50, b=80),
            font=dict(family=FONT, size=10),
            xaxis=dict(side="top", tickangle=0,
                       tickfont=dict(size=11, color="#1e3a5f", family=FONT)),
            yaxis=dict(tickfont=dict(size=9.5)),
            height=max(400, len(num)*28+100),
        )

        # ── Contribution table ────────────────────────────────────────────────
        # For each PC: top 10 features by |loading|²
        contrib_sections = []
        for pc_i in range(min(n_comp, 5)):
            pc_name = f"PC{pc_i+1}"
            contribs = (load_df[pc_name]**2 / (load_df[pc_name]**2).sum() * 100)
            top_feat = contribs.sort_values(ascending=False).head(10)

            header = html.Tr([
                html.Th(f"Feature ({pc_name} — {var_r[pc_i]:.1f}% var.)",
                        style={**_th(), "width":"55%"}),
                html.Th("Loading",       style=_th()),
                html.Th("Contribution%", style=_th()),
                html.Th("Bar",           style=_th()),
            ])
            body = []
            for feat in top_feat.index:
                loading = float(load_df.loc[feat, pc_name])
                contrib = float(top_feat[feat])
                bar_w   = int(contrib / top_feat.max() * 80)
                bar_clr = "#4472c4" if loading >= 0 else "#e74c3c"
                body.append(html.Tr([
                    html.Td(feat[:35], style=_td()),
                    html.Td(f"{loading:+.4f}",
                            style={**_td(),"color":bar_clr,"fontWeight":"700"}),
                    html.Td(f"{contrib:.1f}%", style=_td()),
                    html.Td(html.Div(style={
                        "width":f"{bar_w}px","height":"8px",
                        "background":bar_clr,"borderRadius":"3px","opacity":"0.75",
                    }), style=_td()),
                ], style={"borderBottom":"1px solid #f0f4f8"}))

            contrib_sections.append(html.Div([
                html.Table([html.Thead(header), html.Tbody(body)],
                           style={"width":"100%","borderCollapse":"collapse",
                                  "fontSize":"12px","fontFamily":FONT}),
            ], className="chart-card",
               style={"marginBottom":"12px"}))

        return biplot_el, fig_sc, fig_heat, html.Div(contrib_sections)


# ═══════════════════════════════════════════════════════════════════════════
#  BIPLOT BUILDERS
# ═══════════════════════════════════════════════════════════════════════════

def _biplot_2d(dep, scores, loadings, var_r, xi, yi, num, n_arrows):
    fig = go.Figure()

    if dep.supervised:
        for i, cls in enumerate(dep.classes):
            mask = dep.y == cls
            fig.add_trace(go.Scatter(
                x=scores[mask, xi], y=scores[mask, yi],
                mode="markers", name=f"Classe {cls}",
                marker=dict(color=PAL[i % len(PAL)], size=7, opacity=0.78,
                            line=dict(width=0.5, color="rgba(255,255,255,.6)")),
                hovertemplate=f"Classe {cls}<br>PC{xi+1}: %{{x:.2f}}<br>PC{yi+1}: %{{y:.2f}}<extra></extra>",
            ))
    else:
        fig.add_trace(go.Scatter(
            x=scores[:, xi], y=scores[:, yi], mode="markers",
            marker=dict(color="#4472c4", size=7, opacity=0.75),
            hovertemplate=f"PC{xi+1}: %{{x:.2f}}<br>PC{yi+1}: %{{y:.2f}}<extra></extra>",
        ))

    if n_arrows > 0:
        scale = max(abs(scores[:,xi]).max(), abs(scores[:,yi]).max()) * 0.45
        # Sort features by loading magnitude for selected PCs
        mag = np.sqrt(loadings[xi,:]**2 + loadings[yi,:]**2)
        top_idx = np.argsort(mag)[::-1][:n_arrows]
        for j in top_idx:
            lx = float(loadings[xi, j]) * scale
            ly = float(loadings[yi, j]) * scale
            fig.add_annotation(
                ax=0, ay=0, axref="x", ayref="y",
                x=lx, y=ly,
                arrowhead=3, arrowsize=1.2, arrowwidth=1.8,
                arrowcolor="rgba(231,76,60,0.75)", showarrow=True,
            )
            fig.add_annotation(
                x=lx * 1.18, y=ly * 1.18,
                text=num[j][:14], showarrow=False,
                font=dict(size=9, color="#c0392b", family=FONT),
                bgcolor="rgba(255,255,255,0.75)",
            )

    fig.update_layout(
        title=f"Biplot ACP 2D — PC{xi+1} ({var_r[xi]:.1f}%) vs PC{yi+1} ({var_r[yi]:.1f}%)",
        xaxis=dict(title=f"PC{xi+1} — {var_r[xi]:.1f}%",
                   gridcolor=GRID, zeroline=True, zerolinecolor="#ccc", zerolinewidth=1),
        yaxis=dict(title=f"PC{yi+1} — {var_r[yi]:.1f}%",
                   gridcolor=GRID, zeroline=True, zerolinecolor="#ccc", zerolinewidth=1),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=60,r=20,t=50,b=50),
        font=dict(family=FONT, size=11),
        legend=dict(font=dict(size=11), bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1, bordercolor=GRID),
    )
    return fig


def _biplot_3d(dep, scores, loadings, var_r, xi, yi, zi, num, n_arrows):
    fig = go.Figure()

    if dep.supervised:
        for i, cls in enumerate(dep.classes):
            mask = dep.y == cls
            fig.add_trace(go.Scatter3d(
                x=scores[mask,xi], y=scores[mask,yi], z=scores[mask,zi],
                mode="markers", name=f"Classe {cls}",
                marker=dict(color=PAL[i%len(PAL)], size=4, opacity=0.78,
                            line=dict(width=0.3, color="rgba(255,255,255,.4)")),
            ))
    else:
        fig.add_trace(go.Scatter3d(
            x=scores[:,xi], y=scores[:,yi], z=scores[:,zi],
            mode="markers",
            marker=dict(color="#4472c4", size=4, opacity=0.75),
        ))

    if n_arrows > 0:
        scale = max(abs(scores[:,xi]).max(), abs(scores[:,yi]).max(),
                    abs(scores[:,zi]).max()) * 0.45
        mag = np.sqrt(loadings[xi,:]**2 + loadings[yi,:]**2 + loadings[zi,:]**2)
        top_idx = np.argsort(mag)[::-1][:n_arrows]
        for j in top_idx:
            lx = float(loadings[xi, j]) * scale
            ly = float(loadings[yi, j]) * scale
            lz = float(loadings[zi, j]) * scale
            # Arrow as a line from origin to tip
            fig.add_trace(go.Scatter3d(
                x=[0, lx, None], y=[0, ly, None], z=[0, lz, None],
                mode="lines+text",
                line=dict(color="rgba(231,76,60,0.8)", width=3),
                text=["", num[j][:14], ""],
                textfont=dict(size=9, color="#c0392b"),
                showlegend=False, hoverinfo="skip",
            ))
            # Cone arrow head
            fig.add_trace(go.Cone(
                x=[lx], y=[ly], z=[lz],
                u=[lx*0.2], v=[ly*0.2], w=[lz*0.2],
                colorscale=[[0,"rgba(231,76,60,0.8)"],[1,"rgba(231,76,60,0.8)"]],
                showscale=False, sizemode="absolute", sizeref=0.3,
                hoverinfo="skip",
            ))

    fig.update_layout(
        title=f"Biplot ACP 3D — PC{xi+1}/{yi+1}/{zi+1}",
        scene=dict(
            xaxis=dict(title=f"PC{xi+1} ({var_r[xi]:.1f}%)",
                       gridcolor=GRID, backgroundcolor=BG),
            yaxis=dict(title=f"PC{yi+1} ({var_r[yi]:.1f}%)",
                       gridcolor=GRID, backgroundcolor=BG),
            zaxis=dict(title=f"PC{zi+1} ({var_r[zi]:.1f}%)",
                       gridcolor=GRID, backgroundcolor=BG),
            bgcolor="white",
        ),
        paper_bgcolor="white",
        margin=dict(l=0,r=0,t=50,b=0),
        font=dict(family=FONT, size=11),
        legend=dict(font=dict(size=11), bgcolor="rgba(255,255,255,.9)"),
    )
    return fig


def _th():
    return {"padding":"6px 10px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10.5px","textTransform":"uppercase",
            "letterSpacing":".4px","borderBottom":"2px solid #e0e4ea",
            "textAlign":"left","whiteSpace":"nowrap"}

def _td():
    return {"padding":"5px 10px","color":"#374151",
            "fontSize":"11.5px","whiteSpace":"nowrap"}
