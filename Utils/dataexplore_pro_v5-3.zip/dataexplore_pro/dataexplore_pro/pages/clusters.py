"""
Analyse de Clusters — K-Means + convex hull per cluster + elbow + silhouette.
"""
from __future__ import annotations
import numpy as np
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy.spatial import ConvexHull

CLASS_PALETTE = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"


def _hex_alpha(hex_color, alpha):
    h = hex_color.lstrip("#")
    r,g,b = int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
    return f"rgba({r},{g},{b},{alpha})"


def _hull_trace(x, y, color, name=""):
    pts = np.column_stack([x, y])
    pts = pts[~np.isnan(pts).any(axis=1)]
    if len(pts) < 3:
        return None
    try:
        hull = ConvexHull(pts)
        hx = np.append(pts[hull.vertices,0], pts[hull.vertices[0],0])
        hy = np.append(pts[hull.vertices,1], pts[hull.vertices[0],1])
        return go.Scatter(
            x=hx, y=hy, fill="toself",
            fillcolor=_hex_alpha(color, 0.13),
            line=dict(color=color, width=2, dash="dot"),
            mode="lines", name=f"Hull {name}",
            showlegend=False, hoverinfo="skip",
        )
    except Exception:
        return None


def layout(dep) -> html.Div:
    num = dep.num_features
    return html.Div([
        html.Div("Analyse de Clusters", className="page-title"),
        html.Div("K-Means avec hull convexe, courbe d'inertie et silhouette.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Nombre de clusters K:", className="control-label"),
                      dcc.Slider(id="cl-k", min=2, max=10, step=1, value=3,
                                 marks={i:str(i) for i in range(2,11)})],
                     className="control-group", style={"minWidth":"280px"}),
            html.Div([html.Div("Variables (PCA input):", className="control-label"),
                      dcc.Dropdown(id="cl-vars",
                                   options=[{"label":c,"value":c} for c in num],
                                   value=num[:min(10,len(num))], multi=True,
                                   style={"minWidth":"320px"})],
                     className="control-group"),
            html.Div([html.Div("Hull:", className="control-label"),
                      dcc.Dropdown(id="cl-hull",
                                   options=[{"label":"Convexe","value":"convex"},
                                            {"label":"Aucun","value":"none"}],
                                   value="convex", clearable=False,
                                   style={"width":"150px"})],
                     className="control-group"),
        ], className="controls-row"),

        # Scatter + elbow
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-scatter", config={"displayModeBar":False},
                                style={"height":"420px"}), type="circle", color="#4472c4")], className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-elbow",   config={"displayModeBar":False},
                                style={"height":"420px"}), type="circle", color="#4472c4")], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # Silhouette + profile
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-sil",     config={"displayModeBar":False},
                                style={"height":"300px"}), type="circle", color="#4472c4")], className="chart-card"),
            html.Div([dcc.Graph(id="cl-profile", config={"displayModeBar":False},
                                style={"height":"300px"})], className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("cl-scatter","figure"), Output("cl-elbow","figure"),
         Output("cl-sil","figure"),     Output("cl-profile","figure")],
        [Input("cl-k","value"), Input("cl-vars","value"), Input("cl-hull","value")],
    )
    def update(k, vars_sel, hull_mode):
        from sklearn.cluster import KMeans
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler
        from sklearn.metrics import silhouette_samples, silhouette_score

        if not vars_sel or len(vars_sel) < 2:
            empty = go.Figure()
            return empty, empty, empty, empty

        cols = [c for c in vars_sel if c in dep.num_features]
        X_raw = dep.df[cols].fillna(dep.df[cols].median()).values
        X     = StandardScaler().fit_transform(X_raw)

        # ── Elbow curve ──────────────────────────────────────────────────
        max_k = min(11, len(X))
        ks, inertias = list(range(2, max_k)), []
        for ki in ks:
            km = KMeans(n_clusters=ki, random_state=42, n_init=10)
            km.fit(X)
            inertias.append(km.inertia_)

        fig_elbow = go.Figure([
            go.Scatter(x=ks, y=inertias, mode="lines+markers",
                       line=dict(color="#4472c4", width=2),
                       marker=dict(size=8, color="#e07b39")),
        ])
        fig_elbow.add_vline(x=k, line_dash="dash", line_color="#e74c3c",
                             annotation_text=f"K={k}")
        fig_elbow.update_layout(**_base_layout("Courbe d'Inertie (Méthode du Coude)"),
                                xaxis_title="K", yaxis_title="Inertie")

        # ── K-Means fit ──────────────────────────────────────────────────
        km     = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(X)

        # ── PCA 2D ───────────────────────────────────────────────────────
        pca = PCA(n_components=2)
        X2  = pca.fit_transform(X)
        v1, v2 = pca.explained_variance_ratio_[:2] * 100

        fig_sc = go.Figure()
        for ci in range(k):
            mask = labels == ci
            clr  = CLASS_PALETTE[ci % len(CLASS_PALETTE)]
            fig_sc.add_trace(go.Scatter(
                x=X2[mask,0], y=X2[mask,1], mode="markers",
                name=f"Cluster {ci}",
                marker=dict(color=clr, size=7, opacity=0.82,
                            line=dict(width=0.5, color="rgba(255,255,255,.6)")),
                hovertemplate=f"Cluster {ci}<br>PC1: %{{x:.2f}}<br>PC2: %{{y:.2f}}<extra></extra>",
            ))
            if hull_mode == "convex" and mask.sum() >= 3:
                ht = _hull_trace(X2[mask,0], X2[mask,1], clr, str(ci))
                if ht:
                    fig_sc.add_trace(ht)
        # Centroids projected
        cents_2d = pca.transform(km.cluster_centers_)
        fig_sc.add_trace(go.Scatter(
            x=cents_2d[:,0], y=cents_2d[:,1], mode="markers",
            marker=dict(symbol="x", size=14, color="black", line_width=2),
            name="Centroïdes", hoverinfo="skip",
        ))
        fig_sc.update_layout(**_base_layout(f"Clusters K-Means K={k} — Projection ACP"),
                              xaxis_title=f"PC1 ({v1:.1f}%)", yaxis_title=f"PC2 ({v2:.1f}%)",
                              legend=dict(font=dict(size=11)))

        # ── Silhouette per sample ─────────────────────────────────────────
        if len(X) > 2000:
            idx = np.random.choice(len(X), 2000, replace=False)
            X_s, L_s = X[idx], labels[idx]
        else:
            X_s, L_s = X, labels

        try:
            sil_vals = silhouette_samples(X_s, L_s)
            avg_sil  = sil_vals.mean()
        except Exception:
            sil_vals = np.zeros(len(X_s))
            avg_sil  = 0

        fig_sil = go.Figure()
        y_lower = 0
        for ci in range(k):
            sv = np.sort(sil_vals[L_s == ci])
            y_upper = y_lower + len(sv)
            clr = CLASS_PALETTE[ci % len(CLASS_PALETTE)]
            fig_sil.add_trace(go.Bar(
                y=list(range(y_lower, y_upper)), x=sv,
                orientation="h", marker_color=clr, name=f"C{ci}",
                showlegend=False, width=1,
            ))
            y_lower = y_upper + 5
        fig_sil.add_vline(x=avg_sil, line_dash="dash", line_color="#e74c3c",
                           annotation_text=f"moy={avg_sil:.2f}")
        fig_sil.update_layout(**_base_layout(f"Silhouette par Échantillon (moy={avg_sil:.3f})"),
                               xaxis_title="Score Silhouette",
                               yaxis=dict(visible=False))

        # ── Cluster mean profile (radar-like bar) ─────────────────────────
        show_cols = cols[:8]
        X_df = dep.df[show_cols].fillna(dep.df[show_cols].median())
        from sklearn.preprocessing import MinMaxScaler
        X_norm = MinMaxScaler().fit_transform(X_df.values)

        fig_prof = go.Figure()
        for ci in range(k):
            mask  = labels == ci
            means = X_norm[mask].mean(axis=0)
            clr   = CLASS_PALETTE[ci % len(CLASS_PALETTE)]
            fig_prof.add_trace(go.Bar(
                x=[c[:12] for c in show_cols], y=means,
                name=f"Cluster {ci}", marker_color=clr, opacity=0.8,
            ))
        fig_prof.update_layout(
            **_base_layout("Profil Moyen des Clusters (normalisé 0-1)"),
            barmode="group",
            xaxis=dict(tickangle=-30, gridcolor=GRID),
            yaxis_title="Valeur normalisée",
            legend=dict(font=dict(size=11), orientation="h"),
        )

        return fig_sc, fig_elbow, fig_sil, fig_prof


def _base_layout(title=""):
    return dict(
        title=dict(text=title, font=dict(size=13)),
        plot_bgcolor=BG, paper_bgcolor="#fff",
        margin=dict(l=50, r=20, t=45, b=55),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=11),
        xaxis=dict(gridcolor=GRID, zeroline=False),
        yaxis=dict(gridcolor=GRID, zeroline=False),
    )
