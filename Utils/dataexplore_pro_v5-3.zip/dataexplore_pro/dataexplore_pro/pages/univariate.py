"""
Analyse Univariée — distribution complète d'une variable numérique.
  • Histogramme + KDE + rug
  • Box + Violin + Strip
  • QQ-plot (normalité)
  • ECDF avec bandes de confiance
  • Ajustement de distributions (normal, log-normal, gamma, beta)
  • Transformations (log, sqrt, Box-Cox, Yeo-Johnson)
  • Comparaison inter-classes (si supervisé)
  • Panel de stats complet avec tests
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


# ══════════════════════════════════════════════════════════════════════════════
#  LAYOUT
# ══════════════════════════════════════════════════════════════════════════════

def layout(dep) -> html.Div:
    num      = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]

    CHART_OPTS = [
        {"label": "Histogramme + KDE", "value": "hist"},
        {"label": "Box + Violin",       "value": "boxviolin"},
        {"label": "QQ-Plot (normalité)","value": "qq"},
        {"label": "ECDF",               "value": "ecdf"},
        {"label": "Ajustement distrib.","value": "fit"},
        {"label": "Transformations",    "value": "transform"},
    ]

    return html.Div([
        html.Div("Analyse Univariée", className="page-title"),
        html.Div("Distribution complète — tests statistiques, QQ-plot, fit de distribution, transformations.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Variable:", className="control-label"),
                      dcc.Dropdown(id="uni-col", options=col_opts,
                                   value=num[0] if num else None,
                                   clearable=False, style={"width":"260px"})],
                     className="control-group"),
            html.Div([html.Div("Graphique:", className="control-label"),
                      dcc.Dropdown(id="uni-type", options=CHART_OPTS,
                                   value="hist", clearable=False,
                                   style={"width":"220px"})],
                     className="control-group"),
            html.Div([html.Div("Grouper par target:", className="control-label"),
                      dcc.RadioItems(id="uni-group",
                                     options=[{"label":" Oui","value":"yes"},
                                              {"label":" Non","value":"no"}],
                                     value="yes" if dep.supervised else "no",
                                     inline=True,
                                     inputStyle={"marginRight":"4px"},
                                     labelStyle={"marginRight":"12px","fontSize":"13px"})],
                     className="control-group"),
            html.Div([html.Div("Bins (histo):", className="control-label"),
                      dcc.Slider(id="uni-bins", min=5, max=80, step=5, value=25,
                                 marks={10:"10",25:"25",50:"50",80:"80"},
                                 tooltip={"placement":"bottom","always_visible":False})],
                     className="control-group", style={"minWidth":"200px"}),
        ], className="controls-row"),

        # Main chart
        html.Div([dcc.Loading(dcc.Graph(id="uni-main", config={"displayModeBar":True},
                            style={"height":"400px"}), type="circle", color="#4472c4")],
                 className="chart-card", style={"marginBottom":"16px"}),

        # Stats + secondary chart
        html.Div([
            html.Div([html.Div(id="uni-stats-panel")], className="chart-card"),
            html.Div([dcc.Graph(id="uni-secondary", config={"displayModeBar":False},
                                style={"height":"360px"})], className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


# ══════════════════════════════════════════════════════════════════════════════
#  CALLBACKS
# ══════════════════════════════════════════════════════════════════════════════

def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("uni-main",         "figure"),
         Output("uni-secondary",    "figure"),
         Output("uni-stats-panel",  "children")],
        [Input("uni-col",   "value"),
         Input("uni-type",  "value"),
         Input("uni-group", "value"),
         Input("uni-bins",  "value")],
    )
    def update(col, chart_type, group, n_bins):
        if col is None:
            empty = go.Figure()
            return empty, empty, []

        df       = dep.df
        s_all    = df[col].dropna()
        n_bins   = n_bins or 25
        by_group = dep.supervised and group == "yes"

        # ── Main chart ──────────────────────────────────────────────────────
        if chart_type == "hist":
            fig_main = _hist_kde(dep, col, s_all, by_group, n_bins)
        elif chart_type == "boxviolon":
            fig_main = _box_violin(dep, col, s_all, by_group)
        elif chart_type == "boxviolin":
            fig_main = _box_violin(dep, col, s_all, by_group)
        elif chart_type == "qq":
            fig_main = _qqplot(col, s_all)
        elif chart_type == "ecdf":
            fig_main = _ecdf_chart(dep, col, s_all, by_group)
        elif chart_type == "fit":
            fig_main = _dist_fit(col, s_all)
        elif chart_type == "transform":
            fig_main = _transform_chart(col, s_all)
        else:
            fig_main = _hist_kde(dep, col, s_all, by_group, n_bins)

        # ── Secondary: always Box+Violin per class or single ────────────────
        fig_sec = _box_violin(dep, col, s_all, by_group)

        # ── Stats panel ─────────────────────────────────────────────────────
        stats_panel = _stats_panel(dep, col, s_all, by_group)

        return fig_main, fig_sec, stats_panel


# ══════════════════════════════════════════════════════════════════════════════
#  CHART BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _hist_kde(dep, col, s_all, by_group, n_bins):
    fig = go.Figure()

    groups = ([(f"Classe {cls}", dep.df[dep.df[dep.target_name]==cls][col].dropna(),
                PAL[i%len(PAL)])
               for i, cls in enumerate(dep.classes)]
              if by_group else
              [(col, s_all, "#4472c4")])

    for name, vals, clr in groups:
        # Histogram
        fig.add_trace(go.Histogram(
            x=vals, name=name,
            marker=dict(color=clr, opacity=0.55,
                        line=dict(width=0.5, color="rgba(255,255,255,.5)")),
            nbinsx=n_bins, histnorm="probability density",
        ))
        # KDE overlay
        xg, dens = _kde(vals.values)
        if len(xg):
            fig.add_trace(go.Scatter(
                x=xg, y=dens, mode="lines", name=f"KDE {name}",
                line=dict(color=clr, width=2.5),
                showlegend=False,
            ))
        # Mean + median lines
        fig.add_vline(x=float(vals.mean()), line_dash="dash",
                      line_color=clr, line_width=1.5,
                      annotation_text=f"μ={vals.mean():.3g}",
                      annotation_font_size=9)

    fig.update_layout(**_base("Histogramme + KDE — " + col),
                      barmode="overlay",
                      xaxis_title=col, yaxis_title="Densité")
    return fig


def _box_violin(dep, col, s_all, by_group):
    fig = go.Figure()
    groups = ([(f"Cls {cls}", dep.df[dep.df[dep.target_name]==cls][col].dropna(),
                PAL[i%len(PAL)])
               for i, cls in enumerate(dep.classes)]
              if by_group else [(col, s_all, "#4472c4")])

    for name, vals, clr in groups:
        fig.add_trace(go.Violin(
            y=vals, name=name,
            fillcolor=_alpha(clr, 0.25),
            line_color=clr, line_width=1.8,
            box_visible=True, meanline_visible=True,
            points="outliers",
            marker=dict(color=clr, size=4, opacity=0.6),
            spanmode="hard",
        ))

    fig.update_layout(**_base("Box + Violin — " + col),
                      violinmode="group",
                      yaxis_title=col)
    return fig


def _qqplot(col, vals):
    """Normal QQ-plot with confidence band."""
    sorted_v = np.sort(vals.values)
    n        = len(sorted_v)
    theor    = sp_stats.norm.ppf((np.arange(1, n+1) - 0.375) / (n + 0.25))

    # 95% confidence band (Kolmogorov)
    slope, intercept, r, _, _ = sp_stats.linregress(theor, sorted_v)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=theor, y=sorted_v, mode="markers",
        marker=dict(color="#4472c4", size=5, opacity=0.75,
                    line=dict(width=0.3, color="rgba(255,255,255,.5)")),
        name="Quantiles",
        hovertemplate="Théorique: %{x:.3f}<br>Observé: %{y:.3f}<extra></extra>",
    ))
    # Reference line
    x_ref = np.linspace(theor.min(), theor.max(), 2)
    fig.add_trace(go.Scatter(
        x=x_ref, y=slope*x_ref + intercept,
        mode="lines", line=dict(color="#e74c3c", width=2, dash="dash"),
        name="Ligne normale", showlegend=True,
    ))
    # Band ±1.36/sqrt(n)
    se = np.sqrt(sp_stats.norm.pdf(theor)**2)
    band_w = 1.36 / np.sqrt(n)
    fig.add_trace(go.Scatter(
        x=np.concatenate([theor, theor[::-1]]),
        y=np.concatenate([sorted_v + band_w*sorted_v.std(),
                          (sorted_v - band_w*sorted_v.std())[::-1]]),
        fill="toself", fillcolor="rgba(68,114,196,0.08)",
        line=dict(width=0), showlegend=False, hoverinfo="skip",
    ))

    _, p_sw   = sp_stats.shapiro(vals.values[:min(5000,n)])
    _, p_norm = sp_stats.normaltest(vals.values)

    fig.update_layout(
        **_base(f"QQ-Plot — {col}  |  Shapiro p={p_sw:.4f}  D'Agostino p={p_norm:.4f}"),
        xaxis_title="Quantiles théoriques (Normal)",
        yaxis_title=f"Quantiles observés — {col}",
    )
    return fig


def _ecdf_chart(dep, col, s_all, by_group):
    fig = go.Figure()
    groups = ([(f"Cls {cls}", dep.df[dep.df[dep.target_name]==cls][col].dropna(),
                PAL[i%len(PAL)])
               for i, cls in enumerate(dep.classes)]
              if by_group else [(col, s_all, "#4472c4")])

    for name, vals, clr in groups:
        sv = np.sort(vals.values)
        ey = np.arange(1, len(sv)+1) / len(sv)
        # KS confidence band
        eps = 1.36 / np.sqrt(len(sv))
        fig.add_trace(go.Scatter(
            x=np.concatenate([sv, sv[::-1]]),
            y=np.concatenate([np.clip(ey+eps, 0, 1), np.clip(ey-eps, 0, 1)[::-1]]),
            fill="toself", fillcolor=_alpha(clr, 0.10),
            line=dict(width=0), showlegend=False, hoverinfo="skip",
        ))
        fig.add_trace(go.Scatter(
            x=sv, y=ey, mode="lines", name=name,
            line=dict(color=clr, width=2.5),
            hovertemplate=f"{name}<br>x=%{{x:.3g}}<br>F(x)=%{{y:.3f}}<extra></extra>",
        ))

    if by_group and len(dep.classes) == 2:
        # KS test
        g1 = dep.df[dep.df[dep.target_name]==dep.classes[0]][col].dropna().values
        g2 = dep.df[dep.df[dep.target_name]==dep.classes[1]][col].dropna().values
        ks, p_ks = sp_stats.ks_2samp(g1, g2)
        title_extra = f"  |  KS={ks:.3f}  p={p_ks:.4f}"
    else:
        title_extra = ""

    fig.update_layout(**_base(f"ECDF — {col}{title_extra}"),
                      xaxis_title=col, yaxis_title="F(x)",
                      yaxis=dict(range=[0,1.05], gridcolor=GRID, zeroline=False))
    return fig


def _dist_fit(col, vals):
    """Fit normal, lognormal, gamma, exponential and show best."""
    v   = vals.dropna().values
    xg  = np.linspace(v.min() - 0.05*(v.max()-v.min()),
                      v.max() + 0.05*(v.max()-v.min()), 300)

    DISTS = [
        ("Normal",      sp_stats.norm),
        ("Log-Normal",  sp_stats.lognorm),
        ("Gamma",       sp_stats.gamma),
        ("Exponentielle",sp_stats.expon),
        ("Weibull",     sp_stats.weibull_min),
        ("Beta",        sp_stats.beta),
    ]

    fig = go.Figure()
    # Empirical histogram
    fig.add_trace(go.Histogram(
        x=v, histnorm="probability density",
        marker=dict(color="rgba(68,114,196,0.4)",
                    line=dict(width=0.5, color="white")),
        nbinsx=30, name="Empirique", showlegend=True,
    ))

    results = []
    for dist_name, dist_obj in DISTS:
        try:
            if dist_obj == sp_stats.lognorm and (v <= 0).any():
                continue
            if dist_obj == sp_stats.beta and (not (0 < v).all() and (v < 1).all()):
                continue
            params = dist_obj.fit(v)
            pdf_y  = dist_obj.pdf(xg, *params)
            ks, p  = sp_stats.kstest(v, dist_obj.cdf, args=params)
            results.append((dist_name, dist_obj, params, pdf_y, ks, p))
        except Exception:
            pass

    results.sort(key=lambda x: x[4])  # sort by KS stat (ascending = better fit)

    for i, (dist_name, _, _, pdf_y, ks, p) in enumerate(results):
        clr  = PAL[i % len(PAL)]
        dash = "solid" if i == 0 else "dot"
        fig.add_trace(go.Scatter(
            x=xg, y=pdf_y, mode="lines",
            name=f"{dist_name} (KS={ks:.3f}, p={p:.3f})",
            line=dict(color=clr, width=2.5 if i==0 else 1.5, dash=dash),
        ))

    best = results[0][0] if results else "N/A"
    fig.update_layout(**_base(f"Ajustement de distributions — {col}  |  Meilleure: {best}"),
                      xaxis_title=col, yaxis_title="Densité",
                      legend=dict(font=dict(size=9.5), x=1.01))
    return fig


def _transform_chart(col, vals):
    """Show 4 transformations side by side as subplots."""
    from plotly.subplots import make_subplots
    v = vals.dropna().values

    transforms = [("Original", v)]
    if (v > 0).all():
        transforms.append(("Log(x)", np.log(v)))
        transforms.append(("√x", np.sqrt(v)))
    try:
        vt, lam = sp_stats.boxcox(v)
        transforms.append((f"Box-Cox (λ={lam:.2f})", vt))
    except Exception:
        pass
    try:
        vt = sp_stats.yeojohnson(v)[0]
        transforms.append(("Yeo-Johnson", vt))
    except Exception:
        pass

    n = len(transforms)
    cols_n = min(n, 3)
    rows_n = (n + cols_n - 1) // cols_n

    fig = make_subplots(rows=rows_n, cols=cols_n,
                        subplot_titles=[t[0] for t in transforms])

    for idx, (name, tv) in enumerate(transforms):
        r = idx // cols_n + 1
        c = idx % cols_n + 1
        clr = PAL[idx % len(PAL)]
        fig.add_trace(go.Histogram(
            x=tv, nbinsx=25,
            marker=dict(color=clr, opacity=0.75,
                        line=dict(width=0.4, color="white")),
            name=name, showlegend=False,
        ), row=r, col=c)
        # KDE
        xg, dens = _kde(tv)
        if len(xg):
            # Scale KDE to match histogram
            hist_vals, bin_edges = np.histogram(tv, bins=25, density=True)
            scale = max(hist_vals) / max(dens) if max(dens) > 0 else 1
            fig.add_trace(go.Scatter(
                x=xg, y=dens,
                mode="lines", line=dict(color=clr, width=2),
                showlegend=False, hoverinfo="skip",
            ), row=r, col=c)

    fig.update_layout(
        title=dict(text=f"Transformations — {col}", font=dict(size=13)),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=40,r=20,t=60,b=40),
        font=dict(family=FONT, size=10),
        height=300 * rows_n,
    )
    for axis in fig.layout:
        if axis.startswith("xaxis") or axis.startswith("yaxis"):
            fig.layout[axis].update(gridcolor=GRID, zeroline=False)
    return fig


# ══════════════════════════════════════════════════════════════════════════════
#  STATS PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _stats_panel(dep, col, s_all, by_group):
    v = s_all.values
    n = len(v)

    # Descriptive
    q1, med, q3 = np.percentile(v, [25, 50, 75])
    iqr = q3 - q1

    rows = [
        ("N valides", f"{n:,}"),
        ("Moyenne ± Std", f"{v.mean():.4g} ± {v.std():.4g}"),
        ("Médiane / Mode", f"{med:.4g} / {sp_stats.mode(v, keepdims=True).mode[0]:.4g}"),
        ("Q1 — Q3", f"{q1:.4g} — {q3:.4g}"),
        ("IQR", f"{iqr:.4g}"),
        ("Min — Max", f"{v.min():.4g} — {v.max():.4g}"),
    ]

    # Shape
    skw  = float(sp_stats.skew(v))
    kurt = float(sp_stats.kurtosis(v))
    rows += [
        ("Asymétrie (skewness)", f"{skw:+.4f}  ({'→ droite' if skw>0 else '← gauche'})"),
        ("Kurtosis (excès)",     f"{kurt:+.4f}  ({'leptokurtique' if kurt>0 else 'platykurtique'})"),
    ]

    # Normality
    if n >= 8:
        _, p_dag = sp_stats.normaltest(v)
        rows.append(("Test D'Agostino",
                     f"p={p_dag:.4f}  {'✅ Normale' if p_dag>0.05 else '❌ Non-normale'}"))
    if n <= 5000:
        _, p_sw = sp_stats.shapiro(v[:5000])
        rows.append(("Test Shapiro-Wilk",
                     f"p={p_sw:.4f}  {'✅ Normale' if p_sw>0.05 else '❌ Non-normale'}"))

    # Outliers
    n_iqr = int(np.sum((v < q1-1.5*iqr)|(v > q3+1.5*iqr)))
    if v.std() > 0:
        n_z = int(np.sum(np.abs((v-v.mean())/v.std()) > 3))
        rows.append(("Outliers |Z|>3",  f"{n_z} ({n_z/n:.1%})"))
    rows.append(("Outliers IQR×1.5",    f"{n_iqr} ({n_iqr/n:.1%})"))

    # % NaN
    pct_nan = dep.df[col].isnull().mean()
    rows.append(("% NaN", f"{pct_nan:.1%}"))

    # Group comparisons
    group_rows = []
    if by_group and dep.is_classification and len(dep.classes) >= 2:
        groups = {cls: dep.df[dep.df[dep.target_name]==cls][col].dropna().values
                  for cls in dep.classes}
        valid_g = {k: v for k,v in groups.items() if len(v)>=3}

        if len(valid_g) >= 2:
            # Levene
            try:
                _, p_lev = sp_stats.levene(*valid_g.values())
                group_rows.append(("Levene (variances égales)",
                                   f"p={p_lev:.4f}  {'✅' if p_lev>0.05 else '❌'}"))
            except Exception:
                pass
            # ANOVA / Kruskal
            try:
                f, p_anov = sp_stats.f_oneway(*valid_g.values())
                group_rows.append(("ANOVA F",
                                   f"F={f:.3f}  p={p_anov:.4f}  {'✅ Sig.' if p_anov<0.05 else '❌'}"))
            except Exception:
                pass
            try:
                h, p_kw = sp_stats.kruskal(*valid_g.values())
                group_rows.append(("Kruskal-Wallis H",
                                   f"H={h:.3f}  p={p_kw:.4f}  {'✅ Sig.' if p_kw<0.05 else '❌'}"))
            except Exception:
                pass
            # Pairwise means
            for cls in dep.classes:
                vg = groups.get(cls, np.array([]))
                if len(vg):
                    group_rows.append((f"  Cls {cls} — Moy±Std",
                                       f"{vg.mean():.4g} ± {vg.std():.4g}  (n={len(vg):,})"))

    # Build HTML
    def _row(label, val):
        return html.Tr([
            html.Td(label, style={"padding":"4px 8px","color":"#6b7a8d",
                                   "fontWeight":"600","fontSize":"11px",
                                   "whiteSpace":"nowrap","width":"52%"}),
            html.Td(val,   style={"padding":"4px 8px","color":"#1e3a5f",
                                   "fontSize":"11px","fontWeight":"500"}),
        ], style={"borderBottom":"1px solid #f5f5f5"})

    table_rows = [_row(l,v) for l,v in rows]

    children = [
        html.Div("📊 Statistiques descriptives", className="chart-card-title"),
        html.Table(html.Tbody(table_rows),
                   style={"width":"100%","borderCollapse":"collapse",
                          "fontFamily":FONT,"marginBottom":"12px",
                          "background":"#f7f8fa","borderRadius":"8px"}),
    ]
    if group_rows:
        group_table = [_row(l,v) for l,v in group_rows]
        children += [
            html.Div("🔬 Tests inter-groupes", className="chart-card-title",
                     style={"marginTop":"10px"}),
            html.Table(html.Tbody(group_table),
                       style={"width":"100%","borderCollapse":"collapse",
                              "fontFamily":FONT,"background":"#f0f4ff",
                              "borderRadius":"8px"}),
        ]
    return children


# ── helpers ───────────────────────────────────────────────────────────────────

def _kde(vals, n=200):
    if len(vals) < 3: return np.array([]), np.array([])
    try:
        kde  = sp_stats.gaussian_kde(vals, bw_method="scott")
        pad  = (vals.max()-vals.min()) * 0.1 + 1e-9
        xg   = np.linspace(vals.min()-pad, vals.max()+pad, n)
        return xg, kde(xg)
    except Exception:
        return np.array([]), np.array([])


def _alpha(hex_color, alpha):
    h = hex_color.lstrip("#")
    r,g,b = int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
    return f"rgba({r},{g},{b},{alpha})"


def _base(title=""):
    return dict(
        title=dict(text=title, font=dict(size=12, color="#1e3a5f")),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=50,r=20,t=48,b=50),
        font=dict(family=FONT, size=11),
        xaxis=dict(gridcolor=GRID, zeroline=False),
        yaxis=dict(gridcolor=GRID, zeroline=False),
        legend=dict(font=dict(size=11), bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1, bordercolor=GRID),
    )
