"""
Synthèse et Conclusions Scientifiques — rapport automatique de l'analyse.
  • Score de qualité du dataset (complétude, variance, corrélations)
  • Résumé des features (top importantes, collinéaires, à faible variance)
  • Alertes et recommandations détectées automatiquement
  • Métriques clés de l'analyse supervisée
  • Exportabilité (table récapitulative copiable)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep) -> html.Div:
    return html.Div([
        html.Div("Synthèse et Conclusions Scientifiques", className="page-title"),
        html.Div("Rapport automatique — qualité des données, alertes, recommandations.",
                 className="page-subtitle"),

        dcc.Loading(
            html.Div(id="synth-content"),
            type="dot", color="#4472c4",
        ),
    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        Output("synth-content", "children"),
        Input("synth-content", "id"),
    )
    def render(_):
        return _build_synthesis(dep)


def _build_synthesis(dep):
    df  = dep.df
    num = dep.num_features
    n   = len(df)
    p   = len(num)

    sections = []

    # ════════════════════════════════════════════════════════════════
    # 1. Dataset quality scorecard
    # ════════════════════════════════════════════════════════════════
    pct_nan     = df.isnull().mean().mean() * 100
    n_duplicates= int(df.duplicated().sum())
    pct_dup     = n_duplicates / max(n,1) * 100

    X       = df[num].fillna(df[num].median())
    variances = X.std()
    n_low_var = int((variances < variances.quantile(0.1)).sum())

    corr_mat  = X.corr()
    np.fill_diagonal(corr_mat.values, 0)
    n_high_corr = int((corr_mat.abs() > 0.9).sum().sum() // 2)

    score_nan    = max(0, 100 - pct_nan * 5)
    score_dup    = max(0, 100 - pct_dup * 10)
    score_var    = max(0, 100 - n_low_var/max(p,1)*100)
    score_corr   = max(0, 100 - n_high_corr/max(p,1)*50)
    score_size   = min(100, n / 100 * 10)
    global_score = np.mean([score_nan, score_dup, score_var, score_corr, score_size])

    # Score gauge
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=round(global_score, 1),
        title={"text": "Score Qualité Dataset", "font": {"size":15,"family":FONT}},
        delta={"reference": 80},
        gauge={
            "axis": {"range":[0,100], "tickwidth":1},
            "bar":  {"color": "#4472c4"},
            "steps": [
                {"range":[0,40],  "color":"#fde8e8"},
                {"range":[40,70], "color":"#fff3e0"},
                {"range":[70,100],"color":"#e8f5e9"},
            ],
            "threshold": {"line":{"color":"#e74c3c","width":3},
                          "thickness":0.8, "value":80},
        },
    ))
    fig_gauge.update_layout(
        height=220, paper_bgcolor="white",
        margin=dict(l=30,r=30,t=40,b=20),
        font=dict(family=FONT),
    )

    score_cards = html.Div([
        _scard("Complétude",    f"{100-pct_nan:.1f}%",
               "✅" if pct_nan<5 else "⚠️",
               f"{pct_nan:.1f}% NaN"),
        _scard("Doublons",      f"{n_duplicates}",
               "✅" if pct_dup<1 else "⚠️",
               f"{pct_dup:.1f}% des lignes"),
        _scard("Variance",      f"{p-n_low_var}/{p}",
               "✅" if n_low_var<3 else "⚠️",
               f"{n_low_var} features faible var."),
        _scard("Collinéarité",  f"{n_high_corr}",
               "✅" if n_high_corr==0 else "⚠️",
               "paires |r|>0.9"),
        _scard("Taille (n)",    f"{n:,}",
               "✅" if n>=500 else "⚠️",
               f"{p} features"),
    ], className="metric-cards")

    sections.append(html.Div([
        html.Div("🏆 Qualité du Dataset", className="chart-card-title"),
        html.Div([
            html.Div([dcc.Graph(figure=fig_gauge, config={"displayModeBar":False},
                                style={"height":"220px"})],
                     style={"flex":"1","minWidth":"280px"}),
            html.Div(score_cards, style={"flex":"3"}),
        ], style={"display":"flex","gap":"16px","alignItems":"flex-start","flexWrap":"wrap"}),
    ], className="chart-card", style={"marginBottom":"16px"}))

    # ════════════════════════════════════════════════════════════════
    # 2. Alerts
    # ════════════════════════════════════════════════════════════════
    alerts = []
    if pct_nan > 20:
        alerts.append(("error", f"🔴 {pct_nan:.1f}% de valeurs manquantes — imputation recommandée"))
    elif pct_nan > 5:
        alerts.append(("warn", f"🟡 {pct_nan:.1f}% de valeurs manquantes — surveiller l'impact"))
    if n_duplicates > 0:
        alerts.append(("warn", f"🟡 {n_duplicates} lignes dupliquées — dédupliquer avant modélisation"))
    if n_high_corr > 0:
        alerts.append(("warn", f"🟡 {n_high_corr} paires avec |r|>0.9 — risque de multicolinéarité"))
    if n_low_var > 0:
        alerts.append(("warn", f"🟡 {n_low_var} features à très faible variance — candidats à suppression"))
    if n < 100:
        alerts.append(("error", f"🔴 Seulement {n} observations — risque de sur-apprentissage élevé"))
    elif n < 500:
        alerts.append(("warn", f"🟡 {n} observations — dataset petit, utiliser CV k-fold"))
    if p > n:
        alerts.append(("error", f"🔴 Plus de features ({p}) que d'observations ({n}) — p >> n !"))

    if dep.supervised and dep.is_classification:
        y = dep.df[dep.target_name]
        cls_cnt = y.value_counts()
        imbalance = cls_cnt.max() / max(cls_cnt.min(), 1)
        if imbalance > 5:
            alerts.append(("error",
                f"🔴 Déséquilibre de classes x{imbalance:.1f} — SMOTE / class_weight recommandé"))
        elif imbalance > 2:
            alerts.append(("warn",
                f"🟡 Déséquilibre modéré x{imbalance:.1f} — envisager rééchantillonnage"))

    if not alerts:
        alerts.append(("ok", "✅ Aucune alerte critique détectée — dataset de bonne qualité"))

    alert_els = []
    COLOR_MAP = {"error":"#fde8e8","warn":"#fff8e1","ok":"#e8f5e9"}
    BORDER_MAP= {"error":"#e74c3c","warn":"#f39c12","ok":"#27ae60"}
    for kind, msg in alerts:
        alert_els.append(html.Div(msg, style={
            "background": COLOR_MAP[kind],
            "borderLeft": f"4px solid {BORDER_MAP[kind]}",
            "padding": "10px 14px",
            "borderRadius": "0 8px 8px 0",
            "marginBottom": "6px",
            "fontSize": "12.5px",
            "fontFamily": FONT,
            "color": "#1e3a5f",
        }))

    sections.append(html.Div([
        html.Div("⚠️ Alertes & Recommandations", className="chart-card-title"),
        html.Div(alert_els),
    ], className="chart-card", style={"marginBottom":"16px"}))

    # ════════════════════════════════════════════════════════════════
    # 3. Feature summary radar + table
    # ════════════════════════════════════════════════════════════════
    feat_stats = []
    y_num = None
    if dep.supervised:
        y_s = dep.df[dep.target_name]
        if not dep.is_classification:
            y_num = y_s.fillna(y_s.median())

    for col in num[:25]:
        v    = df[col].dropna().values
        pnan = df[col].isnull().mean()
        cv   = v.std()/abs(v.mean()) if abs(v.mean()) > 1e-9 else 0
        skw  = float(sp_stats.skew(v)) if len(v)>3 else 0
        n_out = int(np.sum(np.abs(v-v.mean())>3*v.std())) if v.std()>0 else 0
        corr_t = 0.0
        if y_num is not None and len(v) > 5:
            idx = df[col].dropna().index.intersection(y_num.dropna().index)
            if len(idx) > 5:
                corr_t = abs(float(sp_stats.pearsonr(df.loc[idx,col], y_num.loc[idx])[0]))
        feat_stats.append({
            "Feature": col,
            "% NaN":   f"{pnan:.1%}",
            "CV":      f"{cv:.3f}",
            "Skewness":f"{skw:+.3f}",
            "Outliers":f"{n_out}",
            "|r| target": f"{corr_t:.3f}" if y_num is not None else "—",
            "⚠️": ("NaN" if pnan>0.1 else "") +
                  (" LoVar" if cv<0.05 else "") +
                  (" Skew" if abs(skw)>2 else ""),
        })

    df_feat = pd.DataFrame(feat_stats)

    th_style = {"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
                "fontWeight":"700","fontSize":"10px","textTransform":"uppercase",
                "letterSpacing":".3px","borderBottom":"2px solid #e0e4ea",
                "textAlign":"left","whiteSpace":"nowrap"}
    td_style = {"padding":"4px 8px","fontSize":"11px","color":"#374151","whiteSpace":"nowrap"}

    header = html.Tr([html.Th(c, style=th_style) for c in df_feat.columns])
    body   = []
    for _, row in df_feat.iterrows():
        has_warn = bool(row["⚠️"].strip())
        body.append(html.Tr([
            html.Td(row["Feature"],      style={**td_style,"fontWeight":"700","color":"#1e3a5f"}),
            html.Td(row["% NaN"],        style={**td_style, "color":"#e74c3c" if float(row["% NaN"].strip("%"))>10 else "#374151"}),
            html.Td(row["CV"],           style=td_style),
            html.Td(row["Skewness"],     style={**td_style,"color":"#e07b39" if abs(float(row["Skewness"]))>2 else "#374151"}),
            html.Td(row["Outliers"],     style=td_style),
            html.Td(row["|r| target"],   style={**td_style,"fontWeight":"700","color":"#4472c4"}),
            html.Td(row["⚠️"] or "✅",  style={**td_style,"color":"#e07b39" if has_warn else "#27ae60",
                                                "fontWeight":"700","fontSize":"10px"}),
        ], style={"borderBottom":"1px solid #f0f4f8",
                  "background":"#fffbf0" if has_warn else "white"}))

    feat_table = html.Div(
        html.Table([html.Thead(header), html.Tbody(body)],
                   style={"width":"100%","borderCollapse":"collapse",
                          "fontFamily":FONT,"fontSize":"12px"}),
        style={"overflowX":"auto","maxHeight":"420px","overflowY":"auto"},
    )

    sections.append(html.Div([
        html.Div("📋 Récapitulatif des Features", className="chart-card-title"),
        feat_table,
    ], className="chart-card", style={"marginBottom":"16px"}))

    # ════════════════════════════════════════════════════════════════
    # 4. Class balance (if supervised classification)
    # ════════════════════════════════════════════════════════════════
    if dep.supervised and dep.is_classification:
        y = dep.df[dep.target_name]
        cls_cnts = y.value_counts()
        fig_cls = go.Figure(go.Bar(
            x=[str(c) for c in cls_cnts.index],
            y=cls_cnts.values,
            marker=dict(color=PAL[:len(cls_cnts)],
                        line=dict(width=0.5, color="white")),
            text=[f"{v:,}\n({v/n:.1%})" for v in cls_cnts.values],
            textposition="outside",
        ))
        fig_cls.add_hline(y=n/dep.n_classes, line_dash="dash", line_color="#6b7a8d",
                           annotation_text="Équilibre parfait",
                           annotation_font_size=9)
        fig_cls.update_layout(
            title=f"Équilibre des classes — {dep.target_name}",
            xaxis=dict(title="Classe"),
            yaxis=dict(title="Count", gridcolor=GRID),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=50,b=50),
            font=dict(family=FONT, size=11),
            height=280,
        )
        sections.append(html.Div([
            html.Div("⚖️ Équilibre des Classes", className="chart-card-title"),
            dcc.Graph(figure=fig_cls, config={"displayModeBar":False},
                      style={"height":"280px"}),
        ], className="chart-card", style={"marginBottom":"16px"}))

    # ════════════════════════════════════════════════════════════════
    # 5. Summary text conclusions
    # ════════════════════════════════════════════════════════════════
    top_corr_pairs = []
    for i in range(len(num)):
        for j in range(i+1, len(num)):
            r = abs(corr_mat.iloc[i,j])
            if r > 0.7:
                top_corr_pairs.append((num[i], num[j], round(float(r),3)))
    top_corr_pairs.sort(key=lambda x: -x[2])

    conclusions = []
    conclusions.append(f"• Le dataset contient **{n:,} observations** et **{p} features numériques**.")
    if pct_nan > 0:
        conclusions.append(f"• Taux global de NaN : **{pct_nan:.1f}%** — "
                           f"{'attention requise' if pct_nan>5 else 'acceptable'}.")
    if top_corr_pairs:
        pair_txt = ", ".join(f"{a}↔{b} (r={r})" for a,b,r in top_corr_pairs[:3])
        conclusions.append(f"• **{len(top_corr_pairs)} paire(s) très corrélées** (|r|>0.7) : {pair_txt}.")
    if dep.supervised:
        mode = "Classification" if dep.is_classification else "Régression"
        conclusions.append(f"• Mode supervisé — **{mode}** sur '{dep.target_name}' "
                           f"({dep.n_classes} classes)." if dep.is_classification else
                           f"• Mode supervisé — **{mode}** sur '{dep.target_name}'.")
    conclusions.append(f"• Score de qualité global : **{global_score:.1f}/100**.")

    conc_els = [html.P(c.replace("**",""), style={"fontSize":"13px","margin":"4px 0",
                                                   "color":"#374151","lineHeight":"1.7"})
                for c in conclusions]
    sections.append(html.Div([
        html.Div("💡 Conclusions", className="chart-card-title"),
        html.Div(conc_els),
    ], className="chart-card"))

    return html.Div(sections)


def _scard(label, value, icon, sub):
    return html.Div([
        html.Div(f"{icon} {label}", style={"fontSize":"11px","fontWeight":"700",
                                            "color":"#6b7a8d","marginBottom":"2px"}),
        html.Div(value, style={"fontSize":"22px","fontWeight":"800","color":"#1e3a5f",
                                "lineHeight":"1.2"}),
        html.Div(sub, style={"fontSize":"10.5px","color":"#9aa5b4","marginTop":"2px"}),
    ], className="metric-card")
