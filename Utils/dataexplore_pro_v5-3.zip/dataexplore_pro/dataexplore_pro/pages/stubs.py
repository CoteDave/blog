"""
Stub pages for sections that show a "coming soon" placeholder.
"""

from __future__ import annotations
from dash import html


_STUBS = {
    "corr_clusters": ("Clusters de Corrélation", "Regroupement des variables selon leur corrélation."),
    "causal":        ("Découverte Causale",        "Inférence causale automatisée (PC algorithm, NOTEARS)."),
    "posthoc":       ("Analyses Post Hoc",         "Tests post-hoc après ANOVA : Tukey HSD, Bonferroni, etc."),
    "anova":         ("ANOVA Fonctionnelle",        "ANOVA sur courbes et données fonctionnelles."),
    "synthesis":     ("Synthèse et Conclusions Scientifiques",
                      "Rapport automatique : résumé statistique, visualisations clés, recommandations."),
}


def layout(dep, page_id: str = "synthesis") -> html.Div:
    info = _STUBS.get(page_id, ("Page", ""))
    title, desc = info

    return html.Div([
        html.Div(title, className="page-title"),
        html.Div([
            html.Div("🔬", className="empty-state-icon"),
            html.Div(f"Module « {title} » — disponible dans la prochaine version.",
                     style={"fontWeight": "600", "fontSize": "15px", "color": "#1e3a5f"}),
            html.Div(desc, style={"marginTop": "8px", "color": "#6b7a8d", "fontSize": "13px"}),
        ], className="empty-state"),
    ], className="page-card")
