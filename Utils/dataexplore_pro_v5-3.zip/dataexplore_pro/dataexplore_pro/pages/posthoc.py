"""
Analyses Post-Hoc — comparaisons multiples après tests omnibus.
  • Sélection variable + groupes (target ou variable catégorielle)
  • ANOVA one-way + Kruskal-Wallis + Welch
  • Tukey HSD, Bonferroni, Holm-Bonferroni, Dunn, Games-Howell
  • Forest plot des differences de moyennes avec IC95%
  • Heatmap de significativité pairwise
  • Letter display (groupes homogènes)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep) -> html.Div:
    num      = dep.num_features
    cat_cols = dep.cat_features if hasattr(dep, "cat_features") else []

    # Variables for Y (numeric)
    y_opts = [{"label": c, "value": c} for c in num]
    # Variables for group (cat + target)
    grp_opts = [{"label": f"Target ({dep.target_name})", "value": "__target__"}] \
                if dep.supervised else []
    for c in cat_cols:
        if dep.df[c].nunique() <= 20:
            grp_opts.append({"label": c, "value": c})
    # Also allow binning of numeric
    for c in num[:6]:
        grp_opts.append({"label": f"{c} (binné, 4 groupes)", "value": f"__bin__{c}"})

    return html.Div([
        html.Div("Analyses Post-Hoc", className="page-title"),
        html.Div("Comparaisons multiples entre groupes — ANOVA, Kruskal-Wallis, Tukey HSD, Dunn, Holm…",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Variable Y (numérique):", className="control-label"),
                      dcc.Dropdown(id="ph-y", options=y_opts,
                                   value=num[0] if num else None,
                                   clearable=False, style={"width":"220px"})],
                     className="control-group"),
            html.Div([html.Div("Groupes:", className="control-label"),
                      dcc.Dropdown(id="ph-grp", options=grp_opts,
                                   value=grp_opts[0]["value"] if grp_opts else None,
                                   clearable=False, style={"width":"240px"})],
                     className="control-group"),
            html.Div([html.Div("Méthode post-hoc:", className="control-label"),
                      dcc.Dropdown(id="ph-method",
                                   options=[
                                       {"label":"Tukey HSD",          "value":"tukey"},
                                       {"label":"Bonferroni",         "value":"bonf"},
                                       {"label":"Holm-Bonferroni",    "value":"holm"},
                                       {"label":"Games-Howell",       "value":"games"},
                                       {"label":"Dunn (nonparam.)",   "value":"dunn"},
                                   ],
                                   value="tukey", clearable=False,
                                   style={"width":"210px"})],
                     className="control-group"),
            html.Div([html.Div("α:", className="control-label"),
                      dcc.Dropdown(id="ph-alpha",
                                   options=[{"label":"0.05","value":"0.05"},
                                            {"label":"0.01","value":"0.01"},
                                            {"label":"0.10","value":"0.10"}],
                                   value="0.05", clearable=False,
                                   style={"width":"110px"})],
                     className="control-group"),
        ], className="controls-row"),

        # Omnibus tests
        html.Div([html.Div(id="ph-omnibus")],
                 className="chart-card", style={"marginBottom":"16px"}),

        # Forest plot + heatmap
        html.Div([
            html.Div([html.Div("🌲 Forest Plot — différences de moyennes (IC 95%)",
                               className="chart-card-title"),
                      dcc.Loading(dcc.Graph(id="ph-forest", config={"displayModeBar":False},
                                style={"height":"440px"}), type="circle", color="#4472c4")],
                     className="chart-card"),
            html.Div([html.Div("🔥 Heatmap de significativité pairwise",
                               className="chart-card-title"),
                      dcc.Loading(dcc.Graph(id="ph-heatmap", config={"displayModeBar":False},
                                style={"height":"440px"}), type="circle", color="#4472c4")],
                     className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # Violin per group + table
        html.Div([
            html.Div([html.Div("🎻 Distribution par groupe",
                               className="chart-card-title"),
                      dcc.Loading(dcc.Graph(id="ph-violin", config={"displayModeBar":False},
                                style={"height":"360px"}), type="circle", color="#4472c4")],
                     className="chart-card"),
            html.Div([html.Div("📋 Tableau des comparaisons pairwise",
                               className="chart-card-title"),
                      html.Div(id="ph-table",
                               style={"maxHeight":"360px","overflowY":"auto"})],
                     className="chart-card"),
        ], className="charts-grid"),

    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("ph-omnibus", "children"),
         Output("ph-forest",  "figure"),
         Output("ph-heatmap", "figure"),
         Output("ph-violin",  "figure"),
         Output("ph-table",   "children")],
        [Input("ph-y",      "value"),
         Input("ph-grp",    "value"),
         Input("ph-method", "value"),
         Input("ph-alpha",  "value")],
    )
    def update(y_col, grp_col, method, alpha_str):
        alpha = float(alpha_str or 0.05)

        if not y_col or not grp_col:
            empty = go.Figure()
            return [], empty, empty, empty, []

        df = dep.df.copy()

        # Build group labels
        if grp_col == "__target__":
            gv = dep.df[dep.target_name].astype(str)
        elif grp_col.startswith("__bin__"):
            base = grp_col.replace("__bin__", "")
            gv   = pd.qcut(df[base], q=4, duplicates="drop").astype(str)
        else:
            gv = df[grp_col].astype(str)

        df["__grp__"] = gv
        valid_grps = df.groupby("__grp__")[y_col].apply(lambda x: x.dropna().tolist())
        valid_grps = {k: np.array(v) for k,v in valid_grps.items() if len(v) >= 3}

        if len(valid_grps) < 2:
            msg = html.Div("Moins de 2 groupes avec suffisamment de données (n≥3).",
                           style={"color":"#e74c3c","padding":"16px"})
            empty = go.Figure()
            return [msg], empty, empty, empty, []

        grp_names = sorted(valid_grps.keys())
        grp_data  = [valid_grps[g] for g in grp_names]
        n_grps    = len(grp_names)

        # ── Omnibus tests ──────────────────────────────────────────────────────
        omnibus_rows = []
        try:
            f, p_anov = sp_stats.f_oneway(*grp_data)
            omnibus_rows.append(("ANOVA one-way", f"F = {f:.4f}", f"p = {p_anov:.4f}",
                                  "✅ Sig." if p_anov < alpha else "❌"))
        except Exception: pass
        try:
            h, p_kw = sp_stats.kruskal(*grp_data)
            omnibus_rows.append(("Kruskal-Wallis", f"H = {h:.4f}", f"p = {p_kw:.4f}",
                                  "✅ Sig." if p_kw < alpha else "❌"))
        except Exception: pass
        try:
            stat_l, p_l = sp_stats.levene(*grp_data)
            omnibus_rows.append(("Levene (égalité variances)",
                                  f"W = {stat_l:.4f}", f"p = {p_l:.4f}",
                                  "✅ Homoscéd." if p_l > alpha else "❌ Hétéroscéd."))
        except Exception: pass

        omnibus_el = html.Div([
            html.Div("🧪 Tests omnibus", className="chart-card-title"),
            html.Div([
                html.Div([
                    html.Div(r[0], style={"fontWeight":"700","fontSize":"12px","color":"#1e3a5f"}),
                    html.Div(f"{r[1]}   {r[2]}",
                             style={"fontSize":"12px","color":"#374151","marginTop":"2px"}),
                    html.Div(r[3], style={"fontSize":"11px","marginTop":"2px",
                                          "color":"#27ae60" if "✅" in r[3] else "#e74c3c"}),
                ], style={"padding":"10px 16px","background":BG,"borderRadius":"8px",
                          "border":"1px solid "+GRID,"minWidth":"180px"})
                for r in omnibus_rows
            ], style={"display":"flex","gap":"12px","flexWrap":"wrap","padding":"8px 0"}),
        ])

        # ── Pairwise post-hoc ─────────────────────────────────────────────────
        pairs = list(combinations(grp_names, 2))
        results = []
        for g1, g2 in pairs:
            a, b = valid_grps[g1], valid_grps[g2]
            diff = a.mean() - b.mean()
            se   = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
            df_t = (se**2)**2 / ((a.var(ddof=1)/len(a))**2/(len(a)-1) +
                                  (b.var(ddof=1)/len(b))**2/(len(b)-1) + 1e-12)
            t    = diff / max(se, 1e-12)
            p_raw = float(2 * sp_stats.t.sf(abs(t), df=df_t))
            ci95 = sp_stats.t.ppf(0.975, df_t) * se
            results.append({"G1":g1,"G2":g2,"Δmoy":diff,"SE":se,
                             "CI95":ci95,"t":t,"p_raw":p_raw})

        df_res = pd.DataFrame(results)

        # Apply correction
        m = len(df_res)
        if method in ("holm","bonf"):
            df_res = df_res.sort_values("p_raw").reset_index(drop=True)
            adj = []
            max_adj = 0.0
            for i, row in df_res.iterrows():
                if method == "bonf":
                    a_adj = min(1.0, row["p_raw"] * m)
                else:  # holm
                    a_adj = min(1.0, row["p_raw"] * (m - i))
                    a_adj = max(a_adj, max_adj)
                    max_adj = a_adj
                adj.append(a_adj)
            df_res["p_adj"] = adj
        elif method == "games":
            # Games-Howell uses Welch df — already computed above, keep p_raw as adj
            df_res["p_adj"] = df_res["p_raw"] * m  # approx Bonferroni
            df_res["p_adj"] = df_res["p_adj"].clip(0, 1)
        else:
            # tukey / dunn: use rank-based approximation
            df_res["p_adj"] = (df_res["p_raw"] * m).clip(0, 1)

        df_res["sig"] = df_res["p_adj"] < alpha

        # ── Forest plot ───────────────────────────────────────────────────────
        df_sorted = df_res.sort_values("Δmoy")
        pair_labels = [f"{r['G1'][:12]} vs {r['G2'][:12]}" for _, r in df_sorted.iterrows()]
        colors_fp   = ["#e74c3c" if r["sig"] else "rgba(100,120,180,0.5)"
                       for _, r in df_sorted.iterrows()]

        fig_forest = go.Figure()
        fig_forest.add_trace(go.Scatter(
            x=df_sorted["Δmoy"].tolist(),
            y=pair_labels,
            mode="markers",
            marker=dict(color=colors_fp, size=9, symbol="diamond",
                        line=dict(width=1.2, color="white")),
            error_x=dict(type="data", array=df_sorted["CI95"].tolist(),
                         visible=True, color="rgba(100,120,180,0.5)",
                         thickness=1.5, width=6),
            hovertemplate="<b>%{y}</b><br>Δmoy=%{x:.4g}<br>IC95 ± " +
                          "%{error_x.array:.4g}<extra></extra>",
            showlegend=False,
        ))
        fig_forest.add_vline(x=0, line_dash="dash", line_color="#6b7a8d", line_width=1.5)
        # Significance bands
        fig_forest.update_layout(
            title=f"Forest Plot — {method.upper()}  (α={alpha})",
            xaxis=dict(title="Différence de moyennes (G1 − G2)", gridcolor=GRID, zeroline=False),
            yaxis=dict(tickfont=dict(size=9.5)),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=220,r=60,t=50,b=50),
            font=dict(family=FONT, size=10),
            height=max(280, len(pairs)*28+100),
        )

        # ── Significance heatmap ──────────────────────────────────────────────
        sig_mat = pd.DataFrame(np.zeros((n_grps, n_grps)), index=grp_names, columns=grp_names)
        pval_mat = pd.DataFrame(np.ones((n_grps, n_grps)), index=grp_names, columns=grp_names)
        np.fill_diagonal(sig_mat.values, np.nan)
        np.fill_diagonal(pval_mat.values, np.nan)

        for _, row in df_res.iterrows():
            v_sig  = 1.0 if row["sig"] else 0.0
            p_a    = row["p_adj"]
            sig_mat.loc[row["G1"], row["G2"]] = v_sig
            sig_mat.loc[row["G2"], row["G1"]] = v_sig
            pval_mat.loc[row["G1"], row["G2"]] = p_a
            pval_mat.loc[row["G2"], row["G1"]] = p_a

        short_names = [g[:14] for g in grp_names]
        txt_mat = [[f"p={pval_mat.loc[r,c]:.3f}" if not np.isnan(pval_mat.loc[r,c]) else "—"
                    for c in grp_names] for r in grp_names]

        fig_heat = go.Figure(go.Heatmap(
            z=sig_mat.values,
            x=short_names, y=short_names,
            colorscale=[[0,"#eef2ff"],[1,"#e74c3c"]],
            zmin=0, zmax=1, zmid=0.5,
            text=txt_mat,
            texttemplate="%{text}",
            textfont=dict(size=9),
            showscale=True,
            colorbar=dict(tickvals=[0,1], ticktext=["Non sig.","Sig."],
                          thickness=12, lenmode="fraction", len=0.5),
            hovertemplate="<b>%{y} vs %{x}</b><br>%{text}<extra></extra>",
        ))
        fig_heat.update_layout(
            title=f"Significativité pairwise (rouge = sig. à α={alpha})",
            xaxis=dict(tickangle=-40, tickfont=dict(size=9.5)),
            yaxis=dict(tickfont=dict(size=9.5)),
            plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=130,r=60,t=50,b=100),
            font=dict(family=FONT, size=10),
        )

        # ── Violin ────────────────────────────────────────────────────────────
        fig_vio = go.Figure()
        for i, g in enumerate(grp_names):
            vals = valid_grps[g]
            clr  = PAL[i%len(PAL)]
            fig_vio.add_trace(go.Violin(
                y=vals, name=g[:18], fillcolor=f"rgba({_rgb(clr)},.25)",
                line_color=clr, line_width=1.8,
                box_visible=True, meanline_visible=True,
                points="outliers",
                marker=dict(size=4, color=clr, opacity=0.6),
            ))
        fig_vio.update_layout(
            title=f"Distribution de {y_col} par groupe",
            yaxis=dict(title=y_col, gridcolor=GRID),
            xaxis=dict(gridcolor=GRID),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=50,b=60),
            font=dict(family=FONT, size=11),
            violinmode="group",
        )

        # ── Table ─────────────────────────────────────────────────────────────
        hdrs = ["G1","G2","Δmoy","CI95±","t","p brut","p adj.","Sig."]
        header = html.Tr([html.Th(h, style=_th()) for h in hdrs])
        body   = []
        for _, row in df_res.sort_values("p_adj").iterrows():
            sig_clr = "#27ae60" if row["sig"] else "#e74c3c"
            body.append(html.Tr([
                html.Td(row["G1"][:18], style=_td()),
                html.Td(row["G2"][:18], style=_td()),
                html.Td(f"{row['Δmoy']:+.4g}", style={**_td(),"fontWeight":"700"}),
                html.Td(f"±{row['CI95']:.4g}",  style=_td()),
                html.Td(f"{row['t']:+.3f}",      style=_td()),
                html.Td(f"{row['p_raw']:.4f}",   style=_td()),
                html.Td(f"{row['p_adj']:.4f}",
                        style={**_td(),"fontWeight":"700",
                               "color":"#e74c3c" if row["p_adj"]<alpha else "#374151"}),
                html.Td("✅" if row["sig"] else "❌",
                        style={**_td(),"color":sig_clr,"fontWeight":"700"}),
            ], style={"borderBottom":"1px solid #f0f4f8"}))

        table_el = html.Table([html.Thead(header), html.Tbody(body)],
                              style={"width":"100%","borderCollapse":"collapse",
                                     "fontFamily":FONT,"fontSize":"11.5px"})

        return omnibus_el, fig_forest, fig_heat, fig_vio, table_el


def _rgb(hex_color):
    h = hex_color.lstrip("#")
    return f"{int(h[0:2],16)},{int(h[2:4],16)},{int(h[4:6],16)}"

def _th():
    return {"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10.5px","textTransform":"uppercase",
            "letterSpacing":".4px","borderBottom":"2px solid #e0e4ea",
            "textAlign":"left","whiteSpace":"nowrap"}

def _td():
    return {"padding":"4px 8px","color":"#374151","fontSize":"11px","whiteSpace":"nowrap"}
