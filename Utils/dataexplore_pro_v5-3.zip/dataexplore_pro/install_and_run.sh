#!/usr/bin/env bash
# ============================================================
#  DataExplore Pro — Install & Launch
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

DATASET="${1:-breast_cancer}"
PORT="${2:-8050}"

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║       DataExplore Pro Setup          ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "  ❌  Python 3 not found. Please install Python 3.8+."
    exit 1
fi

PY_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "  ✓  Python $PY_VERSION found"

# Install dependencies
echo "  📦  Installing dependencies …"
pip install -q -r requirements.txt

echo "  ✓  Dependencies installed"
echo ""
echo "  🚀  Launching dashboard with dataset: $DATASET"
echo "      Port: $PORT"
echo ""

python3 run_example.py --dataset "$DATASET" --port "$PORT"
