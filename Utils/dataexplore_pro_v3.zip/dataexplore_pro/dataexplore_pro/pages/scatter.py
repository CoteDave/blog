"""
Analyse Bivariée — Diagrammes de Dispersion
Scatter plot with lasso selection, convex hull, and rich stats panel.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output, no_update
import plotly.graph_objects as go
from scipy.spatial import ConvexHull
from scipy import stats as sp_stats

CLASS_PALETTE = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
PLOT_BG   = "#f7f8fa"
GRID_CLR  = "#e0e4ea"


# ── hull helper ──────────────────────────────────────────────────────────────
def _convex_hull_trace(x, y, color, name="", opacity=0.12):
    pts = np.column_stack([x, y])
    pts = pts[~np.isnan(pts).any(axis=1)]
    if len(pts) < 3:
        return None
    try:
        hull = ConvexHull(pts)
        hx = np.append(pts[hull.vertices, 0], pts[hull.vertices[0], 0])
        hy = np.append(pts[hull.vertices, 1], pts[hull.vertices[0], 1])
        return go.Scatter(
            x=hx, y=hy, fill="toself",
            fillcolor=color.replace(")", f",{opacity})").replace("rgb(", "rgba(") if "rgb" in color else _hex_alpha(color, opacity),
            line=dict(color=color, width=1.5, dash="dot"),
            mode="lines", name=name, showlegend=False, hoverinfo="skip",
        )
    except Exception:
        return None


def _hex_alpha(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def _clr(dep, cls_val) -> str:
    idx = dep.classes.index(cls_val) if cls_val in dep.classes else 0
    return CLASS_PALETTE[idx % len(CLASS_PALETTE)]


# ── layout ───────────────────────────────────────────────────────────────────
def layout(dep) -> html.Div:
    num = dep.num_features
    x_def = num[0] if num else None
    y_def = num[1] if len(num) > 1 else x_def

    tgt_opts = [{"label": "Tout", "value": "__all__"}]
    if dep.supervised:
        for c in dep.classes:
            tgt_opts.append({"label": f"Classe {c}", "value": str(c)})

    col_opts = [{"label": c, "value": c} for c in num]

    return html.Div([
        html.Div("Analyse Bivariée — Diagrammes de Dispersion", className="page-title"),

        # controls
        html.Div([
            html.Div([html.Div("Variable X:", className="control-label"),
                      dcc.Dropdown(id="sc-x", options=col_opts, value=x_def, clearable=False)], className="control-group"),
            html.Div([html.Div("Variable Y:", className="control-label"),
                      dcc.Dropdown(id="sc-y", options=col_opts, value=y_def, clearable=False)], className="control-group"),
            html.Div([html.Div("Filtrer Target:", className="control-label"),
                      dcc.Dropdown(id="sc-target", options=tgt_opts, value="__all__", clearable=False)],
                     className="control-group", style={"maxWidth":"240px"}),
            html.Div([html.Div("Hull par classe:", className="control-label"),
                      dcc.Dropdown(id="sc-hull",
                                   options=[{"label":"Aucun","value":"none"},
                                            {"label":"Convexe","value":"convex"}],
                                   value="convex" if dep.supervised else "none",
                                   clearable=False)],
                     className="control-group", style={"maxWidth":"200px"}),
        ], className="controls-row"),

        # main layout: scatter | stats panel
        html.Div([
            html.Div([
                dcc.Graph(id="sc-graph",
                          config={"displayModeBar":True,
                                  "modeBarButtonsToAdd":["lasso2d","select2d"],
                                  "scrollZoom":True},
                          style={"height":"530px"}),
            ]),
            html.Div([
                html.Div(id="sc-panel"),
            ], className="stats-panel", style={"overflowY":"auto","maxHeight":"560px"}),
        ], className="scatter-layout"),
    ], className="page-card")


# ── callbacks ────────────────────────────────────────────────────────────────
def register_callbacks(app, dep) -> None:

    @app.callback(
        Output("sc-graph", "figure"),
        [Input("sc-x","value"), Input("sc-y","value"),
         Input("sc-target","value"), Input("sc-hull","value")],
    )
    def update_scatter(xc, yc, tgt_flt, hull_mode):
        if not xc or not yc:
            return go.Figure()
        df = dep.df.copy()
        if tgt_flt != "__all__" and dep.supervised:
            try:
                df = df[df[dep.target_name] == type(dep.classes[0])(tgt_flt)]
            except Exception:
                pass

        fig = go.Figure()

        if dep.supervised:
            for cls in dep.classes:
                mask = df[dep.target_name] == cls
                sub  = df[mask]
                clr  = _clr(dep, cls)
                fig.add_trace(go.Scatter(
                    x=sub[xc], y=sub[yc], mode="markers",
                    name=f"Classe {cls}",
                    marker=dict(color=clr, size=8, opacity=0.82,
                                line=dict(width=0.6, color="rgba(255,255,255,.6)")),
                    customdata=sub[dep.target_name],
                    hovertemplate=f"<b>Classe %{{customdata}}</b><br>{xc}: %{{x:.2f}}<br>{yc}: %{{y:,.1f}}<extra></extra>",
                ))
                if hull_mode == "convex" and mask.sum() >= 3:
                    h = _convex_hull_trace(sub[xc].values, sub[yc].values, clr, f"Hull {cls}")
                    if h:
                        fig.add_trace(h)
        else:
            fig.add_trace(go.Scatter(
                x=df[xc], y=df[yc], mode="markers",
                marker=dict(color="#4472c4", size=8, opacity=0.8,
                            line=dict(width=0.5, color="rgba(255,255,255,.6)")),
                hovertemplate=f"{xc}: %{{x:.2f}}<br>{yc}: %{{y:,.1f}}<extra></extra>",
            ))

        fig.update_layout(
            dragmode="lasso",
            plot_bgcolor=PLOT_BG, paper_bgcolor="#fff",
            margin=dict(l=54, r=16, t=20, b=54),
            xaxis=dict(title=xc, gridcolor=GRID_CLR, zeroline=False, tickfont=dict(size=11)),
            yaxis=dict(title=yc, gridcolor=GRID_CLR, zeroline=False, tickfont=dict(size=11)),
            legend=dict(font=dict(size=12), bgcolor="rgba(255,255,255,.9)",
                        borderwidth=1, bordercolor=GRID_CLR),
            font=dict(family="Plus Jakarta Sans, sans-serif"),
            hoverlabel=dict(bgcolor="#1e3a5f", font_size=12, font_color="white",
                            bordercolor="#1e3a5f"),
            uirevision="scatter",
        )
        return fig

    # ── lasso → full stats panel ──────────────────────────────────────────

    @app.callback(
        Output("sc-panel", "children"),
        [Input("sc-graph", "selectedData"),
         Input("sc-x", "value"), Input("sc-y", "value")],
    )
    def update_panel(sel, xc, yc):
        df_all = dep.df
        df_all = df_all.copy()

        # resolve selection
        if sel and sel.get("points"):
            pts = sel["points"]
            idxs = []
            for p in pts:
                if "pointIndex" in p:
                    idxs.append(p["pointIndex"])
                elif "text" in p:
                    try: idxs.append(int(p["text"]))
                    except: pass
            idxs = list(set(idxs))
        else:
            idxs = None

        sel_df  = df_all.iloc[idxs] if idxs else df_all
        rest_df = df_all.drop(index=sel_df.index) if idxs and len(idxs) < len(df_all) else None

        is_lasso = idxs is not None and len(idxs) < len(df_all)
        title = f"Sélection Lasso — {len(sel_df):,} pts" if is_lasso else f"Global — {len(df_all):,} pts"

        panel = [html.Div(title, className="stats-panel-title")]

        # ── Basic stats ──────────────────────────────────────────────────
        rows = [_stat_row("N points", f"{len(sel_df):,}")]
        if xc:
            rows.append(_stat_row(f"Moy. {xc}", f"{sel_df[xc].mean():.3g}"))
        if yc and yc != xc:
            rows.append(_stat_row(f"Moy. {yc}", f"{sel_df[yc].mean():.3g}"))

        if dep.supervised and dep.is_classification:
            cls1 = dep.classes[-1]
            rate = (sel_df[dep.target_name] == cls1).mean()
            rows.append(_stat_row(f"Taux Cls {cls1}", f"{rate:.1%}",
                                  color="#e07b39" if rate > 0.5 else "#4472c4"))

        panel.append(html.Div(rows, style={"marginBottom":"14px"}))

        # ── Target proportion chart ──────────────────────────────────────
        if dep.supervised and dep.is_classification:
            panel.append(_target_proportion_chart(dep, sel_df, rest_df, is_lasso))

        # ── Statistical tests (if lasso active) ─────────────────────────
        if is_lasso and rest_df is not None and len(rest_df) >= 5 and len(sel_df) >= 5:
            panel.append(_stat_tests_block(dep, sel_df, rest_df, xc, yc))

        # ── Top feature diffs ────────────────────────────────────────────
        if is_lasso and rest_df is not None and len(rest_df) >= 3:
            panel.append(_feature_diff_chart(dep, sel_df, rest_df))

        # ── Histogram of X in selection ──────────────────────────────────
        if xc:
            panel.append(_mini_hist(sel_df, xc, f"Distribution {xc}"))

        if not is_lasso:
            panel.append(html.Div(
                "← Utilisez le lasso pour sélectionner des points",
                style={"fontSize":"11.5px","color":"#6b7a8d","marginTop":"10px","fontStyle":"italic"}
            ))

        return panel


# ── panel component builders ─────────────────────────────────────────────────

def _stat_row(label, value, color=None):
    return html.Div([
        html.Span(label, className="stat-label"),
        html.Span(value, className="stat-value",
                  style={"color": color} if color else {}),
    ], className="stat-row")


def _target_proportion_chart(dep, sel_df, rest_df, is_lasso):
    classes = dep.classes
    pal     = CLASS_PALETTE

    sel_counts  = [(sel_df[dep.target_name] == c).sum()  for c in classes]
    sel_pcts    = [n / len(sel_df) * 100 if len(sel_df) else 0  for n in sel_counts]

    fig = go.Figure()
    for i, (cls, pct) in enumerate(zip(classes, sel_pcts)):
        fig.add_trace(go.Bar(
            name=f"Cls {cls}", x=[f"Cls {cls}"], y=[pct],
            marker_color=pal[i % len(pal)],
            text=[f"{pct:.0f}%"], textposition="outside",
        ))

    if is_lasso and rest_df is not None:
        rest_pcts = [(rest_df[dep.target_name] == c).sum() / len(rest_df) * 100
                     for c in classes]
        for i, (cls, pct) in enumerate(zip(classes, rest_pcts)):
            fig.add_trace(go.Bar(
                name=f"Reste Cls {cls}", x=[f"Cls {cls}"], y=[pct],
                marker_color=pal[i % len(pal)], opacity=0.35,
                text=[f"{pct:.0f}%"], textposition="outside",
                showlegend=False,
            ))

    fig.update_layout(
        title=dict(text="Répartition Target", font=dict(size=12)),
        barmode="group",
        **_mini_layout(),
        yaxis=dict(range=[0,115], visible=False),
        showlegend=False,
        height=160,
    )
    return html.Div([
        html.Div("Répartition Target (sélection vs reste)", className="chart-card-title"),
        dcc.Graph(figure=fig, config={"displayModeBar":False}, style={"height":"160px"}),
    ], style={"marginBottom":"14px"})


def _stat_tests_block(dep, sel_df, rest_df, xc, yc):
    results = []
    num_cols = [c for c in [xc, yc] if c and c in dep.num_features]

    for col in num_cols[:3]:
        a = sel_df[col].dropna().values
        b = rest_df[col].dropna().values
        if len(a) < 3 or len(b) < 3:
            continue
        # Mann-Whitney U (non-parametric)
        try:
            stat, p = sp_stats.mannwhitneyu(a, b, alternative="two-sided")
            sig = "✅ Sig." if p < 0.05 else "❌ Non sig."
            color = "#27ae60" if p < 0.05 else "#e74c3c"
            diff_pct = (a.mean() - b.mean()) / (abs(b.mean()) + 1e-9) * 100
            results.append(html.Div([
                html.Span(col[:18], style={"fontWeight":"600","color":"#1e3a5f","fontSize":"12px"}),
                html.Span(f"  Δ {diff_pct:+.1f}%",
                          style={"fontSize":"11px","color":"#6b7a8d","marginLeft":"6px"}),
                html.Span(f"  p={p:.3f}  {sig}",
                          style={"fontSize":"11px","color":color,"marginLeft":"4px"}),
            ], style={"padding":"4px 0","borderBottom":"1px solid #f0f0f0"}))
        except Exception:
            pass

    # Chi2 for target if supervised
    if dep.supervised and dep.is_classification and len(results) < 4:
        try:
            obs_sel  = np.array([(sel_df[dep.target_name] == c).sum()  for c in dep.classes])
            obs_rest = np.array([(rest_df[dep.target_name] == c).sum() for c in dep.classes])
            chi2, p, _, _ = sp_stats.chi2_contingency(np.vstack([obs_sel, obs_rest]))
            sig = "✅ Sig." if p < 0.05 else "❌ Non sig."
            color = "#27ae60" if p < 0.05 else "#e74c3c"
            results.append(html.Div([
                html.Span("Target (χ²)", style={"fontWeight":"600","color":"#1e3a5f","fontSize":"12px"}),
                html.Span(f"  p={p:.3f}  {sig}",
                          style={"fontSize":"11px","color":color,"marginLeft":"4px"}),
            ], style={"padding":"4px 0"}))
        except Exception:
            pass

    if not results:
        return html.Div()

    return html.Div([
        html.Div("Tests Statistiques (Mann-Whitney U)", className="chart-card-title",
                 style={"marginTop":"14px"}),
        html.Div(results, style={
            "background":"#f7f8fa","borderRadius":"8px",
            "padding":"10px 12px","border":"1.5px solid #e0e4ea",
            "marginBottom":"14px",
        }),
    ])


def _feature_diff_chart(dep, sel_df, rest_df):
    num = dep.num_features[:20]
    diffs, labels, colors = [], [], []

    for col in num:
        a = sel_df[col].dropna()
        b = rest_df[col].dropna()
        if len(a) < 2 or len(b) < 2:
            continue
        # Normalised difference (effect size approx)
        pooled_std = np.sqrt((a.std()**2 + b.std()**2) / 2 + 1e-9)
        d = (a.mean() - b.mean()) / pooled_std
        diffs.append(d)
        labels.append(col[:20])
        colors.append("#e07b39" if d > 0 else "#4472c4")

    if not diffs:
        return html.Div()

    # Sort by |effect size| desc, take top 10
    order = np.argsort(np.abs(diffs))[::-1][:10]
    diffs_s  = [diffs[i]  for i in order]
    labels_s = [labels[i] for i in order]
    colors_s = [colors[i] for i in order]

    fig = go.Figure(go.Bar(
        y=labels_s[::-1], x=diffs_s[::-1],
        orientation="h",
        marker_color=colors_s[::-1],
        text=[f"{d:+.2f}σ" for d in diffs_s[::-1]],
        textposition="outside",
    ))
    fig.add_vline(x=0, line_color="#6b7a8d", line_width=1)
    fig.update_layout(
        **_mini_layout(),
        height=max(180, len(labels_s) * 22 + 40),
        xaxis=dict(title="Effect size (Cohen's d approx)", gridcolor=GRID_CLR, zeroline=False),
        yaxis=dict(gridcolor=GRID_CLR),
        margin=dict(l=130, r=60, t=10, b=30),
    )
    return html.Div([
        html.Div("Top Features — Différence Sélection vs Reste", className="chart-card-title",
                 style={"marginTop":"14px"}),
        dcc.Graph(figure=fig, config={"displayModeBar":False},
                  style={"height": f"{max(180, len(labels_s)*22+40)}px"}),
    ], style={"marginBottom":"14px"})


def _mini_hist(df, col, title):
    vals = df[col].dropna()
    fig  = go.Figure(go.Histogram(x=vals, nbinsx=18,
                                  marker_color="#4472c4", opacity=0.85))
    fig.update_layout(**_mini_layout(), height=150,
                      xaxis=dict(title=col, gridcolor=GRID_CLR),
                      yaxis=dict(gridcolor=GRID_CLR),
                      margin=dict(l=30, r=10, t=10, b=36))
    return html.Div([
        html.Div(title, className="chart-card-title"),
        dcc.Graph(figure=fig, config={"displayModeBar":False}, style={"height":"150px"}),
    ], style={"marginBottom":"10px"})


def _mini_layout():
    return dict(
        plot_bgcolor=PLOT_BG, paper_bgcolor="#fff",
        margin=dict(l=30, r=10, t=10, b=30),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
        showlegend=False,
    )
