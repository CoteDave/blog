"""
Aperçu Global — Variable catalog + rich interactive detail panel.
Click any variable name to open a dtype-aware analysis panel on the right.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output, ALL, ctx, no_update
import plotly.graph_objects as go
from scipy import stats as sp_stats

# ─────────────────────────────────────────────────────────────────────────────
PALETTE  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID     = "#e0e4ea"
BG       = "#f7f8fa"
RARE_THR_FREQ  = 0.01   # < 1 % → rare
RARE_THR_COUNT = 10     # < 10 obs → rare
MAX_CAT_SHOWN  = 40     # cap categories shown


# ══════════════════════════════════════════════════════════════════════════════
#  Dtype helper
# ══════════════════════════════════════════════════════════════════════════════
def _classify_col(series: pd.Series) -> str:
    if pd.api.types.is_bool_dtype(series):
        return "Booléen"
    if pd.api.types.is_integer_dtype(series):
        return "Entier"
    if pd.api.types.is_float_dtype(series):
        return "Flottant"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "Date/Heure"
    if pd.api.types.is_categorical_dtype(series):
        return "Catégoriel"
    if series.nunique() <= 30 and pd.api.types.is_object_dtype(series):
        return "Catégoriel"
    # Free text heuristic: average word count > 5
    try:
        sample = series.dropna().astype(str).head(200)
        avg_words = sample.str.split().apply(len).mean()
        if avg_words > 5:
            return "Texte"
    except Exception:
        pass
    return "Catégoriel"


def _is_numeric_dtype(lbl: str) -> bool:
    return lbl in ("Flottant", "Entier")


def _is_cat_dtype(lbl: str) -> bool:
    return lbl in ("Catégoriel", "Booléen")


# ══════════════════════════════════════════════════════════════════════════════
#  Layout
# ══════════════════════════════════════════════════════════════════════════════
def layout(dep) -> html.Div:
    df   = dep.df
    cols = [c for c in df.columns if c != dep.target_name]

    # Metric cards
    n_rows  = len(df)
    n_miss  = int(df.isnull().sum().sum())
    miss_pct = n_miss / max(1, n_rows * len(df.columns)) * 100

    metric_cards = html.Div([
        _mcard("Observations",   f"{n_rows:,}",             "lignes"),
        _mcard("Var. numériques",f"{len(dep.num_features)}", "colonnes"),
        _mcard("Var. catégorielles",f"{len(dep.cat_features)}","colonnes"),
        _mcard("Valeurs NaN",    f"{n_miss:,}",             f"{miss_pct:.1f}%",
               accent=n_miss > 0),
        _mcard("Target",
               f"{dep.n_classes} classes" if dep.supervised and dep.is_classification
               else dep.target_name if dep.supervised else "—",
               "supervisé" if dep.supervised else "non supervisé"),
    ], className="metric-cards")

    # Variable groups
    groups: dict[str, list] = {}
    for c in cols:
        groups.setdefault(_classify_col(df[c]), []).append(c)

    TYPE_ICONS = {"Flottant":"🔢","Entier":"🔢","Catégoriel":"🏷️",
                  "Booléen":"🔘","Date/Heure":"📅","Texte":"📝"}

    group_sections = []
    for dtype_lbl in ["Flottant","Entier","Catégoriel","Booléen","Date/Heure","Texte"]:
        if dtype_lbl not in groups:
            continue
        gcols = groups[dtype_lbl]
        icon  = TYPE_ICONS.get(dtype_lbl, "📊")
        group_sections.append(html.Div([
            html.Div([
                html.Span(icon, style={"marginRight":"8px","fontSize":"16px"}),
                html.Span(
                    f"{dtype_lbl}  ·  {len(gcols)} variable{'s' if len(gcols)>1 else ''}",
                    style={"fontWeight":"700","fontSize":"14px","color":"#1e3a5f"}),
            ], style={"marginBottom":"10px","display":"flex","alignItems":"center"}),
            _var_table(df, gcols, dtype_lbl),
        ], className="chart-card", style={"marginBottom":"16px"}))

    # ── Always-in-DOM detail panel ──────────────────────────────────────────
    detail_panel = html.Div([
        # Header
        html.Div([
            html.Div(id="ov-panel-varname",
                     style={"fontWeight":"800","fontSize":"16px","color":"#1e3a5f",
                            "flex":"1","overflow":"hidden","textOverflow":"ellipsis",
                            "whiteSpace":"nowrap"}),
            html.Button("✕", id="ov-panel-close", n_clicks=0,
                        style={"background":"none","border":"none","fontSize":"20px",
                               "cursor":"pointer","color":"#6b7a8d","lineHeight":"1",
                               "padding":"0 4px","flexShrink":"0"}),
        ], style={"display":"flex","alignItems":"center","gap":"8px",
                  "marginBottom":"12px","paddingBottom":"10px",
                  "borderBottom":"2px solid #e0e4ea"}),

        # Metric selector (cat + num)
        html.Div([
            html.Div("Mesure :", style={"fontSize":"12px","fontWeight":"700",
                                         "color":"#6b7a8d","marginBottom":"4px"}),
            dcc.RadioItems(
                id="ov-metric",
                options=[{"label":" Target","value":"target"},
                         {"label":" Target Mean Diff","value":"meandiff"},
                         {"label":" Fréquence","value":"freq"},
                         {"label":" Count","value":"count"}],
                value="target",
                inline=True,
                inputStyle={"marginRight":"4px"},
                labelStyle={"marginRight":"14px","fontSize":"13px","cursor":"pointer"},
            ),
        ], id="ov-metric-wrap", style={"marginBottom":"12px"}),

        # Bin controls (numeric only)
        html.Div([
            html.Div([
                html.Div("Bins :", style={"fontSize":"12px","fontWeight":"700",
                                           "color":"#6b7a8d","whiteSpace":"nowrap"}),
                dcc.Slider(id="ov-bin-n", min=3, max=30, step=1, value=10,
                           marks={3:"3",10:"10",20:"20",30:"30"},
                           tooltip={"placement":"bottom","always_visible":False}),
            ], style={"flex":"1","minWidth":"180px"}),
            html.Div([
                html.Div("Méthode :", style={"fontSize":"12px","fontWeight":"700",
                                              "color":"#6b7a8d","marginBottom":"4px"}),
                dcc.Dropdown(id="ov-bin-method",
                             options=[{"label":"Quantiles","value":"quantile"},
                                      {"label":"Intervalles égaux","value":"equal"},
                                      {"label":"Arbre décisionnel","value":"dtree"}],
                             value="quantile", clearable=False,
                             style={"fontSize":"12px","minWidth":"170px"}),
            ]),
        ], id="ov-bin-controls",
           style={"display":"none","gap":"16px","alignItems":"flex-end",
                  "marginBottom":"14px","flexWrap":"wrap"}),

        # Dynamic content area
        html.Div(id="ov-panel-content",
                 style={"overflowY":"auto","flex":"1"}),
    ], id="ov-detail-panel",
       style={"display":"none","flexDirection":"column","padding":"18px",
              "background":"white","borderRadius":"12px",
              "border":"1.5px solid #e0e4ea","boxShadow":"0 4px 18px rgba(0,0,0,.10)",
              "width":"520px","flexShrink":"0","position":"sticky","top":"0",
              "maxHeight":"calc(100vh - 100px)"})

    return html.Div([
        dcc.Store(id="ov-selected-var", data=None),

        html.Div("Aperçu Global — Catalogue des Variables", className="page-title"),
        html.Div(
            "Cliquez sur un nom de variable pour afficher son analyse détaillée.",
            className="page-subtitle"),

        metric_cards,

        html.Div("📋 Variables par Type de Données",
                 style={"fontWeight":"800","fontSize":"17px","color":"#1e3a5f",
                        "marginBottom":"14px","marginTop":"8px"}),

        # Flex container: catalog (left) + panel (right)
        html.Div([
            html.Div(group_sections, id="ov-catalog-wrap",
                     style={"flex":"1","minWidth":"0"}),
            detail_panel,
        ], style={"display":"flex","gap":"18px","alignItems":"flex-start"}),
    ], className="page-card")


# ══════════════════════════════════════════════════════════════════════════════
#  Callbacks
# ══════════════════════════════════════════════════════════════════════════════
def register_callbacks(app, dep) -> None:

    # ── 1. Select / deselect variable ─────────────────────────────────────────
    @app.callback(
        Output("ov-selected-var", "data"),
        [Input({"type":"ov-var-click","index":ALL}, "n_clicks"),
         Input("ov-panel-close", "n_clicks")],
        prevent_initial_call=True,
    )
    def select_var(var_clicks, close_click):
        triggered = ctx.triggered_id
        if triggered == "ov-panel-close":
            return None
        if isinstance(triggered, dict) and triggered.get("type") == "ov-var-click":
            return triggered["index"]
        return no_update

    # ── 2. Panel visibility + controls ────────────────────────────────────────
    @app.callback(
        [Output("ov-detail-panel",   "style"),
         Output("ov-catalog-wrap",   "style"),
         Output("ov-panel-varname",  "children"),
         Output("ov-bin-controls",   "style"),
         Output("ov-metric-wrap",    "style")],
        Input("ov-selected-var", "data"),
    )
    def toggle_panel(col):
        panel_hidden = {"display":"none"}
        panel_show   = {
            "display":"flex","flexDirection":"column","padding":"18px",
            "background":"white","borderRadius":"12px",
            "border":"1.5px solid #e0e4ea","boxShadow":"0 4px 18px rgba(0,0,0,.10)",
            "width":"520px","flexShrink":"0","position":"sticky","top":"0",
            "maxHeight":"calc(100vh - 100px)",
        }
        cat_full    = {"flex":"1","minWidth":"0"}
        cat_shrink  = {"flex":"1","minWidth":"0"}  # panel pushes naturally

        if col is None:
            return panel_hidden, cat_full, "",                    {"display":"none"}, {"marginBottom":"12px"}

        dtype = _classify_col(dep.df[col])
        is_num = _is_numeric_dtype(dtype)

        badge_clr = {"Flottant":"#4472c4","Entier":"#27ae60",
                     "Catégoriel":"#e07b39","Booléen":"#9b59b6",
                     "Texte":"#e74c3c","Date/Heure":"#1abc9c"}.get(dtype,"#6b7a8d")

        title_el = html.Div([
            html.Span(col, style={"fontWeight":"800","color":"#1e3a5f"}),
            html.Span(f" {dtype}",
                      style={"background":badge_clr,"color":"white",
                             "borderRadius":"6px","padding":"1px 8px",
                             "fontSize":"11px","fontWeight":"700","marginLeft":"8px"}),
        ])

        bin_style   = ({"display":"flex","gap":"16px","alignItems":"flex-end",
                        "marginBottom":"14px","flexWrap":"wrap"} if is_num
                       else {"display":"none"})
        metric_style = ({"marginBottom":"12px"} if dtype != "Texte"
                        else {"display":"none"})

        return panel_show, cat_shrink, title_el, bin_style, metric_style

    # ── 3. Build panel content ─────────────────────────────────────────────────
    @app.callback(
        Output("ov-panel-content", "children"),
        [Input("ov-selected-var", "data"),
         Input("ov-metric",       "value"),
         Input("ov-bin-n",        "value"),
         Input("ov-bin-method",   "value")],
    )
    def build_panel(col, metric, n_bins, bin_method):
        if col is None or col not in dep.df.columns:
            return []
        dtype = _classify_col(dep.df[col])

        if _is_cat_dtype(dtype):
            return _build_cat_panel(dep, col, metric or "target")
        elif _is_numeric_dtype(dtype):
            return _build_num_panel(dep, col, metric or "target",
                                    n_bins or 10, bin_method or "quantile")
        elif dtype == "Texte":
            return _build_text_panel(dep, col)
        else:
            return [html.Div(f"Type {dtype} non supporté pour l'analyse détaillée.",
                             style={"color":"#6b7a8d","fontSize":"13px","padding":"20px"})]


# ══════════════════════════════════════════════════════════════════════════════
#  STATS HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _target_type(dep) -> str:
    """Returns: 'none', 'binary', 'multiclass', 'numeric'"""
    if not dep.supervised:
        return "none"
    if not dep.is_classification:
        return "numeric"
    return "binary" if dep.n_classes == 2 else "multiclass"


def _cramers_v(x: pd.Series, y: pd.Series):
    from scipy.stats import chi2_contingency
    ct = pd.crosstab(x.astype(str), y.astype(str))
    chi2, p, dof, _ = chi2_contingency(ct)
    n = len(x)
    k = min(ct.shape) - 1
    v = float(np.sqrt(chi2 / max(n * k, 1e-9)))
    return float(chi2), float(p), int(dof), min(v, 1.0)


def _welch_posthoc(groups: dict) -> pd.DataFrame:
    """Pairwise Welch t-tests + Holm-Bonferroni correction."""
    keys = [k for k, v in groups.items() if len(v) >= 3]
    if len(keys) < 2:
        return pd.DataFrame()
    rows = []
    for k1, k2 in combinations(keys, 2):
        g1, g2 = groups[k1], groups[k2]
        t, p = sp_stats.ttest_ind(g1, g2, equal_var=False)
        rows.append({"G1":str(k1)[:22],"G2":str(k2)[:22],
                     "ΔMoy":g1.mean()-g2.mean(), "p_raw":p,
                     "N1":len(g1),"N2":len(g2)})
    df_r = pd.DataFrame(rows).sort_values("p_raw").reset_index(drop=True)
    m = len(df_r)
    adj = []
    max_seen = 0.0
    for rank, (_, row) in enumerate(df_r.iterrows()):
        a = min(1.0, row["p_raw"] * (m - rank))
        a = max(a, max_seen)
        max_seen = a
        adj.append(a)
    df_r["p_holm"] = adj
    df_r["Sig"]    = df_r["p_holm"].apply(lambda p: "✅ p<.05" if p < 0.05 else "❌")
    df_r["ΔMoy"]   = df_r["ΔMoy"].apply(lambda x: f"{x:+.3g}")
    df_r["p (Holm)"] = df_r["p_holm"].apply(lambda p: f"{p:.4f}")
    return df_r[["G1","G2","N1","N2","ΔMoy","p (Holm)","Sig"]]


def _normality_report(s: pd.Series) -> list:
    """Return list of (label, value) tuples describing distribution."""
    vals = s.dropna().values
    n    = len(vals)
    if n < 3:
        return [("N", str(n)), ("Statut", "Insuffisant (<3 obs)")]

    rows = []
    rows.append(("N valides", f"{n:,}"))
    rows.append(("Moyenne ± Std", f"{vals.mean():.4g} ± {vals.std():.4g}"))
    rows.append(("Médiane", f"{np.median(vals):.4g}"))

    # Skewness
    skw = float(sp_stats.skew(vals))
    if   abs(skw) < 0.5:  skw_lbl = "Symétrique"
    elif skw > 2:          skw_lbl = f"Forte asymétrie droite ({skw:+.2f})"
    elif skw > 0:          skw_lbl = f"Légère asymétrie droite ({skw:+.2f})"
    elif skw < -2:         skw_lbl = f"Forte asymétrie gauche ({skw:+.2f})"
    else:                  skw_lbl = f"Légère asymétrie gauche ({skw:+.2f})"
    rows.append(("Asymétrie (skewness)", skw_lbl))

    # Kurtosis
    kurt = float(sp_stats.kurtosis(vals))
    if   abs(kurt) < 1:   kurt_lbl = f"Mésokurtique ≈ normale ({kurt:+.2f})"
    elif kurt > 0:         kurt_lbl = f"Leptokurtique — queues épaisses ({kurt:+.2f})"
    else:                  kurt_lbl = f"Platykurtique — queues fines ({kurt:+.2f})"
    rows.append(("Kurtosis (excès)", kurt_lbl))

    # Normality
    if n >= 8:
        stat_n, p_n = sp_stats.normaltest(vals)
        norm_lbl = ("✅ Normale (p=%.4f)" % p_n if p_n > 0.05
                    else "❌ Non-normale (p=%.4f)" % p_n)
        rows.append(("Test normalité D'Agostino-Pearson", norm_lbl))
    else:
        rows.append(("Test normalité", "N/A (n<8)"))

    # Outliers IQR
    q1, q3 = np.percentile(vals, 25), np.percentile(vals, 75)
    iqr     = q3 - q1
    n_iqr   = int(np.sum((vals < q1 - 1.5*iqr) | (vals > q3 + 1.5*iqr)))
    rows.append((f"Outliers IQR×1.5", f"{n_iqr} ({n_iqr/n:.1%})"))

    # Outliers Z>3
    if vals.std() > 0:
        n_z = int(np.sum(np.abs((vals - vals.mean()) / vals.std()) > 3))
        rows.append((f"Outliers |Z|>3", f"{n_z} ({n_z/n:.1%})"))

    # Levene heteroscedasticity (split into quartile groups)
    if n >= 20:
        try:
            qt = pd.qcut(vals, q=4, duplicates="drop")
            grps = [vals[qt == c] for c in qt.cat.categories if (qt == c).sum() >= 3]
            if len(grps) >= 2:
                lev_stat, lev_p = sp_stats.levene(*grps)
                lev_lbl = ("✅ Homoscédastique (p=%.4f)" % lev_p if lev_p > 0.05
                           else "❌ Hétéroscédastique (p=%.4f)" % lev_p)
                rows.append(("Hétéroscédasticité (Levene)", lev_lbl))
        except Exception:
            pass

    return rows


def _kde_values(vals: np.ndarray, n_pts=200):
    """Compute KDE and return (x_grid, density)."""
    if len(vals) < 3:
        return np.array([]), np.array([])
    try:
        kde  = sp_stats.gaussian_kde(vals, bw_method="scott")
        xmin, xmax = vals.min(), vals.max()
        pad  = (xmax - xmin) * 0.1 + 1e-6
        xg   = np.linspace(xmin - pad, xmax + pad, n_pts)
        return xg, kde(xg)
    except Exception:
        return np.array([]), np.array([])


# ══════════════════════════════════════════════════════════════════════════════
#  BUBBLE CHART builder (shared by cat + num)
# ══════════════════════════════════════════════════════════════════════════════

def _cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Cohen's d effect size between two groups."""
    if len(a) < 2 or len(b) < 2:
        return 0.0
    pooled = np.sqrt((a.std(ddof=1)**2 + b.std(ddof=1)**2) / 2 + 1e-12)
    return float((a.mean() - b.mean()) / pooled)


def _bubble_chart(dep, cats, counts, freqs, metric,
                  target_means=None, target_cis=None,
                  target_props=None,
                  target_groups=None,   # dict {cat: np.ndarray} for meandiff
                  global_target_mean=None,
                  title="", is_ordered_by_value=False) -> go.Figure:
    """
    Build the horizontal bubble / dot chart.
    metric='meandiff': shows (cat_mean - global_mean) with dashed zero line,
    diamond shape for |Cohen's d| >= 0.5 (significant effect), circle otherwise.
    """
    df_plot = pd.DataFrame({
        "cat":   list(cats),
        "count": [counts[c] for c in cats],
        "freq":  [freqs[c]  for c in cats],
    })
    df_plot["rare"] = (df_plot["freq"] < RARE_THR_FREQ) | (df_plot["count"] < RARE_THR_COUNT)

    # ── x-values ─────────────────────────────────────────────────────────────
    if metric == "count":
        df_plot["xval"] = df_plot["count"]
        if not is_ordered_by_value:
            df_plot = df_plot.sort_values("xval", ascending=True)
    elif metric == "freq":
        df_plot["xval"] = df_plot["freq"] * 100
        if not is_ordered_by_value:
            df_plot = df_plot.sort_values("xval", ascending=True)
    elif metric == "meandiff" and target_groups is not None and global_target_mean is not None:
        diffs, sigs, ds = {}, {}, {}
        all_vals = np.concatenate(list(target_groups.values())) if target_groups else np.array([])
        for cat in cats:
            grp = target_groups.get(cat, np.array([]))
            if len(grp) >= 2:
                diff = grp.mean() - global_target_mean
                rest = all_vals  # compare cat group vs global
                d    = _cohens_d(grp, all_vals)
                _, p = sp_stats.ttest_1samp(grp, global_target_mean)
                diffs[cat] = diff
                sigs[cat]  = p < 0.05 and abs(d) >= 0.2
                ds[cat]    = d
            else:
                diffs[cat] = 0.0
                sigs[cat]  = False
                ds[cat]    = 0.0
        df_plot["xval"]     = df_plot["cat"].map(diffs).fillna(0.0)
        df_plot["sig"]      = df_plot["cat"].map(sigs).fillna(False)
        df_plot["cohens_d"] = df_plot["cat"].map(ds).fillna(0.0)
        if not is_ordered_by_value:
            df_plot = df_plot.sort_values("xval", ascending=True)
    elif metric == "target" and target_means is not None:
        df_plot["xval"] = df_plot["cat"].map(target_means).fillna(np.nan)
        if not is_ordered_by_value:
            df_plot = df_plot.sort_values("xval", ascending=True, na_position="first")
    elif metric == "target" and target_props is not None:
        df_plot["xval"] = df_plot["cat"].map(
            lambda c: target_props.get(c, {}).get("cls1", np.nan))
        if not is_ordered_by_value:
            df_plot = df_plot.sort_values("xval", ascending=True, na_position="first")
    else:
        df_plot["xval"] = df_plot["freq"] * 100

    df_plot = df_plot.tail(MAX_CAT_SHOWN)
    df_plot = df_plot.reset_index(drop=True)

    fig      = go.Figure()
    y_labels = [str(c)[:45] for c in df_plot["cat"]]
    max_freq = df_plot["freq"].max() if df_plot["freq"].max() > 0 else 1
    sizes    = (df_plot["freq"] / max_freq * 22 + 8).clip(5, 32).tolist()

    # ── For meandiff: split into two traces (sig / non-sig) ──────────────────
    if metric == "meandiff" and "sig" in df_plot.columns:
        for is_sig in [False, True]:
            mask = df_plot["sig"] == is_sig
            sub  = df_plot[mask]
            sub_y = [y_labels[i] for i in sub.index]
            sub_sz= [sizes[i] for i in sub.index]
            sub_clr = [
                ("rgba(180,180,180,0.35)" if row["rare"] else
                 ("#e07b39" if row["xval"] > 0 else "#4472c4"))
                for _, row in sub.iterrows()
            ]
            sym = "diamond" if is_sig else "circle"
            lbl = "Sig. (|d|≥0.2, p<.05)" if is_sig else "Non sig."
            fig.add_trace(go.Scatter(
                x=sub["xval"].tolist(), y=sub_y,
                mode="markers", name=lbl,
                marker=dict(
                    symbol=sym, size=sub_sz, color=sub_clr,
                    line=dict(width=1.5 if is_sig else 0.8,
                              color="#e07b39" if is_sig else "rgba(100,120,160,0.4)"),
                    opacity=0.88,
                ),
                hovertemplate=[
                    f"<b>{str(row['cat'])[:40]}</b><br>"
                    f"Δmoy: {row['xval']:+.4g}<br>"
                    f"Cohen d: {row['cohens_d']:+.3f}<br>"
                    f"Fréq: {row['freq']:.1%}<br>"
                    f"{'✅ Sig. (p<.05)' if row['sig'] else '❌ Non sig.'}"
                    "<extra></extra>"
                    for _, row in sub.iterrows()
                ],
                showlegend=is_sig,
            ))
        # Global mean dashed line at x=0
        fig.add_vline(x=0, line_dash="dash", line_color="#6b7a8d",
                      line_width=1.5,
                      annotation_text=f"Moy. globale ({global_target_mean:.3g})",
                      annotation_position="top",
                      annotation_font=dict(size=9, color="#6b7a8d"))
    else:
        # Standard single trace
        colors = [
            "rgba(180,180,180,0.4)" if r else "rgba(68,114,196,0.82)"
            for r in df_plot["rare"]
        ]
        err_x = None
        if metric == "target" and target_cis is not None:
            err_vals = [target_cis.get(c, 0) for c in df_plot["cat"]]
            err_x = dict(type="data", array=err_vals, visible=True,
                         color="rgba(68,114,196,0.5)", thickness=1.5, width=6)
        hover_parts = []
        for _, row in df_plot.iterrows():
            c = row["cat"]
            h = f"<b>{str(c)[:40]}</b><br>Count: {row['count']:,}<br>Fréq: {row['freq']:.1%}"
            if metric == "target" and target_means and c in target_means:
                v = target_means.get(c, np.nan)
                if not (isinstance(v, float) and np.isnan(v)):
                    h += f"<br>Moy. target: {v:.4g}"
            hover_parts.append(h + "<extra></extra>")

        fig.add_trace(go.Scatter(
            x=df_plot["xval"].tolist(), y=y_labels,
            mode="markers",
            marker=dict(size=sizes, color=colors,
                        line=dict(width=1, color="rgba(68,114,196,0.6)")),
            error_x=err_x,
            hovertemplate=hover_parts,
            showlegend=False,
        ))

    # ── Right-side value annotations ─────────────────────────────────────────
    for i, row in df_plot.iterrows():
        xv = row["xval"]
        if pd.isna(xv):
            continue
        if metric == "meandiff":
            ann_txt = f"  {xv:+.3g}"
            if "sig" in row and row["sig"]:
                ann_txt += f"  ★d={row['cohens_d']:+.2f}"
        else:
            ann_txt = f"  {xv:.3g}  ({row['freq']:.1%})"
        fig.add_annotation(
            x=xv, y=y_labels[i], text=ann_txt, showarrow=False,
            xanchor="left" if xv >= 0 else "right",
            xshift=(sizes[i]//2 + 5) if xv >= 0 else -(sizes[i]//2 + 5),
            font=dict(size=9, color="#6b7a8d" if row["rare"] else "#374151"),
        )

    x_title = {
        "count": "Effectif", "freq": "Fréquence (%)",
        "target": "Target moyen / proportion",
        "meandiff": "Δ Target Mean vs Moyenne Globale",
    }.get(metric, "")

    fig.update_layout(
        title=dict(text=title, font=dict(size=12)),
        xaxis=dict(title=x_title, gridcolor=GRID,
                   zeroline=(metric == "meandiff"), zerolinecolor="#aaa",
                   tickfont=dict(size=10)),
        yaxis=dict(tickfont=dict(size=9, color="#b0b8c9"),
                   autorange=False, range=[-1, len(df_plot)]),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=140, r=130, t=36, b=40),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
        height=max(260, min(len(df_plot) * 26 + 80, 540)),
        legend=dict(font=dict(size=10), x=0.01, y=1.0,
                    bgcolor="rgba(255,255,255,.85)"),
        showlegend=(metric == "meandiff"),
    )
    return fig


# ══════════════════════════════════════════════════════════════════════════════
#  CATEGORICAL PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _build_cat_panel(dep, col: str, metric: str) -> list:
    s     = dep.df[col].fillna("__NaN__").astype(str)
    n_tot = len(s)
    vc    = s.value_counts()

    cats   = list(vc.index)
    counts = vc.to_dict()
    freqs  = {c: counts[c] / n_tot for c in cats}

    tt = _target_type(dep)
    target_means = None
    target_cis   = None
    target_props = None

    # Compute target stats per category
    if tt == "numeric":
        target_means, target_cis = {}, {}
        tgt = dep.df[dep.target_name]
        for cat in cats:
            mask = s == str(cat)
            vals = tgt[mask].dropna().values
            if len(vals) < 1:
                target_means[cat] = np.nan; target_cis[cat] = 0; continue
            m = vals.mean()
            ci = (sp_stats.t.ppf(0.975, len(vals)-1) * vals.std(ddof=1) / np.sqrt(len(vals))
                  if len(vals) >= 2 else 0.0)
            target_means[cat] = m
            target_cis[cat]   = ci

    elif tt in ("binary", "multiclass"):
        target_props = {}
        tgt = dep.df[dep.target_name]
        for cat in cats:
            mask = s == str(cat)
            grp  = tgt[mask].dropna()
            props = {}
            for cls in dep.classes:
                props[f"cls_{cls}"] = (grp == cls).mean()
            props["cls1"] = props.get(f"cls_{dep.classes[-1]}", 0.0)
            target_props[cat] = props

    # Compute target_groups for meandiff (any supervised)
    target_groups      = None
    global_target_mean = None
    if dep.supervised and metric == "meandiff":
        tgt_s = dep.df[dep.target_name]
        # Encode target numerically for mean diff
        if dep.is_classification:
            from sklearn.preprocessing import LabelEncoder
            le   = LabelEncoder()
            tgt_num = pd.Series(le.fit_transform(tgt_s.fillna(tgt_s.mode().iloc[0])),
                                index=tgt_s.index)
        else:
            tgt_num = tgt_s.fillna(tgt_s.median())
        global_target_mean = float(tgt_num.mean())
        target_groups = {cat: tgt_num[s == cat].dropna().values for cat in cats}

    # Build bubble chart
    fig_bubble = _bubble_chart(
        dep, cats, counts, freqs, metric,
        target_means=target_means, target_cis=target_cis,
        target_props=target_props,
        target_groups=target_groups,
        global_target_mean=global_target_mean,
        title=f"Distribution de '{col}' — mesure: {metric}",
    )

    elements = []

    # ── Basic info table ──────────────────────────────────────────────────────
    n_rare = sum(1 for c in cats
                 if freqs[c] < RARE_THR_FREQ or counts[c] < RARE_THR_COUNT)
    top3   = cats[:3]
    info_rows = [
        ("N catégories",         f"{len(cats)}"),
        ("N catégories rares",   f"{n_rare}  (<1% ou <10 obs)"),
        ("Mode (plus fréquent)", f"{cats[0]}  ({freqs[cats[0]]:.1%})"),
        ("2ème fréquent",        f"{cats[1]}  ({freqs[cats[1]]:.1%})" if len(cats)>1 else "—"),
        ("% NaN",                f"{dep.df[col].isnull().mean():.1%}"),
    ]
    if tt in ("binary","multiclass") and target_props:
        chi2, p_chi2, dof, v = _cramers_v(
            s.rename(col), dep.df[dep.target_name].astype(str))
        assoc = ("Nulle" if v < 0.1 else "Faible" if v < 0.2 else
                 "Modérée" if v < 0.4 else "Forte")
        info_rows += [
            ("Chi² (df=%d)" % dof,   f"{chi2:.3f}  (p={p_chi2:.4f})"),
            ("V de Cramér",          f"{v:.4f}  → {assoc}"),
            ("Chi² significatif",    "✅ Oui (p<.05)" if p_chi2 < 0.05 else "❌ Non (p≥.05)"),
        ]
    elif tt == "numeric" and target_means:
        grps = {c: dep.df[dep.target_name][s == c].dropna().values
                for c in cats if (s == c).sum() >= 3}
        if len(grps) >= 2:
            try:
                f_stat, p_anova = sp_stats.f_oneway(*grps.values())
                info_rows += [
                    ("ANOVA F-stat", f"{f_stat:.3f}  (p={p_anova:.4f})"),
                    ("ANOVA significatif", "✅ Oui" if p_anova < 0.05 else "❌ Non"),
                ]
            except Exception:
                pass

    elements.append(_info_table(info_rows, "ℹ️ Informations"))
    elements.append(_graph(fig_bubble, height=fig_bubble.layout.height or 320))

    # ── Post-hoc / Chi2 detail ────────────────────────────────────────────────
    if tt == "numeric" and target_means and len(cats) >= 2:
        grps = {c: dep.df[dep.target_name][s == c].dropna().values
                for c in cats}
        ph_df = _welch_posthoc(grps)
        if not ph_df.empty:
            elements.append(html.Div("🔬 Tests post-hoc (Welch + Holm-Bonferroni)",
                                     className="chart-card-title",
                                     style={"marginTop":"16px"}))
            elements.append(_df_table(ph_df.head(30)))

    # ── KDE overlay of target by category ────────────────────────────────────
    if tt == "numeric" and target_means:
        top_cats = [c for c in cats if counts.get(c,0) >= RARE_THR_COUNT][:6]
        fig_kde = go.Figure()
        tgt = dep.df[dep.target_name]
        for i, cat in enumerate(top_cats):
            vals = tgt[s == cat].dropna().values
            if len(vals) < 5: continue
            xg, dens = _kde_values(vals)
            if len(xg) == 0: continue
            clr = PALETTE[i % len(PALETTE)]
            fig_kde.add_trace(go.Scatter(
                x=xg, y=dens, fill="tozeroy",
                fillcolor=_hex_alpha(clr, 0.12),
                line=dict(color=clr, width=2),
                name=str(cat)[:25],
            ))
        fig_kde.update_layout(
            title=f"Distribution du target par catégorie (top {len(top_cats)})",
            xaxis=dict(title=dep.target_name, gridcolor=GRID, zeroline=False),
            yaxis=dict(title="Densité", gridcolor=GRID, zeroline=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=36,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_kde, height=240, mt=14))

    # ── KDE overlay of variable distribution per class (if classification) ───
    if tt in ("binary","multiclass"):
        tgt = dep.df[dep.target_name]
        # proportions stacked bar per category
        top_cats = [c for c in cats if counts.get(c,0) >= RARE_THR_COUNT][:25]
        fig_stack = go.Figure()
        for i, cls in enumerate(dep.classes):
            y_vals = [(dep.df[col].fillna("__NaN__").astype(str) == c) & (tgt == cls)
                      for c in top_cats]
            props  = [v.sum() / max(counts.get(c,1), 1) for v, c in zip(y_vals, top_cats)]
            fig_stack.add_trace(go.Bar(
                x=[str(c)[:30] for c in top_cats],
                y=props,
                name=f"Cls {cls}",
                marker_color=PALETTE[i % len(PALETTE)],
            ))
        fig_stack.update_layout(
            barmode="stack",
            title="Proportion des classes par catégorie",
            xaxis=dict(tickangle=-35, gridcolor=GRID, tickfont=dict(size=9)),
            yaxis=dict(title="Proportion", gridcolor=GRID, range=[0,1.05]),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=36,b=80),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_stack, height=260, mt=14))

    return elements


# ══════════════════════════════════════════════════════════════════════════════
#  NUMERIC PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _bin_series(series: pd.Series, target, n_bins: int, method: str) -> pd.Series:
    s = series.dropna()
    if method == "dtree" and target is not None:
        try:
            from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
            X = s.values.reshape(-1, 1)
            y = target.loc[s.index].fillna(target.median()).values
            is_cls = y.dtype.kind not in ("f",) or len(np.unique(y)) <= 20
            dt = (DecisionTreeClassifier(max_leaf_nodes=n_bins, min_samples_leaf=10,
                                          random_state=42)
                  if is_cls else
                  DecisionTreeRegressor(max_leaf_nodes=n_bins, min_samples_leaf=10,
                                         random_state=42))
            dt.fit(X, y)
            thrs = sorted(set(dt.tree_.threshold[dt.tree_.threshold > -2]))
            cuts = [-np.inf] + thrs + [np.inf]
            return pd.cut(s, bins=cuts, duplicates="drop")
        except Exception:
            pass
    if method == "quantile":
        return pd.qcut(s, q=n_bins, duplicates="drop")
    return pd.cut(s, bins=n_bins, duplicates="drop")


def _build_num_panel(dep, col: str, metric: str, n_bins: int, method: str) -> list:
    s   = dep.df[col].dropna()
    tt  = _target_type(dep)

    elements = []

    # ── Distribution stats table ──────────────────────────────────────────────
    dist_rows = _normality_report(s)
    elements.append(_info_table(dist_rows, "📊 Statistiques de distribution"))

    # ── KDE of the variable itself ────────────────────────────────────────────
    xg, dens = _kde_values(s.values)
    fig_kde_self = go.Figure()
    if len(xg) > 0:
        fig_kde_self.add_trace(go.Scatter(
            x=xg, y=dens, fill="tozeroy",
            fillcolor="rgba(68,114,196,0.12)",
            line=dict(color="#4472c4", width=2),
            name=col, showlegend=False,
        ))
        # Rug
        fig_kde_self.add_trace(go.Scatter(
            x=s.sample(min(500, len(s)), random_state=42).values,
            y=np.zeros(min(500, len(s))),
            mode="markers", marker=dict(symbol="line-ns",size=8,
                                         color="rgba(68,114,196,0.35)",
                                         line=dict(width=1,color="rgba(68,114,196,0.5)")),
            showlegend=False, hoverinfo="x",
        ))
    q1,q3  = s.quantile([0.25,0.75])
    fig_kde_self.add_vrect(x0=q1, x1=q3,
        fillcolor="rgba(68,114,196,0.07)",
        line_width=0,
        annotation_text="IQR", annotation_position="top left",
        annotation_font_size=9)
    fig_kde_self.update_layout(
        title=f"Distribution de '{col}'",
        xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
        yaxis=dict(title="Densité", gridcolor=GRID, zeroline=False),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=50,r=20,t=36,b=40),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
    )
    elements.append(_graph(fig_kde_self, height=220, mt=14))

    # ── KDE by class (classification target) ─────────────────────────────────
    if tt in ("binary", "multiclass"):
        fig_kde_cls = go.Figure()
        tgt = dep.df[dep.target_name]
        for i, cls in enumerate(dep.classes):
            vals = s[dep.df[dep.target_name] == cls].values
            if len(vals) < 5: continue
            xg_c, dens_c = _kde_values(vals)
            if len(xg_c) == 0: continue
            clr = PALETTE[i % len(PALETTE)]
            fig_kde_cls.add_trace(go.Scatter(
                x=xg_c, y=dens_c, fill="tozeroy",
                fillcolor=_hex_alpha(clr, 0.13),
                line=dict(color=clr, width=2),
                name=f"Classe {cls}",
            ))
        fig_kde_cls.update_layout(
            title=f"Distribution de '{col}' par classe",
            xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
            yaxis=dict(title="Densité", gridcolor=GRID, zeroline=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=36,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_kde_cls, height=220, mt=14))

    # ── Scatter + spline (numeric target) ────────────────────────────────────
    if tt == "numeric":
        tgt    = dep.df[dep.target_name].dropna()
        common = s.index.intersection(tgt.index)
        xs     = s.loc[common].values
        ys     = tgt.loc[common].values

        # Pearson + Spearman
        r_pear, p_pear   = sp_stats.pearsonr(xs, ys)
        r_spear, p_spear = sp_stats.spearmanr(xs, ys)

        # R²
        from scipy.stats import linregress
        slope, intercept, r_val, _, _ = linregress(xs, ys)
        r2 = r_val ** 2

        # Polynomial spline (deg 3)
        sort_idx = np.argsort(xs)
        xs_s, ys_s = xs[sort_idx], ys[sort_idx]
        n_knots = min(max(int(len(xs)/30), 3), 15)
        try:
            from scipy.interpolate import make_smoothing_spline
            spl = make_smoothing_spline(xs_s, ys_s)
            xg_sp = np.linspace(xs_s.min(), xs_s.max(), 300)
            yg_sp = spl(xg_sp)
        except Exception:
            xg_sp = np.linspace(xs_s.min(), xs_s.max(), 300)
            yg_sp = slope * xg_sp + intercept

        fig_scat = go.Figure()
        samp = np.random.choice(len(xs), min(500, len(xs)), replace=False)
        fig_scat.add_trace(go.Scatter(
            x=xs[samp], y=ys[samp], mode="markers",
            marker=dict(color="rgba(68,114,196,0.45)", size=5),
            name="Observations", hoverinfo="x+y",
        ))
        fig_scat.add_trace(go.Scatter(
            x=xg_sp, y=yg_sp, mode="lines",
            line=dict(color="#e07b39", width=2.5),
            name="Spline",
        ))
        fig_scat.update_layout(
            title=(f"Scatter '{col}' vs '{dep.target_name}'  ·  "
                   f"R²={r2:.3f}  r={r_pear:.3f} (p={p_pear:.3f})  "
                   f"ρ={r_spear:.3f}"),
            xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
            yaxis=dict(title=dep.target_name, gridcolor=GRID, zeroline=False),
            plot_bgcolor=BG, paper_bgcolor="white",
            margin=dict(l=50,r=20,t=50,b=40),
            font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            legend=dict(font=dict(size=10)),
        )
        elements.append(_graph(fig_scat, height=260, mt=14))

        # Correlation summary
        corr_rows = [
            ("Pearson r",     f"{r_pear:.4f}  (p={p_pear:.4f})"),
            ("Spearman ρ",    f"{r_spear:.4f}  (p={p_spear:.4f})"),
            ("R² (linéaire)", f"{r2:.4f}"),
            ("Pearson sig.",  "✅ Oui (p<.05)" if p_pear < 0.05 else "❌ Non"),
        ]
        elements.append(_info_table(corr_rows, "📐 Corrélation avec target"))

    # ── Binned bubble chart ───────────────────────────────────────────────────
    tgt_series = (dep.df[dep.target_name] if dep.supervised else None)
    try:
        binned = _bin_series(s, tgt_series, n_bins, method)
    except Exception:
        binned = pd.cut(s, bins=min(n_bins, s.nunique()), duplicates="drop")

    bin_labels = [str(b) for b in binned.cat.categories]
    bin_counts = binned.value_counts().reindex(binned.cat.categories).fillna(0)
    n_tot_bin  = bin_counts.sum()
    bin_freqs  = (bin_counts / n_tot_bin).to_dict()
    bin_cnts   = bin_counts.to_dict()

    # Use bin category labels as keys
    cats_bin   = [str(c) for c in bin_counts.index]
    bin_freqs  = {str(k): v for k, v in bin_freqs.items()}
    bin_cnts   = {str(k): int(v) for k, v in bin_cnts.items()}

    bm_means, bm_cis = None, None
    if tt == "numeric" and tgt_series is not None:
        bm_means, bm_cis = {}, {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = binned == b
            vals = tgt_series[mask.reindex(dep.df.index, fill_value=False)].dropna().values
            if len(vals) < 1:
                bm_means[cat] = np.nan; bm_cis[cat] = 0; continue
            m  = vals.mean()
            ci = (sp_stats.t.ppf(0.975, len(vals)-1) * vals.std(ddof=1) / np.sqrt(len(vals))
                  if len(vals) >= 2 else 0.0)
            bm_means[cat] = m
            bm_cis[cat]   = ci

    bm_props = None
    if tt in ("binary","multiclass") and tgt_series is not None:
        bm_props = {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = (binned == b).reindex(dep.df.index, fill_value=False)
            grp  = tgt_series[mask].dropna()
            props = {f"cls_{cls}": (grp == cls).mean() for cls in dep.classes}
            props["cls1"] = props.get(f"cls_{dep.classes[-1]}", 0.0)
            bm_props[cat] = props

    # Compute meandiff groups for bins
    bm_groups      = None
    global_bm_mean = None
    if dep.supervised and metric == "meandiff" and tgt_series is not None:
        if dep.is_classification:
            from sklearn.preprocessing import LabelEncoder
            le      = LabelEncoder()
            tgt_num = pd.Series(
                le.fit_transform(tgt_series.fillna(tgt_series.mode().iloc[0])),
                index=tgt_series.index)
        else:
            tgt_num = tgt_series.fillna(tgt_series.median())
        global_bm_mean = float(tgt_num.mean())
        bm_groups = {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = (binned == b).reindex(dep.df.index, fill_value=False)
            bm_groups[cat] = tgt_num[mask].dropna().values

    fig_bin = _bubble_chart(
        dep, cats_bin, bin_cnts, bin_freqs, metric,
        target_means=bm_means, target_cis=bm_cis,
        target_props=bm_props,
        target_groups=bm_groups,
        global_target_mean=global_bm_mean,
        title=f"'{col}' — bins ({method}, n={n_bins})",
        is_ordered_by_value=True,
    )
    elements.append(html.Div("📊 Analyse par Bins", className="chart-card-title",
                             style={"marginTop":"18px"}))
    elements.append(_graph(fig_bin, height=fig_bin.layout.height or 300))

    # Post-hoc on bins
    if tt == "numeric" and bm_means and len(cats_bin) >= 2:
        grps_bin = {}
        for cat, b in zip(cats_bin, bin_counts.index):
            mask = (binned == b).reindex(dep.df.index, fill_value=False)
            vals = tgt_series[mask].dropna().values
            if len(vals) >= 3:
                grps_bin[cat] = vals
        ph_df = _welch_posthoc(grps_bin)
        if not ph_df.empty:
            elements.append(html.Div("🔬 Tests post-hoc bins (Welch + Holm-Bonferroni)",
                                     className="chart-card-title", style={"marginTop":"14px"}))
            elements.append(_df_table(ph_df.head(20)))

    return elements


# ══════════════════════════════════════════════════════════════════════════════
#  TEXT PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _build_text_panel(dep, col: str) -> list:
    s       = dep.df[col].dropna().astype(str)
    n       = len(s)
    lengths = s.str.split().apply(len)

    elements = []

    # Basic word stats
    info_rows = [
        ("N documents",       f"{n:,}"),
        ("Mots moy. / doc",   f"{lengths.mean():.1f}"),
        ("Mots médiane",      f"{lengths.median():.0f}"),
        ("Mots max",          f"{lengths.max():,}"),
        ("Mots min",          f"{lengths.min():,}"),
        ("Vocabulaire total", f"{len(set(' '.join(s.tolist()).split())):,}"),
    ]
    elements.append(_info_table(info_rows, "📝 Statistiques textuelles"))

    # Word length distribution
    fig_wl = go.Figure(go.Histogram(
        x=lengths, nbinsx=30,
        marker_color="#4472c4", opacity=0.85,
    ))
    fig_wl.update_layout(
        title="Distribution du nombre de mots par document",
        xaxis=dict(title="Nb mots", gridcolor=GRID, zeroline=False),
        yaxis=dict(title="Count",   gridcolor=GRID),
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=50,r=20,t=36,b=40),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
    )
    elements.append(_graph(fig_wl, height=200, mt=14))

    # Token-target correlation
    tt = _target_type(dep)
    if tt != "none":
        try:
            from sklearn.feature_extraction.text import CountVectorizer
            vec  = CountVectorizer(max_features=200, min_df=3, stop_words="english")
            X_tf = vec.fit_transform(s.tolist()).toarray()
            tgt  = dep.df.loc[s.index, dep.target_name].values

            corrs = []
            for i, token in enumerate(vec.get_feature_names_out()):
                if tt == "numeric":
                    r, p = sp_stats.pearsonr(X_tf[:, i], tgt)
                else:
                    r, p = sp_stats.pointbiserialr(
                        X_tf[:, i], (tgt == dep.classes[-1]).astype(float))
                corrs.append((token, r, p))

            corrs.sort(key=lambda x: abs(x[1]), reverse=True)
            top_n = min(20, len(corrs))
            tokens  = [c[0] for c in corrs[:top_n]]
            rvals   = [c[1] for c in corrs[:top_n]]
            colors  = ["#4472c4" if r >= 0 else "#e07b39" for r in rvals]

            fig_tok = go.Figure(go.Bar(
                y=tokens[::-1], x=rvals[::-1],
                orientation="h",
                marker_color=colors[::-1],
                text=[f"{r:.3f}" for r in rvals[::-1]],
                textposition="outside",
            ))
            fig_tok.add_vline(x=0, line_color="#999", line_width=1)
            fig_tok.update_layout(
                title=f"Top tokens — corrélation avec target ({dep.target_name})",
                xaxis=dict(title="Corrélation", gridcolor=GRID, zeroline=False),
                yaxis=dict(gridcolor=GRID, tickfont=dict(size=9)),
                plot_bgcolor=BG, paper_bgcolor="white",
                margin=dict(l=130,r=70,t=36,b=40),
                font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
            )
            elements.append(_graph(fig_tok, height=max(220, top_n*22+60), mt=14))
        except Exception as e:
            elements.append(html.Div(f"Analyse tokens indisponible : {e}",
                                     style={"color":"#6b7a8d","fontSize":"12px"}))

    return elements


# ══════════════════════════════════════════════════════════════════════════════
#  UI COMPONENT HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _mcard(label, value, sub, accent=False):
    return html.Div([
        html.Div(label, className="metric-label"),
        html.Div(value, className="metric-value" + (" metric-accent" if accent else "")),
        html.Div(sub,   className="metric-sub"),
    ], className="metric-card")


def _var_table(df: pd.DataFrame, cols: list, dtype_lbl: str) -> html.Table:
    is_num = _is_numeric_dtype(dtype_lbl)
    hdrs   = (["Variable","Dtype","N uniques","% NaN","Min","Max","Moyenne","Std"]
              if is_num else
              ["Variable","Dtype","N uniques","% NaN","Top valeurs"])

    header = html.Tr([html.Th(h, style=_th()) for h in hdrs])
    rows   = []
    for col in cols:
        s       = df[col]
        n_uniq  = s.nunique()
        pct_nan = s.isnull().mean() * 100
        nan_clr = "#e74c3c" if pct_nan > 20 else "#e07b39" if pct_nan > 5 else "#6b7a8d"

        name_cell = html.Td(
            html.Span(col,
                      id={"type":"ov-var-click","index":col},
                      n_clicks=0,
                      style={"fontWeight":"700","color":"#4472c4","fontSize":"12.5px",
                             "cursor":"pointer","textDecoration":"underline dotted",
                             "textUnderlineOffset":"3px"}),
        )
        dtype_cell = html.Td(
            html.Span(str(s.dtype),
                      style={"background":"#eef2ff","color":"#4472c4","borderRadius":"4px",
                             "padding":"1px 6px","fontSize":"10.5px","fontWeight":"600"}),
        )
        base = [name_cell, dtype_cell,
                html.Td(f"{n_uniq:,}", style=_td()),
                html.Td(f"{pct_nan:.1f}%",
                        style={**_td(),"color":nan_clr,"fontWeight":"600"})]

        if is_num:
            sn = s.dropna()
            extra = ([html.Td(f"{sn.min():.3g}", style=_td()),
                      html.Td(f"{sn.max():.3g}", style=_td()),
                      html.Td(f"{sn.mean():.3g}", style=_td()),
                      html.Td(f"{sn.std():.3g}",  style=_td())]
                     if len(sn) else [html.Td("—", style=_td())] * 4)
        else:
            top = s.value_counts().head(3)
            ts  = "  ·  ".join(f"{v} ({n})" for v,n in top.items())
            extra = [html.Td(ts[:65],
                             style={**_td(),"maxWidth":"240px","overflow":"hidden",
                                    "textOverflow":"ellipsis","whiteSpace":"nowrap"})]

        rows.append(html.Tr(base + extra,
                            style={"borderBottom":"1px solid #f0f4f8",
                                   "transition":"background .12s"},
                            className="var-row"))

    return html.Table([html.Thead(header), html.Tbody(rows)],
                      style={"width":"100%","borderCollapse":"collapse",
                             "fontSize":"12px","fontFamily":"Plus Jakarta Sans, sans-serif"})


def _info_table(rows: list, title: str = "") -> html.Div:
    tr_els = [
        html.Tr([
            html.Td(lbl, style={"padding":"5px 10px","color":"#6b7a8d",
                                 "fontWeight":"600","fontSize":"11.5px",
                                 "whiteSpace":"nowrap","width":"52%"}),
            html.Td(val, style={"padding":"5px 10px","color":"#1e3a5f",
                                 "fontWeight":"500","fontSize":"11.5px"}),
        ], style={"borderBottom":"1px solid #f0f4f8"})
        for lbl, val in rows
    ]
    children = []
    if title:
        children.append(html.Div(title, className="chart-card-title",
                                  style={"marginBottom":"8px"}))
    children.append(
        html.Table(html.Tbody(tr_els),
                   style={"width":"100%","borderCollapse":"collapse",
                          "background":"#f7f8fa","borderRadius":"8px",
                          "overflow":"hidden","marginBottom":"10px"})
    )
    return html.Div(children)


def _df_table(df_data: pd.DataFrame) -> html.Div:
    if df_data.empty:
        return html.Div()
    header = html.Tr([html.Th(c, style=_th()) for c in df_data.columns])
    body   = [
        html.Tr([
            html.Td(str(df_data.iloc[i][c])[:30], style=_td())
            for c in df_data.columns
        ], style={"borderBottom":"1px solid #f0f4f8",
                  "background":"#fff5f0" if df_data.iloc[i].get("Sig","") == "✅ p<.05"
                               else "white"})
        for i in range(len(df_data))
    ]
    return html.Div(
        html.Table([html.Thead(header), html.Tbody(body)],
                   style={"width":"100%","borderCollapse":"collapse",
                          "fontSize":"11px","fontFamily":"Plus Jakarta Sans, sans-serif",
                          "marginBottom":"12px","overflowX":"auto","display":"block"}),
        style={"overflowX":"auto","marginBottom":"12px"},
    )


def _graph(fig, height=260, mt=0) -> html.Div:
    return html.Div(
        dcc.Graph(figure=fig, config={"displayModeBar":False},
                  style={"height":f"{height}px"}),
        style={"marginTop":f"{mt}px","marginBottom":"4px"},
    )


def _th():
    return {"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10.5px","textTransform":"uppercase",
            "letterSpacing":".4px","textAlign":"left","borderBottom":"2px solid #e0e4ea",
            "whiteSpace":"nowrap"}

def _td():
    return {"padding":"4px 8px","color":"#374151","fontSize":"11px","whiteSpace":"nowrap"}


def _hex_alpha(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return f"rgba({r},{g},{b},{alpha})"
