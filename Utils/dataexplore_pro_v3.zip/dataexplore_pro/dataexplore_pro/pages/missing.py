"""
Valeurs Manquantes (NaN) — analyse complète des données manquantes.
  • Résumé par variable + bar chart
  • Heatmap de présence/absence (échantillon)
  • Matrice de co-occurrence des NaN (quelles variables manquent ensemble ?)
  • Corrélation des indicateurs NaN (MCAR heuristic)
  • Impact des NaN sur le target (mean diff)
  • Patterns de missingness (top patterns)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"
PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c"]


def layout(dep) -> html.Div:
    cols_with_nan = [c for c in dep.df.columns
                     if dep.df[c].isnull().any() and c != dep.target_name]
    has_nan = len(cols_with_nan) > 0

    return html.Div([
        html.Div("Valeurs Manquantes (NaN)", className="page-title"),
        html.Div("Analyse de la structure, des patterns et de l'impact des données manquantes.",
                 className="page-subtitle"),

        # ── Summary metrics ─────────────────────────────────────────────────
        html.Div(id="miss-summary-cards", style={"marginBottom":"16px"}),

        # ── Bar chart + heatmap presence ─────────────────────────────────────
        html.Div([
            html.Div([dcc.Graph(id="miss-bar",
                                config={"displayModeBar":False},
                                style={"height":"380px"})],
                     className="chart-card"),
            html.Div([dcc.Graph(id="miss-heatmap",
                                config={"displayModeBar":False},
                                style={"height":"380px"})],
                     className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # ── Co-occurrence + NaN correlation ──────────────────────────────────
        html.Div([
            html.Div([
                html.Div("🔗 Co-occurrence des NaN (quelles variables manquent ensemble)",
                         className="chart-card-title"),
                dcc.Graph(id="miss-cooccur",
                          config={"displayModeBar":False},
                          style={"height":"360px"}),
            ], className="chart-card"),
            html.Div([
                html.Div("📐 Corrélation des indicateurs NaN (heuristique MCAR)",
                         className="chart-card-title"),
                dcc.Graph(id="miss-corr",
                          config={"displayModeBar":False},
                          style={"height":"360px"}),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # ── Target impact + patterns ──────────────────────────────────────────
        html.Div([
            html.Div([
                html.Div("🎯 Impact NaN → Target (mean diff présent vs manquant)",
                         className="chart-card-title"),
                dcc.Graph(id="miss-target-impact",
                          config={"displayModeBar":False},
                          style={"height":"340px"}),
            ], className="chart-card"),
            html.Div([
                html.Div("🧩 Top Patterns de Missingness",
                         className="chart-card-title"),
                html.Div(id="miss-patterns"),
            ], className="chart-card"),
        ], className="charts-grid"),

    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("miss-summary-cards",   "children"),
         Output("miss-bar",             "figure"),
         Output("miss-heatmap",         "figure"),
         Output("miss-cooccur",         "figure"),
         Output("miss-corr",            "figure"),
         Output("miss-target-impact",   "figure"),
         Output("miss-patterns",        "children")],
        Input("miss-bar", "id"),
    )
    def update(_):
        df       = dep.df.drop(columns=[dep.target_name], errors="ignore")
        n_rows   = len(df)
        miss_pct = df.isnull().mean() * 100
        miss_cnt = df.isnull().sum()
        cols_nan = miss_pct[miss_pct > 0].sort_values(ascending=False)

        total_cells   = df.size
        total_missing = int(df.isnull().sum().sum())
        pct_total     = total_missing / max(total_cells, 1) * 100
        n_complete     = int((~df.isnull().any(axis=1)).sum())
        n_any_miss     = n_rows - n_complete

        # ── Summary cards ────────────────────────────────────────────────────
        cards = html.Div([
            _mcard("Cellules manquantes", f"{total_missing:,}",
                   f"{pct_total:.2f}% du total",
                   accent=pct_total > 5),
            _mcard("Variables avec NaN", f"{len(cols_nan)}",
                   f"sur {len(df.columns)} variables"),
            _mcard("Lignes complètes", f"{n_complete:,}",
                   f"{n_complete/n_rows:.1%} sans NaN"),
            _mcard("Lignes incomplètes", f"{n_any_miss:,}",
                   f"{n_any_miss/n_rows:.1%} ont ≥1 NaN",
                   accent=n_any_miss > 0),
        ], className="metric-cards")

        # ── Bar chart ────────────────────────────────────────────────────────
        if len(cols_nan) == 0:
            fig_bar = _empty_fig("✅ Aucune valeur manquante dans ce dataset !")
        else:
            colors = ["#e74c3c" if v>20 else "#e07b39" if v>5 else "#4472c4"
                      for v in cols_nan.values]
            fig_bar = go.Figure(go.Bar(
                y=cols_nan.index.tolist(),
                x=cols_nan.values,
                orientation="h",
                marker=dict(color=colors, line=dict(width=0.5, color="white")),
                text=[f"{v:.1f}%" for v in cols_nan.values],
                textposition="outside",
                hovertemplate="<b>%{y}</b><br>%{x:.2f}% manquant<extra></extra>",
            ))
            fig_bar.add_vline(x=5,  line_dash="dot", line_color="#e07b39",
                               annotation_text="5%", annotation_font_size=9)
            fig_bar.add_vline(x=20, line_dash="dot", line_color="#e74c3c",
                               annotation_text="20%", annotation_font_size=9)
            fig_bar.update_layout(
                title="% Valeurs manquantes par variable",
                xaxis=dict(title="%", range=[0,115], gridcolor=GRID),
                yaxis=dict(autorange="reversed", tickfont=dict(size=10)),
                **_base_layout(),
            )

        # ── Presence heatmap ─────────────────────────────────────────────────
        sample_n = min(300, n_rows)
        sample   = df.sample(sample_n, random_state=42) if n_rows>300 else df
        sample_sorted = sample.sort_values(
            list(cols_nan.index[:3]) if len(cols_nan) else df.columns[:1])

        fig_heat = go.Figure(go.Heatmap(
            z=sample_sorted.isnull().values.astype(int).T,
            x=[f"Obs {i}" for i in range(len(sample_sorted))],
            y=list(sample_sorted.columns),
            colorscale=[[0,"#eef2ff"],[1,"#e74c3c"]],
            showscale=True,
            colorbar=dict(tickvals=[0,1], ticktext=["Présent","Manquant"],
                          lenmode="fraction", len=0.5, thickness=12),
            hovertemplate="Col: %{y}<br>Obs: %{x}<br>%{z}<extra></extra>",
        ))
        fig_heat.update_layout(
            title=f"Présence/Absence — échantillon {sample_n} obs.",
            xaxis=dict(showticklabels=False, title="Observations"),
            yaxis=dict(tickfont=dict(size=9.5)),
            **_base_layout(),
            margin=dict(l=150, r=30, t=50, b=40),
        )

        # ── Co-occurrence matrix ──────────────────────────────────────────────
        miss_cols = list(cols_nan.index[:20])  # cap at 20
        if len(miss_cols) >= 2:
            miss_ind = df[miss_cols].isnull()
            cooc = pd.DataFrame(index=miss_cols, columns=miss_cols, dtype=float)
            for i in miss_cols:
                for j in miss_cols:
                    if i == j:
                        cooc.loc[i,j] = miss_ind[i].mean() * 100
                    else:
                        both = (miss_ind[i] & miss_ind[j]).sum()
                        cooc.loc[i,j] = both / max(miss_ind[i].sum(), 1) * 100
            z = cooc.values.astype(float)
            fig_cooc = go.Figure(go.Heatmap(
                z=z, x=miss_cols, y=miss_cols,
                colorscale=[[0,"#eef2ff"],[0.5,"#e07b39"],[1,"#e74c3c"]],
                zmin=0, zmax=100,
                text=[[f"{v:.0f}%" for v in row] for row in z],
                texttemplate="%{text}", textfont=dict(size=9),
                hovertemplate="%{y} manquant QUAND %{x} manquant: %{z:.1f}%<extra></extra>",
                colorbar=dict(title="%", thickness=12),
            ))
            fig_cooc.update_layout(
                xaxis=dict(tickangle=-40, tickfont=dict(size=9)),
                yaxis=dict(tickfont=dict(size=9)),
                **_base_layout(),
                margin=dict(l=130,r=60,t=40,b=100),
            )
        else:
            fig_cooc = _empty_fig("Moins de 2 variables avec NaN")

        # ── NaN-indicator correlation ─────────────────────────────────────────
        if len(miss_cols) >= 2:
            ind_df = df[miss_cols].isnull().astype(int)
            corr   = ind_df.corr().values
            fig_corr = go.Figure(go.Heatmap(
                z=corr, x=miss_cols, y=miss_cols,
                colorscale=[[0,"#e74c3c"],[0.5,"#ffffff"],[1,"#4472c4"]],
                zmid=0, zmin=-1, zmax=1,
                text=[[f"{v:.2f}" for v in row] for row in corr],
                texttemplate="%{text}", textfont=dict(size=9),
                hovertemplate="r(%{y}, %{x}) = %{z:.3f}<extra></extra>",
                colorbar=dict(title="r", thickness=12),
            ))
            fig_corr.update_layout(
                xaxis=dict(tickangle=-40, tickfont=dict(size=9)),
                yaxis=dict(tickfont=dict(size=9)),
                **_base_layout(),
                margin=dict(l=130,r=60,t=40,b=100),
            )
            # Note: high correlation → MAR; low/zero → MCAR hint
        else:
            fig_corr = _empty_fig("Moins de 2 variables avec NaN")

        # ── Target impact ─────────────────────────────────────────────────────
        if dep.supervised and len(miss_cols) > 0:
            tgt = dep.df[dep.target_name]
            is_cls = dep.is_classification

            impact_cols  = miss_cols[:12]
            diffs, pvals, col_names = [], [], []

            for col in impact_cols:
                present = dep.df[~dep.df[col].isnull()]
                missing = dep.df[dep.df[col].isnull()]
                if len(missing) < 5:
                    continue
                if is_cls:
                    # proportion of class[-1]
                    p_pres = (present[dep.target_name] == dep.classes[-1]).mean()
                    p_miss = (missing[dep.target_name] == dep.classes[-1]).mean()
                    diff   = p_miss - p_pres
                else:
                    p_pres = present[dep.target_name].mean()
                    p_miss = missing[dep.target_name].mean()
                    diff   = p_miss - p_pres

                from scipy.stats import ttest_ind, mannwhitneyu
                try:
                    _, pv = mannwhitneyu(
                        present[dep.target_name].dropna(),
                        missing[dep.target_name].dropna(),
                        alternative="two-sided")
                except Exception:
                    pv = 1.0

                diffs.append(diff)
                pvals.append(pv)
                col_names.append(col[:22])

            if diffs:
                colors_impact = [
                    "#e74c3c" if (pv<0.05 and d>0) else
                    "#4472c4" if (pv<0.05 and d<=0) else
                    "rgba(180,180,180,0.6)"
                    for d,pv in zip(diffs,pvals)
                ]
                fig_tgt = go.Figure(go.Bar(
                    y=col_names, x=diffs, orientation="h",
                    marker=dict(color=colors_impact,
                                line=dict(width=0.5, color="white")),
                    text=[f"{d:+.4g}  {'✅' if p<0.05 else '❌'}"
                          for d,p in zip(diffs,pvals)],
                    textposition="outside",
                    hovertemplate="<b>%{y}</b><br>Δtarget: %{x:+.4g}<extra></extra>",
                ))
                fig_tgt.add_vline(x=0, line_color="#6b7a8d", line_width=1)
                fig_tgt.update_layout(
                    xaxis=dict(title=f"Δ Target ({dep.target_name}): manquant − présent",
                               gridcolor=GRID, zeroline=False),
                    yaxis=dict(autorange="reversed", tickfont=dict(size=10)),
                    **_base_layout(),
                    margin=dict(l=160, r=80, t=40, b=50),
                )
            else:
                fig_tgt = _empty_fig("Pas assez de données manquantes pour l'analyse")
        else:
            fig_tgt = _empty_fig("Pas de target supervisé ou aucun NaN")

        # ── Missing patterns ──────────────────────────────────────────────────
        if len(miss_cols) >= 1:
            ind_df  = df[miss_cols[:15]].isnull().astype(int)
            patterns= ind_df.astype(str).agg("".join, axis=1).value_counts()
            top_pat = patterns.head(10)

            header = html.Tr([
                html.Th("Pattern (1=NaN)", style=_th()),
                html.Th("Count",          style=_th()),
                html.Th("%",              style=_th()),
                html.Th("Visualisation",  style=_th()),
            ])
            body = []
            for pat, cnt in top_pat.items():
                pct    = cnt / n_rows * 100
                bits   = list(pat)
                chips  = html.Div([
                    html.Span(miss_cols[i][:10],
                              style={"background":"#e74c3c" if b=="1" else "#eef2ff",
                                     "color":"white" if b=="1" else "#4472c4",
                                     "padding":"1px 5px","borderRadius":"3px",
                                     "fontSize":"9.5px","margin":"1px","fontWeight":"600"})
                    for i, b in enumerate(bits) if i < len(miss_cols)
                ], style={"display":"flex","flexWrap":"wrap","gap":"2px"})
                body.append(html.Tr([
                    html.Td(pat, style={**_td(),"fontFamily":"monospace",
                                        "letterSpacing":"1px","fontSize":"11px"}),
                    html.Td(f"{cnt:,}", style=_td()),
                    html.Td(f"{pct:.1f}%",
                            style={**_td(),
                                   "fontWeight":"700",
                                   "color":"#e74c3c" if pct>20 else "#374151"}),
                    html.Td(chips),
                ], style={"borderBottom":"1px solid #f0f4f8"}))

            pat_table = html.Table(
                [html.Thead(header), html.Tbody(body)],
                style={"width":"100%","borderCollapse":"collapse",
                       "fontFamily":FONT,"fontSize":"12px"}
            )
            legend = html.Div([
                html.Span("Variables: ", style={"fontSize":"10px","color":"#6b7a8d"}),
                *[html.Span(c[:12],
                            style={"fontSize":"9.5px","marginRight":"6px",
                                   "color":"#4472c4"})
                  for c in miss_cols[:15]],
            ], style={"marginBottom":"8px"})
            patterns_el = html.Div([legend, pat_table])
        else:
            patterns_el = html.Div("Aucun NaN détecté.",
                                   style={"color":"#6b7a8d","padding":"12px"})

        return (cards, fig_bar, fig_heat, fig_cooc,
                fig_corr, fig_tgt, patterns_el)


def _mcard(label, value, sub, accent=False):
    return html.Div([
        html.Div(label, className="metric-label"),
        html.Div(value, className="metric-value" + (" metric-accent" if accent else "")),
        html.Div(sub,   className="metric-sub"),
    ], className="metric-card")


def _empty_fig(msg=""):
    fig = go.Figure()
    fig.add_annotation(text=msg, xref="paper", yref="paper",
                       x=0.5, y=0.5, showarrow=False,
                       font=dict(size=13, color="#6b7a8d"))
    fig.update_layout(plot_bgcolor="white", paper_bgcolor="white",
                      margin=dict(l=20,r=20,t=20,b=20))
    return fig


def _base_layout():
    return dict(plot_bgcolor=BG, paper_bgcolor="white",
                font=dict(family=FONT, size=11))


def _th():
    return {"padding":"5px 8px","background":"#f0f4f8","color":"#6b7a8d",
            "fontWeight":"700","fontSize":"10.5px","textTransform":"uppercase",
            "letterSpacing":".4px","borderBottom":"2px solid #e0e4ea",
            "textAlign":"left","whiteSpace":"nowrap"}

def _td():
    return {"padding":"4px 8px","color":"#374151","fontSize":"11.5px"}
