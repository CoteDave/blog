"""
Analyses 3D — scatter 3D avancé avec couleur, taille, annotations.
  • Scatter 3D coloré par target ou par variable continue
  • Taille des points pilotable par une 4ème variable
  • Ellipsoïdes de confiance par classe (95%)
  • Paires de scatter 2D (matrice Splom)
  • Projection sur les 3 plans 2D
  • Stats : distances inter-centroids, chevauchement de classes
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep) -> html.Div:
    num      = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]
    defaults = (num + [None]*3)[:3]

    color_opts = [{"label": "Target (classes)", "value": "__target__"}] + col_opts \
                 if dep.supervised else col_opts

    return html.Div([
        html.Div("Analyses 3D", className="page-title"),
        html.Div("Scatter 3D interactif — 4 dimensions, ellipsoïdes de confiance, matrice de projections.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Axe X:", className="control-label"),
                      dcc.Dropdown(id="a3d-x", options=col_opts, value=defaults[0],
                                   clearable=False, style={"width":"200px"})],
                     className="control-group"),
            html.Div([html.Div("Axe Y:", className="control-label"),
                      dcc.Dropdown(id="a3d-y", options=col_opts, value=defaults[1],
                                   clearable=False, style={"width":"200px"})],
                     className="control-group"),
            html.Div([html.Div("Axe Z:", className="control-label"),
                      dcc.Dropdown(id="a3d-z", options=col_opts, value=defaults[2],
                                   clearable=False, style={"width":"200px"})],
                     className="control-group"),
            html.Div([html.Div("Couleur:", className="control-label"),
                      dcc.Dropdown(id="a3d-color",
                                   options=color_opts,
                                   value="__target__" if dep.supervised else (num[0] if num else None),
                                   clearable=False, style={"width":"200px"})],
                     className="control-group"),
            html.Div([html.Div("Taille ∝ var.:", className="control-label"),
                      dcc.Dropdown(id="a3d-size-col", options=[{"label":"(uniforme)","value":"__none__"}]+col_opts,
                                   value="__none__", clearable=False, style={"width":"180px"})],
                     className="control-group"),
        ], className="controls-row"),

        html.Div([
            html.Div([
                dcc.Checklist(id="a3d-options",
                              options=[{"label":" Ellipsoïdes de confiance (95%)", "value":"ellipse"},
                                       {"label":" Afficher centroids",             "value":"centroids"}],
                              value=["centroids"] if dep.supervised else [],
                              inline=True,
                              inputStyle={"marginRight":"4px"},
                              labelStyle={"marginRight":"16px","fontSize":"13px"}),
            ], className="control-group"),
            html.Div([html.Div("Taille points:", className="control-label"),
                      dcc.Slider(id="a3d-ptsize", min=2, max=14, step=1, value=5,
                                 marks={2:"2",5:"5",10:"10",14:"14"},
                                 tooltip={"placement":"bottom","always_visible":False})],
                     className="control-group", style={"minWidth":"220px"}),
        ], className="controls-row"),

        # Main 3D + stats
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="a3d-main", config={"displayModeBar":True},
                                style={"height":"520px"}), type="circle", color="#4472c4")],
                     className="chart-card"),
            html.Div([html.Div(id="a3d-stats-panel")],
                     className="chart-card"),
        ], className="charts-grid", style={"marginBottom":"16px"}),

        # Splom matrix
        html.Div([
            html.Div("🗺️ Matrice de Scatter 2D (SPLOM) — top 6 features",
                     className="chart-card-title"),
            dcc.Loading(dcc.Graph(id="a3d-splom", config={"displayModeBar":True},
                          style={"height":"600px"}), type="circle", color="#4472c4"),
        ], className="chart-card", style={"marginBottom":"16px"}),

        # 2D projections
        html.Div([
            html.Div("📐 Projections 2D sur les 3 plans (XY / XZ / YZ)",
                     className="chart-card-title"),
            dcc.Loading(dcc.Graph(id="a3d-proj", config={"displayModeBar":False},
                      style={"height":"300px"}), type="circle", color="#4472c4"),
        ], className="chart-card"),

    ], className="page-card")


def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("a3d-main",        "figure"),
         Output("a3d-stats-panel", "children"),
         Output("a3d-splom",       "figure"),
         Output("a3d-proj",        "figure")],
        [Input("a3d-x",        "value"),
         Input("a3d-y",        "value"),
         Input("a3d-z",        "value"),
         Input("a3d-color",    "value"),
         Input("a3d-size-col", "value"),
         Input("a3d-ptsize",   "value"),
         Input("a3d-options",  "value")],
    )
    def update(x_col, y_col, z_col, color_col, size_col, pt_size, options):
        options  = options or []
        pt_size  = pt_size or 5
        use_cls  = color_col == "__target__" and dep.supervised
        use_size = size_col != "__none__" and size_col is not None

        if not all([x_col, y_col, z_col]):
            empty = go.Figure()
            return empty, [], empty, empty

        df     = dep.df.copy()
        cols_needed = list({x_col, y_col, z_col} |
                           ({size_col} if use_size else set()))
        df_clean = df.dropna(subset=cols_needed)

        # Marker sizes
        if use_size:
            sv   = df_clean[size_col].values
            sv_n = (sv - sv.min()) / max(sv.max()-sv.min(), 1e-9)
            sizes= (sv_n * 14 + 4).clip(2, 18)
        else:
            sizes = pt_size

        # ── Main 3D ──────────────────────────────────────────────────────────
        fig3d = go.Figure()

        if use_cls:
            groups = [(cls, df_clean[df_clean[dep.target_name]==cls], PAL[i%len(PAL)])
                      for i, cls in enumerate(dep.classes)]
        else:
            # Color by continuous variable
            if color_col and color_col in df_clean.columns:
                cv = df_clean[color_col].values
                groups = [(color_col, df_clean, cv)]
            else:
                groups = [("Données", df_clean, "#4472c4")]

        centroids = {}
        for item in groups:
            if use_cls:
                lbl, sub, clr = item
                cv = clr
            else:
                lbl, sub, cv = item

            marker = dict(
                size=sizes if not use_size else sizes[sub.index.isin(df_clean.index)],
                color=cv if not use_cls else cv,
                opacity=0.78,
                line=dict(width=0.3, color="rgba(255,255,255,.4)"),
            )
            if isinstance(cv, str):
                marker["color"] = cv
            else:
                marker["colorscale"] = "Viridis"
                marker["showscale"]  = True

            fig3d.add_trace(go.Scatter3d(
                x=sub[x_col], y=sub[y_col], z=sub[z_col],
                mode="markers", name=str(lbl)[:25],
                marker=marker,
                hovertemplate=(
                    f"<b>Cls {lbl}</b><br>"
                    f"{x_col}: %{{x:.3g}}<br>"
                    f"{y_col}: %{{y:.3g}}<br>"
                    f"{z_col}: %{{z:.3g}}"
                    "<extra></extra>"
                ),
            ))

            if use_cls:
                cx = float(sub[x_col].mean())
                cy = float(sub[y_col].mean())
                cz = float(sub[z_col].mean())
                centroids[lbl] = (cx, cy, cz, clr)

                if "ellipse" in options and len(sub) >= 4:
                    _add_ellipsoid(fig3d, sub[[x_col,y_col,z_col]].dropna(), clr)

        # Centroids
        if "centroids" in options and centroids:
            for lbl, (cx, cy, cz, clr) in centroids.items():
                fig3d.add_trace(go.Scatter3d(
                    x=[cx], y=[cy], z=[cz],
                    mode="markers+text",
                    text=[f"C{lbl}"],
                    textfont=dict(size=12, color="white"),
                    marker=dict(color=clr, size=14, opacity=1.0,
                                symbol="diamond",
                                line=dict(color="white", width=2)),
                    showlegend=False, hoverinfo="skip",
                ))

        fig3d.update_layout(
            title=f"Scatter 3D — {x_col} / {y_col} / {z_col}",
            scene=dict(
                xaxis=dict(title=x_col[:20], gridcolor=GRID, backgroundcolor=BG),
                yaxis=dict(title=y_col[:20], gridcolor=GRID, backgroundcolor=BG),
                zaxis=dict(title=z_col[:20], gridcolor=GRID, backgroundcolor=BG),
                bgcolor="white",
            ),
            paper_bgcolor="white",
            margin=dict(l=0,r=0,t=50,b=0),
            font=dict(family=FONT, size=11),
            legend=dict(font=dict(size=11), bgcolor="rgba(255,255,255,.9)",
                        borderwidth=1, bordercolor=GRID),
        )

        # ── Stats panel ───────────────────────────────────────────────────────
        stats_children = _stats_panel(dep, df_clean, x_col, y_col, z_col,
                                       centroids, use_cls)

        # ── SPLOM ─────────────────────────────────────────────────────────────
        splom_cols = list(dict.fromkeys([x_col, y_col, z_col] +
                                         dep.num_features[:6]))[:6]
        fig_splom  = _splom(dep, df_clean, splom_cols, use_cls)

        # ── 2D Projections ────────────────────────────────────────────────────
        fig_proj = _projections(dep, df_clean, x_col, y_col, z_col, use_cls)

        return fig3d, stats_children, fig_splom, fig_proj


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _add_ellipsoid(fig, df_xyz, color, n_pts=30, conf=0.95):
    """Add a 95% confidence ellipsoid surface around a group."""
    try:
        from scipy.stats import chi2
        vals = df_xyz.values
        mean = vals.mean(axis=0)
        cov  = np.cov(vals.T)
        if np.linalg.matrix_rank(cov) < 3:
            return
        eigvals, eigvecs = np.linalg.eigh(cov)
        radii = np.sqrt(eigvals * chi2.ppf(conf, df=3))

        u = np.linspace(0, 2*np.pi, n_pts)
        v = np.linspace(0, np.pi, n_pts)
        x = radii[0] * np.outer(np.cos(u), np.sin(v))
        y = radii[1] * np.outer(np.sin(u), np.sin(v))
        z = radii[2] * np.outer(np.ones_like(u), np.cos(v))

        xyz = np.dot(eigvecs, np.array([x.ravel(), y.ravel(), z.ravel()])) + mean[:, None]
        x_e = xyz[0].reshape(n_pts, n_pts) 
        y_e = xyz[1].reshape(n_pts, n_pts)
        z_e = xyz[2].reshape(n_pts, n_pts)

        r,g,b = tuple(int(color.lstrip("#")[i:i+2], 16) for i in (0,2,4))
        fig.add_trace(go.Surface(
            x=x_e, y=y_e, z=z_e,
            opacity=0.10,
            colorscale=[[0,f"rgba({r},{g},{b},.1)"],[1,f"rgba({r},{g},{b},.15)"]],
            showscale=False, hoverinfo="skip",
        ))
    except Exception:
        pass


def _stats_panel(dep, df_clean, x_col, y_col, z_col, centroids, use_cls):
    from scipy.spatial.distance import euclidean
    children = [html.Div("📊 Statistiques 3D", className="chart-card-title")]

    # Basic stats per axis
    for col in [x_col, y_col, z_col]:
        v = df_clean[col].dropna().values
        children.append(_stat_row(col,
            f"μ={v.mean():.3g}  σ={v.std():.3g}  [{v.min():.3g}–{v.max():.3g}]"))

    children.append(html.Hr(style={"margin":"8px 0","borderColor":GRID}))
    children.append(html.Div(f"N observations: {len(df_clean):,}",
                             style={"fontSize":"12px","color":"#6b7a8d","marginBottom":"6px"}))

    if use_cls and centroids and len(centroids) >= 2:
        children.append(html.Div("Distances inter-centroids (Euclidean):",
                                  style={"fontSize":"11px","fontWeight":"700",
                                         "color":"#1e3a5f","margin":"8px 0 4px 0"}))
        cls_list = list(centroids.keys())
        for i in range(len(cls_list)):
            for j in range(i+1, len(cls_list)):
                c1 = centroids[cls_list[i]][:3]
                c2 = centroids[cls_list[j]][:3]
                d  = euclidean(c1, c2)
                children.append(
                    _stat_row(f"Cls {cls_list[i]} ↔ {cls_list[j]}", f"d = {d:.4g}")
                )

        # Overlap heuristic: % points of class i closer to centroid j
        children.append(html.Div("Chevauchement (% mal assigné centroid):",
                                  style={"fontSize":"11px","fontWeight":"700",
                                         "color":"#1e3a5f","margin":"8px 0 4px 0"}))
        for cls in dep.classes:
            sub = df_clean[df_clean[dep.target_name]==cls][[x_col,y_col,z_col]].dropna()
            if len(sub) < 2:
                continue
            pts = sub.values
            # Distance to own centroid vs nearest other centroid
            own_c = np.array(centroids[cls][:3])
            other_cs = [np.array(centroids[c][:3]) for c in dep.classes if c != cls]
            if not other_cs:
                continue
            d_own   = np.linalg.norm(pts - own_c, axis=1)
            d_other = np.min([np.linalg.norm(pts - oc, axis=1) for oc in other_cs], axis=0)
            overlap = (d_other < d_own).mean()
            children.append(
                _stat_row(f"Cls {cls}",
                          f"{overlap:.1%} proches d'une autre classe",
                          color="#e74c3c" if overlap > 0.2 else "#27ae60")
            )

    return children


def _stat_row(label, value, color="#374151"):
    return html.Div([
        html.Span(label[:28], style={"fontSize":"11px","color":"#6b7a8d",
                                      "fontWeight":"600","minWidth":"120px",
                                      "display":"inline-block"}),
        html.Span(value, style={"fontSize":"11px","color":color,"fontWeight":"500"}),
    ], style={"marginBottom":"4px","padding":"3px 0",
              "borderBottom":"1px solid #f5f5f5"})


def _splom(dep, df_clean, cols, use_cls):
    """Scatter matrix (SPLOM)."""
    cols = [c for c in cols if c in df_clean.columns][:6]
    if len(cols) < 2:
        return go.Figure()

    if use_cls:
        dimensions = [dict(label=c[:14], values=df_clean[c]) for c in cols]
        color_arr  = pd.Categorical(df_clean[dep.target_name]).codes
        fig = go.Figure(go.Splom(
            dimensions=dimensions,
            showupperhalf=False,
            diagonal_visible=True,
            marker=dict(
                color=color_arr,
                colorscale=[[i/max(len(PAL)-1,1), c] for i,c in enumerate(PAL[:len(dep.classes)])],
                size=3.5, opacity=0.65,
                showscale=False,
                line=dict(width=0.2, color="rgba(255,255,255,.3)"),
            ),
        ))
    else:
        dimensions = [dict(label=c[:14], values=df_clean[c]) for c in cols]
        fig = go.Figure(go.Splom(
            dimensions=dimensions,
            showupperhalf=False,
            diagonal_visible=True,
            marker=dict(color="#4472c4", size=3, opacity=0.6),
        ))

    fig.update_layout(
        title=f"SPLOM — {', '.join(c[:10] for c in cols)}",
        plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=80,r=20,t=50,b=80),
        font=dict(family=FONT, size=10),
        dragmode="select",
    )
    return fig


def _projections(dep, df_clean, x_col, y_col, z_col, use_cls):
    """3-panel 2D projections (XY, XZ, YZ)."""
    plans = [(x_col, y_col, "Plan XY"), (x_col, z_col, "Plan XZ"), (y_col, z_col, "Plan YZ")]

    fig = make_subplots(rows=1, cols=3, subplot_titles=[p[2] for p in plans])

    for col_idx, (cx, cy, ptitle) in enumerate(plans, 1):
        if use_cls:
            for i, cls in enumerate(dep.classes):
                sub = df_clean[df_clean[dep.target_name]==cls]
                clr = PAL[i%len(PAL)]
                fig.add_trace(go.Scatter(
                    x=sub[cx], y=sub[cy], mode="markers",
                    name=f"Cls {cls}" if col_idx==1 else None,
                    marker=dict(color=clr, size=4, opacity=0.65,
                                line=dict(width=0.2, color="rgba(255,255,255,.3)")),
                    showlegend=(col_idx==1),
                    hovertemplate=f"Cls {cls}: ({cx}=%{{x:.3g}}, {cy}=%{{y:.3g}})<extra></extra>",
                ), row=1, col=col_idx)
        else:
            fig.add_trace(go.Scatter(
                x=df_clean[cx], y=df_clean[cy], mode="markers",
                marker=dict(color="#4472c4", size=4, opacity=0.65),
                showlegend=False,
            ), row=1, col=col_idx)

        fig.update_xaxes(title_text=cx[:14], gridcolor=GRID, row=1, col=col_idx)
        fig.update_yaxes(title_text=cy[:14], gridcolor=GRID, row=1, col=col_idx)

    fig.update_layout(
        title="Projections 2D",
        plot_bgcolor=BG, paper_bgcolor="white",
        margin=dict(l=50,r=20,t=60,b=50),
        font=dict(family=FONT, size=10),
        legend=dict(font=dict(size=10)),
    )
    return fig
