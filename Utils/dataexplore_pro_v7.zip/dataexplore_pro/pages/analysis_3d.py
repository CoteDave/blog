"""
Analyses 3D v7 — Scatter3D + SPLOM + Ellipsoïdes + 2D projections
  • Utilise display_df (≤50k) + Scatter3d WebGL
  • PCA projection depuis cache
"""
from __future__ import annotations
import numpy as np
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"

def _a(h,a):
    h=h.lstrip("#"); r,g,b=int(h[:2],16),int(h[2:4],16),int(h[4:],16)
    return f"rgba({r},{g},{b},{a})"


def layout(dep):
    num=dep.num_features
    opts=[{"label":c,"value":c} for c in num]
    tgt_opts=[{"label":"Target (couleur)","value":dep.target_name}]+opts if dep.supervised else opts
    modes=[{"label":"Scatter 4D","value":"scatter4d"},
           {"label":"Ellipsoïdes","value":"ellipsoid"},
           {"label":"SPLOM","value":"splom"},
           {"label":"Projections 2D","value":"proj2d"}]
    return html.Div([
        html.Div("Analyses 3D & 4D",className="page-title"),
        html.Div("Scatter3D WebGL · SPLOM · ellipsoïdes de confiance · projections 2D.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Variable X:",className="control-label"),
                      dcc.Dropdown(id="a3-x",options=opts,value=num[0],clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Variable Y:",className="control-label"),
                      dcc.Dropdown(id="a3-y",options=opts,value=num[1] if len(num)>1 else num[0],clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Variable Z:",className="control-label"),
                      dcc.Dropdown(id="a3-z",options=opts,value=num[2] if len(num)>2 else num[0],clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Couleur (4D):",className="control-label"),
                      dcc.Dropdown(id="a3-col",options=tgt_opts,
                                   value=dep.target_name if dep.supervised else num[0],clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Mode:",className="control-label"),
                      dcc.Dropdown(id="a3-mode",options=modes,value="scatter4d",clearable=False)],
                     className="control-group",style={"maxWidth":"200px"}),
            html.Div([html.Div("Taille pts:",className="control-label"),
                      dcc.Slider(id="a3-ptsize",min=2,max=10,step=1,value=4,
                                 marks={2:"2",4:"4",6:"6",10:"10"},tooltip={"placement":"bottom"})],
                     className="control-group",style={"minWidth":"200px"}),
            html.Div([html.Div("Options:",className="control-label"),
                      dcc.Checklist(id="a3-opts",
                                    options=[{"label":" Ellipsoïde","value":"ell"}],
                                    value=["ell"],inline=True,labelStyle={"fontSize":"12.5px"})],
                     className="control-group"),
        ],className="controls-row"),
        html.Div([dcc.Loading(html.Div(id="a3-graph-wrap"),type="circle",color="#4472c4")],
                 className="chart-card"),
    ],className="page-card")


def register_callbacks(app, dep):

    @app.callback(Output("a3-graph-wrap","children"),
        [Input("a3-x","value"),Input("a3-y","value"),Input("a3-z","value"),
         Input("a3-col","value"),Input("a3-mode","value"),
         Input("a3-ptsize","value"),Input("a3-opts","value")])
    def update(xc,yc,zc,cc,mode,ptsize,opts):
        df   = dep.display_df
        ptsize = ptsize or 4
        opts   = opts or []

        if mode=="splom":
            dims_cols = [xc,yc,zc,cc] if cc!=dep.target_name else [xc,yc,zc]
            dims_cols = list(dict.fromkeys(c for c in dims_cols if c in dep.num_features))[:5]
            dims = [dict(label=c,values=df[c]) for c in dims_cols]
            color=df[dep.target_name].values if dep.supervised else df[xc].values
            fig  = go.Figure(go.Splom(dimensions=dims,marker=dict(color=color,size=4,
                opacity=0.7,showscale=dep.is_classification if dep.supervised else False,
                colorscale="Portland" if not (dep.supervised and dep.is_classification) else None),
                showlowerhalf=True,showupperhalf=False,diagonal=dict(visible=True)))
            fig.update_layout(paper_bgcolor="#fff",height=520,
                              font=dict(family=FONT,size=10),
                              title=dict(text="SPLOM",font=dict(size=12,color="#1e3a5f")),
                              margin=dict(l=30,r=20,t=44,b=30))
            return dcc.Graph(figure=fig,config={"displayModeBar":True},style={"height":"520px"})

        if mode=="proj2d":
            pairs=[(xc,yc),(xc,zc),(yc,zc)]
            fig=make_subplots(rows=1,cols=3,subplot_titles=[f"{a} × {b}" for a,b in pairs])
            for i,(a,b) in enumerate(pairs):
                if dep.supervised and dep.is_classification:
                    for j,cls in enumerate(dep.classes):
                        m=df[dep.target_name]==cls
                        fig.add_trace(go.Scattergl(x=df[m][a],y=df[m][b],mode="markers",
                            name=f"Cls {cls}" if i==0 else None,showlegend=i==0,
                            marker=dict(color=PAL[j%len(PAL)],size=4,opacity=0.7,line=dict(width=0))),
                            row=1,col=i+1)
                else:
                    fig.add_trace(go.Scattergl(x=df[a],y=df[b],mode="markers",showlegend=False,
                        marker=dict(color="#4472c4",size=4,opacity=0.7,line=dict(width=0))),row=1,col=i+1)
            fig.update_layout(paper_bgcolor="#fff",plot_bgcolor=BG,height=350,
                               font=dict(family=FONT,size=10),
                               title=dict(text="Projections 2D",font=dict(size=12,color="#1e3a5f")),
                               margin=dict(l=40,r=20,t=60,b=40))
            for ax in fig.layout:
                if ax.startswith("xaxis") or ax.startswith("yaxis"):
                    fig.layout[ax].update(gridcolor=GRID,zeroline=False)
            return dcc.Graph(figure=fig,config={"displayModeBar":False},style={"height":"350px"})

        # scatter4d / ellipsoid
        fig = go.Figure()
        color_arr = df[cc].values if cc in df.columns else df[xc].values
        is_cat = dep.supervised and dep.is_classification and cc==dep.target_name

        if is_cat:
            for i,cls in enumerate(dep.classes):
                m=df[dep.target_name]==cls; clr=PAL[i%len(PAL)]
                fig.add_trace(go.Scatter3d(x=df[m][xc],y=df[m][yc],z=df[m][zc],
                    mode="markers",name=f"Cls {cls} (n={m.sum():,})",
                    marker=dict(color=clr,size=ptsize,opacity=0.75)))
                if "ell" in opts and m.sum()>=10:
                    _add_ellipsoid(fig,df[m][xc].values,df[m][yc].values,df[m][zc].values,clr)
        else:
            fig.add_trace(go.Scatter3d(x=df[xc],y=df[yc],z=df[zc],mode="markers",
                marker=dict(color=color_arr,size=ptsize,opacity=0.75,
                            colorscale="Viridis",showscale=True,
                            colorbar=dict(title=cc[:14],thickness=10)),
                hovertemplate=f"{xc}:%{{x:.3g}}<br>{yc}:%{{y:.3g}}<br>{zc}:%{{z:.3g}}<extra></extra>"))

        fig.update_layout(
            scene=dict(xaxis_title=xc,yaxis_title=yc,zaxis_title=zc,
                        bgcolor=BG,
                        xaxis=dict(gridcolor=GRID,zeroline=False),
                        yaxis=dict(gridcolor=GRID,zeroline=False),
                        zaxis=dict(gridcolor=GRID,zeroline=False)),
            paper_bgcolor="#fff",height=560,
            title=dict(text="Scatter 4D",font=dict(size=12,color="#1e3a5f")),
            legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)"),
            font=dict(family=FONT,size=11),margin=dict(l=0,r=0,t=44,b=0))
        return dcc.Graph(figure=fig,config={"displayModeBar":True},style={"height":"560px"})


def _add_ellipsoid(fig,x,y,z,color,n_pts=20):
    """Confidence ellipsoid (95%) via covariance eigendecomposition."""
    try:
        data = np.column_stack([x,y,z])
        data = data[~np.isnan(data).any(axis=1)]
        if len(data)<4: return
        mu = data.mean(axis=0)
        cov= np.cov(data.T)
        vals,vecs=np.linalg.eigh(cov)
        vals=np.clip(vals,0,None)
        r = np.sqrt(vals)*2.45  # chi2 95% for 3 dof
        u=np.linspace(0,2*np.pi,n_pts); v=np.linspace(0,np.pi,n_pts)
        sph=np.array([np.outer(np.cos(u),np.sin(v)),
                       np.outer(np.sin(u),np.sin(v)),
                       np.outer(np.ones_like(u),np.cos(v))])
        ell=np.einsum("ij,jkl->ikl",vecs,(sph*r[:,None,None]))+mu[:,None,None]
        c=color.lstrip("#"); rgb=int(c[:2],16),int(c[2:4],16),int(c[4:],16)
        fig.add_trace(go.Surface(x=ell[0],y=ell[1],z=ell[2],showscale=False,
                                  opacity=0.12,
                                  colorscale=[[0,f"rgba({rgb[0]},{rgb[1]},{rgb[2]},.12)"],
                                              [1,f"rgba({rgb[0]},{rgb[1]},{rgb[2]},.12)"]],
                                  hoverinfo="skip",showlegend=False))
    except: pass
