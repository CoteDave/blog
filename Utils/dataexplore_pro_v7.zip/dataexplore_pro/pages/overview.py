"""
Aperçu Global v7 — lit tout depuis dep.cache
  • Catalogue trié par IV/η² depuis le cache (précalculé)
  • Détail panel : stats depuis cache.fstats (O(1))
  • Mini-charts sur display_df uniquement
  • Aucun calcul lourd dans les callbacks
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output, ALL, ctx, no_update
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"

IV_LABELS = [(0.5,"Très fort"),(0.3,"Fort"),(0.1,"Moyen"),(0.02,"Faible"),(0.0,"Nul")]
def _iv_lbl(v):
    for t,l in IV_LABELS:
        if v>=t: return l
    return "Nul"
def _iv_clr(v):
    if v>=0.3: return "#27ae60"
    if v>=0.1: return "#f39c12"
    if v>=0.02:return "#4472c4"
    return "#9aa5b4"


def layout(dep):
    num = dep.num_features
    n, p = len(dep.df), len(num)
    n_cat = len(dep.cat_features)
    n_missing = int(dep.df[num].isnull().any(axis=1).sum()) if num else 0
    mode_lbl = ("Classification" if dep.is_classification else "Régression") if dep.supervised else "Non supervisé"

    return html.Div([
        html.Div("Aperçu Global", className="page-title"),
        html.Div("Catalogue de variables · stats précalculées · cliquer pour le détail.",
                 className="page-subtitle"),

        # KPI cards
        html.Div([
            _kpi(f"{n:,}",         "Observations",    "#4472c4"),
            _kpi(f"{p}",           "Features num.",   "#e07b39"),
            _kpi(f"{n_cat}",       "Features cat.",   "#27ae60"),
            _kpi(f"{n_missing:,}", "Lignes avec NaN", "#e74c3c"),
            _kpi(mode_lbl,         "Mode",            "#9b59b6"),
        ], className="metric-cards"),

        # Catalog + detail panel
        html.Div([
            html.Div([
                html.Div(id="ov-sort-store", style={"display":"none"}, children="iv"),
                _sort_bar(),
                html.Div(id="ov-catalog", style={"overflowY":"auto","maxHeight":"600px"}),
            ], style={"width":"55%","minWidth":"320px"}),
            html.Div(id="ov-detail-panel",
                     style={"flex":"1","minWidth":"300px","maxHeight":"640px"}),
        ], style={"display":"flex","gap":"18px","alignItems":"flex-start"}),

    ], className="page-card")


def _kpi(val, label, color):
    return html.Div([
        html.Div(label, className="metric-label"),
        html.Div(val,   className="metric-value", style={"color":color}),
    ], className="metric-card")


def _sort_bar():
    return html.Div([
        html.Span("Trier par:", style={"fontSize":"11px","color":"#6b7a8d","marginRight":"8px","fontWeight":"600"}),
        *[html.Span(lbl, id={"type":"ov-sort","index":key},
                    style={"cursor":"pointer","fontSize":"11px","padding":"3px 8px",
                           "borderRadius":"99px","marginRight":"4px",
                           "background":"rgba(68,114,196,.12)","color":"#2e5fb3","fontWeight":"600"})
          for lbl, key in [("IV/η²","iv"),("Nom","name"),("NaN%","nan"),("Skewness","skew"),("Outliers","out")]],
    ], style={"marginBottom":"10px","display":"flex","alignItems":"center","flexWrap":"wrap","gap":"4px"})


def register_callbacks(app, dep):

    @app.callback(
        Output("ov-sort-store","children"),
        Input({"type":"ov-sort","index":ALL},"n_clicks"),
        prevent_initial_call=True,
    )
    def update_sort(_):
        t = ctx.triggered_id
        return t.get("index","iv") if isinstance(t,dict) else "iv"

    @app.callback(
        Output("ov-catalog","children"),
        [Input("ov-sort-store","children")],
    )
    def render_catalog(sort_key):
        num  = dep.num_features
        fst  = dep.cache.get("fstats")
        iv_d = dep.cache.get("iv", default={}, wait=False) or {}

        rows = []
        for i, col in enumerate(num):
            iv    = float(iv_d.get(col, 0.0))
            nan_p = float(fst["nan_pct"][i]*100) if fst else 0.0
            skw   = float(fst["skew"][i])        if fst else 0.0
            out_p = float(fst["outlier_pct"][i]*100) if fst else 0.0
            rows.append({"col":col,"iv":iv,"nan":nan_p,"skew":skw,"out":out_p,"idx":i})

        key_map = {"iv":"iv","name":"col","nan":"nan","skew":"skew","out":"out"}
        rows.sort(key=lambda r: r[key_map.get(sort_key,"iv")],
                  reverse=(sort_key != "name"))

        items = [html.Div([
            html.Span(f"{'▮'*min(3,max(1,int(r['iv']*10)))}", style={"color":_iv_clr(r['iv']),"marginRight":"8px","fontSize":"10px"}),
            html.Span(r["col"][:26], style={"fontWeight":"600","fontSize":"12px","color":"#1e3a5f",
                                             "flexGrow":"1","overflow":"hidden","textOverflow":"ellipsis","whiteSpace":"nowrap"}),
            html.Span(_iv_lbl(r["iv"]),
                      style={"fontSize":"10px","padding":"1px 6px","borderRadius":"99px","marginRight":"6px",
                             "background":_iv_clr(r['iv'])+"22","color":_iv_clr(r['iv']),"fontWeight":"700"}),
            html.Span(f"NaN {r['nan']:.1f}%", style={"fontSize":"10px","color":"#e74c3c" if r["nan"]>10 else "#9aa5b4","marginRight":"6px"}),
            html.Span(f"skew {r['skew']:+.1f}", style={"fontSize":"10px","color":"#f39c12" if abs(r['skew'])>2 else "#9aa5b4"}),
        ], id={"type":"ov-row","index":r["col"]},
           className="var-row",
           style={"display":"flex","alignItems":"center","padding":"6px 10px",
                  "borderBottom":"1px solid #f5f5f5","borderRadius":"6px",
                  "background":"#fff"},
           n_clicks=0) for r in rows]

        return items

    @app.callback(
        Output("ov-detail-panel","children"),
        Input({"type":"ov-row","index":ALL},"n_clicks"),
        prevent_initial_call=True,
    )
    def show_detail(ncs):
        t = ctx.triggered_id
        if not isinstance(t,dict): return no_update
        col = t.get("index")
        if not col or col not in dep.num_features: return no_update
        return _detail_panel(dep, col)


def _detail_panel(dep, col):
    """Build detail panel entirely from cache — zero heavy compute."""
    num = dep.num_features
    idx = num.index(col)
    fst = dep.cache.get("fstats")
    iv_d = dep.cache.get("iv", default={}, wait=False) or {}

    # Stats from cache
    def _g(key): return float(fst[key][idx]) if fst and key in fst else float("nan")

    mean_v = _g("mean"); std_v = _g("std"); med_v = _g("q50")
    q25 = _g("q25"); q75 = _g("q75"); skw = _g("skew"); krt = _g("kurt")
    nan_p = _g("nan_pct")*100; out_p = _g("outlier_pct")*100
    iv    = float(iv_d.get(col, 0.0))

    # Mini histogram — display_df only (fast)
    vals  = dep.display_df[col].dropna()
    fig_h = go.Figure(go.Histogram(x=vals, nbinsx=25,
                                    marker_color="#4472c4", opacity=0.78,
                                    hovertemplate=f"{col}: %{{x}}<br>N: %{{y}}<extra></extra>"))
    if dep.supervised and dep.is_classification:
        for i,cls in enumerate(dep.classes):
            sv = dep.display_df[dep.display_df[dep.target_name]==cls][col].dropna()
            fig_h.add_trace(go.Histogram(x=sv, nbinsx=25, name=f"Cls {cls}",
                                          marker_color=PAL[i%len(PAL)], opacity=0.6))
        fig_h.update_layout(barmode="overlay")

    fig_h.add_vline(x=float(mean_v), line_dash="dash", line_color="#e07b39",
                    line_width=1.5, annotation_text=f"μ={mean_v:.3g}", annotation_font_size=8)
    fig_h.update_layout(plot_bgcolor=BG, paper_bgcolor="#fff", height=170,
                         showlegend=dep.supervised,
                         margin=dict(l=28,r=8,t=8,b=30),
                         font=dict(family=FONT,size=10),
                         xaxis=dict(gridcolor=GRID,zeroline=False),
                         yaxis=dict(gridcolor=GRID))

    def _row(l,v,clr=None):
        return html.Tr([
            html.Td(l, style={"padding":"3px 8px","color":"#6b7a8d","fontSize":"11px","fontWeight":"600","width":"50%"}),
            html.Td(v, style={"padding":"3px 8px","color":clr or "#1e3a5f","fontSize":"11px","fontWeight":"700"}),
        ])

    stats_tbl = html.Table(html.Tbody([
        _row("Moyenne ± Std",  f"{mean_v:.4g} ± {std_v:.4g}"),
        _row("Médiane",        f"{med_v:.4g}"),
        _row("Q25 — Q75",      f"{q25:.4g} — {q75:.4g}"),
        _row("Skewness",       f"{skw:+.3f}", "#f39c12" if abs(skw)>2 else None),
        _row("Kurtosis",       f"{krt:+.3f}"),
        _row("% NaN",          f"{nan_p:.2f}%", "#e74c3c" if nan_p>10 else None),
        _row("% Outliers IQR", f"{out_p:.2f}%", "#f39c12" if out_p>5 else None),
        _row("IV / η²",        f"{iv:.4f}  ({_iv_lbl(iv)})", _iv_clr(iv)),
    ]), style={"width":"100%","borderCollapse":"collapse","background":"#f7f8fa","borderRadius":"8px"})

    return html.Div([
        html.Div([
            html.Span(col[:30], style={"fontWeight":"800","color":"#1e3a5f","fontSize":"15px"}),
            html.Span(" · cache O(1)",style={"fontSize":"10px","color":"#27ae60","marginLeft":"8px","fontWeight":"600"}),
        ], style={"marginBottom":"10px"}),
        html.Div([dcc.Graph(figure=fig_h, config={"displayModeBar":False},
                             style={"height":"170px"})],
                 style={"marginBottom":"10px"}),
        stats_tbl,
    ], className="chart-card")
