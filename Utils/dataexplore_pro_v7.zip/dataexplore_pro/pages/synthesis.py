"""
Synthèse & Conclusions v6
  • Score de qualité dataset (jauge)
  • Alertes automatiques catégorisées (erreur / avertissement / OK)
  • Tableau récapitulatif des features (IV, skew, NaN, outliers)
  • Métriques supervisées (balance des classes, baseline)
  • Recommandations actionnables
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep):
    return html.Div([
        html.Div("Synthèse & Conclusions", className="page-title"),
        html.Div("Rapport automatique — qualité des données, alertes, recommandations.",
                 className="page-subtitle"),
        dcc.Loading(html.Div(id="synth-content"), type="dot", color="#4472c4"),
    ], className="page-card")


def register_callbacks(app, dep):
    @app.callback(
        Output("synth-content", "children"),
        Input("synth-content", "id"),
    )
    def render(_):
        return _build(dep)


def _build(dep):
    # v7: cache for all precomputed metrics
    fst_cache = dep.cache.get("fstats", wait=False)
    imp_cache = dep.cache.get("importance", wait=False)
    iv_cache  = dep.cache.get("iv", wait=False) or {}
    df  = dep.df
    num = dep.num_features
    n   = len(df)
    p   = len(num)

    # ── Scores ──────────────────────────────────────────────────────
    pct_nan      = df.isnull().mean().mean() * 100
    n_dup        = int(df.duplicated().sum())
    pct_dup      = n_dup / max(n, 1) * 100
    X            = df[num].fillna(df[num].median())
    stds         = X.std()
    n_low_var    = int((stds < stds.quantile(0.1)).sum())
    corr_m       = X.corr().abs()
    np.fill_diagonal(corr_m.values, 0)
    n_high_corr  = int((corr_m > 0.9).sum().sum() // 2)

    s_nan   = max(0, 100 - pct_nan * 5)
    s_dup   = max(0, 100 - pct_dup * 10)
    s_var   = max(0, 100 - n_low_var / max(p, 1) * 100)
    s_corr  = max(0, 100 - n_high_corr / max(p, 1) * 50)
    s_size  = min(100, n / 100 * 10)
    score   = float(np.mean([s_nan, s_dup, s_var, s_corr, s_size]))

    # ── Gauge ────────────────────────────────────────────────────────
    clr_gauge = "#27ae60" if score >= 75 else ("#f39c12" if score >= 50 else "#e74c3c")
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=round(score, 1),
        title={"text": "Score Qualité Dataset", "font": {"size": 15, "family": FONT}},
        delta={"reference": 80},
        number={"font": {"size": 36, "family": FONT, "color": clr_gauge}},
        gauge={
            "axis":    {"range": [0, 100], "tickwidth": 1},
            "bar":     {"color": clr_gauge, "thickness": 0.3},
            "steps": [
                {"range": [0,  50], "color": "#fde8e8"},
                {"range": [50, 75], "color": "#fff8e1"},
                {"range": [75, 100],"color": "#e8f5e9"},
            ],
            "threshold": {"line": {"color": "#1e3a5f", "width": 3},
                          "thickness": 0.75, "value": 80},
        },
    ))
    fig_gauge.update_layout(
        height=220, margin=dict(l=30, r=30, t=30, b=20),
        paper_bgcolor="#fff", font=dict(family=FONT),
    )

    # Sub-scores bar
    fig_sub = go.Figure(go.Bar(
        x=["NaN", "Doublons", "Variance", "Corrélation", "Taille"],
        y=[s_nan, s_dup, s_var, s_corr, s_size],
        marker_color=[
            "#27ae60" if s >= 75 else ("#f39c12" if s >= 50 else "#e74c3c")
            for s in [s_nan, s_dup, s_var, s_corr, s_size]
        ],
        text=[f"{s:.0f}" for s in [s_nan, s_dup, s_var, s_corr, s_size]],
        textposition="outside",
        hovertemplate="%{x}: %{y:.1f}/100<extra></extra>",
    ))
    fig_sub.update_layout(
        plot_bgcolor=BG, paper_bgcolor="#fff",
        yaxis=dict(range=[0, 118], visible=False),
        margin=dict(l=10, r=10, t=10, b=30),
        height=160, font=dict(family=FONT, size=11),
        showlegend=False,
    )

    # ── Alerts ───────────────────────────────────────────────────────
    alerts = []

    def _alert(cls, icon, msg):
        alerts.append(html.Div([
            html.Span(icon, style={"fontSize": "16px", "flexShrink": "0"}),
            html.Span(msg, style={"fontSize": "12.5px"}),
        ], className=f"alert-item {cls}"))

    if pct_nan > 20:
        _alert("alert-error", "🚨", f"{pct_nan:.1f}% de valeurs manquantes — imputation fortement recommandée.")
    elif pct_nan > 5:
        _alert("alert-warn", "⚠️", f"{pct_nan:.1f}% de valeurs manquantes — vérifier la stratégie d'imputation.")
    else:
        _alert("alert-ok", "✅", f"Valeurs manquantes faibles ({pct_nan:.1f}%).")

    if n_dup > 0:
        _alert("alert-warn", "⚠️", f"{n_dup:,} lignes dupliquées ({pct_dup:.1f}%) — supprimer avant modélisation.")
    else:
        _alert("alert-ok", "✅", "Aucun doublon détecté.")

    if n_high_corr > 0:
        _alert("alert-warn", "⚠️",
               f"{n_high_corr} paire(s) de variables corrélées > 0.9 — risque de multicolinéarité.")
    if n_low_var > 0:
        _alert("alert-warn", "⚠️",
               f"{n_low_var} variable(s) à très faible variance (bottom 10%) — potentiellement inutiles.")
    if n < 100:
        _alert("alert-warn", "⚠️", f"Dataset petit (n={n:,}) — risque de sur-apprentissage élevé.")
    elif n >= 10_000:
        _alert("alert-ok", "✅", f"Dataset de bonne taille (n={n:,}).")

    # Supervised-specific
    if dep.supervised and dep.is_classification:
        cnts = pd.Series([( df[dep.target_name] == c).sum() for c in dep.classes],
                         index=dep.classes)
        max_r = float(cnts.max() / cnts.sum())
        min_r = float(cnts.min() / cnts.sum())
        if max_r > 0.85:
            _alert("alert-error", "🚨",
                   f"Déséquilibre classes sévère (max ratio={max_r:.1%}) — SMOTE / class_weight conseillé.")
        elif max_r > 0.70:
            _alert("alert-warn", "⚠️", f"Déséquilibre de classes modéré (max={max_r:.1%}).")
        else:
            _alert("alert-ok", "✅", f"Classes équilibrées (min={min_r:.1%} max={max_r:.1%}).")

    # Skew
    high_skew = [(c, float(sp_stats.skew(df[c].dropna())))
                 for c in num if abs(sp_stats.skew(df[c].dropna())) > 3]
    if high_skew:
        names = ", ".join(f"{c} ({s:+.1f})" for c, s in high_skew[:5])
        _alert("alert-warn", "⚠️", f"Asymétrie élevée (|skew|>3) : {names}")

    # ── Feature summary table ─────────────────────────────────────────
    rows = []
    for col in num[:30]:
        v     = df[col].dropna().values
        pnan  = df[col].isnull().mean() * 100
        skw   = float(sp_stats.skew(v)) if len(v) > 3 else 0.0
        q1, q3 = np.percentile(v, [25, 75])
        iqr   = q3 - q1
        n_out = int(np.sum((v < q1 - 1.5*iqr) | (v > q3 + 1.5*iqr)))
        pout  = n_out / max(len(v), 1) * 100

        rows.append(html.Tr([
            html.Td(col[:22], style={"fontWeight": "600", "color": "#1e3a5f",
                                      "fontSize": "11px", "padding": "5px 8px",
                                      "maxWidth": "160px", "overflow": "hidden",
                                      "textOverflow": "ellipsis", "whiteSpace": "nowrap"}),
            html.Td(f"{v.mean():.3g}",  style=_td()),
            html.Td(f"{v.std():.3g}",   style=_td()),
            html.Td(f"{skw:+.2f}",      style=_td(_skw_clr(skw))),
            html.Td(f"{pnan:.1f}%",     style=_td("#e74c3c" if pnan > 10 else None)),
            html.Td(f"{pout:.1f}%",     style=_td("#f39c12" if pout > 5 else None)),
        ], style={"borderBottom": "1px solid #f5f5f5"}))

    table = html.Table([
        html.Thead(html.Tr([
            html.Th(h, style={"padding": "5px 8px", "background": "#f0f4f8",
                               "fontSize": "10.5px", "fontWeight": "700",
                               "color": "#6b7a8d", "textTransform": "uppercase",
                               "letterSpacing": ".4px"})
            for h in ["Variable", "Moyenne", "Std", "Skewness", "% NaN", "% Outliers"]
        ])),
        html.Tbody(rows),
    ], style={"width": "100%", "borderCollapse": "collapse",
              "fontFamily": FONT, "fontSize": "11px"})

    # ── Class balance chart ────────────────────────────────────────────
    cls_section = html.Div()
    if dep.supervised and dep.is_classification:
        cnts  = [(c, int((df[dep.target_name] == c).sum())) for c in dep.classes]
        total = sum(v for _, v in cnts)
        fig_cls = go.Figure(go.Bar(
            x=[str(c) for c, _ in cnts],
            y=[v for _, v in cnts],
            marker_color=[PAL[i % len(PAL)] for i in range(len(cnts))],
            text=[f"{v:,} ({v/total:.1%})" for _, v in cnts],
            textposition="outside",
            hovertemplate="Classe %{x}<br>N=%{y:,}<extra></extra>",
        ))
        fig_cls.update_layout(
            title=dict(text="Distribution des classes (target)", font=dict(size=12)),
            plot_bgcolor=BG, paper_bgcolor="#fff",
            yaxis=dict(visible=False, range=[0, max(v for _, v in cnts) * 1.2]),
            xaxis=dict(gridcolor=GRID),
            margin=dict(l=20, r=20, t=40, b=30),
            height=200, font=dict(family=FONT, size=11),
            showlegend=False,
        )
        cls_section = html.Div([
            html.Div("Distribution des classes", className="chart-card-title"),
            dcc.Graph(figure=fig_cls, config={"displayModeBar": False},
                      style={"height": "200px"}),
        ], className="chart-card", style={"marginBottom": "16px"})

    return html.Div([
        # Row 1: gauge + sub-scores
        html.Div([
            html.Div([
                html.Div("Score global de qualité", className="chart-card-title"),
                dcc.Graph(figure=fig_gauge, config={"displayModeBar": False},
                          style={"height": "220px"}),
            ], className="chart-card"),
            html.Div([
                html.Div("Scores par dimension", className="chart-card-title"),
                dcc.Graph(figure=fig_sub, config={"displayModeBar": False},
                          style={"height": "160px"}),
                html.Div([
                    html.Div([
                        html.Div(html.B(f"{n:,}"), className="metric-value"),
                        html.Div("observations", className="metric-label"),
                    ], className="metric-card"),
                    html.Div([
                        html.Div(html.B(f"{p}"), className="metric-value"),
                        html.Div("variables num.", className="metric-label"),
                    ], className="metric-card"),
                ], style={"display": "grid", "gridTemplateColumns": "1fr 1fr",
                           "gap": "10px", "marginTop": "12px"}),
            ], className="chart-card"),
        ], className="charts-grid", style={"marginBottom": "16px"}),

        # Class balance
        cls_section,

        # Alerts
        html.Div([
            html.Div("Alertes & Recommandations", className="chart-card-title"),
            html.Div(alerts),
        ], className="chart-card", style={"marginBottom": "16px"}),

        # Feature table
        html.Div([
            html.Div("Récapitulatif des features (top 30)", className="chart-card-title"),
            html.Div(table, style={"overflowX": "auto", "maxHeight": "420px",
                                    "overflowY": "auto"}),
        ], className="chart-card"),
    ])


def _td(color=None):
    s = {"padding": "5px 8px", "fontSize": "11px", "color": "#1e3a5f",
         "fontWeight": "500", "textAlign": "right"}
    if color:
        s["color"] = color
        s["fontWeight"] = "700"
    return s

def _skw_clr(skw):
    if abs(skw) > 3:   return "#e74c3c"
    if abs(skw) > 1.5: return "#f39c12"
    return None
