"""
Synthèse & Conclusions v7
  • Lit depuis cache : fstats, iv, importance, miss
  • Score qualité + alertes automatiques + feature table complète
  • 0 recompute
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

GRID="#e0e4ea"; BG="#f7f8fa"; FONT="Plus Jakarta Sans, sans-serif"


def layout(dep):
    return html.Div([
        html.Div("Synthèse & Conclusions",className="page-title"),
        html.Div("Score qualité dataset · alertes · feature table complète. Tout depuis le cache.",
                 className="page-subtitle"),
        html.Div([dcc.Loading(html.Div(id="syn-main"),type="circle",color="#4472c4")]),
    ],className="page-card")


def register_callbacks(app, dep):

    @app.callback(Output("syn-main","children"), Input("syn-main","id"))
    def render(_):
        fst  = dep.cache.get("fstats")
        miss = dep.cache.get("miss",wait=False)
        imp  = dep.cache.get("importance",wait=False)
        iv_d = dep.cache.get("iv",default={},wait=False) or {}

        num = dep.num_features; n = len(dep.df); p = len(num)

        # ── Scores ─────────────────────────────────────────────────────
        def _score_miss():
            if fst is None: return 1.0
            avg_nan = float(np.nanmean(fst["nan_pct"]))
            return max(0.0, 1.0 - avg_nan*3)

        def _score_outliers():
            if fst is None: return 1.0
            avg_out = float(np.nanmean(fst["outlier_pct"]))
            return max(0.0, 1.0 - avg_out*2)

        def _score_skew():
            if fst is None: return 1.0
            avg_sk = float(np.nanmean(np.abs(fst["skew"])))
            return max(0.0, 1.0 - avg_sk/10)

        def _score_importance():
            if imp is None or "global" not in imp: return 0.5
            top5 = np.sort(imp["global"])[::-1][:5]
            return float(np.clip(top5.mean()*2, 0, 1))

        def _score_balance():
            if not dep.supervised or not dep.is_classification: return 1.0
            from collections import Counter
            cnt = Counter(dep.y)
            vals = list(cnt.values()); mx=max(vals); mn=min(vals)
            return float(mn/mx) if mx>0 else 1.0

        scores = {
            "Complétude":    _score_miss(),
            "Outliers":      _score_outliers(),
            "Distribution":  _score_skew(),
            "Importance":    _score_importance(),
            "Balance cls":   _score_balance(),
        }
        global_score = float(np.mean(list(scores.values())))*100

        # KPI card
        qlr = "🟢 Excellent" if global_score>=80 else "🟡 Correct" if global_score>=60 else "🔴 Attention"
        clr = "#27ae60" if global_score>=80 else "#f39c12" if global_score>=60 else "#e74c3c"
        kpi_row = html.Div([
            html.Div([html.Div("Score Global",className="metric-label"),
                      html.Div(f"{global_score:.0f}/100",className="metric-value",style={"color":clr}),
                      html.Div(qlr,className="metric-sub")],className="metric-card"),
            html.Div([html.Div("Observations",className="metric-label"),
                      html.Div(f"{n:,}",className="metric-value"),
                      html.Div(f"Affiché: {len(dep.display_df):,}",className="metric-sub")],className="metric-card"),
            html.Div([html.Div("Features",className="metric-label"),
                      html.Div(f"{p}",className="metric-value"),
                      html.Div(f"{len(dep.cat_features)} catégorielle(s)",className="metric-sub")],className="metric-card"),
        ],className="metric-cards",style={"gridTemplateColumns":"repeat(3,1fr)","marginBottom":"16px"})

        # Sub-score bar
        fig_scores = go.Figure(go.Bar(
            y=list(scores.keys()),
            x=[v*100 for v in scores.values()],
            orientation="h",
            marker_color=["#27ae60" if v>=0.8 else "#f39c12" if v>=0.6 else "#e74c3c"
                          for v in scores.values()],
            text=[f"{v*100:.0f}%" for v in scores.values()],
            textposition="outside",
            hovertemplate="%{y}: %{x:.1f}%<extra></extra>",
        ))
        fig_scores.update_layout(
            title=dict(text="Sous-scores qualité",font=dict(size=12,color="#1e3a5f")),
            plot_bgcolor=BG,paper_bgcolor="#fff",height=220,
            xaxis=dict(range=[0,115],gridcolor=GRID,title="%"),
            yaxis=dict(gridcolor=GRID),
            margin=dict(l=120,r=60,t=44,b=30),font=dict(family=FONT,size=11))

        # Alerts
        alerts = []
        if fst is not None:
            avg_nan = float(np.nanmean(fst["nan_pct"]))*100
            if avg_nan>20:
                alerts.append(("error",f"⚠️ Taux de NaN moyen élevé: {avg_nan:.1f}%"))
            elif avg_nan>5:
                alerts.append(("warn",f"📊 NaN moyen: {avg_nan:.1f}%"))
            else:
                alerts.append(("ok",f"✅ Peu de valeurs manquantes ({avg_nan:.2f}%)"))

            avg_out = float(np.nanmean(fst["outlier_pct"]))*100
            if avg_out>15:
                alerts.append(("error",f"⚠️ Taux outliers élevé: {avg_out:.1f}%"))
            elif avg_out>5:
                alerts.append(("warn",f"📈 Outliers fréquents: {avg_out:.1f}%"))

            cols_high_sk=[num[i] for i in range(len(num)) if abs(fst["skew"][i])>3]
            if cols_high_sk:
                alerts.append(("warn",f"📐 Skewness >3 : {', '.join(cols_high_sk[:5])}{'…' if len(cols_high_sk)>5 else ''}"))

        if dep.supervised and dep.is_classification:
            from collections import Counter
            cnt=Counter(dep.y); vals=list(cnt.values()); mx=max(vals); mn=min(vals)
            ratio=mn/mx if mx>0 else 1.0
            if ratio<0.2:
                alerts.append(("error",f"⚠️ Déséquilibre sévère: ratio min/max={ratio:.2f}"))
            elif ratio<0.5:
                alerts.append(("warn",f"📊 Déséquilibre modéré: ratio={ratio:.2f}"))
            else:
                alerts.append(("ok",f"✅ Classes bien équilibrées (ratio={ratio:.2f})"))

        if n>1_000_000:
            alerts.append(("ok",f"⚡ Dataset très large ({n:,}) — optimisations v7 actives"))

        alert_items=[html.Div(msg,className=f"alert-item alert-{lvl}") for lvl,msg in alerts]

        # Feature table
        tbl_rows = []
        for i,col in enumerate(num):
            def _g(k): return float(fst[k][i]) if fst and k in fst else float("nan")
            nan_p=_g("nan_pct")*100; out_p=_g("outlier_pct")*100; skw=_g("skew")
            iv=float(iv_d.get(col,0.0))
            rf=float(imp["rf"][i]) if imp and "rf" in imp else float("nan")
            flag = "🔴" if nan_p>20 or abs(skw)>5 else "🟡" if nan_p>5 or abs(skw)>2 else "🟢"
            tbl_rows.append(html.Tr([
                html.Td(flag,style={"textAlign":"center"}),
                html.Td(col[:24],style={"fontWeight":"600","color":"#1e3a5f","fontSize":"11px"}),
                html.Td(f"{_g('mean'):.4g}",style=_tc()),
                html.Td(f"{_g('std'):.4g}",style=_tc()),
                html.Td(f"{skw:+.2f}",style=_tc("#f39c12" if abs(skw)>2 else None)),
                html.Td(f"{nan_p:.1f}%",style=_tc("#e74c3c" if nan_p>10 else None)),
                html.Td(f"{out_p:.1f}%",style=_tc("#f39c12" if out_p>5 else None)),
                html.Td(f"{iv:.3f}",style=_tc("#27ae60" if iv>=0.1 else None)),
                html.Td(f"{rf:.3f}" if not np.isnan(rf) else "—",style=_tc()),
            ],style={"borderBottom":"1px solid #f5f5f5","transition":"background .1s"},
              className="var-row"))

        tbl_hdr = html.Tr([html.Th(h,style={"padding":"6px 8px","background":"#f0f4f8","fontSize":"10px",
                                              "fontWeight":"800","color":"#6b7a8d","textTransform":"uppercase",
                                              "letterSpacing":".5px"})
                           for h in ["","Nom","Moy","Std","Skew","NaN%","Out%","IV/η²","RF"]])
        feature_tbl=html.Table([html.Thead(tbl_hdr),html.Tbody(tbl_rows)],
                                style={"width":"100%","borderCollapse":"collapse","fontSize":"11px"})

        return html.Div([
            kpi_row,
            html.Div([
                html.Div([html.Div([dcc.Graph(figure=fig_scores,config={"displayModeBar":False},style={"height":"220px"})],
                                   className="chart-card"),
                          html.Div([html.Div("Alertes automatiques",className="chart-card-title",style={"marginBottom":"10px"}),
                                    *alert_items],
                                   className="chart-card")],
                         style={"display":"flex","flexDirection":"column","gap":"16px","width":"40%"}),
                html.Div([html.Div([
                    html.Div("Feature Table complète",className="chart-card-title",style={"marginBottom":"10px"}),
                    html.Div(feature_tbl,style={"overflowY":"auto","maxHeight":"500px","overflowX":"auto"}),
                    html.Div("⚡ Tous les stats calculés sur 100% des données via cache.",
                             style={"fontSize":"9.5px","color":"#27ae60","marginTop":"8px","fontWeight":"600"}),
                ],className="chart-card")],style={"flex":"1","minWidth":"0"}),
            ],style={"display":"flex","gap":"16px","alignItems":"flex-start"}),
        ])


def _tc(clr=None):
    return {"padding":"4px 8px","fontSize":"11px","color":clr or "#1e3a5f","textAlign":"right"}
