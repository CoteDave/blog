"""
Analyse Univariée v7
  • Stats panel lit dep.cache["fstats"] (O(1))
  • Graphiques sur display_df seulement
  • KDE sur ≤ 10k points (sous-échantillon si besoin)
  • ECDF vectorisé
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"
KDE_MAX = 10_000   # subsample for KDE


def layout(dep):
    num = dep.num_features
    OPTS = [{"label":"Histogramme + KDE","value":"hist"},
            {"label":"Box + Violin","value":"boxviolin"},
            {"label":"QQ-Plot","value":"qq"},
            {"label":"ECDF","value":"ecdf"},
            {"label":"Dist. fit","value":"fit"},
            {"label":"Transformations","value":"transform"}]
    return html.Div([
        html.Div("Analyse Univariée", className="page-title"),
        html.Div("Stats depuis cache (O(1)) · graphiques sur échantillon display_df.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Variable:",className="control-label"),
                      dcc.Dropdown(id="uni-col",options=[{"label":c,"value":c} for c in num],
                                   value=num[0] if num else None,clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Graphique:",className="control-label"),
                      dcc.Dropdown(id="uni-type",options=OPTS,value="hist",clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Par target:",className="control-label"),
                      dcc.RadioItems(id="uni-group",
                                     options=[{"label":" Oui","value":"yes"},
                                              {"label":" Non","value":"no"}],
                                     value="yes" if dep.supervised else "no",inline=True,
                                     labelStyle={"fontSize":"12.5px","marginRight":"10px"})],
                     className="control-group",style={"maxWidth":"180px"}),
            html.Div([html.Div("Bins:",className="control-label"),
                      dcc.Slider(id="uni-bins",min=5,max=80,step=5,value=25,
                                 marks={10:"10",25:"25",50:"50",80:"80"},
                                 tooltip={"placement":"bottom"})],
                     className="control-group",style={"minWidth":"200px"}),
        ],className="controls-row"),
        html.Div([dcc.Loading(dcc.Graph(id="uni-main",config={"displayModeBar":True},
                                         style={"height":"400px"}),
                               type="circle",color="#4472c4")],
                 className="chart-card",style={"marginBottom":"16px"}),
        html.Div([
            html.Div([html.Div(id="uni-stats")],className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="uni-sec",config={"displayModeBar":False},
                                             style={"height":"360px"}),
                                   type="circle",color="#4472c4")],className="chart-card"),
        ],className="charts-grid"),
    ],className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        [Output("uni-main","figure"),Output("uni-sec","figure"),Output("uni-stats","children")],
        [Input("uni-col","value"),Input("uni-type","value"),
         Input("uni-group","value"),Input("uni-bins","value")],
    )
    def update(col, ctype, group, nbins):
        if col is None: e=go.Figure(); return e,e,[]
        df      = dep.display_df   # always display sample
        nbins   = nbins or 25
        bygroup = dep.supervised and group=="yes"
        s_all   = df[col].dropna()

        if   ctype=="hist":      fm = _hist(dep,col,s_all,bygroup,nbins,df)
        elif ctype=="boxviolin": fm = _box(dep,col,s_all,bygroup,df)
        elif ctype=="qq":        fm = _qq(col,s_all)
        elif ctype=="ecdf":      fm = _ecdf(dep,col,s_all,bygroup,df)
        elif ctype=="fit":       fm = _fit(col,s_all)
        elif ctype=="transform": fm = _transform(col,s_all)
        else:                    fm = _hist(dep,col,s_all,bygroup,nbins,df)

        # Contextual secondary (never identical)
        if   ctype=="hist":      fs = _ecdf(dep,col,s_all,bygroup,df)
        elif ctype=="ecdf":      fs = _box(dep,col,s_all,bygroup,df)
        elif ctype in("qq","fit","transform"): fs = _hist(dep,col,s_all,bygroup,nbins,df)
        else:                    fs = _ecdf(dep,col,s_all,bygroup,df)

        return fm, fs, _stats_panel(dep, col)


def _hist(dep,col,s_all,bygroup,nbins,df):
    fig = go.Figure()
    grps = _groups(dep,col,bygroup,df)
    for nm,vals,clr in grps:
        fig.add_trace(go.Histogram(x=vals,name=nm,nbinsx=nbins,histnorm="probability density",
                                    marker=dict(color=clr,opacity=0.52,
                                                line=dict(width=0.5,color="rgba(255,255,255,.5)"))))
        xk,dk = _kde(vals.values)
        if len(xk):
            fig.add_trace(go.Scatter(x=xk,y=dk,mode="lines",name=f"KDE {nm}",
                                      line=dict(color=clr,width=2.5),showlegend=False))
        fig.add_vline(x=float(vals.mean()),line_dash="dash",line_color=clr,line_width=1.3,
                      annotation_text=f"μ={vals.mean():.3g}",annotation_font_size=8)
    fig.update_layout(**_base(f"Histogramme + KDE — {col}"),
                       barmode="overlay",xaxis_title=col,yaxis_title="Densité")
    return fig

def _box(dep,col,s_all,bygroup,df):
    fig = go.Figure()
    for nm,vals,clr in _groups(dep,col,bygroup,df):
        fig.add_trace(go.Violin(y=vals,name=nm,fillcolor=_a(clr,.22),line_color=clr,
                                 line_width=1.8,box_visible=True,meanline_visible=True,
                                 points="outliers",marker=dict(color=clr,size=3,opacity=0.5),
                                 spanmode="hard"))
    fig.update_layout(**_base(f"Box + Violin — {col}"),violinmode="group",yaxis_title=col)
    return fig

def _qq(col,vals):
    sv = np.sort(vals.values); n = len(sv)
    th = sp_stats.norm.ppf((np.arange(1,n+1)-.375)/(n+.25))
    sl,ic,_,_,_ = sp_stats.linregress(th,sv)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=th,y=sv,mode="markers",
                              marker=dict(color="#4472c4",size=5,opacity=0.72),
                              hovertemplate="Théorique: %{x:.3f}<br>Observé: %{y:.3f}<extra></extra>"))
    xr = np.array([th.min(),th.max()])
    fig.add_trace(go.Scatter(x=xr,y=sl*xr+ic,mode="lines",
                              line=dict(color="#e74c3c",width=2,dash="dash"),name="Normale"))
    _,p_sw = sp_stats.shapiro(sv[:min(5000,n)])
    fig.update_layout(**_base(f"QQ-Plot — {col}  |  Shapiro p={p_sw:.4f}"),
                       xaxis_title="Quantiles théoriques",yaxis_title=col)
    return fig

def _ecdf(dep,col,s_all,bygroup,df):
    fig = go.Figure()
    for nm,vals,clr in _groups(dep,col,bygroup,df):
        sv = np.sort(vals.values); ey = np.arange(1,len(sv)+1)/len(sv)
        eps = 1.36/np.sqrt(max(len(sv),1))
        fig.add_trace(go.Scatter(
            x=np.concatenate([sv,sv[::-1]]),
            y=np.concatenate([np.clip(ey+eps,0,1),np.clip(ey-eps,0,1)[::-1]]),
            fill="toself",fillcolor=_a(clr,.08),line=dict(width=0),
            showlegend=False,hoverinfo="skip"))
        fig.add_trace(go.Scatter(x=sv,y=ey,mode="lines",name=nm,
                                  line=dict(color=clr,width=2.5),
                                  hovertemplate=f"x=%{{x:.3g}}<br>F(x)=%{{y:.3f}}<extra></extra>"))
    fig.update_layout(**_base(f"ECDF — {col}"),xaxis_title=col,yaxis_title="F(x)",
                       yaxis=dict(range=[0,1.05],gridcolor=GRID))
    return fig

def _fit(col,vals):
    v = vals.values; xg = np.linspace(v.min()-(v.max()-v.min())*.05,
                                       v.max()+(v.max()-v.min())*.05,300)
    DISTS = [("Normal",sp_stats.norm),("Log-Normal",sp_stats.lognorm),
             ("Gamma",sp_stats.gamma),("Expon.",sp_stats.expon),("Weibull",sp_stats.weibull_min)]
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=v,histnorm="probability density",nbinsx=30,
                                marker=dict(color="rgba(68,114,196,.38)",line=dict(width=.5,color="white")),
                                name="Empirique"))
    res=[]
    for dn,dobj in DISTS:
        try:
            if dobj==sp_stats.lognorm and (v<=0).any(): continue
            p=dobj.fit(v); ks,pv=sp_stats.kstest(v,dobj.cdf,args=p)
            res.append((dn,dobj.pdf(xg,*p),ks,pv))
        except: pass
    res.sort(key=lambda x:x[2])
    for i,(dn,pdf,ks,pv) in enumerate(res):
        fig.add_trace(go.Scatter(x=xg,y=pdf,mode="lines",
                                  name=f"{dn} (KS={ks:.3f})",
                                  line=dict(color=PAL[i%len(PAL)],width=2.5 if i==0 else 1.5,
                                            dash="solid" if i==0 else "dot")))
    fig.update_layout(**_base(f"Ajustement — {col}  |  Meilleure: {res[0][0] if res else '?'}"),
                       xaxis_title=col,yaxis_title="Densité",
                       legend=dict(font=dict(size=9.5),x=1.01))
    return fig

def _transform(col,vals):
    from plotly.subplots import make_subplots
    v = vals.values
    trs=[("Original",v)]
    if (v>0).all(): trs+=[(f"log(x)",np.log(v)),(f"√x",np.sqrt(v))]
    try: vt,lam=sp_stats.boxcox(v); trs.append((f"Box-Cox λ={lam:.2f}",vt))
    except: pass
    try: vt=sp_stats.yeojohnson(v)[0]; trs.append(("Yeo-Johnson",vt))
    except: pass
    nc=min(len(trs),3); nr=(len(trs)+nc-1)//nc
    fig=make_subplots(rows=nr,cols=nc,subplot_titles=[t[0] for t in trs])
    for i,(nm,tv) in enumerate(trs):
        r=i//nc+1; c=i%nc+1
        fig.add_trace(go.Histogram(x=tv,nbinsx=25,marker=dict(color=PAL[i%len(PAL)],opacity=.75,
                                    line=dict(width=.4,color="white")),name=nm,showlegend=False),row=r,col=c)
        xk,dk=_kde(tv)
        if len(xk): fig.add_trace(go.Scatter(x=xk,y=dk,mode="lines",showlegend=False,
                                              line=dict(color=PAL[i%len(PAL)],width=2)),row=r,col=c)
    fig.update_layout(title=dict(text=f"Transformations — {col}",font=dict(size=12)),
                       plot_bgcolor=BG,paper_bgcolor="#fff",
                       margin=dict(l=40,r=20,t=60,b=40),font=dict(family=FONT,size=10),
                       height=290*nr)
    for ax in fig.layout:
        if ax.startswith("xaxis") or ax.startswith("yaxis"):
            fig.layout[ax].update(gridcolor=GRID,zeroline=False)
    return fig


def _stats_panel(dep, col):
    """Read from cache — O(1)."""
    num = dep.num_features
    if col not in num: return []
    idx = num.index(col)
    fst = dep.cache.get("fstats", wait=False)

    def _g(k): return float(fst[k][idx]) if fst and k in fst else float("nan")

    def _row(l,v,clr=None):
        return html.Tr([
            html.Td(l,style={"padding":"3px 8px","color":"#6b7a8d","fontSize":"11px","fontWeight":"600","width":"52%"}),
            html.Td(v,style={"padding":"3px 8px","color":clr or "#1e3a5f","fontSize":"11px","fontWeight":"700"}),
        ])

    n_total = len(dep.df)
    nan_p = _g("nan_pct")*100
    out_p = _g("outlier_pct")*100
    skw   = _g("skew")

    rows = [
        _row("N (total)",     f"{n_total:,}"),
        _row("Moyenne",       f"{_g('mean'):.4g}"),
        _row("Std",           f"{_g('std'):.4g}"),
        _row("Médiane",       f"{_g('q50'):.4g}"),
        _row("Q25 — Q75",     f"{_g('q25'):.4g} — {_g('q75'):.4g}"),
        _row("Min — Max",     f"{_g('min'):.4g} — {_g('max'):.4g}"),
        _row("Skewness",      f"{skw:+.3f}","#f39c12" if abs(skw)>2 else None),
        _row("Kurtosis",      f"{_g('kurt'):+.3f}"),
        _row("% NaN (total)", f"{nan_p:.2f}%","#e74c3c" if nan_p>10 else None),
        _row("% Outliers",    f"{out_p:.2f}%","#f39c12" if out_p>5 else None),
    ]

    # Tests normalité sur display_df (≤50k — fast)
    v = dep.display_df[col].dropna().values
    if len(v)>=8:
        _,p_dag = sp_stats.normaltest(v)
        rows.append(_row("D'Agostino p",f"{p_dag:.4f}  {'✅' if p_dag>.05 else '❌'}"))
    if len(v)>=3 and len(v)<=5000:
        _,p_sw = sp_stats.shapiro(v)
        rows.append(_row("Shapiro p",f"{p_sw:.4f}  {'✅' if p_sw>.05 else '❌'}"))

    note = html.Div("⚡ stats sur 100% des données (cache)",
                    style={"fontSize":"9.5px","color":"#27ae60","marginTop":"6px","fontWeight":"600"})
    return [html.Div("Stats descriptives",className="chart-card-title"),
            html.Table(html.Tbody(rows),style={"width":"100%","borderCollapse":"collapse",
                                                "background":"#f7f8fa","borderRadius":"8px"}),
            note]


# ── helpers ────────────────────────────────────────────────────────────────────
def _groups(dep,col,bygroup,df):
    if bygroup and dep.supervised and dep.is_classification:
        return [(f"Cls {c}",df[df[dep.target_name]==c][col].dropna(),PAL[i%len(PAL)])
                for i,c in enumerate(dep.classes)]
    return [(col,df[col].dropna(),"#4472c4")]

def _kde(vals,n=200):
    if len(vals)<3: return np.array([]),np.array([])
    # Sub-sample for very large arrays
    if len(vals)>KDE_MAX:
        vals = np.random.default_rng(42).choice(vals,size=KDE_MAX,replace=False)
    try:
        kde = sp_stats.gaussian_kde(vals,bw_method="scott")
        pad = max((vals.max()-vals.min())*.1,1e-9)
        xg  = np.linspace(vals.min()-pad,vals.max()+pad,n)
        return xg,kde(xg)
    except: return np.array([]),np.array([])

def _a(h,a):
    h=h.lstrip("#"); r,g,b=int(h[:2],16),int(h[2:4],16),int(h[4:],16)
    return f"rgba({r},{g},{b},{a})"

def _base(t=""):
    return dict(title=dict(text=t,font=dict(size=12,color="#1e3a5f")),
                plot_bgcolor=BG,paper_bgcolor="#fff",
                margin=dict(l=50,r=20,t=44,b=50),
                font=dict(family=FONT,size=11),
                xaxis=dict(gridcolor=GRID,zeroline=False),
                yaxis=dict(gridcolor=GRID,zeroline=False),
                legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)",
                            borderwidth=1,bordercolor=GRID))
