"""
Valeurs Manquantes v7 — lit dep.cache["miss"] (précalculé, full pass)
  • miss_pct / miss_cnt sur 100% des données
  • Co-occurrence matrix précalculée
  • Target impact sur display_df
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"
PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]


def layout(dep):
    miss_cols = [c for c in dep.num_features if dep.df[c].isnull().any()]
    has_miss  = len(miss_cols) > 0

    return html.Div([
        html.Div("Valeurs Manquantes", className="page-title"),
        html.Div("Stats sur 100% des données · co-occurrence précalculée.",
                 className="page-subtitle"),
        html.Div([dcc.Loading(html.Div(id="miss-content"), type="dot", color="#4472c4")]),
        html.Div(id="miss-target-impact", style={"marginTop":"16px"}) if dep.supervised else html.Div(),
    ], className="page-card")


def register_callbacks(app, dep):

    @app.callback(Output("miss-content","children"), Input("miss-content","id"))
    def render(_):
        md = dep.cache.get("miss")
        if md is None:
            return html.Div("Précalcul en cours…",style={"padding":"20px","color":"#6b7a8d"})

        miss_pct = md["miss_pct"]   # dict col→float
        miss_cnt = md["miss_cnt"]
        total_p  = md["total_pct"]
        n_comp   = md["n_complete"]
        n        = len(dep.df)

        # Sort by missing pct
        sorted_cols = sorted(miss_pct.items(), key=lambda x: -x[1])
        miss_cols   = [(c,v) for c,v in sorted_cols if v>0]

        # KPI cards
        kpi_row = html.Div([
            html.Div([html.Div("% Manquant global",className="metric-label"),
                      html.Div(f"{total_p:.2f}%",className="metric-value",style={"color":"#e74c3c" if total_p>10 else "#27ae60"})],
                     className="metric-card"),
            html.Div([html.Div("Lignes complètes",className="metric-label"),
                      html.Div(f"{n_comp:,}",className="metric-value"),
                      html.Div(f"{n_comp/max(n,1):.1%}",className="metric-sub")],
                     className="metric-card"),
            html.Div([html.Div("Cols avec NaN",className="metric-label"),
                      html.Div(f"{len(miss_cols)}",className="metric-value",style={"color":"#e07b39"})],
                     className="metric-card"),
        ], className="metric-cards", style={"gridTemplateColumns":"repeat(3,1fr)","marginBottom":"16px"})

        if not miss_cols:
            return html.Div([kpi_row,
                html.Div([html.Div("✅","style",className="empty-state-icon"),
                          html.Div("Aucune valeur manquante.",style={"fontWeight":"600"})],
                         className="empty-state")])

        # Bar chart: % missing per column (top 40)
        top40 = miss_cols[:40]
        cols_ = [c for c,_ in top40]; vals_ = [v*100 for _,v in top40]
        fig_bar = go.Figure(go.Bar(
            x=cols_, y=vals_,
            marker_color=["#e74c3c" if v>20 else "#f39c12" if v>5 else "#4472c4" for v in vals_],
            text=[f"{v:.1f}%" for v in vals_], textposition="outside",
            hovertemplate="%{x}<br>%{y:.2f}%<extra></extra>",
        ))
        fig_bar.update_layout(**_base(f"% Manquant par variable (top {len(top40)})"),
                               xaxis=dict(tickangle=-45,gridcolor=GRID),
                               yaxis=dict(title="%",gridcolor=GRID,range=[0,max(vals_)*1.2+2]),
                               height=300, margin=dict(l=50,r=10,t=44,b=90))

        # Co-occurrence heatmap
        cooc   = md["cooc"]
        cooc_c = md.get("cols",[])[:40]
        nc     = len(cooc_c)
        cooc_s = cooc[:nc,:nc] if cooc is not None and nc>0 else None

        figs = [html.Div([html.Div("% Manquant par variable",className="chart-card-title"),
                          dcc.Graph(figure=fig_bar,config={"displayModeBar":False},
                                    style={"height":"300px"})],className="chart-card")]

        if cooc_s is not None and nc>0:
            fig_co = go.Figure(go.Heatmap(
                z=cooc_s*100, x=cooc_c, y=cooc_c,
                colorscale=[[0,"#f7f8fa"],[1,"#e74c3c"]],
                hovertemplate="%{x} × %{y}: %{z:.2f}%<extra></extra>",
                colorbar=dict(title="%",thickness=12)
            ))
            fig_co.update_layout(**_base("Co-occurrence des valeurs manquantes"),
                                  height=max(300,nc*18+100),
                                  xaxis=dict(tickangle=-45),
                                  margin=dict(l=100,r=20,t=44,b=100))
            figs.append(html.Div([html.Div("Co-occurrence (% paires manquantes)",className="chart-card-title"),
                                   dcc.Graph(figure=fig_co,config={"displayModeBar":False},
                                             style={"height":f"{max(300,nc*18+100)}px"})],
                                  className="chart-card"))

        return html.Div([kpi_row, html.Div(figs, className="charts-grid")])

    if dep.supervised:
        @app.callback(Output("miss-target-impact","children"),
                      Input("miss-target-impact","id"))
        def target_impact(_):
            miss_cols = [c for c in dep.num_features if dep.df[c].isnull().any()][:20]
            if not miss_cols:
                return html.Div()

            # Use display_df for speed
            df   = dep.display_df
            rows = []
            for col in miss_cols:
                pres = df[~df[col].isnull()]
                mis  = df[df[col].isnull()]
                if len(mis) < 3: continue
                if dep.is_classification:
                    cls1  = dep.classes[-1]
                    pp    = (pres[dep.target_name]==cls1).mean()
                    pm    = (mis[dep.target_name]==cls1).mean()
                    diff  = pm-pp
                    rows.append({"col":col[:22],"present":pp*100,"missing":pm*100,"diff":diff*100})
                else:
                    pp  = pres[dep.target_name].mean()
                    pm  = mis[dep.target_name].mean()
                    rows.append({"col":col[:22],"present":pp,"missing":pm,"diff":pm-pp})

            if not rows: return html.Div()
            rows.sort(key=lambda r: abs(r["diff"]),reverse=True)

            fig = go.Figure()
            cols_ = [r["col"] for r in rows]
            fig.add_trace(go.Bar(name="Présent",x=cols_,y=[r["present"] for r in rows],
                                  marker_color="#4472c4",opacity=0.82))
            fig.add_trace(go.Bar(name="Manquant",x=cols_,y=[r["missing"] for r in rows],
                                  marker_color="#e74c3c",opacity=0.82))
            lbl = "Taux target %" if dep.is_classification else "Moyenne target"
            fig.update_layout(**_base(f"Impact de la valeur manquante sur la target — {lbl}"),
                               barmode="group",xaxis=dict(tickangle=-30),
                               yaxis_title=lbl,height=300)
            return html.Div([html.Div("Impact valeur manquante → target",className="chart-card-title"),
                              dcc.Graph(figure=fig,config={"displayModeBar":False},
                                        style={"height":"300px"})], className="chart-card")


def _base(t=""):
    return dict(title=dict(text=t,font=dict(size=12,color="#1e3a5f")),
                plot_bgcolor=BG,paper_bgcolor="#fff",
                margin=dict(l=50,r=16,t=44,b=50),
                font=dict(family=FONT,size=11))
