"""
Clusters v7 — K-Means + DBSCAN sur display_df
  • PCA projection réutilise dep.cache["pca"] (précalculée)
  • KMeans elbow sur display_df seulement
  • ScatterGL pour ≥ 10k points
"""
from __future__ import annotations
import numpy as np
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy.spatial import ConvexHull

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"

def _a(h,a):
    h=h.lstrip("#"); r,g,b=int(h[:2],16),int(h[2:4],16),int(h[4:],16)
    return f"rgba({r},{g},{b},{a})"

def _hull(x,y,c):
    pts=np.column_stack([x,y]); pts=pts[~np.isnan(pts).any(1)]
    if len(pts)<3: return None
    try:
        h=ConvexHull(pts)
        hx=np.append(pts[h.vertices,0],pts[h.vertices[0],0])
        hy=np.append(pts[h.vertices,1],pts[h.vertices[0],1])
        return go.Scatter(x=hx,y=hy,fill="toself",fillcolor=_a(c,.12),
                          line=dict(color=c,width=1.5,dash="dot"),
                          mode="lines",showlegend=False,hoverinfo="skip")
    except: return None


def layout(dep):
    num=dep.num_features
    return html.Div([
        html.Div("Analyse de Clusters",className="page-title"),
        html.Div("K-Means · DBSCAN · PCA projection depuis cache · ScatterGL.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Algorithme:",className="control-label"),
                      dcc.Dropdown(id="cl-algo",options=[{"label":"K-Means","value":"kmeans"},
                                                          {"label":"DBSCAN","value":"dbscan"}],
                                   value="kmeans",clearable=False,style={"width":"150px"})],
                     className="control-group",style={"maxWidth":"170px"}),
            html.Div([html.Div("K (K-Means):",className="control-label"),
                      dcc.Slider(id="cl-k",min=2,max=10,step=1,value=3,
                                 marks={i:str(i) for i in range(2,11)})],
                     className="control-group",style={"minWidth":"250px"}),
            html.Div([html.Div("Variables:",className="control-label"),
                      dcc.Dropdown(id="cl-vars",options=[{"label":c,"value":c} for c in num],
                                   value=num[:min(10,len(num))],multi=True,
                                   style={"minWidth":"280px"})],
                     className="control-group"),
            html.Div([html.Div("Hull:",className="control-label"),
                      dcc.Dropdown(id="cl-hull",options=[{"label":"Convexe","value":"convex"},
                                                          {"label":"Aucun","value":"none"}],
                                   value="convex",clearable=False,style={"width":"130px"})],
                     className="control-group",style={"maxWidth":"150px"}),
        ],className="controls-row"),
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-scatter",config={"displayModeBar":False},
                                            style={"height":"420px"}),type="circle",color="#4472c4")],
                     className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-elbow",config={"displayModeBar":False},
                                            style={"height":"420px"}),type="circle",color="#4472c4")],
                     className="chart-card"),
        ],className="charts-grid",style={"marginBottom":"16px"}),
        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-sil",config={"displayModeBar":False},
                                            style={"height":"300px"}),type="circle",color="#4472c4")],
                     className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-profile",config={"displayModeBar":False},
                                            style={"height":"300px"}),type="circle",color="#4472c4")],
                     className="chart-card"),
        ],className="charts-grid"),
    ],className="page-card")


def register_callbacks(app, dep):
    _use_gl = len(dep.display_df) > 5000
    ScFn = go.Scattergl if _use_gl else go.Scatter

    @app.callback(
        [Output("cl-scatter","figure"),Output("cl-elbow","figure"),
         Output("cl-sil","figure"),Output("cl-profile","figure")],
        [Input("cl-k","value"),Input("cl-vars","value"),
         Input("cl-hull","value"),Input("cl-algo","value")],
    )
    def update(k,vars_sel,hull,algo):
        from sklearn.cluster import KMeans, DBSCAN
        from sklearn.metrics import silhouette_samples
        from sklearn.neighbors import NearestNeighbors
        from sklearn.preprocessing import StandardScaler, MinMaxScaler

        algo = algo or "kmeans"
        if not vars_sel or len(vars_sel)<2:
            e=go.Figure(); return e,e,e,e

        cols = [c for c in vars_sel if c in dep.num_features]
        df_d = dep.display_df
        X_raw = df_d[cols].fillna(df_d[cols].median()).values
        X     = StandardScaler().fit_transform(X_raw)

        # PCA 2D from cache (already fitted)
        pca_d = dep.cache.get("pca", wait=False)
        if pca_d is not None:
            # Project display data through cached PCA
            vcols = pca_d["cols"]
            avail = [c for c in vcols if c in df_d.columns]
            df_pc = df_d[avail].fillna(df_d[avail].median())
            Xs    = pca_d["scaler"].transform(df_pc.values).astype(np.float64)
            X2    = pca_d["pca"].transform(Xs)[:,:2].astype(np.float32)
            exp   = pca_d["explained"][:2]*100
            v1,v2 = float(exp[0]), float(exp[1])
        else:
            from sklearn.decomposition import PCA
            pca2 = PCA(n_components=2,svd_solver="randomized",random_state=42)
            X2   = pca2.fit_transform(X).astype(np.float32)
            v1,v2 = 50.0, 25.0

        # Cluster assignment
        if algo=="dbscan":
            nbrs = NearestNeighbors(n_neighbors=min(5,len(X)-1)).fit(X)
            dists,_ = nbrs.kneighbors(X)
            eps_auto = float(np.percentile(np.sort(dists[:,-1]),85))
            db = DBSCAN(eps=eps_auto,min_samples=max(3,len(X)//60)).fit(X)
            labels = db.labels_
            yd = np.sort(dists[:,-1])
            fig_elbow = go.Figure(go.Scatter(x=list(range(len(yd))),y=yd,mode="lines",
                                              line=dict(color="#4472c4",width=2)))
            fig_elbow.add_hline(y=eps_auto,line_dash="dash",line_color="#e74c3c",
                                annotation_text=f"ε={eps_auto:.3f}",annotation_font_size=9)
            n_cls = len(set(labels))-(1 if -1 in labels else 0)
            fig_elbow.update_layout(**_base(f"DBSCAN k-distance | ε={eps_auto:.3f} → {n_cls} clusters"),
                                     xaxis_title="Points",yaxis_title="k-NN dist")
        else:
            max_k = min(11,len(X))
            ks,inertias=[],[]
            for ki in range(2,max_k):
                km_i=KMeans(n_clusters=ki,random_state=42,n_init="auto")
                km_i.fit(X); ks.append(ki); inertias.append(km_i.inertia_)
            k = min(k,max_k-1)
            labels = KMeans(n_clusters=k,random_state=42,n_init="auto").fit_predict(X)
            fig_elbow = go.Figure(go.Scatter(x=ks,y=inertias,mode="lines+markers",
                                              line=dict(color="#4472c4",width=2),
                                              marker=dict(size=8,color="#e07b39"),
                                              hovertemplate="K=%{x}<br>Inertie: %{y:,.0f}<extra></extra>"))
            fig_elbow.add_vline(x=k,line_dash="dash",line_color="#e74c3c",
                                annotation_text=f"K={k}",annotation_font_size=9)
            fig_elbow.update_layout(**_base("Courbe d'Inertie — Méthode du Coude"),
                                     xaxis_title="K",yaxis_title="Inertie")

        unique_lbl = sorted([l for l in set(labels) if l!=-1])

        # Scatter
        fig_sc = go.Figure()
        if -1 in labels:
            m=labels==-1
            fig_sc.add_trace(ScFn(x=X2[m,0],y=X2[m,1],mode="markers",name="Bruit",
                                   marker=dict(color="#aaa",size=4,opacity=0.5)))
        for ci in unique_lbl:
            m=labels==ci; clr=PAL[ci%len(PAL)]; nc=int(m.sum())
            fig_sc.add_trace(ScFn(x=X2[m,0],y=X2[m,1],mode="markers",name=f"Cluster {ci} (n={nc:,})",
                                   marker=dict(color=clr,size=5,opacity=0.78,line=dict(width=0))))
            if hull=="convex" and nc>=3:
                h=_hull(X2[m,0],X2[m,1],clr)
                if h: fig_sc.add_trace(h)
            cx,cy=X2[m,0].mean(),X2[m,1].mean()
            fig_sc.add_trace(go.Scatter(x=[cx],y=[cy],mode="markers+text",
                marker=dict(symbol="x",size=14,color=clr,line=dict(width=2,color="white")),
                text=[str(ci)],textfont=dict(size=10),showlegend=False,hoverinfo="skip"))
        fig_sc.update_layout(**_base(f"Clusters (PCA 2D) | PC1={v1:.1f}% PC2={v2:.1f}%"),
                              xaxis_title=f"PC1 ({v1:.1f}%)",yaxis_title=f"PC2 ({v2:.1f}%)")

        # Silhouette
        try:
            ok = labels!=-1
            if len(set(labels[ok]))>=2 and ok.sum()>=4:
                sv   = silhouette_samples(X[ok],labels[ok])
                savg = float(sv.mean())
                fig_sil=go.Figure(); y_lo=0
                for ci in unique_lbl:
                    sc_=np.sort(sv[labels[ok]==ci]); clr=PAL[ci%len(PAL)]
                    y_hi=y_lo+len(sc_)
                    fig_sil.add_trace(go.Bar(x=sc_,y=list(range(y_lo,y_hi)),orientation="h",
                                              name=f"Cls {ci}",marker_color=clr,opacity=0.82))
                    y_lo=y_hi+4
                fig_sil.add_vline(x=savg,line_dash="dash",line_color="#e74c3c",
                                  annotation_text=f"moy={savg:.3f}",annotation_font_size=9)
                fig_sil.update_layout(**_base(f"Silhouette | score={savg:.3f}"),
                                       xaxis_title="Coefficient",yaxis=dict(visible=False))
            else: fig_sil=go.Figure()
        except: fig_sil=go.Figure()

        # Radar profile
        try:
            top_c=cols[:min(7,len(cols))]
            Xn=MinMaxScaler().fit_transform(df_d[top_c].fillna(df_d[top_c].median()).values)
            fig_prof=go.Figure()
            for ci in unique_lbl:
                m=labels==ci; mu=Xn[m].mean(axis=0)
                th=top_c+[top_c[0]]; rv=list(mu)+[mu[0]]
                fig_prof.add_trace(go.Scatterpolar(r=rv,theta=th,fill="toself",
                                                    name=f"Cluster {ci}",line_color=PAL[ci%len(PAL)],opacity=0.8))
            fig_prof.update_layout(polar=dict(radialaxis=dict(visible=True,range=[0,1],
                                                               gridcolor=GRID,tickfont=dict(size=8))),
                                    showlegend=True,paper_bgcolor="#fff",font=dict(family=FONT,size=10),
                                    title=dict(text="Profile Radar (normalisé)",font=dict(size=11)),
                                    margin=dict(l=50,r=50,t=50,b=30))
        except: fig_prof=go.Figure()

        return fig_sc,fig_elbow,fig_sil,fig_prof


def _base(t=""):
    return dict(title=dict(text=t,font=dict(size=12,color="#1e3a5f")),
                plot_bgcolor=BG,paper_bgcolor="#fff",
                margin=dict(l=50,r=16,t=44,b=50),
                font=dict(family=FONT,size=11),
                xaxis=dict(gridcolor=GRID,zeroline=False),
                yaxis=dict(gridcolor=GRID,zeroline=False),
                legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)",
                            borderwidth=1,bordercolor=GRID))
