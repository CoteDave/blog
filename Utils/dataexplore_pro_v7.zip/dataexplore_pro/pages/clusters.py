"""
Analyse de Clusters v6
  • K-Means + DBSCAN
  • Hull convexe par cluster
  • Courbe d'inertie / k-distance
  • Silhouette plot
  • Profile radar des clusters
"""
from __future__ import annotations
import numpy as np
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy.spatial import ConvexHull

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad"]
GRID = "#e0e4ea"
BG   = "#f7f8fa"
FONT = "Plus Jakarta Sans, sans-serif"


def _hex_alpha(h, a):
    h = h.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{a})"


def _hull_trace(x, y, color, name=""):
    pts = np.column_stack([x, y])
    pts = pts[~np.isnan(pts).any(axis=1)]
    if len(pts) < 3:
        return None
    try:
        hull = ConvexHull(pts)
        hx = np.append(pts[hull.vertices, 0], pts[hull.vertices[0], 0])
        hy = np.append(pts[hull.vertices, 1], pts[hull.vertices[0], 1])
        return go.Scatter(
            x=hx, y=hy, fill="toself",
            fillcolor=_hex_alpha(color, 0.13),
            line=dict(color=color, width=2, dash="dot"),
            mode="lines", name=f"Hull {name}",
            showlegend=False, hoverinfo="skip",
        )
    except Exception:
        return None


def layout(dep):
    num = dep.num_features
    return html.Div([
        html.Div("Analyse de Clusters", className="page-title"),
        html.Div("K-Means · DBSCAN · hull convexe · silhouette · profile des clusters.",
                 className="page-subtitle"),

        html.Div([
            html.Div([html.Div("Algorithme:", className="control-label"),
                      dcc.Dropdown(id="cl-algo",
                                   options=[{"label": "K-Means", "value": "kmeans"},
                                            {"label": "DBSCAN",  "value": "dbscan"}],
                                   value="kmeans", clearable=False,
                                   style={"width": "160px"})],
                     className="control-group", style={"maxWidth": "180px"}),
            html.Div([html.Div("K (K-Means):", className="control-label"),
                      dcc.Slider(id="cl-k", min=2, max=10, step=1, value=3,
                                 marks={i: str(i) for i in range(2, 11)})],
                     className="control-group", style={"minWidth": "260px"}),
            html.Div([html.Div("Variables (PCA input):", className="control-label"),
                      dcc.Dropdown(id="cl-vars",
                                   options=[{"label": c, "value": c} for c in num],
                                   value=num[:min(10, len(num))], multi=True,
                                   style={"minWidth": "300px"})],
                     className="control-group"),
            html.Div([html.Div("Hull:", className="control-label"),
                      dcc.Dropdown(id="cl-hull",
                                   options=[{"label": "Convexe", "value": "convex"},
                                            {"label": "Aucun",   "value": "none"}],
                                   value="convex", clearable=False,
                                   style={"width": "140px"})],
                     className="control-group", style={"maxWidth": "160px"}),
        ], className="controls-row"),

        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-scatter", config={"displayModeBar": False},
                                            style={"height": "420px"}),
                                  type="circle", color="#4472c4")],
                     className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-elbow", config={"displayModeBar": False},
                                            style={"height": "420px"}),
                                  type="circle", color="#4472c4")],
                     className="chart-card"),
        ], className="charts-grid", style={"marginBottom": "16px"}),

        html.Div([
            html.Div([dcc.Loading(dcc.Graph(id="cl-sil", config={"displayModeBar": False},
                                            style={"height": "300px"}),
                                  type="circle", color="#4472c4")],
                     className="chart-card"),
            html.Div([dcc.Loading(dcc.Graph(id="cl-profile", config={"displayModeBar": False},
                                            style={"height": "300px"}),
                                  type="circle", color="#4472c4")],
                     className="chart-card"),
        ], className="charts-grid"),
    ], className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        [Output("cl-scatter", "figure"), Output("cl-elbow",   "figure"),
         Output("cl-sil",     "figure"), Output("cl-profile", "figure")],
        [Input("cl-k",    "value"), Input("cl-vars", "value"),
         Input("cl-hull", "value"), Input("cl-algo", "value")],
    )
    def update(k, vars_sel, hull_mode, algo):
        from sklearn.cluster     import KMeans, DBSCAN
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler
        from sklearn.metrics       import silhouette_samples, silhouette_score
        from sklearn.neighbors     import NearestNeighbors

        algo = algo or "kmeans"
        if not vars_sel or len(vars_sel) < 2:
            e = go.Figure()
            return e, e, e, e

        cols  = [c for c in vars_sel if c in dep.num_features]
        # v7: use display_df (≤50k) for clustering
        X_raw = dep.display_df[cols].fillna(dep.display_df[cols].median()).values
        X     = StandardScaler().fit_transform(X_raw)

        # ── Cluster assignment ───────────────────────────────────────
        if algo == "dbscan":
            nbrs = NearestNeighbors(n_neighbors=min(5, len(X)-1)).fit(X)
            dists_knn, _ = nbrs.kneighbors(X)
            eps_auto = float(np.percentile(np.sort(dists_knn[:, -1]), 85))
            db     = DBSCAN(eps=eps_auto,
                            min_samples=max(3, len(X) // 60)).fit(X)
            labels = db.labels_
            n_cls  = len(set(labels)) - (1 if -1 in labels else 0)

            # k-distance plot as elbow substitute
            yd = np.sort(dists_knn[:, -1])
            fig_elbow = go.Figure([
                go.Scatter(x=list(range(len(yd))), y=yd,
                           mode="lines", line=dict(color="#4472c4", width=2),
                           hovertemplate="idx=%{x}<br>dist=%{y:.4f}<extra></extra>"),
            ])
            fig_elbow.add_hline(y=eps_auto, line_dash="dash", line_color="#e74c3c",
                                annotation_text=f"ε={eps_auto:.3f}",
                                annotation_font_size=10)
            fig_elbow.update_layout(
                **_base(f"DBSCAN k-distance  |  ε={eps_auto:.3f}  →  {n_cls} clusters"),
                xaxis_title="Points triés", yaxis_title=f"k-NN distance (k={min(5,len(X)-1)})",
            )
        else:
            # K-Means
            max_k = min(11, len(X))
            ks, inertias = list(range(2, max_k)), []
            for ki in ks:
                km_i = KMeans(n_clusters=ki, random_state=42, n_init=10)
                km_i.fit(X)
                inertias.append(km_i.inertia_)

            fig_elbow = go.Figure([
                go.Scatter(x=ks, y=inertias, mode="lines+markers",
                           line=dict(color="#4472c4", width=2),
                           marker=dict(size=8, color="#e07b39"),
                           hovertemplate="K=%{x}<br>Inertie: %{y:,.0f}<extra></extra>"),
            ])
            fig_elbow.add_vline(x=k, line_dash="dash", line_color="#e74c3c",
                                annotation_text=f"K={k}", annotation_font_size=10)
            fig_elbow.update_layout(
                **_base("Courbe d'Inertie — Méthode du Coude"),
                xaxis_title="Nombre de clusters K", yaxis_title="Inertie",
            )

            km     = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = km.fit_predict(X)
            n_cls  = k

        # ── PCA 2D projection ─────────────────────────────────────────
        pca = PCA(n_components=2)
        X2  = pca.fit_transform(X)
        v1, v2 = pca.explained_variance_ratio_[:2] * 100

        fig_sc = go.Figure()
        unique_labels = [l for l in sorted(set(labels)) if l != -1]
        if -1 in labels:
            noise = X2[labels == -1]
            fig_sc.add_trace(go.Scatter(
                x=noise[:, 0], y=noise[:, 1], mode="markers",
                name="Bruit (-1)", marker=dict(color="#aaa", size=5, opacity=0.5),
                hovertemplate="Bruit<br>PC1: %{x:.2f}<br>PC2: %{y:.2f}<extra></extra>",
            ))

        for ci in unique_labels:
            mask = labels == ci
            clr  = PAL[ci % len(PAL)]
            n_c  = int(mask.sum())
            fig_sc.add_trace(go.Scatter(
                x=X2[mask, 0], y=X2[mask, 1], mode="markers",
                name=f"Cluster {ci}  (n={n_c:,})",
                marker=dict(color=clr, size=7, opacity=0.82,
                            line=dict(width=0.5, color="rgba(255,255,255,.6)")),
                hovertemplate=f"Cluster {ci}<br>PC1: %{{x:.2f}}<br>PC2: %{{y:.2f}}<extra></extra>",
            ))
            if hull_mode == "convex" and n_c >= 3:
                h = _hull_trace(X2[mask, 0], X2[mask, 1], clr, str(ci))
                if h:
                    fig_sc.add_trace(h)

        # Centroids
        for ci in unique_labels:
            cx, cy = X2[labels == ci].mean(axis=0)
            fig_sc.add_trace(go.Scatter(
                x=[cx], y=[cy], mode="markers+text",
                marker=dict(symbol="x", size=13, color=PAL[ci % len(PAL)],
                            line=dict(width=2, color="white")),
                text=[str(ci)], textposition="top center",
                textfont=dict(size=11, color="white",
                              family=FONT),
                showlegend=False, hoverinfo="skip",
            ))

        fig_sc.update_layout(
            **_base(f"Clusters PCA 2D  |  PC1={v1:.1f}%  PC2={v2:.1f}%"),
            xaxis_title=f"PC1 ({v1:.1f}%)", yaxis_title=f"PC2 ({v2:.1f}%)",
        )

        # ── Silhouette ───────────────────────────────────────────────
        try:
            valid = (labels != -1)
            if len(set(labels[valid])) >= 2 and valid.sum() >= 4:
                sil_vals = silhouette_samples(X[valid], labels[valid])
                sil_avg  = float(sil_vals.mean())
                fig_sil  = go.Figure()
                y_lo = 0
                for ci in unique_labels:
                    sil_ci = np.sort(sil_vals[labels[valid] == ci])
                    clr    = PAL[ci % len(PAL)]
                    y_hi   = y_lo + len(sil_ci)
                    fig_sil.add_trace(go.Bar(
                        x=sil_ci, y=list(range(y_lo, y_hi)),
                        orientation="h", name=f"Cls {ci}",
                        marker_color=clr, opacity=0.82,
                        hovertemplate=f"Cluster {ci}<br>Sil: %{{x:.3f}}<extra></extra>",
                    ))
                    y_lo = y_hi + 4
                fig_sil.add_vline(x=sil_avg, line_dash="dash", line_color="#e74c3c",
                                  annotation_text=f"moy={sil_avg:.3f}",
                                  annotation_font_size=10)
                fig_sil.update_layout(
                    **_base(f"Silhouette  |  score moyen = {sil_avg:.3f}"),
                    xaxis_title="Coefficient silhouette", yaxis=dict(visible=False),
                    showlegend=True,
                )
            else:
                fig_sil = go.Figure()
        except Exception:
            fig_sil = go.Figure()

        # ── Cluster profile (radar) ───────────────────────────────────
        try:
            top_cols = cols[:min(8, len(cols))]
            from sklearn.preprocessing import MinMaxScaler
            X_norm = MinMaxScaler().fit_transform(dep.display_df[top_cols].fillna(
                dep.display_df[top_cols].median()).values)  # v7: display_df

            fig_prof = go.Figure()
            for ci in unique_labels:
                mask = labels == ci
                means = X_norm[mask].mean(axis=0)
                theta = top_cols + [top_cols[0]]
                r     = list(means) + [means[0]]
                fig_prof.add_trace(go.Scatterpolar(
                    r=r, theta=theta,
                    fill="toself", name=f"Cluster {ci}",
                    line_color=PAL[ci % len(PAL)],
                    opacity=0.8,
                    hovertemplate=f"Cluster {ci}<br>%{{theta}}: %{{r:.2f}}<extra></extra>",
                ))
            fig_prof.update_layout(
                polar=dict(radialaxis=dict(visible=True, range=[0, 1],
                                           gridcolor=GRID, tickfont=dict(size=9))),
                showlegend=True,
                title=dict(text="Profile Radar des clusters (normalisé)", font=dict(size=12)),
                paper_bgcolor="#fff",
                font=dict(family=FONT, size=11),
                margin=dict(l=50, r=50, t=50, b=30),
                legend=dict(font=dict(size=11)),
            )
        except Exception:
            fig_prof = go.Figure()

        return fig_sc, fig_elbow, fig_sil, fig_prof


def _base(title=""):
    return dict(
        title=dict(text=title, font=dict(size=12, color="#1e3a5f")),
        plot_bgcolor=BG, paper_bgcolor="#fff",
        margin=dict(l=50, r=16, t=44, b=50),
        font=dict(family=FONT, size=11),
        xaxis=dict(gridcolor=GRID, zeroline=False),
        yaxis=dict(gridcolor=GRID, zeroline=False),
        legend=dict(font=dict(size=11), bgcolor="rgba(255,255,255,.9)",
                    borderwidth=1, bordercolor=GRID),
    )
