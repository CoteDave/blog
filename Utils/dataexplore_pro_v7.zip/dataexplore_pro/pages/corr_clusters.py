"""
Clusters de Corrélation v7 — lit dep.cache["corr_pearson"/"corr_spearman"]
  • Dendrogramme + heatmap clusterisée
  • 0 recompute pour pearson/spearman
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots

GRID="#e0e4ea"; BG="#f7f8fa"; FONT="Plus Jakarta Sans, sans-serif"
PAL=["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12","#8e44ad","#d35400","#16a085"]


def layout(dep):
    num=dep.num_features[:80]
    return html.Div([
        html.Div("Clusters de Corrélation",className="page-title"),
        html.Div("Dendrogramme hiérarchique + heatmap clusterisée. Pearson/Spearman depuis cache.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Méthode:",className="control-label"),
                      dcc.Dropdown(id="cc-method",options=[{"label":"Pearson","value":"pearson"},
                                                            {"label":"Spearman","value":"spearman"}],
                                   value="pearson",clearable=False,style={"width":"150px"})],
                     className="control-group"),
            html.Div([html.Div("Linkage:",className="control-label"),
                      dcc.Dropdown(id="cc-linkage",options=[{"label":"Ward","value":"ward"},
                                                             {"label":"Complete","value":"complete"},
                                                             {"label":"Average","value":"average"}],
                                   value="ward",clearable=False,style={"width":"140px"})],
                     className="control-group"),
            html.Div([html.Div("K clusters:",className="control-label"),
                      dcc.Slider(id="cc-k",min=2,max=10,step=1,value=4,
                                 marks={i:str(i) for i in range(2,11)})],
                     className="control-group",style={"minWidth":"240px"}),
            html.Div([html.Div("Variables:",className="control-label"),
                      dcc.Dropdown(id="cc-vars",
                                   options=[{"label":c,"value":c} for c in num],
                                   value=num[:min(25,len(num))],multi=True,
                                   style={"minWidth":"260px"})],
                     className="control-group"),
        ],className="controls-row"),
        html.Div([dcc.Loading(html.Div(id="cc-main"),type="circle",color="#4472c4")],
                 className="chart-card"),
    ],className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        Output("cc-main","children"),
        [Input("cc-method","value"),Input("cc-linkage","value"),
         Input("cc-k","value"),Input("cc-vars","value")],
    )
    def update(method,linkage_m,k,vars_sel):
        from scipy.cluster.hierarchy import linkage as sp_link, fcluster, dendrogram
        from scipy.spatial.distance import squareform

        if not vars_sel or len(vars_sel)<3:
            return html.Div("Sélectionner ≥ 3 variables.",style={"padding":"20px","color":"#6b7a8d"})
        k = k or 4

        # Read from cache (O(1) for pearson/spearman)
        key = "corr_pearson" if method=="pearson" else "corr_spearman"
        full = dep.cache.get(key)
        if full is not None:
            valid = [c for c in vars_sel if c in full.index]
            corr  = full.loc[valid,valid]
        else:
            df_s = dep.display_df[vars_sel].fillna(dep.display_df[vars_sel].median())
            corr = df_s.corr(method=method)
            valid = vars_sel

        n = len(valid)
        dist = np.clip(1-corr.abs().values, 0, None); np.fill_diagonal(dist,0)
        condensed = squareform(dist, checks=False); condensed = np.clip(condensed,0,None)
        Z = sp_link(condensed, method=linkage_m)
        cl_lbl = fcluster(Z, min(k,n), criterion="maxclust")

        # Reorder by dendrogram
        dend = dendrogram(Z, no_plot=True)
        order = dend["leaves"]
        ordered = [valid[i] for i in order]
        corr_ord = corr.loc[ordered,ordered]
        cl_ord   = [cl_lbl[i]-1 for i in order]

        h = max(420, n*18+120)

        # Clustered heatmap
        fig = go.Figure(go.Heatmap(
            z=corr_ord.values, x=ordered, y=ordered[::-1],
            colorscale=[[0,"#e74c3c"],[0.5,"#fff"],[1,"#4472c4"]],
            zmin=-1,zmax=1,
            hovertemplate="%{x} × %{y}<br>r=%{z:.3f}<extra></extra>",
            colorbar=dict(title="r",thickness=12,len=0.6)))

        # Cluster boundaries
        ci=0
        for grp in range(1,k+1):
            cnt=cl_ord.count(grp-1)
            if cnt: ci+=cnt; fig.add_shape(type="rect",xref="x",yref="y",
                x0=ci-cnt-.5,x1=ci-.5,y0=n-ci+cnt-.5,y1=n-ci+.5,
                line=dict(color=PAL[grp%len(PAL)],width=2.5),
                fillcolor="rgba(0,0,0,0)")

        fig.update_layout(
            title=dict(text=f"Heatmap Clusterisée — {method.capitalize()} | K={min(k,n)} clusters",
                        font=dict(size=12,color="#1e3a5f")),
            plot_bgcolor=BG,paper_bgcolor="#fff",height=h,
            margin=dict(l=110,r=20,t=50,b=110),font=dict(family=FONT,size=10),
            xaxis=dict(tickangle=-45,side="bottom"),
            yaxis=dict(autorange="reversed"))

        # Cluster cards
        cards = []
        for grp in sorted(set(cl_lbl)):
            members = [valid[i] for i,l in enumerate(cl_lbl) if l==grp]
            clr = PAL[(grp-1)%len(PAL)]
            if len(members)>1:
                sub_c = corr.loc[members,members]
                avg_r = float(sub_c.where(np.triu(np.ones_like(sub_c.values),1).astype(bool)).stack().abs().mean())
            else: avg_r=1.0
            cards.append(html.Div([
                html.Div(f"Cluster {grp}",style={"fontWeight":"800","color":clr,"fontSize":"12px"}),
                html.Div(f"|r| moyen: {avg_r:.3f}",style={"fontSize":"10.5px","color":"#6b7a8d","margin":"2px 0 4px"}),
                html.Div([html.Span(m[:18],style={"display":"inline-block","margin":"2px",
                    "padding":"2px 6px","borderRadius":"99px","fontSize":"10px","fontWeight":"600",
                    "background":clr+"22","color":clr}) for m in members]),
            ],style={"padding":"10px 12px","borderRadius":"8px","border":f"1.5px solid {clr}44",
                     "background":"#fff","minWidth":"150px"}))

        return html.Div([
            dcc.Graph(figure=fig,config={"displayModeBar":True},style={"height":f"{h}px"}),
            html.Div("Clusters identifiés:",style={"fontWeight":"700","color":"#1e3a5f",
                                                    "fontSize":"12.5px","margin":"16px 0 10px"}),
            html.Div(cards,style={"display":"flex","flexWrap":"wrap","gap":"10px"}),
        ])
