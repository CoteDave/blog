from dash import html

def layout(dep, page_id=""):
    names={"causal":"Découverte Causale","anova":"ANOVA Multi-factorielle"}
    return html.Div([
        html.Div(names.get(page_id,page_id),className="page-title"),
        html.Div([
            html.Span("🚧",style={"fontSize":"48px","display":"block","textAlign":"center","margin":"30px 0 14px"}),
            html.Div("Page en cours de développement.",style={"fontWeight":"700","color":"#1e3a5f","textAlign":"center","fontSize":"15px"}),
            html.Div("Disponible dans la prochaine version.",style={"color":"#9aa5b4","fontSize":"13px","textAlign":"center","marginTop":"6px"}),
        ],className="page-card",style={"padding":"50px 24px"})
    ],className="page-card")
