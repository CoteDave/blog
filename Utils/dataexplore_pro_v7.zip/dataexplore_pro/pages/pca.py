"""
ACP v7 — lit dep.cache["pca"] (précalculé, randomized SVD)
  • Biplot 2D / 3D avec ScatterGL
  • Scree plot depuis cache
  • Loadings matrix depuis cache
  • Projection de nouveaux PC à la volée sur display_df
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from plotly.subplots import make_subplots

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"


def layout(dep):
    return html.Div([
        html.Div("ACP — Réduction de Dimension", className="page-title"),
        html.Div("Précalculé via SVD aléatoire (sklearn) sur ≤ 200k lignes.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("PC abscisse:", className="control-label"),
                      dcc.Dropdown(id="pca-pcx", value=0, clearable=False,
                                   style={"width":"130px"})], className="control-group"),
            html.Div([html.Div("PC ordonnée:", className="control-label"),
                      dcc.Dropdown(id="pca-pcy", value=1, clearable=False,
                                   style={"width":"130px"})], className="control-group"),
            html.Div([html.Div("PC Z (3D):", className="control-label"),
                      dcc.Dropdown(id="pca-pcz", value=2, clearable=False,
                                   style={"width":"130px"})], className="control-group"),
            html.Div([html.Div("Vue:", className="control-label"),
                      dcc.Dropdown(id="pca-mode",
                                   options=[{"label":"Biplot 2D","value":"2d"},
                                            {"label":"Biplot 3D","value":"3d"},
                                            {"label":"Scree","value":"scree"},
                                            {"label":"Loadings","value":"load"}],
                                   value="2d", clearable=False)], className="control-group"),
            html.Div([html.Div("Flèches loadings:", className="control-label"),
                      dcc.Slider(id="pca-arrows", min=0, max=20, step=5, value=8,
                                 marks={0:"0",5:"5",10:"10",20:"20"},
                                 tooltip={"placement":"bottom"})],
                     className="control-group", style={"minWidth":"200px"}),
        ], className="controls-row"),
        html.Div([dcc.Loading(html.Div(id="pca-fig-wrap"), type="circle", color="#4472c4")],
                 className="chart-card"),
    ], className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        [Output("pca-pcx","options"), Output("pca-pcy","options"), Output("pca-pcz","options")],
        Input("pca-fig-wrap","id"),
    )
    def set_opts(_):
        pca_d = dep.cache.get("pca")
        n_c   = pca_d["n_comp"] if pca_d else 2
        opts  = [{"label":f"PC{i+1}","value":i} for i in range(n_c)]
        return opts, opts, opts

    @app.callback(
        Output("pca-fig-wrap","children"),
        [Input("pca-pcx","value"), Input("pca-pcy","value"),
         Input("pca-pcz","value"), Input("pca-mode","value"),
         Input("pca-arrows","value")],
    )
    def update(pcx, pcy, pcz, mode, n_arrows):
        pca_d = dep.cache.get("pca")
        if pca_d is None:
            return html.Div("Précalcul en cours…", style={"padding":"20px","color":"#6b7a8d"})

        scores   = pca_d["scores"]        # (n_sample, n_comp) float32
        loadings = pca_d["loadings"]      # (p_valid, n_comp) float32
        exp      = pca_d["explained"]     # (n_comp,) float32
        cols     = pca_d["cols"]          # variable names matching loadings rows
        n_comp   = pca_d["n_comp"]

        pcx = min(pcx or 0, n_comp-1); pcy = min(pcy or 1, n_comp-1)
        pcz = min(pcz or 2, n_comp-1)

        ScatterFn = go.Scattergl if len(scores) > 5000 else go.Scatter

        if mode == "scree":
            cum = np.cumsum(exp)*100
            fig = go.Figure()
            fig.add_trace(go.Bar(x=[f"PC{i+1}" for i in range(n_comp)],
                                  y=exp*100, name="Variance expliquée",
                                  marker_color="#4472c4", opacity=0.82))
            fig.add_trace(go.Scatter(x=[f"PC{i+1}" for i in range(n_comp)],
                                      y=cum, mode="lines+markers",
                                      name="Cumulative", line=dict(color="#e07b39",width=2.5)))
            fig.add_hline(y=80, line_dash="dash", line_color="#27ae60",
                          annotation_text="80%", annotation_font_size=9)
            fig.update_layout(**_base("Scree Plot — Variance expliquée"),
                              yaxis_title="%", height=380)
            return dcc.Graph(figure=fig, config={"displayModeBar":False},style={"height":"380px"})

        elif mode == "load":
            top = min(n_arrows or 8, len(cols))
            abs_load = np.abs(loadings[:, pcx]) + np.abs(loadings[:, pcy])
            order = np.argsort(abs_load)[::-1][:top]
            mat   = loadings[order][:, [pcx,pcy]]
            fig   = go.Figure()
            fig.add_trace(go.Heatmap(
                z=loadings[order][:, :n_comp].T,
                x=[cols[i] for i in order],
                y=[f"PC{i+1}" for i in range(n_comp)],
                colorscale="RdBu", zmid=0,
                hovertemplate="%{x}<br>PC%{y}: %{z:.3f}<extra></extra>",
            ))
            fig.update_layout(**_base("Loadings — top features"),
                              height=max(280, n_comp*30+80),
                              margin=dict(l=60,r=20,t=44,b=80),
                              xaxis=dict(tickangle=-40,gridcolor=GRID))
            return dcc.Graph(figure=fig,config={"displayModeBar":False},
                             style={"height":f"{max(280,n_comp*30+80)}px"})

        # Biplot 2D or 3D
        # Re-project display_df through cached scaler+pca
        scaler = pca_d["scaler"]; pca_obj = pca_d["pca"]
        vcols  = cols
        df_disp = dep.display_df[vcols].fillna(dep.display_df[vcols].median())
        Xs     = scaler.transform(df_disp.values).astype(np.float64)
        sc     = pca_obj.transform(Xs).astype(np.float32)
        y_disp = dep.display_df[dep.target_name].values if dep.supervised else None

        if mode == "2d":
            fig = go.Figure()
            xv, yv = sc[:,pcx], sc[:,pcy]
            ex,ey  = float(exp[pcx]*100), float(exp[pcy]*100)

            if dep.supervised and dep.is_classification:
                for i,cls in enumerate(dep.classes):
                    m = y_disp==cls
                    fig.add_trace(ScatterFn(x=xv[m],y=yv[m],mode="markers",name=f"Cls {cls}",
                        marker=dict(color=PAL[i%len(PAL)],size=5,opacity=0.75,
                                    line=dict(width=0))))
            else:
                fig.add_trace(ScatterFn(x=xv,y=yv,mode="markers",name="Points",
                    marker=dict(color="#4472c4",size=5,opacity=0.72,line=dict(width=0))))

            n_arr = n_arrows or 0
            if n_arr > 0:
                abs_l = np.abs(loadings[:,pcx])+np.abs(loadings[:,pcy])
                sel   = np.argsort(abs_l)[::-1][:n_arr]
                scale = max(float(np.abs(sc[:,[pcx,pcy]]).max()*0.45), 1e-3)
                for i in sel:
                    lx,ly = float(loadings[i,pcx])*scale, float(loadings[i,pcy])*scale
                    fig.add_annotation(x=lx,y=ly,ax=0,ay=0,xref="x",yref="y",
                                       axref="x",ayref="y",
                                       arrowhead=2,arrowwidth=1.8,arrowcolor="#e07b39",
                                       text=cols[i][:14],font=dict(size=8,color="#e07b39"))

            fig.update_layout(**_base(f"Biplot ACP — PC{pcx+1} ({ex:.1f}%) × PC{pcy+1} ({ey:.1f}%)"),
                              xaxis_title=f"PC{pcx+1} ({ex:.1f}%)",
                              yaxis_title=f"PC{pcy+1} ({ey:.1f}%)",
                              height=480)
            return dcc.Graph(figure=fig,config={"displayModeBar":True},style={"height":"480px"})

        else:  # 3d
            ex,ey,ez = float(exp[pcx]*100),float(exp[pcy]*100),float(exp[pcz]*100)
            fig = go.Figure()
            if dep.supervised and dep.is_classification:
                for i,cls in enumerate(dep.classes):
                    m = y_disp==cls
                    fig.add_trace(go.Scatter3d(x=sc[m,pcx],y=sc[m,pcy],z=sc[m,pcz],
                        mode="markers",name=f"Cls {cls}",
                        marker=dict(color=PAL[i%len(PAL)],size=3,opacity=0.75)))
            else:
                fig.add_trace(go.Scatter3d(x=sc[:,pcx],y=sc[:,pcy],z=sc[:,pcz],
                    mode="markers",marker=dict(color="#4472c4",size=3,opacity=0.72)))
            fig.update_layout(scene=dict(
                xaxis_title=f"PC{pcx+1} ({ex:.1f}%)",
                yaxis_title=f"PC{pcy+1} ({ey:.1f}%)",
                zaxis_title=f"PC{pcz+1} ({ez:.1f}%)"),
                title=dict(text="Biplot 3D",font=dict(size=12)),
                paper_bgcolor="#fff",height=520,
                font=dict(family=FONT,size=11),
                legend=dict(font=dict(size=11)))
            return dcc.Graph(figure=fig,config={"displayModeBar":True},style={"height":"520px"})


def _base(t=""):
    return dict(title=dict(text=t,font=dict(size=12,color="#1e3a5f")),
                plot_bgcolor=BG,paper_bgcolor="#fff",
                margin=dict(l=50,r=20,t=44,b=50),
                font=dict(family=FONT,size=11),
                xaxis=dict(gridcolor=GRID,zeroline=False),
                yaxis=dict(gridcolor=GRID,zeroline=False),
                legend=dict(font=dict(size=11),bgcolor="rgba(255,255,255,.9)",
                            borderwidth=1,bordercolor=GRID))
