"""
Post-Hoc v7 — Tests inter-groupes sur display_df
  • Tukey HSD / Holm / Bonferroni / Kruskal-Wallis / Games-Howell
  • Forest plot + heatmap p-values
  • display_df utilisé (≤50k)
"""
from __future__ import annotations
import numpy as np, pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

GRID="#e0e4ea"; BG="#f7f8fa"; FONT="Plus Jakarta Sans, sans-serif"
PAL=["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]


def layout(dep):
    num = dep.num_features
    grp_opts = []
    if dep.supervised:
        grp_opts.append({"label":f"[Target] {dep.target_name}","value":dep.target_name})
    for c in dep.cat_features:
        nu=dep.df[c].nunique()
        if 2<=nu<=20: grp_opts.append({"label":f"{c} ({nu} cat.)","value":c})
    grp_def = grp_opts[0]["value"] if grp_opts else None

    return html.Div([
        html.Div("Analyses Post-Hoc",className="page-title"),
        html.Div("Tests inter-groupes (display_df ≤50k) — Tukey / Holm / KW / Games-Howell.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Variable numérique:",className="control-label"),
                      dcc.Dropdown(id="ph-y",options=[{"label":c,"value":c} for c in num],
                                   value=num[0] if num else None,clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Groupes:",className="control-label"),
                      dcc.Dropdown(id="ph-grp",options=grp_opts,value=grp_def,clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Test:",className="control-label"),
                      dcc.Dropdown(id="ph-method",
                                   options=[{"label":"Tukey HSD","value":"tukey"},
                                            {"label":"Holm","value":"holm"},
                                            {"label":"Bonferroni","value":"bonf"},
                                            {"label":"Kruskal-Wallis","value":"kw"},
                                            {"label":"Games-Howell","value":"gh"}],
                                   value="tukey",clearable=False)],
                     className="control-group",style={"maxWidth":"200px"}),
            html.Div([html.Div("α:",className="control-label"),
                      dcc.Dropdown(id="ph-alpha",
                                   options=[{"label":"0.05","value":"0.05"},
                                            {"label":"0.01","value":"0.01"},
                                            {"label":"0.001","value":"0.001"}],
                                   value="0.05",clearable=False)],
                     className="control-group",style={"maxWidth":"130px"}),
        ],className="controls-row"),
        html.Div([dcc.Loading(html.Div(id="ph-main"),type="circle",color="#4472c4")],
                 className="chart-card"),
    ],className="page-card")


def register_callbacks(app, dep):

    @app.callback(Output("ph-main","children"),
        [Input("ph-y","value"),Input("ph-grp","value"),
         Input("ph-method","value"),Input("ph-alpha","value")])
    def update(y_col,grp_col,method,alpha_s):
        if not y_col or not grp_col:
            return html.Div("Sélectionner une variable et un groupe.",style={"padding":"20px","color":"#6b7a8d"})
        alpha = float(alpha_s or 0.05)
        df = dep.display_df[[y_col,grp_col]].dropna()
        groups = df[grp_col].unique()
        if len(groups)<2:
            return html.Div("Besoin ≥ 2 groupes.",style={"padding":"20px","color":"#6b7a8d"})
        grp_data = [df[df[grp_col]==g][y_col].values for g in groups]

        # Global test
        glob_txt = ""
        try:
            f,pf = sp_stats.f_oneway(*grp_data)
            h,pk = sp_stats.kruskal(*grp_data)
            glob_txt = f"ANOVA F={f:.3f} p={pf:.4f}  |  Kruskal-Wallis H={h:.3f} p={pk:.4f}"
        except: pass

        # Pairwise
        pairs = list(combinations(range(len(groups)),2))
        pvals,labels,effs,cis=[],[],[],[]
        for i,j in pairs:
            a,b = grp_data[i],grp_data[j]
            lbl = f"{str(groups[i])[:12]} vs {str(groups[j])[:12]}"
            labels.append(lbl)
            try:
                if method in("tukey","bonf","holm"):
                    _,p,_=sp_stats.ttest_ind(a,b,equal_var=(method!="gh"))
                elif method=="kw":
                    _,p=sp_stats.mannwhitneyu(a,b,alternative="two-sided")
                else: _,p=sp_stats.ttest_ind(a,b,equal_var=False)
                pvals.append(p)
            except: pvals.append(1.0)
            # Cohen's d
            pooled=np.sqrt(((len(a)-1)*a.std()**2+(len(b)-1)*b.std()**2)/max(len(a)+len(b)-2,1)+1e-9)
            d=(a.mean()-b.mean())/pooled
            ci_d=1.96*np.sqrt(2/max(len(a)+len(b),1))
            effs.append(d); cis.append(ci_d)

        # Multiple correction
        if method=="bonf":
            pvals_c=[min(p*len(pairs),1.0) for p in pvals]
        elif method=="holm":
            order_=np.argsort(pvals); pvals_c=list(pvals)
            for k,idx in enumerate(order_):
                pvals_c[idx]=min(pvals[idx]*(len(pairs)-k),1.0)
        else:
            pvals_c=pvals

        # Forest plot
        sig=["✅" if p<=alpha else "❌" for p in pvals_c]
        colors=["#27ae60" if p<=alpha else "#e74c3c" for p in pvals_c]
        fig_f=go.Figure()
        for k,(lbl,d,ci,p,s,clr) in enumerate(zip(labels,effs,cis,pvals_c,sig,colors)):
            fig_f.add_trace(go.Scatter(x=[d-ci,d+ci],y=[k,k],mode="lines",
                                        line=dict(color=clr,width=2.5),showlegend=False,hoverinfo="skip"))
            fig_f.add_trace(go.Scatter(x=[d],y=[k],mode="markers+text",
                marker=dict(color=clr,size=10),showlegend=False,
                text=[f"d={d:+.2f}  p={p:.4f} {s}"],
                textfont=dict(size=9),textposition="top center",
                hovertemplate=f"{lbl}<br>d={d:+.3f}<br>p={p:.4f}<extra></extra>"))
        fig_f.add_vline(x=0,line_color="#9aa5b4",line_width=1)
        fig_f.add_vline(x=0.5,line_dash="dot",line_color="#27ae60",line_width=1)
        fig_f.add_vline(x=-0.5,line_dash="dot",line_color="#27ae60",line_width=1)
        fig_f.update_layout(
            title=dict(text=f"Forest Plot — Cohen's d  |  {glob_txt}",font=dict(size=11,color="#1e3a5f")),
            plot_bgcolor=BG,paper_bgcolor="#fff",height=max(300,len(labels)*38+80),
            xaxis=dict(title="Cohen's d",gridcolor=GRID,zeroline=False),
            yaxis=dict(tickvals=list(range(len(labels))),ticktext=labels,gridcolor=GRID),
            margin=dict(l=160,r=40,t=60,b=50),font=dict(family=FONT,size=10))

        # Heatmap pvalues
        n_g=len(groups)
        pmat=np.ones((n_g,n_g))
        for (i,j),p in zip(pairs,pvals_c): pmat[i,j]=pmat[j,i]=p
        np.fill_diagonal(pmat,np.nan)
        g_lbls=[str(g)[:14] for g in groups]
        fig_h=go.Figure(go.Heatmap(z=pmat,x=g_lbls,y=g_lbls[::-1],
            colorscale=[[0,"#27ae60"],[alpha/2,"#f39c12"],[alpha,"#fffde7"],[1,"#f7f8fa"]],
            zmin=0,zmax=1,hovertemplate="%{x} vs %{y}<br>p=%{z:.4f}<extra></extra>",
            colorbar=dict(title="p",thickness=12)))
        fig_h.update_layout(
            title=dict(text=f"p-values ({method.upper()}, α={alpha})",font=dict(size=11,color="#1e3a5f")),
            plot_bgcolor=BG,paper_bgcolor="#fff",height=max(280,n_g*35+100),
            margin=dict(l=100,r=20,t=50,b=90),font=dict(family=FONT,size=10),
            xaxis=dict(tickangle=-40),yaxis=dict(autorange="reversed"))

        return html.Div([
            dcc.Graph(figure=fig_f,config={"displayModeBar":False},style={"height":f"{max(300,len(labels)*38+80)}px"}),
            html.Div(style={"height":"16px"}),
            dcc.Graph(figure=fig_h,config={"displayModeBar":False},style={"height":f"{max(280,n_g*35+100)}px"}),
        ])
