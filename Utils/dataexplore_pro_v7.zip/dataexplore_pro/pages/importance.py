"""
Importance des Variables v7
  • Lit entièrement depuis dep.cache["importance"] — 0 recompute
  • Multi-métriques : pearson, spearman, fstat, mi, rf, global
  • Tri + filtre top-N : O(p log p) numpy
  • Heatmap features×métriques
"""
from __future__ import annotations
import numpy as np, pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
GRID = "#e0e4ea"; BG = "#f7f8fa"; FONT = "Plus Jakarta Sans, sans-serif"

METRIC_LABELS = {
    "pearson":"Pearson |r|","spearman":"Spearman |ρ|",
    "fstat":"F-Stat","mi":"Info Mutuelle","rf":"Random Forest","global":"Score Global"
}
METRIC_COLORS = {
    "pearson":"#4472c4","spearman":"#e07b39","fstat":"#27ae60",
    "mi":"#e74c3c","rf":"#9b59b6","global":"#1abc9c"
}


def layout(dep):
    num = dep.num_features
    metrics_avail = ["global","pearson","spearman","fstat","mi","rf"] if dep.supervised \
                    else ["pearson","spearman"]
    metric_opts = [{"label":METRIC_LABELS.get(m,m),"value":m} for m in metrics_avail]

    return html.Div([
        html.Div("Importance des Variables", className="page-title"),
        html.Div("Précalculé (RF + MI + F-stat + Pearson + Spearman) sur échantillon ≤ 100k lignes.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Top N:", className="control-label"),
                      dcc.Slider(id="imp-topn", min=5, max=min(50,len(num)), step=5,
                                 value=min(20,len(num)),
                                 marks={v:str(v) for v in [5,10,20,30,50] if v<=len(num)},
                                 tooltip={"placement":"bottom"})],
                     className="control-group", style={"minWidth":"220px"}),
            html.Div([html.Div("Trier par:", className="control-label"),
                      dcc.Dropdown(id="imp-sort", options=metric_opts,
                                   value="global", clearable=False)],
                     className="control-group", style={"maxWidth":"200px"}),
            html.Div([html.Div("Vue:", className="control-label"),
                      dcc.RadioItems(id="imp-view",
                                     options=[{"label":" Barres","value":"bar"},
                                              {"label":" Heatmap","value":"heat"}],
                                     value="bar", inline=True,
                                     labelStyle={"fontSize":"12.5px","marginRight":"12px"})],
                     className="control-group"),
        ], className="controls-row"),

        html.Div([dcc.Loading(html.Div(id="imp-main"), type="circle", color="#4472c4")],
                 className="chart-card"),
    ], className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        Output("imp-main","children"),
        [Input("imp-topn","value"), Input("imp-sort","value"), Input("imp-view","value")],
    )
    def update(top_n, sort_by, view):
        imp = dep.cache.get("importance")   # blocks until ready, then O(1)

        num = dep.num_features
        top_n = top_n or 20

        if imp is None or not dep.supervised:
            # Unsupervised fallback: variance from fstats
            fst = dep.cache.get("fstats")
            if fst is None:
                return html.Div("Précalcul en cours…", style={"padding":"20px","color":"#6b7a8d"})
            std_v = fst["std"]
            order = np.argsort(std_v)[::-1][:top_n]
            cols_ = [num[i] for i in order]
            vals_ = std_v[order] / (std_v.max()+1e-9)
            fig = go.Figure(go.Bar(y=cols_[::-1], x=vals_[::-1], orientation="h",
                                    marker_color="#4472c4", opacity=0.82,
                                    hovertemplate="%{y}<br>Std norm.: %{x:.3f}<extra></extra>"))
            fig.update_layout(**_base("Variance (std) normalisée"),
                              xaxis_title="Std normalisée", height=max(300,top_n*22+80))
            return dcc.Graph(figure=fig, config={"displayModeBar":False},
                             style={"height":f"{max(300,top_n*22+80)}px"})

        cols = imp["cols"]
        p    = len(cols)
        avail = [m for m in ["global","pearson","spearman","fstat","mi","rf"] if m in imp]
        sort_by = sort_by if sort_by in avail else avail[0]

        sort_arr = imp.get(sort_by, imp[avail[0]])
        order    = np.argsort(sort_arr)[::-1][:top_n]
        sel_cols = [cols[i] for i in order]

        if view == "bar":
            fig = go.Figure()
            for metric in avail:
                vals = imp[metric]
                fig.add_trace(go.Bar(
                    y=sel_cols[::-1], x=vals[order][::-1], orientation="h",
                    name=METRIC_LABELS.get(metric,metric),
                    marker_color=METRIC_COLORS.get(metric,"#4472c4"),
                    opacity=0.85,
                    hovertemplate=f"{METRIC_LABELS.get(metric,metric)}: %{{x:.3f}}<extra></extra>",
                    visible=True if metric in (sort_by,"global") else "legendonly",
                ))
            h = max(300, top_n*22+80)
            fig.update_layout(**_base(f"Importance (triée par {METRIC_LABELS.get(sort_by,sort_by)})"),
                              barmode="group", height=h,
                              xaxis_title="Score normalisé [0-1]",
                              legend=dict(font=dict(size=11), x=1.01))
            return dcc.Graph(figure=fig, config={"displayModeBar":False},
                             style={"height":f"{h}px"})
        else:
            # Heatmap
            mat = np.array([imp[m][order] for m in avail])  # (metrics, top_n)
            fig = go.Figure(go.Heatmap(
                z=mat, x=sel_cols, y=[METRIC_LABELS.get(m,m) for m in avail],
                colorscale=[[0,"#f7f8fa"],[0.5,"#4472c4"],[1,"#1e3a5f"]],
                zmin=0, zmax=1,
                hovertemplate="%{x}<br>%{y}: %{z:.3f}<extra></extra>",
                colorbar=dict(thickness=12, title="Score"),
            ))
            h = max(220, len(avail)*38+80)
            fig.update_layout(**_base("Heatmap importance — features × métriques"),
                              height=h,
                              xaxis=dict(tickangle=-45, gridcolor=GRID),
                              yaxis=dict(gridcolor=GRID))
            return dcc.Graph(figure=fig, config={"displayModeBar":False},
                             style={"height":f"{h}px"})


def _base(title=""):
    return dict(title=dict(text=title,font=dict(size=12,color="#1e3a5f")),
                plot_bgcolor=BG, paper_bgcolor="#fff",
                margin=dict(l=150,r=60,t=44,b=50),
                font=dict(family=FONT,size=11),
                xaxis=dict(gridcolor=GRID,zeroline=False),
                yaxis=dict(gridcolor=GRID,zeroline=False))
