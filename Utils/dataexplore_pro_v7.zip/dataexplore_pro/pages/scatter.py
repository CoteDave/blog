"""
Dispersion Bivariée v6
  • Scatter coloré par classe + hull convexe
  • Régression OLS + IC 95% + R² (global ou par classe)
  • Sélection lasso → stats dynamiques
  • Mann-Whitney U / χ² / Cohen's d
  • Top-10 feature diff (effect size)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy.spatial import ConvexHull
from scipy import stats as sp_stats

PAL  = ["#4472c4", "#e07b39", "#27ae60", "#e74c3c", "#9b59b6", "#1abc9c", "#f39c12"]
BG   = "#f7f8fa"
GRID = "#e0e4ea"
FONT = "Plus Jakarta Sans, sans-serif"


# ── utils ─────────────────────────────────────────────────────────────────────
def _hex_alpha(h, a):
    h = h.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{a})"

def _clr(dep, cls_val):
    try:    return PAL[list(dep.classes).index(cls_val) % len(PAL)]
    except: return PAL[0]

def _hull(x, y, color, opacity=0.11):
    pts = np.column_stack([x, y])
    pts = pts[~np.isnan(pts).any(axis=1)]
    if len(pts) < 3:
        return None
    try:
        hull = ConvexHull(pts)
        hx = np.append(pts[hull.vertices, 0], pts[hull.vertices[0], 0])
        hy = np.append(pts[hull.vertices, 1], pts[hull.vertices[0], 1])
        return go.Scatter(x=hx, y=hy, fill="toself",
                          fillcolor=_hex_alpha(color, opacity),
                          line=dict(color=color, width=1.5, dash="dot"),
                          mode="lines", showlegend=False, hoverinfo="skip")
    except Exception:
        return None

def _ols_traces(xv, yv, color="#e74c3c", name="Régression"):
    """OLS line + 95 % confidence band. Returns (traces, r2, slope)."""
    mask = ~(np.isnan(xv) | np.isnan(yv))
    x, y = xv[mask], yv[mask]
    if len(x) < 4:
        return [], 0.0, 0.0
    slope, intercept, r, _, se = sp_stats.linregress(x, y)
    r2 = r ** 2
    xs = np.linspace(x.min(), x.max(), 200)
    yp = slope * xs + intercept
    n  = len(x)
    xm = x.mean()
    se_fit = se * np.sqrt(1 / n + (xs - xm) ** 2 / ((x - xm) ** 2).sum())
    t = sp_stats.t.ppf(0.975, df=n - 2)
    up  = yp + t * se_fit * np.sqrt(n)
    low = yp - t * se_fit * np.sqrt(n)

    band = go.Scatter(
        x=np.concatenate([xs, xs[::-1]]),
        y=np.concatenate([up, low[::-1]]),
        fill="toself", fillcolor=_hex_alpha(color, 0.09),
        line=dict(width=0), showlegend=False, hoverinfo="skip",
    )
    line = go.Scatter(
        x=xs, y=yp, mode="lines",
        line=dict(color=color, width=2, dash="dash"),
        name=f"{name}  R²={r2:.3f}",
        hovertemplate=f"y = {slope:+.3g}x {intercept:+.3g}<br>R²={r2:.3f}<extra></extra>",
    )
    return [band, line], r2, slope


# ── layout ────────────────────────────────────────────────────────────────────
def layout(dep):
    num      = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]
    x_def    = num[0] if num else None
    y_def    = num[1] if len(num) > 1 else x_def

    tgt_opts = [{"label": "Tout", "value": "__all__"}]
    if dep.supervised:
        for c in dep.classes:
            tgt_opts.append({"label": f"Classe {c}", "value": str(c)})

    return html.Div([
        html.Div("Analyse Bivariée — Dispersion", className="page-title"),
        html.Div(
            "Lasso · hull convexe · régression OLS + IC 95% · Mann-Whitney U · Cohen's d.",
            className="page-subtitle",
        ),

        html.Div([
            html.Div([html.Div("Variable X:", className="control-label"),
                      dcc.Dropdown(id="sc-x", options=col_opts, value=x_def, clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Variable Y:", className="control-label"),
                      dcc.Dropdown(id="sc-y", options=col_opts, value=y_def, clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Filtrer classe:", className="control-label"),
                      dcc.Dropdown(id="sc-target", options=tgt_opts, value="__all__",
                                   clearable=False)],
                     className="control-group", style={"maxWidth": "220px"}),
            html.Div([html.Div("Hull convexe:", className="control-label"),
                      dcc.Dropdown(id="sc-hull",
                                   options=[{"label": "Activé", "value": "convex"},
                                            {"label": "Désactivé", "value": "none"}],
                                   value="convex" if dep.supervised else "none",
                                   clearable=False)],
                     className="control-group", style={"maxWidth": "170px"}),
            html.Div([html.Div("Régression OLS:", className="control-label"),
                      dcc.Dropdown(id="sc-regr",
                                   options=[
                                       {"label": "Aucune",        "value": "none"},
                                       {"label": "Globale",       "value": "global"},
                                       {"label": "Par classe",    "value": "perclass"},
                                   ],
                                   value="perclass" if dep.supervised else "global",
                                   clearable=False)],
                     className="control-group", style={"maxWidth": "190px"}),
        ], className="controls-row"),

        html.Div([
            dcc.Loading(
                dcc.Graph(id="sc-graph",
                          config={"displayModeBar": True,
                                  "modeBarButtonsToAdd": ["lasso2d", "select2d"],
                                  "scrollZoom": True},
                          style={"height": "520px"}),
                type="circle", color="#4472c4",
            ),
            html.Div([html.Div(id="sc-panel")],
                     className="stats-panel",
                     style={"overflowY": "auto", "maxHeight": "560px"}),
        ], className="scatter-layout"),
    ], className="page-card")


# ── callbacks ─────────────────────────────────────────────────────────────────
def register_callbacks(app, dep):

    @app.callback(
        Output("sc-graph", "figure"),
        [Input("sc-x", "value"), Input("sc-y", "value"),
         Input("sc-target", "value"), Input("sc-hull", "value"),
         Input("sc-regr", "value")],
    )
    def update_scatter(xc, yc, tgt_flt, hull_mode, regr_mode):
        if not xc or not yc:
            return go.Figure()
        # v7: use stratified display sample (≤50k) for rendering
        df = dep.display_df.copy()
        if tgt_flt != "__all__" and dep.supervised:
            try:
                df = df[df[dep.target_name] == type(dep.classes[0])(tgt_flt)]
            except Exception:
                pass

        fig = go.Figure()

        if dep.supervised:
            for cls in dep.classes:
                mask = df[dep.target_name] == cls
                sub  = df[mask]
                clr  = _clr(dep, cls)
                n    = int(mask.sum())
                # v7: ScatterGL for WebGL acceleration
                fig.add_trace(go.Scattergl(
                    x=sub[xc], y=sub[yc], mode="markers",
                    name=f"Classe {cls}  (n={n:,})",
                    marker=dict(color=clr, size=7, opacity=0.78,
                                line=dict(width=0.5, color="rgba(255,255,255,.5)")),
                    hovertemplate=(f"<b>Cls {cls}</b><br>"
                                   f"{xc}: %{{x:.3g}}<br>{yc}: %{{y:.3g}}<extra></extra>"),
                ))
                if hull_mode == "convex" and n >= 3:
                    h = _hull(sub[xc].values, sub[yc].values, clr)
                    if h:
                        fig.add_trace(h)
                if regr_mode == "perclass" and n >= 4:
                    for t in _ols_traces(sub[xc].values, sub[yc].values,
                                         clr, f"OLS Cls {cls}")[0]:
                        fig.add_trace(t)
        else:
            # v7: ScatterGL WebGL
            fig.add_trace(go.Scattergl(
                x=df[xc], y=df[yc], mode="markers",
                marker=dict(color="#4472c4", size=7, opacity=0.76,
                            line=dict(width=0.5, color="rgba(255,255,255,.5)")),
                hovertemplate=f"{xc}: %{{x:.3g}}<br>{yc}: %{{y:.3g}}<extra></extra>",
                name="Données",
            ))

        if regr_mode == "global":
            for t in _ols_traces(df[xc].values, df[yc].values)[0]:
                fig.add_trace(t)

        fig.update_layout(
            dragmode="lasso",
            plot_bgcolor=BG, paper_bgcolor="#fff",
            margin=dict(l=52, r=14, t=18, b=52),
            xaxis=dict(title=xc, gridcolor=GRID, zeroline=False,
                       title_font=dict(size=12), tickfont=dict(size=11)),
            yaxis=dict(title=yc, gridcolor=GRID, zeroline=False,
                       title_font=dict(size=12), tickfont=dict(size=11)),
            legend=dict(font=dict(size=11, family=FONT),
                        bgcolor="rgba(255,255,255,.92)",
                        borderwidth=1, bordercolor=GRID,
                        itemsizing="constant"),
            font=dict(family=FONT),
            hoverlabel=dict(bgcolor="#1e3a5f", font_size=12, font_color="white",
                            bordercolor="#1e3a5f"),
            uirevision="scatter-v6",
        )
        return fig

    @app.callback(
        Output("sc-panel", "children"),
        [Input("sc-graph", "selectedData"),
         Input("sc-x", "value"), Input("sc-y", "value")],
    )
    def update_panel(sel, xc, yc):
        df_all = dep.display_df.copy()  # v7: lasso indices on display_df
        idxs   = None
        if sel and sel.get("points"):
            idxs = list({p["pointIndex"] for p in sel["points"] if "pointIndex" in p})

        sel_df  = df_all.iloc[idxs] if idxs else df_all
        rest_df = df_all.drop(index=sel_df.index) \
                  if idxs and len(idxs) < len(df_all) else None
        is_lasso = idxs is not None and len(idxs) < len(df_all)

        title = (f"Sélection Lasso — {len(sel_df):,} pts"
                 if is_lasso else f"Données globales — {len(df_all):,} pts")

        panel = [html.Div(title, className="stats-panel-title")]

        # ── Basic stats ──
        rows = [_srow("N points", f"{len(sel_df):,}")]
        for col in [xc, yc]:
            if col and col in sel_df.columns:
                v = sel_df[col].dropna()
                rows.extend([
                    _srow(f"Moy. {col[:18]}", f"{v.mean():.4g}"),
                    _srow(f"Std  {col[:18]}", f"{v.std():.4g}"),
                ])
        if dep.supervised and dep.is_classification:
            cls1 = dep.classes[-1]
            rate = (sel_df[dep.target_name] == cls1).mean()
            rows.append(_srow(f"Taux cls {cls1}", f"{rate:.1%}",
                              "#e07b39" if rate > 0.5 else "#4472c4"))
        panel.append(html.Div(rows, style={"marginBottom": "12px"}))

        # ── OLS R² ──
        if xc and yc and xc in df_all and yc in df_all:
            idx_c = sel_df[xc].dropna().index.intersection(sel_df[yc].dropna().index)
            if len(idx_c) >= 4:
                _, r2, _ = _ols_traces(sel_df.loc[idx_c, xc].values,
                                        sel_df.loc[idx_c, yc].values)
                clr = "#27ae60" if r2 > 0.3 else ("#f39c12" if r2 > 0.1 else "#9aa5b4")
                panel.append(html.Div(
                    [_srow("R² (OLS)", f"{r2:.4f}", clr)],
                    style={"marginBottom": "12px"},
                ))

        # ── Target proportion bar ──
        if dep.supervised and dep.is_classification:
            panel.append(_tgt_bar(dep, sel_df, rest_df, is_lasso))

        # ── Stat tests (lasso only) ──
        if is_lasso and rest_df is not None and len(sel_df) >= 5 and len(rest_df) >= 5:
            panel.append(_stat_tests(dep, sel_df, rest_df, xc, yc))
            panel.append(_feat_diff(dep, sel_df, rest_df))

        # ── Mini histogram ──
        if xc and xc in sel_df:
            panel.append(_mini_hist(sel_df, xc))

        if not is_lasso:
            panel.append(html.Div(
                "← Utilisez lasso / box pour sélectionner des points",
                style={"fontSize": "11px", "color": "#9aa5b4",
                       "marginTop": "10px", "fontStyle": "italic"},
            ))
        return panel


# ── component helpers ──────────────────────────────────────────────────────────
def _srow(label, value, color=None):
    return html.Div([
        html.Span(label, className="stat-label"),
        html.Span(value, className="stat-value",
                  style={"color": color} if color else {}),
    ], className="stat-row")


def _tgt_bar(dep, sel_df, rest_df, is_lasso):
    classes = dep.classes
    fig = go.Figure()
    for i, cls in enumerate(classes):
        clr = PAL[i % len(PAL)]
        pct = (sel_df[dep.target_name] == cls).mean() * 100
        fig.add_trace(go.Bar(x=[f"Cls {cls}"], y=[pct],
                             marker_color=clr,
                             text=[f"{pct:.0f}%"], textposition="outside",
                             name=f"Sél. Cls {cls}"))
    if is_lasso and rest_df is not None:
        for i, cls in enumerate(classes):
            pct = (rest_df[dep.target_name] == cls).mean() * 100
            fig.add_trace(go.Bar(x=[f"Cls {cls}"], y=[pct],
                                 marker_color=PAL[i % len(PAL)], opacity=0.28,
                                 text=[f"{pct:.0f}%"], textposition="outside",
                                 showlegend=False))
    fig.update_layout(
        plot_bgcolor=BG, paper_bgcolor="#fff",
        barmode="group", height=155,
        margin=dict(l=20, r=10, t=10, b=30),
        yaxis=dict(range=[0, 118], visible=False),
        showlegend=False,
        font=dict(family=FONT, size=10),
    )
    return html.Div([
        html.Div("Répartition target (sél. vs reste)", className="chart-card-title"),
        dcc.Graph(figure=fig, config={"displayModeBar": False},
                  style={"height": "155px"}),
    ], style={"marginBottom": "12px"})


def _stat_tests(dep, sel_df, rest_df, xc, yc):
    rows = []
    for col in [xc, yc]:
        if not col or col not in dep.num_features:
            continue
        a = sel_df[col].dropna().values
        b = rest_df[col].dropna().values
        if len(a) < 3 or len(b) < 3:
            continue
        try:
            _, p = sp_stats.mannwhitneyu(a, b, alternative="two-sided")
            pooled = np.sqrt(((len(a)-1)*a.std()**2 + (len(b)-1)*b.std()**2)
                             / max(len(a)+len(b)-2, 1) + 1e-9)
            d   = (a.mean() - b.mean()) / pooled
            sig = "✅" if p < 0.05 else "❌"
            clr = "#27ae60" if p < 0.05 else "#e74c3c"
            rows.append(html.Div([
                html.Span(col[:18], style={"fontWeight": "700", "color": "#1e3a5f",
                                            "fontSize": "11.5px"}),
                html.Span(f"  d={d:+.2f}",
                          style={"fontSize": "10.5px", "color": "#6b7a8d", "marginLeft": "5px"}),
                html.Span(f"  p={p:.3f} {sig}",
                          style={"fontSize": "10.5px", "color": clr, "marginLeft": "4px"}),
            ], style={"padding": "4px 0", "borderBottom": "1px solid #f0f0f0"}))
        except Exception:
            pass

    if dep.supervised and dep.is_classification:
        try:
            mat = np.vstack([
                [(sel_df[dep.target_name]  == c).sum() for c in dep.classes],
                [(rest_df[dep.target_name] == c).sum() for c in dep.classes],
            ])
            _, p, _, _ = sp_stats.chi2_contingency(mat)
            sig = "✅" if p < 0.05 else "❌"
            clr = "#27ae60" if p < 0.05 else "#e74c3c"
            rows.append(html.Div([
                html.Span("Target (χ²)", style={"fontWeight": "700", "color": "#1e3a5f",
                                                  "fontSize": "11.5px"}),
                html.Span(f"  p={p:.3f} {sig}",
                          style={"fontSize": "10.5px", "color": clr, "marginLeft": "4px"}),
            ], style={"padding": "4px 0"}))
        except Exception:
            pass

    if not rows:
        return html.Div()
    return html.Div([
        html.Div("Tests Mann-Whitney U", className="chart-card-title",
                 style={"marginTop": "12px"}),
        html.Div(rows, style={"background": "#f7f8fa", "borderRadius": "7px",
                               "padding": "8px 10px", "border": "1.5px solid #e0e4ea",
                               "marginBottom": "12px"}),
    ])


def _feat_diff(dep, sel_df, rest_df):
    diffs, labels, colors = [], [], []
    for col in dep.num_features[:20]:
        a = sel_df[col].dropna()
        b = rest_df[col].dropna()
        if len(a) < 2 or len(b) < 2:
            continue
        pooled = np.sqrt((a.std()**2 + b.std()**2) / 2 + 1e-9)
        d = (a.mean() - b.mean()) / pooled
        diffs.append(d)
        labels.append(col[:22])
        colors.append("#e07b39" if d > 0 else "#4472c4")

    if not diffs:
        return html.Div()

    order = np.argsort(np.abs(diffs))[::-1][:10]
    ds = [diffs[i] for i in order]
    ls = [labels[i] for i in order]
    cs = [colors[i] for i in order]

    h = max(160, len(ls) * 24 + 40)
    fig = go.Figure(go.Bar(
        y=ls[::-1], x=ds[::-1], orientation="h",
        marker_color=cs[::-1],
        text=[f"{d:+.2f}σ" for d in ds[::-1]],
        textposition="outside",
        hovertemplate="%{y}<br>Cohen's d: %{x:+.3f}<extra></extra>",
    ))
    fig.add_vline(x=0, line_color="#9aa5b4", line_width=1)
    fig.update_layout(
        plot_bgcolor=BG, paper_bgcolor="#fff",
        height=h, margin=dict(l=130, r=55, t=8, b=28),
        xaxis=dict(title="Cohen's d", gridcolor=GRID, zeroline=False),
        yaxis=dict(gridcolor=GRID),
        font=dict(family=FONT, size=10),
        showlegend=False,
    )
    return html.Div([
        html.Div("Top Features — Sélection vs Reste", className="chart-card-title",
                 style={"marginTop": "12px"}),
        dcc.Graph(figure=fig, config={"displayModeBar": False},
                  style={"height": f"{h}px"}),
    ], style={"marginBottom": "12px"})


def _mini_hist(df, col):
    vals = df[col].dropna()
    fig  = go.Figure(go.Histogram(
        x=vals, nbinsx=20, marker_color="#4472c4", opacity=0.82,
        hovertemplate=f"{col}: %{{x}}<br>N: %{{y}}<extra></extra>",
    ))
    fig.add_vline(x=float(vals.mean()), line_dash="dash",
                  line_color="#e07b39", line_width=1.5,
                  annotation_text=f"μ={vals.mean():.3g}", annotation_font_size=9)
    fig.update_layout(
        plot_bgcolor=BG, paper_bgcolor="#fff",
        height=140, margin=dict(l=28, r=8, t=8, b=34),
        xaxis=dict(title=col, gridcolor=GRID, zeroline=False),
        yaxis=dict(gridcolor=GRID),
        font=dict(family=FONT, size=10),
        showlegend=False,
    )
    return html.Div([
        html.Div(f"Distribution {col}", className="chart-card-title"),
        dcc.Graph(figure=fig, config={"displayModeBar": False},
                  style={"height": "140px"}),
    ])
