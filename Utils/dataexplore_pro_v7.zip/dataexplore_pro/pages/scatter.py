"""
Dispersion Bivariée v7 — ultra-rapide
  • ScatterGL (WebGL) pour N > 10 000 points
  • display_df (50k) pour les graphiques
  • Régression OLS sur sample ≤ 20 000 pts
  • Stats panel lit depuis dep.cache
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy.spatial import ConvexHull
from scipy import stats as sp_stats

PAL  = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6","#1abc9c","#f39c12"]
BG   = "#f7f8fa"; GRID = "#e0e4ea"; FONT = "Plus Jakarta Sans, sans-serif"
USE_GL_THRESHOLD = 10_000   # use ScatterGL above this


def _hex_alpha(h, a):
    h = h.lstrip("#"); r,g,b = int(h[:2],16),int(h[2:4],16),int(h[4:],16)
    return f"rgba({r},{g},{b},{a})"

def _clr(dep, cls):
    try: return PAL[list(dep.classes).index(cls) % len(PAL)]
    except: return PAL[0]

def _hull(x, y, color):
    pts = np.column_stack([x,y]); pts = pts[~np.isnan(pts).any(1)]
    if len(pts) < 3: return None
    try:
        hull = ConvexHull(pts)
        hx = np.append(pts[hull.vertices,0], pts[hull.vertices[0],0])
        hy = np.append(pts[hull.vertices,1], pts[hull.vertices[0],1])
        return go.Scatter(x=hx,y=hy,fill="toself",
                          fillcolor=_hex_alpha(color,.10),
                          line=dict(color=color,width=1.5,dash="dot"),
                          mode="lines",showlegend=False,hoverinfo="skip")
    except: return None

def _ols(xv, yv, color="#e74c3c", name="OLS"):
    mask = ~(np.isnan(xv)|np.isnan(yv)); x,y = xv[mask],yv[mask]
    if len(x) < 4: return [], 0.0
    sl,ic,r,_,se = sp_stats.linregress(x,y); r2 = r**2
    xs = np.linspace(x.min(),x.max(),200); yp = sl*xs+ic
    n = len(x); xm = x.mean()
    se_b = se*np.sqrt(1/n+(xs-xm)**2/max(((x-xm)**2).sum(),1e-9))
    t = sp_stats.t.ppf(.975, df=n-2)
    up = yp+t*se_b*np.sqrt(n); lo = yp-t*se_b*np.sqrt(n)
    band = go.Scatter(x=np.concatenate([xs,xs[::-1]]),
                      y=np.concatenate([up,lo[::-1]]),
                      fill="toself",fillcolor=_hex_alpha(color,.08),
                      line=dict(width=0),showlegend=False,hoverinfo="skip")
    line = go.Scatter(x=xs,y=yp,mode="lines",
                      line=dict(color=color,width=2,dash="dash"),
                      name=f"{name}  R²={r2:.3f}",
                      hovertemplate=f"R²={r2:.3f}<extra></extra>")
    return [band,line], r2


def layout(dep):
    num = dep.num_features
    col_opts = [{"label":c,"value":c} for c in num]
    x_def = num[0] if num else None
    y_def = num[1] if len(num)>1 else x_def
    tgt_opts = [{"label":"Tout","value":"__all__"}]
    if dep.supervised:
        for c in dep.classes: tgt_opts.append({"label":f"Classe {c}","value":str(c)})
    n_disp = len(dep.display_df)
    n_full = len(dep.df)
    sub = "" if n_full == n_disp else f" — échantillon {n_disp:,}/{n_full:,}"

    return html.Div([
        html.Div("Analyse Bivariée — Dispersion", className="page-title"),
        html.Div(f"ScatterGL · hull convexe · OLS+IC 95%{sub}.", className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Variable X:",className="control-label"),
                      dcc.Dropdown(id="sc-x",options=col_opts,value=x_def,clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Variable Y:",className="control-label"),
                      dcc.Dropdown(id="sc-y",options=col_opts,value=y_def,clearable=False)],
                     className="control-group"),
            html.Div([html.Div("Classe:",className="control-label"),
                      dcc.Dropdown(id="sc-target",options=tgt_opts,value="__all__",clearable=False)],
                     className="control-group",style={"maxWidth":"200px"}),
            html.Div([html.Div("Hull:",className="control-label"),
                      dcc.Dropdown(id="sc-hull",
                                   options=[{"label":"Convexe","value":"convex"},{"label":"Aucun","value":"none"}],
                                   value="convex" if dep.supervised else "none",clearable=False)],
                     className="control-group",style={"maxWidth":"160px"}),
            html.Div([html.Div("Régression:",className="control-label"),
                      dcc.Dropdown(id="sc-regr",
                                   options=[{"label":"Aucune","value":"none"},
                                            {"label":"Globale","value":"global"},
                                            {"label":"Par classe","value":"perclass"}],
                                   value="perclass" if dep.supervised else "global",clearable=False)],
                     className="control-group",style={"maxWidth":"190px"}),
        ],className="controls-row"),
        html.Div([
            dcc.Loading(dcc.Graph(id="sc-graph",
                          config={"displayModeBar":True,
                                  "modeBarButtonsToAdd":["lasso2d","select2d"],
                                  "scrollZoom":True},
                          style={"height":"520px"}),
                        type="circle",color="#4472c4"),
            html.Div([html.Div(id="sc-panel")],className="stats-panel",
                     style={"overflowY":"auto","maxHeight":"560px"}),
        ],className="scatter-layout"),
    ],className="page-card")


def register_callbacks(app, dep):
    _use_gl = len(dep.display_df) > USE_GL_THRESHOLD
    ScatterFn = go.Scattergl if _use_gl else go.Scatter

    @app.callback(
        Output("sc-graph","figure"),
        [Input("sc-x","value"),Input("sc-y","value"),
         Input("sc-target","value"),Input("sc-hull","value"),
         Input("sc-regr","value")],
    )
    def update_scatter(xc,yc,tgt_flt,hull_mode,regr_mode):
        if not xc or not yc: return go.Figure()
        df = dep.display_df  # ALWAYS use display sample
        if tgt_flt != "__all__" and dep.supervised:
            try: df = df[df[dep.target_name]==type(dep.classes[0])(tgt_flt)]
            except: pass
        fig = go.Figure()
        if dep.supervised:
            for cls in dep.classes:
                mask = df[dep.target_name]==cls; sub = df[mask]; clr = _clr(dep,cls); n = int(mask.sum())
                fig.add_trace(ScatterFn(x=sub[xc],y=sub[yc],mode="markers",
                    name=f"Cls {cls} (n={n:,})",
                    marker=dict(color=clr,size=5,opacity=0.72,
                                line=dict(width=0,color="rgba(0,0,0,0)")),
                    hovertemplate=f"<b>Cls {cls}</b><br>{xc}: %{{x:.3g}}<br>{yc}: %{{y:.3g}}<extra></extra>"))
                if hull_mode=="convex" and n>=3:
                    h = _hull(sub[xc].values,sub[yc].values,clr)
                    if h: fig.add_trace(h)
                if regr_mode=="perclass" and n>=4:
                    for t in _ols(sub[xc].values,sub[yc].values,clr,f"OLS Cls {cls}")[0]: fig.add_trace(t)
        else:
            fig.add_trace(ScatterFn(x=df[xc],y=df[yc],mode="markers",
                marker=dict(color="#4472c4",size=5,opacity=0.72,
                            line=dict(width=0,color="rgba(0,0,0,0)")),
                hovertemplate=f"{xc}: %{{x:.3g}}<br>{yc}: %{{y:.3g}}<extra></extra>",name="Données"))
        if regr_mode=="global":
            for t in _ols(df[xc].values,df[yc].values)[0]: fig.add_trace(t)
        fig.update_layout(dragmode="lasso",plot_bgcolor=BG,paper_bgcolor="#fff",
            margin=dict(l=50,r=12,t=16,b=50),
            xaxis=dict(title=xc,gridcolor=GRID,zeroline=False),
            yaxis=dict(title=yc,gridcolor=GRID,zeroline=False),
            legend=dict(font=dict(size=11,family=FONT),bgcolor="rgba(255,255,255,.92)",
                        borderwidth=1,bordercolor=GRID,itemsizing="constant"),
            font=dict(family=FONT),
            hoverlabel=dict(bgcolor="#1e3a5f",font_size=12,font_color="white"),
            uirevision="sc-v7")
        return fig

    @app.callback(Output("sc-panel","children"),
                  [Input("sc-graph","selectedData"),Input("sc-x","value"),Input("sc-y","value")])
    def update_panel(sel,xc,yc):
        df = dep.display_df
        idxs = None
        if sel and sel.get("points"):
            idxs = list({p["pointIndex"] for p in sel["points"] if "pointIndex" in p})
        sel_df  = df.iloc[idxs] if idxs else df
        rest_df = df.drop(index=sel_df.index) if idxs and len(idxs)<len(df) else None
        is_l    = idxs is not None and len(idxs)<len(df)
        title   = (f"Lasso — {len(sel_df):,} pts" if is_l else f"Sample — {len(df):,} pts")
        panel   = [html.Div(title,className="stats-panel-title")]

        rows = [_srow("N",f"{len(sel_df):,}")]
        for col in [xc,yc]:
            if col and col in sel_df.columns:
                v = sel_df[col].dropna()
                rows += [_srow(f"μ {col[:16]}",f"{v.mean():.4g}"),
                          _srow(f"σ {col[:16]}",f"{v.std():.4g}")]
        if dep.supervised and dep.is_classification:
            cls1 = dep.classes[-1]; rate=(sel_df[dep.target_name]==cls1).mean()
            rows.append(_srow(f"Taux cls {cls1}",f"{rate:.1%}","#e07b39" if rate>.5 else "#4472c4"))
        panel.append(html.Div(rows,style={"marginBottom":"10px"}))

        if xc and yc and xc in df and yc in df:
            idx_c = sel_df[xc].dropna().index.intersection(sel_df[yc].dropna().index)
            if len(idx_c)>=4:
                _,r2=_ols(sel_df.loc[idx_c,xc].values,sel_df.loc[idx_c,yc].values)
                clr="#27ae60" if r2>.3 else ("#f39c12" if r2>.1 else "#9aa5b4")
                panel.append(html.Div([_srow("R² (OLS)",f"{r2:.4f}",clr)],style={"marginBottom":"10px"}))

        if is_l and rest_df is not None and len(sel_df)>=5 and len(rest_df)>=5:
            panel.append(_stat_tests(dep,sel_df,rest_df,xc,yc))
            panel.append(_feat_diff(dep,sel_df,rest_df))
        if xc and xc in sel_df: panel.append(_mini_hist(sel_df,xc))
        if not is_l: panel.append(html.Div("← Lasso pour sélectionner",
            style={"fontSize":"11px","color":"#9aa5b4","fontStyle":"italic","marginTop":"8px"}))
        return panel


def _srow(l,v,c=None):
    return html.Div([html.Span(l,className="stat-label"),
                     html.Span(v,className="stat-value",style={"color":c} if c else {})],
                    className="stat-row")

def _stat_tests(dep,sel_df,rest_df,xc,yc):
    rows=[]
    for col in [xc,yc]:
        if not col or col not in dep.num_features: continue
        a=sel_df[col].dropna().values; b=rest_df[col].dropna().values
        if len(a)<3 or len(b)<3: continue
        try:
            _,p=sp_stats.mannwhitneyu(a,b,alternative="two-sided")
            pooled=np.sqrt(((len(a)-1)*a.std()**2+(len(b)-1)*b.std()**2)/max(len(a)+len(b)-2,1)+1e-9)
            d=(a.mean()-b.mean())/pooled; sig="✅" if p<.05 else "❌"; clr="#27ae60" if p<.05 else "#e74c3c"
            rows.append(html.Div([
                html.Span(col[:16],style={"fontWeight":"700","color":"#1e3a5f","fontSize":"11px"}),
                html.Span(f"  d={d:+.2f}",style={"fontSize":"10px","color":"#6b7a8d","marginLeft":"4px"}),
                html.Span(f"  p={p:.3f} {sig}",style={"fontSize":"10px","color":clr,"marginLeft":"4px"}),
            ],style={"padding":"3px 0","borderBottom":"1px solid #f0f0f0"}))
        except: pass
    if not rows: return html.Div()
    return html.Div([html.Div("Mann-Whitney U",className="chart-card-title",style={"marginTop":"10px"}),
        html.Div(rows,style={"background":"#f7f8fa","borderRadius":"7px","padding":"7px 9px",
                              "border":"1.5px solid #e0e4ea","marginBottom":"10px"})])

def _feat_diff(dep,sel_df,rest_df):
    diffs,labels,colors=[],[],[]
    for col in dep.num_features[:20]:
        a=sel_df[col].dropna(); b=rest_df[col].dropna()
        if len(a)<2 or len(b)<2: continue
        pooled=np.sqrt((a.std()**2+b.std()**2)/2+1e-9)
        d=(a.mean()-b.mean())/pooled; diffs.append(d); labels.append(col[:20])
        colors.append("#e07b39" if d>0 else "#4472c4")
    if not diffs: return html.Div()
    order=np.argsort(np.abs(diffs))[::-1][:10]
    ds=[diffs[i] for i in order]; ls=[labels[i] for i in order]; cs=[colors[i] for i in order]
    h=max(150,len(ls)*22+35)
    fig=go.Figure(go.Bar(y=ls[::-1],x=ds[::-1],orientation="h",marker_color=cs[::-1],
                          text=[f"{d:+.2f}σ" for d in ds[::-1]],textposition="outside",
                          hovertemplate="%{y}: %{x:+.3f}σ<extra></extra>"))
    fig.add_vline(x=0,line_color="#9aa5b4",line_width=1)
    fig.update_layout(plot_bgcolor=BG,paper_bgcolor="#fff",height=h,showlegend=False,
                      font=dict(family=FONT,size=10),margin=dict(l=125,r=50,t=6,b=24),
                      xaxis=dict(title="Cohen's d",gridcolor=GRID,zeroline=False))
    return html.Div([html.Div("Top Features — Sélection vs Reste",className="chart-card-title",style={"marginTop":"10px"}),
        dcc.Graph(figure=fig,config={"displayModeBar":False},style={"height":f"{h}px"})],
        style={"marginBottom":"10px"})

def _mini_hist(df,col):
    vals=df[col].dropna()
    fig=go.Figure(go.Histogram(x=vals,nbinsx=20,marker_color="#4472c4",opacity=0.82,
                                hovertemplate=f"{col}: %{{x}}<br>N: %{{y}}<extra></extra>"))
    fig.add_vline(x=float(vals.mean()),line_dash="dash",line_color="#e07b39",line_width=1.5,
                  annotation_text=f"μ={vals.mean():.3g}",annotation_font_size=9)
    fig.update_layout(plot_bgcolor=BG,paper_bgcolor="#fff",height=130,showlegend=False,
                      font=dict(family=FONT,size=10),margin=dict(l=26,r=6,t=6,b=30),
                      xaxis=dict(title=col,gridcolor=GRID,zeroline=False),
                      yaxis=dict(gridcolor=GRID))
    return html.Div([html.Div(f"Distribution {col}",className="chart-card-title"),
        dcc.Graph(figure=fig,config={"displayModeBar":False},style={"height":"130px"})])
