"""
Matrices de Corrélation — shape-based matrix with Pearson / Spearman / Kendall /
Phi-k / Mutual Information / Predictive Power Score.

Features:
  • Shape per cell: Square / Diamond / Circle / Octagon / Triangle
  • Size ∝ |r|  (strong = big, weak = tiny)
  • Half-matrix toggle
  • Threshold filter (hide |r| < threshold)
  • Multiple colour gradients
  • Cluster colouring (hierarchical groups)
  • Rich hover tooltip
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

# ── palette helpers ──────────────────────────────────────────────────────────
COLOUR_SCALES = {
    "RdBu":       [[0,"#e74c3c"],[0.5,"#ffffff"],[1,"#4472c4"]],
    "RdYlGn":     [[0,"#e74c3c"],[0.5,"#fffde7"],[1,"#27ae60"]],
    "PurpOrange":  [[0,"#7b2d8b"],[0.5,"#f5f5f5"],[1,"#e07b39"]],
    "CoolWarm":   [[0,"#3b4cc0"],[0.5,"#dddddd"],[1,"#b40426"]],
    "Viridis":    [[0,"#440154"],[0.25,"#31688e"],[0.5,"#35b779"],[1,"#fde725"]],
    "Plasma":     [[0,"#0d0887"],[0.5,"#cc4778"],[1,"#f0f921"]],
}

SHAPE_SYMBOLS = {
    "Square":   "square",
    "Diamond":  "diamond",
    "Circle":   "circle",
    "Octagon":  "octagon",
    "Triangle": "triangle-up",
    "Star":     "star",
    "Hexagon":  "hexagon",
}

CLUSTER_PALETTE = [
    "#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6",
    "#1abc9c","#f39c12","#2980b9","#8e44ad","#d35400",
]

BG   = "#f7f8fa"
GRID = "#e0e4ea"


# ════════════════════════════════════════════════════════════════════════════
#  METRIC COMPUTATION
# ════════════════════════════════════════════════════════════════════════════

def _compute_corr(df: pd.DataFrame, cols: list[str], method: str) -> pd.DataFrame:
    """Return correlation matrix for chosen metric."""
    X = df[cols].copy()

    if method in ("pearson", "spearman", "kendall"):
        return X.corr(method=method)

    elif method == "phik":
        return _phik_matrix(X, cols)

    elif method == "mi":
        return _mi_matrix(X, cols)

    elif method == "pps":
        return _pps_matrix(X, cols)

    return X.corr(method="pearson")


# ── Phi-k ────────────────────────────────────────────────────────────────────
def _phik_matrix(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """
    Phi-k correlation: based on chi² from 2-D histogram.
    Returns symmetric matrix in [0, 1].
    """
    n = len(cols)
    mat = np.ones((n, n))

    for i, j in combinations(range(n), 2):
        xi = df[cols[i]].dropna()
        xj = df[cols[j]].dropna()
        idx = xi.index.intersection(xj.index)
        if len(idx) < 4:
            mat[i, j] = mat[j, i] = 0.0
            continue
        xi_v, xj_v = xi.loc[idx].values, xj.loc[idx].values

        # Bin both to 8 equal bins
        try:
            bins_i = np.histogram_bin_edges(xi_v, bins=min(8, len(np.unique(xi_v))))
            bins_j = np.histogram_bin_edges(xj_v, bins=min(8, len(np.unique(xj_v))))
            hist, _, _ = np.histogram2d(xi_v, xj_v, bins=[bins_i, bins_j])
            # chi² → phi-k
            chi2, _, _, _ = sp_stats.chi2_contingency(hist + 1e-6)
            n_obs = len(idx)
            k = min(len(bins_i), len(bins_j)) - 1
            phik = float(np.sqrt(chi2 / max(n_obs * k, 1e-9)))
            phik = min(phik, 1.0)
        except Exception:
            phik = 0.0

        mat[i, j] = mat[j, i] = phik

    return pd.DataFrame(mat, index=cols, columns=cols)


# ── Mutual Information ───────────────────────────────────────────────────────
def _mi_matrix(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """Mutual information (normalised to [0,1])."""
    from sklearn.feature_selection import mutual_info_regression
    from sklearn.preprocessing import QuantileTransformer

    n = len(cols)
    mat = np.ones((n, n))

    X_clean = df[cols].fillna(df[cols].median())
    # Normalise so MI is more comparable
    qt = QuantileTransformer(output_distribution="normal", random_state=0)
    X_norm = qt.fit_transform(X_clean.values)

    for i, j in combinations(range(n), 2):
        try:
            mi = mutual_info_regression(
                X_norm[:, [i]], X_norm[:, j], random_state=0)[0]
            # Normalise: divide by sqrt(H(i)*H(j))  → [0,1] approx
            hi = mutual_info_regression(X_norm[:, [i]], X_norm[:, i], random_state=0)[0]
            hj = mutual_info_regression(X_norm[:, [j]], X_norm[:, j], random_state=0)[0]
            norm = np.sqrt(max(hi * hj, 1e-9))
            val  = float(np.clip(mi / norm, 0, 1))
        except Exception:
            val = 0.0
        mat[i, j] = mat[j, i] = val

    return pd.DataFrame(mat, index=cols, columns=cols)


# ── Predictive Power Score ───────────────────────────────────────────────────
def _pps_matrix(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """
    Simplified PPS: R² gain of a decision tree over a naive baseline.
    Asymmetric: pps[i,j] = how well col_i predicts col_j.
    """
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.model_selection import cross_val_score

    n = len(cols)
    mat = np.zeros((n, n))
    np.fill_diagonal(mat, 1.0)

    X_clean = df[cols].fillna(df[cols].median()).values

    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            xi = X_clean[:, i].reshape(-1, 1)
            yj = X_clean[:, j]
            try:
                dt  = DecisionTreeRegressor(max_depth=4, min_samples_leaf=10,
                                             random_state=0)
                r2s = cross_val_score(dt, xi, yj, cv=3, scoring="r2")
                r2  = float(np.mean(r2s))
                mat[i, j] = float(np.clip(r2, 0, 1))
            except Exception:
                mat[i, j] = 0.0

    return pd.DataFrame(mat, index=cols, columns=cols)


# ── Cluster colouring ────────────────────────────────────────────────────────
def _cluster_labels(corr_abs: np.ndarray, n_clusters: int = 5) -> np.ndarray:
    """Return cluster label (int) per feature via hierarchical clustering."""
    from scipy.cluster.hierarchy import linkage, fcluster
    from scipy.spatial.distance  import squareform

    dist = np.clip(1 - corr_abs, 0, None)
    np.fill_diagonal(dist, 0)
    condensed = squareform(dist, checks=False)
    condensed  = np.clip(condensed, 0, None)
    try:
        Z      = linkage(condensed, method="ward")
        labels = fcluster(Z, n_clusters, criterion="maxclust")
    except Exception:
        labels = np.ones(len(corr_abs), dtype=int)
    return labels


# ════════════════════════════════════════════════════════════════════════════
#  FIGURE BUILDER
# ════════════════════════════════════════════════════════════════════════════

def _build_shape_matrix(
    corr:       pd.DataFrame,
    labels:     list[str],
    shape:      str,
    colorscale: str,
    half:       bool,
    threshold:  float,
    cluster_on: bool,
    cluster_labels: np.ndarray | None,
    method:     str,
    is_signed:  bool,       # False for MI / phik / PPS (always positive)
) -> go.Figure:

    n     = len(labels)
    cs    = COLOUR_SCALES.get(colorscale, COLOUR_SCALES["RdBu"])
    sym   = SHAPE_SYMBOLS.get(shape, "square")
    z_mat = corr.values.astype(float)

    # Colour helper: map value in [-1,1] or [0,1] → hex
    def _val_to_colour(v: float) -> str:
        t = (v + 1) / 2 if is_signed else float(np.clip(v, 0, 1))
        # Linear interpolation through colorscale stops
        stops = cs
        t = float(np.clip(t, 0, 1))
        for k in range(len(stops) - 1):
            t0, c0 = stops[k]
            t1, c1 = stops[k + 1]
            if t0 <= t <= t1:
                frac = (t - t0) / max(t1 - t0, 1e-9)
                return _lerp_hex(c0, c1, frac)
        return stops[-1][1]

    # ── Compute pixel size per cell so markers always fill nicely ────────────
    # height = max(460, n*40+140); plot_h ≈ height - 185 (margins t=55 b=130)
    chart_h   = max(460, n * 40 + 140)
    plot_h_px = max(chart_h - 185, 100)
    px_per_cell = plot_h_px / max(n, 1)
    # max marker fills 85% of cell; minimum = 12% of cell so r≈0 is still visible
    max_sz  = px_per_cell * 0.85
    min_sz  = max(4.0, px_per_cell * 0.12)

    # Traces: one per shape (scatter with individual markers)
    xs, ys, sizes, raw_vals, hovers, border_colours = [], [], [], [], [], []

    for i in range(n):
        for j in range(n):
            if half and j > i:               # upper triangle → skip
                continue
            v    = z_mat[i, j]
            absv = abs(v)

            if i != j and absv < threshold:  # below threshold
                continue

            # Cluster border colour
            if cluster_on and cluster_labels is not None:
                ci = cluster_labels[i] - 1
                cj = cluster_labels[j] - 1
                border_clr = (CLUSTER_PALETTE[ci % len(CLUSTER_PALETTE)]
                              if ci == cj else "rgba(200,200,200,0.3)")
            else:
                border_clr = "rgba(255,255,255,0.6)"

            if i == j:
                sz = max_sz          # diagonal: full size
            else:
                sz = min_sz + absv * (max_sz - min_sz)   # scale linearly

            hover_txt = (
                f"<b>{labels[j]}</b> → <b>{labels[i]}</b><br>"
                f"{method} = <b>{v:.4f}</b><br>"
                f"|r| = {absv:.4f}"
            )

            xs.append(j)
            ys.append(i)
            sizes.append(sz)
            raw_vals.append(float(v))
            hovers.append(hover_txt)
            border_colours.append(border_clr)

    fig = go.Figure()

    # Background grid cells (faint)
    for i in range(n):
        for j in range(n):
            if half and j > i:
                continue
            fig.add_shape(type="rect",
                          x0=j - 0.5, y0=i - 0.5,
                          x1=j + 0.5, y1=i + 0.5,
                          fillcolor="rgba(240,244,248,0.6)",
                          line=dict(color=GRID, width=0.5))

    # Shapes scatter — use raw numeric values for colorscale + colorbar
    cmin = -1.0 if is_signed else 0.0
    fig.add_trace(go.Scatter(
        x=xs, y=ys,
        mode="markers",
        marker=dict(
            symbol=sym,
            size=sizes,
            sizemode="diameter",      # sizes are in pixels (diameter)
            color=raw_vals,
            colorscale=cs,
            cmin=cmin, cmax=1.0,
            showscale=True,
            colorbar=dict(
                title=dict(text=method, font=dict(size=11)),
                thickness=14, len=0.65,
                tickfont=dict(size=10),
                x=1.02,
                tickvals=[cmin, 0, 0.5, 1.0] if is_signed else [0, 0.25, 0.5, 0.75, 1.0],
            ),
            line=dict(color=border_colours, width=1.5),
            opacity=0.92,
        ),
        text=hovers,
        hovertemplate="%{text}<extra></extra>",
        showlegend=False,
    ))

    # Diagonal labels (value text)
    for i in range(n):
        for j in range(n):
            if half and j > i:
                continue
            v    = z_mat[i, j]
            absv = abs(v)
            if i == j:
                txt_clr = "#1e3a5f"
            elif absv < threshold:
                continue
            else:
                txt_clr = "rgba(30,58,95,0.85)" if absv > 0.3 else "rgba(107,122,141,0.7)"

            if i == j:
                lbl = labels[i][:11] + "…" if len(labels[i]) > 12 else labels[i]
                fig.add_annotation(x=j, y=i, text=lbl, showarrow=False,
                                   font=dict(size=8.5, color="#1e3a5f", family="Plus Jakarta Sans"),
                                   bgcolor="rgba(255,255,255,0.7)")
            elif absv >= 0.15:
                fig.add_annotation(x=j, y=i, text=f"{v:.2f}", showarrow=False,
                                   font=dict(size=7.5, color=txt_clr,
                                             family="Plus Jakarta Sans"))

    # Cluster colouring: coloured rectangles around groups
    if cluster_on and cluster_labels is not None:
        for ci in range(1, cluster_labels.max() + 1):
            idxs = [k for k, l in enumerate(cluster_labels) if l == ci]
            if len(idxs) < 2:
                continue
            lo, hi = min(idxs), max(idxs)
            clr    = CLUSTER_PALETTE[(ci - 1) % len(CLUSTER_PALETTE)]
            fig.add_shape(type="rect",
                          x0=lo - 0.5, y0=lo - 0.5,
                          x1=hi + 0.5, y1=hi + 0.5,
                          line=dict(color=clr, width=2.5, dash="dot"),
                          fillcolor="transparent",
                          layer="above")

    # Axis layout
    half_title = " (triangle inférieur)" if half else ""
    fig.update_layout(
        title=dict(text=f"Matrice de corrélation — {method}{half_title}",
                   font=dict(size=14, color="#1e3a5f", family="Plus Jakarta Sans")),
        plot_bgcolor="white",
        paper_bgcolor="white",
        xaxis=dict(
            tickvals=list(range(n)),
            ticktext=[l[:16] + "…" if len(l) > 17 else l for l in labels],
            tickangle=-40,
            tickfont=dict(size=9.5, family="Plus Jakarta Sans", color="#1e3a5f"),
            side="bottom",
            showgrid=False,
            zeroline=False,
            range=[-0.5, n - 0.5],
            scaleanchor="y",
            scaleratio=1,
        ),
        yaxis=dict(
            tickvals=list(range(n)),
            ticktext=[l[:16] + "…" if len(l) > 17 else l for l in labels],
            tickfont=dict(size=9.5, family="Plus Jakarta Sans", color="#1e3a5f"),
            showgrid=False,
            zeroline=False,
            # Use reversed range directly (no autorange conflict)
            range=[n - 0.5, -0.5],
        ),
        margin=dict(l=130, r=90, t=55, b=130),
        font=dict(family="Plus Jakarta Sans, sans-serif", size=10),
        hoverlabel=dict(bgcolor="#1e3a5f", font_size=12, font_color="white",
                        bordercolor="#1e3a5f", font_family="Plus Jakarta Sans"),
        height=chart_h,
        showlegend=False,
    )

    return fig


# ── colour lerp helper ────────────────────────────────────────────────────────
def _lerp_hex(c0: str, c1: str, t: float) -> str:
    def parse(h):
        h = h.lstrip("#")
        if h.startswith("rgba"):
            parts = h.strip("rgba()").split(",")
            return [int(float(p)) for p in parts[:3]]
        return [int(h[i:i+2], 16) for i in (0, 2, 4)]
    r0, g0, b0 = parse(c0)
    r1, g1, b1 = parse(c1)
    r = int(r0 + (r1 - r0) * t)
    g = int(g0 + (g1 - g0) * t)
    b = int(b0 + (b1 - b0) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


# ════════════════════════════════════════════════════════════════════════════
#  LAYOUT
# ════════════════════════════════════════════════════════════════════════════

def layout(dep) -> html.Div:
    num      = dep.num_features
    col_opts = [{"label": c, "value": c} for c in num]

    ctrl_style = {"display":"flex","flexDirection":"column","gap":"4px"}

    return html.Div([
        html.Div("Matrices de Corrélation", className="page-title"),
        html.Div(
            "Matrice interactive avec formes, métriques avancées et regroupement.",
            className="page-subtitle"),

        # ── Controls row 1 ──────────────────────────────────────────────────
        html.Div([

            html.Div([
                html.Div("Métrique:", className="control-label"),
                dcc.Dropdown(
                    id="corr-method",
                    options=[
                        {"label": "Pearson",            "value": "pearson"},
                        {"label": "Spearman",           "value": "spearman"},
                        {"label": "Kendall",            "value": "kendall"},
                        {"label": "Phi-k (φk)",         "value": "phik"},
                        {"label": "Mutual Information", "value": "mi"},
                        {"label": "Predictive Power (PPS)", "value": "pps"},
                    ],
                    value="pearson",
                    clearable=False,
                    style={"width": "220px"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Forme:", className="control-label"),
                dcc.Dropdown(
                    id="corr-shape",
                    options=[{"label": k, "value": k} for k in SHAPE_SYMBOLS],
                    value="Square",
                    clearable=False,
                    style={"width": "160px"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Dégradé de couleur:", className="control-label"),
                dcc.Dropdown(
                    id="corr-colorscale",
                    options=[{"label": k, "value": k} for k in COLOUR_SCALES],
                    value="RdBu",
                    clearable=False,
                    style={"width": "170px"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Seuil |r| ≥:", className="control-label"),
                dcc.Slider(
                    id="corr-threshold",
                    min=0, max=0.9, step=0.05, value=0.0,
                    marks={0: "0", 0.15: ".15", 0.3: ".30",
                           0.5: ".50", 0.7: ".70", 0.9: ".90"},
                    tooltip={"placement": "bottom", "always_visible": False},
                ),
            ], className="control-group", style={"minWidth": "240px"}),

        ], className="controls-row"),

        # ── Controls row 2 ──────────────────────────────────────────────────
        html.Div([
            html.Div([
                html.Div("Variables:", className="control-label"),
                dcc.Dropdown(
                    id="corr-vars",
                    options=col_opts,
                    value=num[:min(18, len(num))],
                    multi=True,
                    style={"minWidth": "340px"},
                ),
            ], className="control-group"),

            html.Div([
                html.Div("Options:", className="control-label"),
                html.Div([
                    dcc.Checklist(
                        id="corr-options",
                        options=[
                            {"label": " Demi-matrice", "value": "half"},
                            {"label": " Couleur par groupe corrélé", "value": "cluster"},
                        ],
                        value=[],
                        inline=True,
                        inputStyle={"marginRight": "5px"},
                        labelStyle={"marginRight": "18px", "fontSize": "13px",
                                    "cursor": "pointer"},
                    ),
                ]),
            ], className="control-group"),

        ], className="controls-row"),

        # ── Graph ────────────────────────────────────────────────────────────
        dcc.Loading(html.Div(id="corr-graph-wrap",
                 style={"overflowX": "auto", "overflowY": "hidden"}), type="circle", color="#4472c4"),

        # ── Sorted correlation table ─────────────────────────────────────────
        html.Div([
            html.Div("🔗 Paires les plus corrélées", className="chart-card-title",
                     style={"marginTop": "6px"}),
            html.Div(id="corr-pairs-table"),
        ], className="chart-card", style={"marginTop": "16px"}),

    ], className="page-card")


# ════════════════════════════════════════════════════════════════════════════
#  CALLBACKS
# ════════════════════════════════════════════════════════════════════════════

def register_callbacks(app, dep) -> None:

    @app.callback(
        [Output("corr-graph-wrap", "children"),
         Output("corr-pairs-table", "children")],
        [Input("corr-method",     "value"),
         Input("corr-vars",       "value"),
         Input("corr-shape",      "value"),
         Input("corr-colorscale", "value"),
         Input("corr-threshold",  "value"),
         Input("corr-options",    "value")],
    )
    def update(method, vars_sel, shape, colorscale, threshold, options):
        options   = options or []
        half      = "half"    in options
        cluster_on = "cluster" in options

        if not vars_sel or len(vars_sel) < 2:
            empty = html.Div("Sélectionnez au moins 2 variables.",
                             style={"color": "#6b7a8d", "padding": "24px"})
            return empty, []

        cols = [c for c in vars_sel if c in dep.num_features][:30]
        if len(cols) < 2:
            return html.Div("Pas assez de variables numériques."), []

        # Compute correlation
        try:
            # v7: use cache for pearson/spearman; compute on display_df otherwise
            if method in ('pearson', 'spearman'):
                cache_key = 'corr_pearson' if method == 'pearson' else 'corr_spearman'
                full_corr = dep.cache.get(cache_key, wait=False)
                if full_corr is not None:
                    valid_cols = [c for c in cols if c in full_corr.index]
                    corr = full_corr.loc[valid_cols, valid_cols]
                    cols = valid_cols
                else:
                    corr = _compute_corr(dep.display_df, cols, method)
            else:
                corr = _compute_corr(dep.display_df, cols, method)
        except Exception as e:
            return html.Div(f"Erreur calcul: {e}"), []

        corr_vals = corr.values.astype(float)
        corr_abs  = np.abs(corr_vals)

        # Cluster labels
        cl_labels = None
        if cluster_on:
            cl_labels = _cluster_labels(corr_abs, n_clusters=min(6, len(cols) // 2 + 1))

        is_signed = method in ("pearson", "spearman", "kendall")

        fig = _build_shape_matrix(
            corr=corr,
            labels=cols,
            shape=shape or "Square",
            colorscale=colorscale or "RdBu",
            half=half,
            threshold=float(threshold or 0),
            cluster_on=cluster_on,
            cluster_labels=cl_labels,
            method=method,
            is_signed=is_signed,
        )

        graph = dcc.Graph(
            figure=fig,
            config={"displayModeBar": True, "scrollZoom": False},
            style={"height": f"{fig.layout.height}px",
                   "minWidth": f"{max(500, len(cols)*40+180)}px"},
        )

        # ── Sorted pairs table ────────────────────────────────────────────
        pair_rows = []
        thr = float(threshold or 0)
        for i, j in combinations(range(len(cols)), 2):
            v    = corr_vals[i, j]
            absv = abs(v)
            if absv < thr:
                continue
            pair_rows.append({
                "Feature A": cols[i],
                "Feature B": cols[j],
                method:      round(float(v), 4),
                "|r|":       round(float(absv), 4),
                "Force":     ("Très forte" if absv >= 0.7 else
                              "Forte"      if absv >= 0.5 else
                              "Modérée"    if absv >= 0.3 else
                              "Faible"),
            })

        pair_rows.sort(key=lambda x: x["|r|"], reverse=True)
        top = pair_rows[:50]

        if not top:
            table_el = html.Div("Aucune paire au-dessus du seuil.",
                                style={"color": "#6b7a8d", "fontSize": "13px",
                                       "padding": "12px"})
        else:
            FORCE_CLR = {"Très forte": "#e74c3c", "Forte": "#e07b39",
                         "Modérée": "#4472c4", "Faible": "#27ae60"}
            hdrs = ["Feature A", "Feature B", method, "|r|", "Force"]
            header = html.Tr([html.Th(h, style=_th()) for h in hdrs])
            body   = []
            for row in top:
                force_clr = FORCE_CLR.get(row["Force"], "#6b7a8d")
                bgclr = "#fff8f5" if row["|r|"] >= 0.7 else "white"
                body.append(html.Tr([
                    html.Td(row["Feature A"][:28], style=_td()),
                    html.Td(row["Feature B"][:28], style=_td()),
                    html.Td(f"{row[method]:.4f}",
                            style={**_td(), "fontWeight": "700",
                                   "color": "#e74c3c" if row[method] < 0 else "#1e3a5f"}),
                    html.Td(f"{row['|r|']:.4f}",  style={**_td(), "fontWeight": "700"}),
                    html.Td(row["Force"],
                            style={**_td(), "color": force_clr, "fontWeight": "700"}),
                ], style={"borderBottom": "1px solid #f0f4f8", "background": bgclr}))

            table_el = html.Div(
                html.Table([html.Thead(header), html.Tbody(body)],
                           style={"width": "100%", "borderCollapse": "collapse",
                                  "fontSize": "12px",
                                  "fontFamily": "Plus Jakarta Sans, sans-serif"}),
                style={"overflowX": "auto", "maxHeight": "340px", "overflowY": "auto"},
            )

        return graph, table_el


def _th():
    return {"padding": "6px 10px", "background": "#f0f4f8", "color": "#6b7a8d",
            "fontWeight": "700", "fontSize": "11px", "textTransform": "uppercase",
            "letterSpacing": ".4px", "textAlign": "left",
            "borderBottom": "2px solid #e0e4ea", "whiteSpace": "nowrap"}


def _td():
    return {"padding": "5px 10px", "color": "#374151",
            "fontSize": "12px", "whiteSpace": "nowrap"}
