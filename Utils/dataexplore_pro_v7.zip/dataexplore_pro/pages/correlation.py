"""
Matrice de Corrélation v7
  • Lit depuis dep.cache (corr_pearson / corr_spearman) — précalculé
  • Kendall calculé à la volée sur sample seulement si demandé
  • Phi-k / MI / PPS également sur le cache ou à la demande via dcc.Loading
  • Zéro recompute pour Pearson/Spearman
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from itertools import combinations
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
from scipy import stats as sp_stats

BG   = "#f7f8fa"; GRID = "#e0e4ea"; FONT = "Plus Jakarta Sans, sans-serif"

COLOUR_SCALES = {
    "RdBu":      [[0,"#e74c3c"],[0.5,"#ffffff"],[1,"#4472c4"]],
    "RdYlGn":    [[0,"#e74c3c"],[0.5,"#fffde7"],[1,"#27ae60"]],
    "PurpOrange":[[0,"#7b2d8b"],[0.5,"#f5f5f5"],[1,"#e07b39"]],
    "CoolWarm":  [[0,"#3b4cc0"],[0.5,"#dddddd"],[1,"#b40426"]],
    "Viridis":   [[0,"#440154"],[0.5,"#35b779"],[1,"#fde725"]],
}

SHAPE_SYMBOLS = {
    "Square":"square","Diamond":"diamond","Circle":"circle",
    "Octagon":"octagon","Triangle":"triangle-up","Star":"star",
}

CLUSTER_PAL = ["#4472c4","#e07b39","#27ae60","#e74c3c","#9b59b6",
               "#1abc9c","#f39c12","#2980b9","#8e44ad","#d35400"]


def _cluster_labels(corr_abs: np.ndarray, n_clusters: int) -> np.ndarray:
    from scipy.cluster.hierarchy import linkage, fcluster
    from scipy.spatial.distance  import squareform
    dist = np.clip(1 - corr_abs, 0, None)
    np.fill_diagonal(dist, 0)
    condensed = squareform(dist, checks=False)
    condensed = np.clip(condensed, 0, None)
    try:
        Z = linkage(condensed, method="ward")
        return fcluster(Z, n_clusters, criterion="maxclust")
    except Exception:
        return np.ones(len(corr_abs), dtype=int)


def _build_shape_matrix(corr: pd.DataFrame, labels: list,
                         shape: str, colorscale: list, threshold: float,
                         half_only: bool, cluster_labels=None):
    n     = len(labels)
    idx_m = {c: i for i, c in enumerate(labels)}
    sym   = SHAPE_SYMBOLS.get(shape, "square")
    SIZE_MAX = max(22, 360 // max(n, 1))

    xs, ys, sizes, colors, texts = [], [], [], [], []

    for i, ci in enumerate(labels):
        for j, cj in enumerate(labels):
            if half_only and j > i: continue
            v = corr.loc[ci, cj] if (ci in corr.index and cj in corr.columns) else 0.0
            if abs(v) < threshold and i != j: continue
            xs.append(cj); ys.append(ci)
            sizes.append(max(4, abs(v) * SIZE_MAX))
            colors.append(float(v))
            texts.append(f"{ci} × {cj}<br>r = {v:.3f}")

    # cluster border colors
    marker_line_colors = []
    if cluster_labels is not None:
        for xi, yi in zip(xs, ys):
            ci_idx = idx_m.get(xi, 0)
            clr    = CLUSTER_PAL[(cluster_labels[ci_idx] - 1) % len(CLUSTER_PAL)]
            marker_line_colors.append(clr)
    else:
        marker_line_colors = ["rgba(0,0,0,.1)"] * len(xs)

    fig = go.Figure(go.Scatter(
        x=xs, y=ys, mode="markers",
        marker=dict(symbol=sym, size=sizes,
                    color=colors, colorscale=colorscale,
                    cmin=-1, cmax=1,
                    colorbar=dict(title="r", thickness=12,
                                  tickvals=[-1,-.5,0,.5,1]),
                    line=dict(color=marker_line_colors, width=1.5),
                    sizemode="diameter"),
        text=texts, hoverinfo="text",
    ))

    fig.update_layout(
        plot_bgcolor=BG, paper_bgcolor="#fff",
        margin=dict(l=130, r=60, t=30, b=130),
        xaxis=dict(tickangle=-45, gridcolor=GRID, zeroline=False,
                   categoryorder="array", categoryarray=labels[::-1]),
        yaxis=dict(gridcolor=GRID, zeroline=False,
                   autorange="reversed",
                   categoryorder="array", categoryarray=labels),
        font=dict(family=FONT, size=11),
        height=max(400, n * 28 + 180),
        uirevision="corr-v7",
    )
    return fig


def layout(dep):
    num = dep.num_features[:100]   # cap at 100 for display clarity
    n_full = len(dep.num_features)
    col_opts = [{"label": c, "value": c} for c in num]
    cap_note = f" (100/{n_full} affichées)" if n_full > 100 else ""

    return html.Div([
        html.Div("Matrice de Corrélation", className="page-title"),
        html.Div(f"Précalculé sur échantillon ≤ 200k lignes{cap_note}.",
                 className="page-subtitle"),
        html.Div([
            html.Div([html.Div("Méthode:", className="control-label"),
                      dcc.Dropdown(id="corr-method",
                                   options=[{"label":"Pearson","value":"pearson"},
                                            {"label":"Spearman","value":"spearman"},
                                            {"label":"Kendall (lent)","value":"kendall"},
                                            {"label":"Phi-k","value":"phik"},
                                            {"label":"Inf. Mutuelle","value":"mi"},
                                            {"label":"PPS","value":"pps"}],
                                   value="pearson", clearable=False,
                                   style={"width":"180px"})],
                     className="control-group"),
            html.Div([html.Div("Forme:", className="control-label"),
                      dcc.Dropdown(id="corr-shape",
                                   options=[{"label":s,"value":s} for s in SHAPE_SYMBOLS],
                                   value="Square", clearable=False, style={"width":"150px"})],
                     className="control-group"),
            html.Div([html.Div("Couleurs:", className="control-label"),
                      dcc.Dropdown(id="corr-color",
                                   options=[{"label":k,"value":k} for k in COLOUR_SCALES],
                                   value="RdBu", clearable=False, style={"width":"160px"})],
                     className="control-group"),
            html.Div([html.Div("Seuil |r| min:", className="control-label"),
                      dcc.Slider(id="corr-thresh", min=0, max=0.9, step=0.05, value=0.0,
                                 marks={0:"0",0.3:"0.3",0.6:"0.6",0.9:"0.9"},
                                 tooltip={"placement":"bottom"})],
                     className="control-group", style={"minWidth":"220px"}),
            html.Div([html.Div("Clusters:", className="control-label"),
                      dcc.Slider(id="corr-clusters", min=1, max=8, step=1, value=3,
                                 marks={i:str(i) for i in range(1,9)})],
                     className="control-group", style={"minWidth":"200px"}),
            html.Div([html.Div("Options:", className="control-label"),
                      dcc.Checklist(id="corr-options",
                                    options=[{"label":" Demi-matrice","value":"half"}],
                                    value=[], inline=True,
                                    labelStyle={"fontSize":"12px"})],
                     className="control-group"),
            html.Div([html.Div("Variables:", className="control-label"),
                      dcc.Dropdown(id="corr-vars", options=col_opts,
                                   value=num[:min(30,len(num))], multi=True,
                                   style={"minWidth":"280px"})],
                     className="control-group"),
        ], className="controls-row"),

        html.Div([dcc.Loading(html.Div(id="corr-graph-wrap"),
                               type="circle", color="#4472c4")],
                 className="chart-card"),
    ], className="page-card")


def register_callbacks(app, dep):

    @app.callback(
        Output("corr-graph-wrap", "children"),
        [Input("corr-method","value"), Input("corr-vars","value"),
         Input("corr-shape","value"),  Input("corr-color","value"),
         Input("corr-thresh","value"), Input("corr-options","value"),
         Input("corr-clusters","value")],
    )
    def update(method, vars_sel, shape, colorname, threshold, options, n_clusters):
        if not vars_sel or len(vars_sel) < 2:
            return html.Div("Sélectionner ≥ 2 variables.", style={"padding":"20px","color":"#6b7a8d"})

        vars_sel = list(vars_sel)[:60]  # cap at 60 for legibility
        threshold = threshold or 0.0
        half = "half" in (options or [])
        cs   = COLOUR_SCALES.get(colorname, COLOUR_SCALES["RdBu"])

        # ── Read from cache (instant for pearson/spearman) ────────────────
        if method == "pearson":
            full = dep.cache.get("corr_pearson")
        elif method == "spearman":
            full = dep.cache.get("corr_spearman")
        else:
            full = None  # will compute below

        if full is not None:
            # Subset to requested variables
            valid = [c for c in vars_sel if c in full.index]
            corr  = full.loc[valid, valid]
        else:
            # Compute on demand using stats sample
            idx     = dep.cache.get("stats_idx")
            X_cache = dep.cache.get("X_display_f32")   # fallback to display
            df_sub  = dep.display_df[vars_sel].fillna(dep.display_df[vars_sel].median())
            corr    = _compute_corr_ondemand(df_sub, vars_sel, method)
            valid   = vars_sel

        corr_abs = corr.abs().values
        cl_labels = _cluster_labels(corr_abs, max(1, n_clusters)) if n_clusters > 1 else None

        fig = _build_shape_matrix(corr, valid, shape, cs, threshold, half, cl_labels)
        return dcc.Graph(figure=fig, config={"displayModeBar": True},
                         style={"height": f"{max(400, len(valid)*28+180)}px"})


def _compute_corr_ondemand(df, cols, method):
    """Slow path: only for Kendall / Phi-k / MI / PPS — on display sample."""
    if method == "kendall":
        return df.corr(method="kendall")
    elif method == "phik":
        return _phik(df, cols)
    elif method == "mi":
        return _mi_matrix(df, cols)
    elif method == "pps":
        return _pps_matrix(df, cols)
    return df.corr(method="pearson")


def _phik(df, cols):
    n = len(cols); mat = np.ones((n,n))
    for i,j in combinations(range(n),2):
        xi,xj = df[cols[i]].dropna(),df[cols[j]].dropna()
        idx = xi.index.intersection(xj.index)
        if len(idx)<4: mat[i,j]=mat[j,i]=0.0; continue
        try:
            bi = np.histogram_bin_edges(xi.loc[idx].values, bins=min(8,len(np.unique(xi.loc[idx].values))))
            bj = np.histogram_bin_edges(xj.loc[idx].values, bins=min(8,len(np.unique(xj.loc[idx].values))))
            hist,_,_ = np.histogram2d(xi.loc[idx].values,xj.loc[idx].values,bins=[bi,bj])
            chi2,_,_,_ = sp_stats.chi2_contingency(hist+1e-6)
            k = min(len(bi),len(bj))-1
            mat[i,j]=mat[j,i]=float(np.sqrt(chi2/max(len(idx)*k,1e-9)).clip(0,1))
        except: mat[i,j]=mat[j,i]=0.0
    return pd.DataFrame(mat,index=cols,columns=cols)


def _mi_matrix(df, cols):
    from sklearn.feature_selection import mutual_info_regression
    from sklearn.preprocessing import QuantileTransformer
    n = len(cols); mat = np.ones((n,n))
    Xc = df[cols].fillna(df[cols].median())
    Xn = QuantileTransformer(output_distribution="normal",random_state=0).fit_transform(Xc.values)
    for i,j in combinations(range(n),2):
        try:
            mi = mutual_info_regression(Xn[:,[i]],Xn[:,j],random_state=0)[0]
            hi = mutual_info_regression(Xn[:,[i]],Xn[:,i],random_state=0)[0]
            hj = mutual_info_regression(Xn[:,[j]],Xn[:,j],random_state=0)[0]
            mat[i,j]=mat[j,i]=float(np.clip(mi/np.sqrt(max(hi*hj,1e-9)),0,1))
        except: mat[i,j]=mat[j,i]=0.0
    return pd.DataFrame(mat,index=cols,columns=cols)


def _pps_matrix(df, cols):
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.model_selection import cross_val_score
    n = len(cols); mat = np.zeros((n,n)); np.fill_diagonal(mat,1.0)
    Xc = df[cols].fillna(df[cols].median()).values
    for i in range(n):
        for j in range(n):
            if i==j: continue
            try:
                dt = DecisionTreeRegressor(max_depth=4,min_samples_leaf=10,random_state=0)
                r2 = float(np.mean(cross_val_score(dt,Xc[:,[i]],Xc[:,j],cv=3,scoring="r2")))
                mat[i,j]=float(np.clip(r2,0,1))
            except: pass
    return pd.DataFrame(mat,index=cols,columns=cols)
