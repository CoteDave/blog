"""
core.py — DataExplore Pro v7
Optimisé pour 5M × 300 :
  • Downcast automatique float64→float32 (½ mémoire, +30% numpy speed)
  • display_df : échantillon stratifié ≤ 50k lignes pour tous les graphiques
  • Précalcul parallèle en arrière-plan (corr, PCA, importance, IV, stats)
  • Aucun callback ne fait de calcul lourd — ils lisent uniquement le cache
"""
from __future__ import annotations
import threading, time, webbrowser
from typing import List, Optional
import numpy as np
import pandas as pd

DISPLAY_N = 50_000


class DataExplorePro:
    def __init__(
        self,
        X,
        y=None,
        feature_names: Optional[List[str]] = None,
        target_name: str  = "Target",
        title: str        = "DataExplore Pro",
    ):
        t0 = time.perf_counter()

        # ── Ingestion & downcast ───────────────────────────────────────
        if isinstance(X, pd.DataFrame):
            _cols = list(X.columns)
            _raw  = X.values
        else:
            _raw  = np.asarray(X)
            _cols = list(feature_names) if feature_names else [f"F{i}" for i in range(_raw.shape[1])]

        self.feature_names: List[str] = _cols

        # Downcast: float64→float32 (halves RAM), int64→int32
        if np.issubdtype(_raw.dtype, np.floating):
            _raw = _raw.astype(np.float32)
        elif np.issubdtype(_raw.dtype, np.integer):
            _raw = _raw.astype(np.int32)

        self.df = pd.DataFrame(_raw, columns=_cols)

        # ── Target ────────────────────────────────────────────────────
        self.supervised: bool   = y is not None
        self.target_name: str   = target_name
        if y is not None:
            self.y = np.asarray(y)
            self.df[target_name]   = self.y
            self.classes: list     = sorted(np.unique(self.y).tolist())
            self.n_classes: int    = len(self.classes)
            self.is_classification = (
                self.n_classes <= 20 and
                (not np.issubdtype(self.y.dtype, np.floating) or self.n_classes == 2)
            )
        else:
            self.y = None; self.classes = []; self.n_classes = 0
            self.is_classification = False

        # ── Feature lists ─────────────────────────────────────────────
        self.num_features: List[str] = [
            c for c in self.df.columns
            if c != target_name and pd.api.types.is_numeric_dtype(self.df[c])
        ]
        self.cat_features: List[str] = [
            c for c in self.df.columns
            if c != target_name and not pd.api.types.is_numeric_dtype(self.df[c])
        ]

        # ── Stratified display sample ─────────────────────────────────
        n   = len(self.df)
        rng = np.random.default_rng(42)
        n_disp = min(DISPLAY_N, n)

        if n_disp >= n:
            self._disp_idx = np.arange(n)
        elif self.supervised and self.is_classification and self.y is not None:
            parts = []
            for cls in self.classes:
                ci = np.where(self.y == cls)[0]
                k  = max(1, int(n_disp * len(ci) / n))
                parts.append(rng.choice(ci, size=min(k, len(ci)), replace=False))
            self._disp_idx = np.concatenate(parts)[:n_disp]
        else:
            self._disp_idx = rng.choice(n, size=n_disp, replace=False)

        self.display_df = self.df.iloc[self._disp_idx].reset_index(drop=True)

        self.title = title
        self._app  = None

        elapsed = time.perf_counter() - t0
        print(f"\n  DataExplore Pro v7")
        print(f"  {n:,} lignes × {len(self.num_features)} features  |  downcast+sample en {elapsed:.2f}s")
        print(f"  Précalcul parallèle en cours…")

        # ── Launch background precompute ──────────────────────────────
        from ._precompute import build_cache
        self.cache = build_cache(self)

    def run(self, host="127.0.0.1", port=8050, debug=False, open_browser=True):
        from .app_factory import create_app
        self._app = create_app(self)
        if open_browser:
            def _open():
                time.sleep(1.5); webbrowser.open(f"http://{host}:{port}")
            threading.Thread(target=_open, daemon=True).start()
        n = len(self.df)
        print(f"\n  URL  : http://{host}:{port}")
        print(f"  Data : {n:,} lignes · {len(self.num_features)} features · {len(self._disp_idx):,} affichés")
        print(f"  Ctrl+C pour arrêter\n")
        self._app.run(host=host, port=port, debug=debug)
