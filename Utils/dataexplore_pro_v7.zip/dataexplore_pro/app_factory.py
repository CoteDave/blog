"""app_factory.py — DataExplore Pro v7"""
from __future__ import annotations
import os, dash
from dash import dcc, html, Input, Output, ctx
import dash_bootstrap_components as dbc

DEFAULT_PAGE = "overview"
SIDEBAR_ITEMS = [
    ("overview",      "⊞", "Aperçu Global"),
    ("univariate",    "≈",  "Analyse Univariée"),
    ("scatter",       "◎", "Dispersion Bivariée"),
    ("correlation",   "⊟", "Matrice de Corrélation"),
    ("analysis3d",    "⬡", "Analyses 3D"),
    ("importance",    "≡",  "Importance des Variables"),
    ("missing",       "▦", "Valeurs Manquantes"),
    ("clusters",      "◑", "Analyse de Clusters"),
    ("pca",           "⊕", "ACP / Réduction"),
    ("corr_clusters", "⊶", "Clusters de Corrélation"),
    ("posthoc",       "⊸", "Analyses Post-Hoc"),
    ("causal",        "→", "Découverte Causale"),
    ("anova",         "∿", "ANOVA"),
    ("synthesis",     "★", "Synthèse & Conclusions"),
]
DIVIDERS_AFTER = {"scatter", "pca", "missing"}
STUBS = {"causal", "anova"}


def create_app(dep):
    assets = os.path.join(os.path.dirname(__file__), "assets")
    app = dash.Dash(__name__,
        external_stylesheets=[dbc.themes.BOOTSTRAP,
            "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"],
        suppress_callback_exceptions=True, title=dep.title, assets_folder=assets)
    app.layout = _layout(dep)
    _callbacks(app, dep)
    return app


def _layout(dep):
    n = len(dep.df); f = len(dep.num_features)
    nd = len(dep.display_df)
    mode = f"Supervisé · {dep.n_classes} cls" if dep.supervised else "Non supervisé"
    sample_note = f"  ·  {nd:,} affichés" if nd < n else ""

    return html.Div([
        dcc.Store(id="active-page", data=DEFAULT_PAGE),
        html.Header([
            html.Div([
                html.Div(html.Span("◰", style={"fontSize":"20px","color":"white","lineHeight":"1"}),
                         className="logo-icon-wrap"),
                html.Span(["Data", html.Span("Explore", style={"color":"#e07b39"}), " Pro v7"],
                          className="logo-text"),
            ], className="logo"),
            html.Div([
                html.Span(f"{n:,}", style={"fontWeight":"800","color":"#1e3a5f"}),
                html.Span(f" lignes · ", style={"color":"#bbb"}),
                html.Span(f"{f}", style={"fontWeight":"700","color":"#4472c4"}),
                html.Span(f" features · ", style={"color":"#bbb"}),
                html.Span(mode, style={"color":"#e07b39","fontWeight":"600"}),
                html.Span(sample_note, style={"color":"#27ae60","fontWeight":"600","fontSize":"11px"}),
            ], style={"marginLeft":"auto","fontSize":"12px","background":"#f0f4f8",
                      "borderRadius":"99px","padding":"5px 14px","border":"1px solid #dde2ea"}),
            html.Div(["⚡ v7 — WebGL · Cache · Float32"], className="perf-badge",
                     style={"marginLeft":"12px"}),
        ], className="app-header"),
        html.Div([
            html.Aside(_sidebar(), className="sidebar"),
            html.Main(
                dcc.Loading(html.Div(id="page-content"), type="circle",
                            color="#4472c4", style={"minHeight":"120px"}),
                className="page-content"),
        ], className="app-body"),
    ], className="app-wrapper")


def _sidebar():
    items = []
    for pid, sym, lbl in SIDEBAR_ITEMS:
        act = pid == DEFAULT_PAGE
        items.append(html.Div([
            html.Span(sym, style={"fontSize":"14px","width":"20px","textAlign":"center",
                                   "flexShrink":"0","display":"inline-block"}),
            html.Span(lbl, style={"fontSize":"12.5px","lineHeight":"1.3"}),
        ], id={"type":"sidebar-item","index":pid},
           className="sidebar-item" + (" active" if act else ""),
           n_clicks=0, title=lbl, style=_sb_style(act)))
        if pid in DIVIDERS_AFTER:
            items.append(html.Hr(className="sb-divider"))
    return items


def _sb_style(active=False):
    return {"display":"flex","alignItems":"center","gap":"9px",
            "padding":"8px 12px","borderRadius":"6px","cursor":"pointer",
            "transition":"background .18s,border-left-color .18s",
            "color":"white" if active else "rgba(255,255,255,.68)",
            "background":"rgba(68,114,196,.22)" if active else "transparent",
            "fontWeight":"700" if active else "500",
            "borderLeft":"3px solid #e07b39" if active else "3px solid transparent"}


def _callbacks(app, dep):
    # register all page callbacks
    from .pages.overview      import register_callbacks as ov
    from .pages.scatter       import register_callbacks as sc
    from .pages.univariate    import register_callbacks as un
    from .pages.correlation   import register_callbacks as co
    from .pages.analysis_3d   import register_callbacks as a3
    from .pages.importance    import register_callbacks as im
    from .pages.missing       import register_callbacks as mi
    from .pages.clusters      import register_callbacks as cl
    from .pages.pca           import register_callbacks as pc
    from .pages.corr_clusters import register_callbacks as cc
    from .pages.posthoc       import register_callbacks as ph
    from .pages.synthesis     import register_callbacks as sy
    for fn in [ov,sc,un,co,a3,im,mi,cl,pc,cc,ph,sy]:
        fn(app, dep)

    @app.callback(
        [Output("active-page","data"),
         Output({"type":"sidebar-item","index":dash.ALL},"className"),
         Output({"type":"sidebar-item","index":dash.ALL},"style")],
        Input({"type":"sidebar-item","index":dash.ALL},"n_clicks"),
        prevent_initial_call=True,
    )
    def navigate(_):
        t = ctx.triggered_id
        page = t.get("index", DEFAULT_PAGE) if isinstance(t, dict) else DEFAULT_PAGE
        return _nav_out(page)

    @app.callback(Output("page-content","children"), Input("active-page","data"))
    def render(page_id):
        return _page(dep, page_id or DEFAULT_PAGE)


def _nav_out(page_id):
    cls, sty = [], []
    for pid,_,_ in SIDEBAR_ITEMS:
        a = pid == page_id
        cls.append("sidebar-item active" if a else "sidebar-item")
        sty.append(_sb_style(a))
    return page_id, cls, sty


def _page(dep, pid):
    from .pages.overview      import layout as ov
    from .pages.scatter       import layout as sc
    from .pages.univariate    import layout as un
    from .pages.correlation   import layout as co
    from .pages.analysis_3d   import layout as a3
    from .pages.importance    import layout as im
    from .pages.missing       import layout as mi
    from .pages.clusters      import layout as cl
    from .pages.pca           import layout as pc
    from .pages.corr_clusters import layout as cc
    from .pages.posthoc       import layout as ph
    from .pages.synthesis     import layout as sy
    from .pages.stubs         import layout as st
    MAP = {"overview":ov,"scatter":sc,"univariate":un,"correlation":co,
           "analysis3d":a3,"importance":im,"missing":mi,"clusters":cl,
           "pca":pc,"corr_clusters":cc,"posthoc":ph,"synthesis":sy}
    if pid in MAP:    return MAP[pid](dep)
    if pid in STUBS:  return st(dep, pid)
    return ov(dep)
