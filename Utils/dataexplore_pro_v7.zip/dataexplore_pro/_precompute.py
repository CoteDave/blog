"""
_precompute.py — DataExplore Pro v7
═══════════════════════════════════════════════════════════════════════
Moteur de précalcul parallèle pour datasets jusqu'à 5M×300.

Stratégie :
  DISPLAY_N  = 50 000   → tous les graphiques (WebGL)
  STATS_N    = 200 000  → corrélations, stats descriptives
  IMP_N      = 100 000  → Random Forest, MI, importance
  FULL_PASS  = vecteurs numpy sur toutes les lignes pour IV/eta²/fstats

Parallélisation : ThreadPoolExecutor(4 workers)
  Thread 1 : fstats + miss + IV
  Thread 2 : corr Pearson + Spearman (vectorisé, pas .corr())
  Thread 3 : PCA (randomized SVD)
  Thread 4 : importance RF + MI + F-stat

Mémoire : float32 partout, pas de copies inutiles
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from .core import DataExplorePro

DISPLAY_N = 50_000
STATS_N   = 200_000
IMP_N     = 100_000


# ─────────────────────────────────────────────────────────────────────────────
#  Thread-safe cache
# ─────────────────────────────────────────────────────────────────────────────

class Cache:
    """
    Dictionnaire thread-safe avec events par clé.
    get(key, wait=True) bloque jusqu'à ce que la clé soit disponible.
    """
    def __init__(self):
        self._d: dict = {}
        self._lock = threading.Lock()
        self._events: dict[str, threading.Event] = {}

    def _ev(self, key: str) -> threading.Event:
        with self._lock:
            if key not in self._events:
                self._events[key] = threading.Event()
            return self._events[key]

    def set(self, key: str, value) -> None:
        with self._lock:
            self._d[key] = value
        self._ev(key).set()

    def get(self, key: str, default=None, wait: bool = True):
        if wait:
            self._ev(key).wait(timeout=120)
        with self._lock:
            return self._d.get(key, default)

    def ready(self, key: str) -> bool:
        return self._ev(key).is_set()


# ─────────────────────────────────────────────────────────────────────────────
#  Main builder
# ─────────────────────────────────────────────────────────────────────────────

def build_cache(dep: "DataExplorePro") -> Cache:
    cache = Cache()

    def _run():
        t0   = time.perf_counter()
        num  = dep.num_features
        n    = len(dep.df)
        rng  = np.random.default_rng(42)

        # ── 1. Shared data: extract float32 arrays ONCE ───────────────
        # Fills NaN with column medians computed globally (fast)
        df_num = dep.df[num]
        col_medians = df_num.median().values.astype(np.float32)
        X_full = df_num.fillna(df_num.median()).values.astype(np.float32)
        y_full = dep.y if dep.supervised else None

        # ── 2. Stratified sample indices ──────────────────────────────
        def _strat(want: int) -> np.ndarray:
            want = min(want, n)
            if want >= n:
                return np.arange(n)
            if dep.supervised and dep.is_classification and y_full is not None:
                parts = []
                classes, counts = np.unique(y_full, return_counts=True)
                for cls, cnt in zip(classes, counts):
                    ci = np.where(y_full == cls)[0]
                    k  = max(1, int(want * cnt / n))
                    parts.append(rng.choice(ci, size=min(k, cnt), replace=False))
                idx = np.concatenate(parts)
                if len(idx) < want:
                    extra = rng.choice(n, size=want - len(idx), replace=False)
                    idx = np.unique(np.concatenate([idx, extra]))
                return idx[:want]
            return rng.choice(n, size=want, replace=False)

        idx_stats = _strat(STATS_N)
        idx_imp   = _strat(IMP_N)

        X_stats = X_full[idx_stats]
        y_stats = y_full[idx_stats] if y_full is not None else None
        X_imp   = X_full[idx_imp]
        y_imp   = y_full[idx_imp]   if y_full is not None else None

        cache.set("idx_stats", idx_stats)
        cache.set("idx_imp",   idx_imp)

        # ── 3. Launch parallel workers ────────────────────────────────
        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="dep7") as pool:
            futures = {}
            futures[pool.submit(_fstats,   X_full,   num, y_full, dep)] = "fstats"
            futures[pool.submit(_miss,     X_full,   num, dep)]         = "miss"
            futures[pool.submit(_corr,     X_stats,  num)]              = "corr"
            futures[pool.submit(_pca_work, X_stats,  num)]              = "pca"
            if dep.supervised and y_imp is not None:
                futures[pool.submit(_importance, X_imp, y_imp,
                                    num, dep.is_classification)]        = "importance"
                futures[pool.submit(_iv,   X_full, y_full, num, dep)]  = "iv"
            else:
                cache.set("importance", None)
                cache.set("iv", {c: 0.0 for c in num})

            for fut in as_completed(futures):
                key = futures[fut]
                try:
                    res = fut.result()
                    if key == "corr":
                        cache.set("corr_pearson",  res[0])
                        cache.set("corr_spearman", res[1])
                    else:
                        cache.set(key, res)
                except Exception as exc:
                    print(f"[dep7] '{key}' failed: {exc}")
                    cache.set(key, None)

        elapsed = time.perf_counter() - t0
        print(f"  ✅  Précalcul terminé en {elapsed:.1f}s  ({len(num)} features × {n:,} lignes)")
        cache.set("_ready", True)

    threading.Thread(target=_run, daemon=True, name="dep7_precompute").start()
    return cache


# ─────────────────────────────────────────────────────────────────────────────
#  WORKER FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def _fstats(X: np.ndarray, cols: list, y, dep) -> dict:
    """
    Vectorised descriptive stats on the FULL dataset in one numpy pass.
    All ops are column-wise → O(N·p) with BLAS-level throughput.
    """
    n, p = X.shape

    q = np.nanpercentile(X, [1, 5, 10, 25, 50, 75, 90, 95, 99], axis=0)

    mean_v = np.nanmean(X, axis=0).astype(np.float64)
    std_v  = np.nanstd( X, axis=0, ddof=1).astype(np.float64)
    min_v  = np.nanmin( X, axis=0).astype(np.float64)
    max_v  = np.nanmax( X, axis=0).astype(np.float64)
    nan_v  = np.isnan(X).mean(axis=0)

    iqr_v   = q[5] - q[3]          # Q3 - Q1
    out_v   = np.mean((X < q[3] - 1.5*iqr_v) | (X > q[5] + 1.5*iqr_v), axis=0)

    # Skewness + excess kurtosis — corrected formulas, fully vectorized
    std_safe = np.where(std_v > 0, std_v, 1e-9)
    Xc  = X - mean_v
    skw = np.nanmean((Xc / std_safe) ** 3, axis=0)
    krt = np.nanmean((Xc / std_safe) ** 4, axis=0) - 3.0

    return dict(
        cols=cols, n=n,
        mean=mean_v, std=std_v, min=min_v, max=max_v,
        q01=q[0], q05=q[1], q10=q[2], q25=q[3],
        q50=q[4], q75=q[5], q90=q[6], q95=q[7], q99=q[8],
        iqr=iqr_v, nan_pct=nan_v, outlier_pct=out_v,
        skew=skw, kurt=krt,
    )


def _miss(X: np.ndarray, cols: list, dep) -> dict:
    """Missing-value analysis — vectorized on full data, co-occurrence on sample."""
    n, p = X.shape

    miss_pct_arr = np.isnan(X).mean(axis=0)      # (p,)
    miss_cnt_arr = np.isnan(X).sum(axis=0)        # (p,)
    total_pct    = float(miss_pct_arr.mean() * 100)
    n_complete   = int((~np.isnan(X).any(axis=1)).sum())

    # Co-occurrence on ≤50k sample (dot product)
    n_samp = min(n, 50_000)
    rng = np.random.default_rng(42)
    idx = rng.choice(n, size=n_samp, replace=False)
    M   = np.isnan(X[idx]).astype(np.float32)
    cooc = (M.T @ M) / n_samp     # proportion

    return dict(
        cols=cols,
        miss_pct=dict(zip(cols, miss_pct_arr.tolist())),
        miss_cnt=dict(zip(cols, miss_cnt_arr.tolist())),
        total_pct=total_pct,
        n_complete=n_complete,
        cooc=cooc,
    )


def _corr(X_sample: np.ndarray, cols: list) -> tuple:
    """
    Pearson + Spearman via pure numpy (no pandas .corr()).
    Fast path: rank-transform then same dot-product formula.
    """
    Xd = X_sample.astype(np.float64)

    # Drop all-NaN columns
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c, m in zip(cols, col_mask) if m]

    # Impute with column mean
    cmeans   = np.nanmean(Xd, axis=0)
    nan_locs = np.isnan(Xd)
    Xd[nan_locs] = np.take(cmeans, np.where(nan_locs)[1])

    def _pearson_mat(M: np.ndarray) -> np.ndarray:
        Mc  = M - M.mean(axis=0)
        nrm = np.linalg.norm(Mc, axis=0)
        nrm = np.where(nrm == 0, 1e-9, nrm)
        Mn  = Mc / nrm
        mat = Mn.T @ Mn
        np.fill_diagonal(mat, 1.0)
        return mat.clip(-1.0, 1.0)

    pearson  = _pearson_mat(Xd)

    # Spearman = Pearson on ranks
    from scipy.stats import rankdata
    Xr      = np.apply_along_axis(rankdata, 0, Xd).astype(np.float64)
    spearman = _pearson_mat(Xr)

    return (
        pd.DataFrame(pearson,  index=cols_valid, columns=cols_valid),
        pd.DataFrame(spearman, index=cols_valid, columns=cols_valid),
    )


def _pca_work(X_sample: np.ndarray, cols: list) -> dict:
    """Randomized PCA (sklearn) on the stats sample."""
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    Xd = X_sample.astype(np.float64)
    col_mask   = ~np.isnan(Xd).all(axis=0)
    Xd         = Xd[:, col_mask]
    cols_valid = [c for c, m in zip(cols, col_mask) if m]

    cmeans = np.nanmean(Xd, axis=0)
    nl     = np.isnan(Xd)
    Xd[nl] = np.take(cmeans, np.where(nl)[1])

    n_comp  = min(15, Xd.shape[1], Xd.shape[0])
    scaler  = StandardScaler()
    Xs      = scaler.fit_transform(Xd)

    # Cap rows for PCA itself
    if Xs.shape[0] > 150_000:
        rng = np.random.default_rng(42)
        Xs  = Xs[rng.choice(Xs.shape[0], 150_000, replace=False)]

    pca     = PCA(n_components=n_comp, random_state=42, svd_solver="randomized")
    scores  = pca.fit_transform(Xs)

    return dict(
        cols=cols_valid, scaler=scaler, pca=pca,
        scores=scores.astype(np.float32),
        loadings=pca.components_.T.astype(np.float32),
        explained=pca.explained_variance_ratio_.astype(np.float32),
        n_comp=n_comp,
    )


def _importance(X: np.ndarray, y: np.ndarray, cols: list, is_cls: bool) -> dict:
    """
    All importance metrics in one pass on the imp sample.
    Pearson/Spearman/F-stat: vectorized numpy.
    MI and RF: sklearn with n_jobs=-1.
    """
    from sklearn.feature_selection import (
        f_classif, f_regression,
        mutual_info_classif, mutual_info_regression,
    )
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.preprocessing import StandardScaler
    from scipy.stats import rankdata

    p    = X.shape[1]
    Xd   = X.astype(np.float64)
    yd   = y.astype(np.float64)

    cmeans = np.nanmean(Xd, axis=0)
    nl     = np.isnan(Xd)
    Xd[nl] = np.take(cmeans, np.where(nl)[1])

    def _norm(a):
        mx = a.max()
        return (a / mx if mx > 0 else a).clip(0, 1)

    out = {"cols": cols}

    # Pearson |r| — vectorized
    Xc  = Xd - Xd.mean(axis=0)
    yc  = yd  - yd.mean()
    sx  = Xd.std(axis=0) + 1e-9
    sy  = yd.std() + 1e-9
    out["pearson"]  = _norm(np.abs((Xc * yc[:, None]).mean(axis=0) / (sx * sy)))

    # Spearman |ρ| — rank-transform then Pearson
    Xr  = np.apply_along_axis(rankdata, 0, Xd)
    yr  = rankdata(yd)
    Xrc = Xr - Xr.mean(axis=0)
    yrc = yr - yr.mean()
    sr  = Xr.std(axis=0) + 1e-9
    syr = yr.std() + 1e-9
    out["spearman"] = _norm(np.abs((Xrc * yrc[:, None]).mean(axis=0) / (sr * syr)))

    # F-stat
    try:
        fn = f_classif if is_cls else f_regression
        yc_ = y.astype(int) if is_cls else yd
        f, _ = fn(Xd, yc_)
        out["fstat"] = _norm(np.nan_to_num(f, nan=0.0, posinf=0.0))
    except Exception:
        out["fstat"] = np.zeros(p)

    # Mutual Information
    try:
        fn_mi = mutual_info_classif if is_cls else mutual_info_regression
        yc_   = y.astype(int) if is_cls else yd
        mi    = fn_mi(Xd, yc_, random_state=42, n_neighbors=5)
        out["mi"] = _norm(np.nan_to_num(mi, nan=0.0))
    except Exception:
        out["mi"] = np.zeros(p)

    # Random Forest — fast: 60 trees, depth 8
    try:
        Xs  = StandardScaler().fit_transform(Xd)
        yc_ = y.astype(int) if is_cls else yd
        RF  = RandomForestClassifier if is_cls else RandomForestRegressor
        rf  = RF(n_estimators=60, max_depth=8, max_features="sqrt",
                 min_samples_leaf=20, n_jobs=-1, random_state=42)
        rf.fit(Xs, yc_)
        out["rf"] = _norm(rf.feature_importances_)
    except Exception:
        out["rf"] = np.zeros(p)

    # Global score = mean of available metrics
    stack = np.column_stack([out["pearson"], out["spearman"],
                              out["fstat"], out["mi"], out["rf"]])
    out["global"] = _norm(stack.mean(axis=1))

    return out


def _iv(X_full: np.ndarray, y_full: np.ndarray, cols: list, dep) -> dict:
    """
    Information Value (binary) or η² (multiclass/regression) — full pass.
    Vectorized quantile binning — fast even on 5M rows.
    """
    if not dep.is_classification or dep.n_classes != 2:
        return _eta2(X_full, y_full, cols)

    cls1      = dep.classes[-1]
    y_bin     = (y_full == cls1).astype(np.int8)
    total_ev  = max(int(y_bin.sum()), 1)
    total_nev = max(len(y_bin) - total_ev, 1)
    result    = {}
    N_BINS    = 10

    for i, col in enumerate(cols):
        x = X_full[:, i]
        ok = ~np.isnan(x)
        xv, yv = x[ok], y_bin[ok]
        if len(xv) < 20:
            result[col] = 0.0
            continue
        try:
            q = np.unique(np.percentile(xv, np.linspace(0, 100, N_BINS + 1)))
            if len(q) < 3:
                result[col] = 0.0
                continue
            b   = np.searchsorted(q[1:-1], xv, side="right")
            iv  = 0.0
            for bi in np.unique(b):
                m   = b == bi
                ev  = max(int(yv[m].sum()), 1)
                nev = max(int((1 - yv[m]).sum()), 1)
                woe = np.log((ev / total_ev) / (nev / total_nev))
                iv += (ev / total_ev - nev / total_nev) * woe
            result[col] = float(np.clip(iv, 0, 5))
        except Exception:
            result[col] = 0.0

    return result


def _eta2(X: np.ndarray, y: np.ndarray, cols: list) -> dict:
    """η² as IV proxy for multiclass/regression."""
    result = {}
    for i, col in enumerate(cols):
        x    = X[:, i]
        ok   = ~np.isnan(x)
        xv   = x[ok].astype(np.float64)
        yv   = y[ok]
        if len(xv) < 10:
            result[col] = 0.0
            continue
        try:
            gm   = xv.mean()
            sst  = ((xv - gm) ** 2).sum()
            if sst < 1e-12:
                result[col] = 0.0
                continue
            ssb  = sum(
                ((xv[yv == c].mean() - gm) ** 2) * (yv == c).sum()
                for c in np.unique(yv) if (yv == c).sum() > 0
            )
            result[col] = float(np.clip(ssb / sst, 0, 1))
        except Exception:
            result[col] = 0.0
    return result
