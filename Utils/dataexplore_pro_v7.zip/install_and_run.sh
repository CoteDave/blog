#!/bin/bash
set -e
echo "  DataExplore Pro v7 — installation..."
pip install -r requirements.txt --quiet
echo "  Installation OK. Démarrage..."
python run_example.py
