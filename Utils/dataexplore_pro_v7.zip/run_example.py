"""Exemple d'utilisation — DataExplore Pro v7"""
from sklearn.datasets import load_breast_cancer
from dataexplore_pro import DataExplorePro

print("\n  ── Exemple : Breast Cancer ──")
data = load_breast_cancer()
dep = DataExplorePro(
    data.data,
    data.target,
    feature_names=list(data.feature_names),
    target_name="Target",
    title="DataExplore Pro v7 — Breast Cancer",
)
dep.run(debug=False)
